function [r_ecf, v_ecf] = transform_eci2ecf(gast, omega, r_eci, v_eci)
% TRANSFORM_ECI2ECF 将 ECI 惯性系状态转换到 ECF 地固系。
%
% 输入:
%   gast  - 从两系重合时刻起地固系转过的角度 (rad)
%   omega - 地球自转角速率 (rad/s，与时间单位同口径)
%
% 输出:
%   r_ecf, v_ecf - 3x1 ECF 位置与相对速度

    R3_w0 = [cos(gast), sin(gast), 0;
        -sin(gast), cos(gast), 0;
        0, 0, 1];

    r_ecf = R3_w0 * r_eci;
    v_ecf = R3_w0 * v_eci - cross([0; 0; omega], r_ecf);
end
