function text = describe_status_marks(status)
% DESCRIBE_STATUS_MARKS 全程图标记的含义，写在窗口标题下面一行：实心点接受，空心点拒绝等。
%
% 点的形状（圆、菱形、三角……）区分的是哪条曲线，实心、空心才表示接受、拒绝，所以
% 这里只说实心、空心，不画具体形状。
%
% 输入:
%   status - 1 x K 元胞，各轮 'accepted' / 'rejected' / 'failed' / 'initial'
%
% 只列出现过的状态，没有任何状态时返回空字符串。

    parts = {};
    if any(strcmp(status, 'accepted'))
        parts{end + 1} = '实心点：接受';
    end
    if any(strcmp(status, 'rejected'))
        parts{end + 1} = '空心点：拒绝';
    end
    if any(strcmp(status, 'initial'))
        parts{end + 1} = '□ 初始参考';
    end
    if any(strcmp(status, 'failed'))
        parts{end + 1} = '× P3 失败';
    end
    text = strjoin(parts, '   ');
end
