function [Point, ReferenceCache, CurrentSolution] = solve_radius_scan_point( ...
        Reference, ReferenceCache, radius_scale, scan_iter, ConstData, ...
        config, retry_solver)
% SOLVE_RADIUS_SCAN_POINT 在一个半径上解 P3 并评价，返回一条扫描记录。
%
% 输入:
%   Reference      - 被扫描轮的参考点（IterationRecord.reference_before）
%   ReferenceCache - 参考处的罚函数 J 和 P2 可行性检查，首个半径时为空，由评价函数现算，
%                    之后各半径共用；结构体，字段 penalty_function、check
%   radius_scale   - 本次的半径 r（基准半径的倍数）
%   scan_iter      - 被扫描的轮号（只用来标记子问题诊断）
%   retry_solver   - 没解出时再解一次用的求解器容差，结构体，字段名与 config.solver
%                    里的相同（如 co_tol_pfeas）；空结构体表示不重解
%
% 输出:
%   Point           - 扫描记录（create_empty_radius_scan_point 的全部字段；
%                     is_actual_radius 和 repair_* 由调用方填）
%   ReferenceCache  - 更新后的缓存
%   CurrentSolution - 候选解，没解出时为空；修复检查拿它当参考
%
% 只调用现有的求解和评价函数，不改它们，也不碰 RunState。先按运行时的容差解；
% 没解出（小半径下 P3 常数值停滞，状态 UNKNOWN）而 retry_solver 非空时，换上
% retry_solver 的容差再解一次，解出的记 relaxed_tolerance = true。两次都没解出
% （含求解出错）时记下第一次的求解状态和 MOSEK 终止码，数值保持 NaN，由调用方
% 继续下一个半径。
%
% 本函数依次完成：
%   1. 建立本半径的信赖域状态，填入参考处的缓存。
%   2. 解 P3，没解出时按 retry_solver 再解一次。
%   3. 求解成功时评价预测下降、预测误差等量。
%   4. 填写扫描记录。

    Point = create_empty_radius_scan_point();
    Point.radius_scale = radius_scale;

    %% 1. 建立本半径的信赖域状态，填入参考处的缓存
    TrustRegionState = initialize_trust_region_state(config);
    TrustRegionState.scale = radius_scale;
    if ~isempty(ReferenceCache)
        TrustRegionState.reference_penalty_function = ReferenceCache.penalty_function;
        TrustRegionState.reference_check = ReferenceCache.check;
    end

    %% 2. 解 P3，没解出时按 retry_solver 再解一次
    [CurrentSolution, SubproblemDiag, Attempt] = solve_scan_subproblem( ...
        Reference, TrustRegionState, ConstData, config, scan_iter);
    Point.solver_status = Attempt.status;
    Point.response_name = Attempt.response_name;
    retry_names = fieldnames(retry_solver);
    if ~Attempt.success && ~isempty(retry_names)
        retry_config = config;
        for k = 1:numel(retry_names)
            if ~isfield(config.solver, retry_names{k})
                error('SCP:UnknownRetrySolverField', ...
                    'scan.retry_solver 里的 %s 不是 config.solver 的字段。', ...
                    retry_names{k});
            end
            retry_config.solver.(retry_names{k}) = retry_solver.(retry_names{k});
        end
        [CurrentSolution, SubproblemDiag, Attempt] = solve_scan_subproblem( ...
            Reference, TrustRegionState, ConstData, retry_config, scan_iter);
        if Attempt.success
            Point.solver_status = Attempt.status;
            Point.response_name = Attempt.response_name;
            Point.relaxed_tolerance = true;
        end
    end
    if ~Attempt.success
        CurrentSolution = [];   % 没解出的结果不当候选解用
        return;
    end
    Point.success = true;

    %% 3. 求解成功时评价预测下降、预测误差等量
    Evaluation = evaluate_reduction_ratio(CurrentSolution, SubproblemDiag, ...
        Reference, TrustRegionState, ConstData, config);
    ReferenceCache = struct('penalty_function', Evaluation.reference, ...
        'check', Evaluation.reference_check);

    %% 4. 填写扫描记录
    Point.predicted_reduction = Evaluation.predicted_reduction;
    Point.actual_reduction = Evaluation.actual_reduction;
    Point.prediction_error = Evaluation.prediction_error;
    Point.ratio = Evaluation.ratio;
    Point.ratio_available = Evaluation.ratio_available;
    Point.threshold = Evaluation.threshold;
    Point.cost_predicted = Evaluation.group.cost.predicted;
    Point.extra_predicted = Evaluation.group.extra.predicted;
    Point.penalty_predicted = Evaluation.group.penalty.predicted;
    Point.cost_error = Evaluation.group.cost.error;
    Point.extra_error = Evaluation.group.extra.error;
    Point.penalty_error = Evaluation.group.penalty.error;
    Point.cost_actual = Evaluation.group.cost.actual;
    Point.extra_actual = Evaluation.group.extra.actual;
    Point.penalty_actual = Evaluation.group.penalty.actual;
    Point.cost_p3 = Evaluation.group.cost.p3;
    Point.extra_p3 = Evaluation.group.extra.p3;
    Point.reference_penalty = Evaluation.group.penalty.reference;
    Point.candidate_penalty = Evaluation.group.penalty.candidate;
    Point.slack_penalty = Evaluation.slack_penalty;
    Point.slack_zero = Evaluation.slack_zero;
    Point.step_ratio = Evaluation.step_ratio;
    Point.step_ratio_channel = Evaluation.step_ratio_channel;
    Point.step_ratio_channels = Evaluation.step_ratio_channels;
    % 时长不受信赖域限制，记下它实际变了多少，用来判断余项里含时长的部分为什么不随半径缩小
    Point.time_change = (CurrentSolution.t_f(:)' - Reference.t_f(:)') ...
        ./ Reference.t_f(:)';
    Point.curvature_estimate = Evaluation.curvature_estimate;
    Point.remainder_split = Evaluation.remainder_split;
    Point.max_feasibility_ratio = SubproblemDiag.p2_feasibility.max_ratio;
end


function [CurrentSolution, SubproblemDiag, Attempt] = solve_scan_subproblem( ...
        Reference, TrustRegionState, ConstData, config, scan_iter)
% SOLVE_SCAN_SUBPROBLEM 解一次 P3，把是否解出、求解状态和 MOSEK 终止码记进 Attempt。
%
% 求解出错（如 MOSEK 接口报错）不往外抛，状态记成 'error: <原因>'，按没解出处理。

    CurrentSolution = [];
    SubproblemDiag = [];
    Attempt.success = false;
    Attempt.status = '';
    Attempt.response_name = '';
    try
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            Reference, TrustRegionState, ConstData, config, scan_iter);
    catch exception
        Attempt.status = ['error: ' exception.message];
        return;
    end
    Attempt.success = SubproblemDiag.success;
    Attempt.status = SubproblemDiag.solver.status;
    Attempt.response_name = SubproblemDiag.solver.mosek_report.response_name;
end
