# twosided_compare：文献 [15] 双侧共用松弛 CCD 对比实验

在保持同一 SCP 外壳的条件下（`scp_config_default()` 基础上设 `iter.tolerance = 0`、固定信赖域 `r = 1`，带总脉冲平台停止：最近 5 个被接受轮极差 $\le 0.1\text{ m/s}$ 且对 P2 可行；关闭绘图与逐轮打印；不保存 `scp_run_full.mat` 与 `scp_run_scan.mat`），运行文献 [15]（Ning et al. 2026）双侧共用松弛模式 `config.unit_norm.mode = 'twosided'` 的全部 12 个工况，并与只读复用的 5 个 `Version1-3-standard-5` 基线存档（`none`、`norm_w1e-4`、`normgap_w1e-3..5`）统一对比。数据整理见阶段报告 `../docs/算法改进_阶段1_双侧共用松弛对比实验.md`。

## 工况清单（12 个 `twosided` 工况，$s_{\max} = 2$）

| 组别 | 工况名 | $P$ | 上限轮数 | 保 $\pm 1$ 箱形界 | 速率约束 | 初始控制 |
|---|---|---|---|---|---|---|
| 主扫描 | `twosided_P1e-3`、`P1e-2`、`P3e-2`、`P1e-1`、`P1e0`、`P1e1`、`P1e2` | $10^{-3},10^{-2},3\times 10^{-2},10^{-1},1,10,100$ | 50 | 否（放宽至 $\pm 3$） | 是 | 默认单位圆 |
| 箱形界对照 | `twosidedkeep_P1e-1` | $10^{-1}$ | 50 | 是 | 是 | 默认单位圆 |
| 初值与速率专项 | `twosided_init0p3_P1e-1` | $10^{-1}$ | 10 | 否 | 是 | 模长缩为 $0.3$ |
|  | `twosided_init0_P1e-1` | $10^{-1}$ | 10 | 否 | 是 | 全零 $u=0$ |
|  | `twosided_init0_nr_P1e-1` | $10^{-1}$ | 10 | 否 | 否 | 全零 $u=0$ |
|  | `twosided_init0_P1e2` | $10^2$ | 10 | 否 | 是 | 全零 $u=0$ |

## 运行方法

MATLAB 工作目录任意；脚本按自身路径补齐 `Version1-3-ccd-twosided` 各模块与 `twosided_compare/`，运行结束自动恢复原路径（严禁同一 MATLAB 进程混加多个版本路径）：

```matlab
run('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-ccd-twosided/twosided_compare/SCP_twosided_compare.m')
```

运行前可在工作区设置的可选变量：

- `rerun_existing`：逻辑值，默认 `false`（目录已有 `case_metrics.mat` 时跳过，日志打 `[CASE] ... skipped`）。
- `case_filter`：工况名元胞数组（如 `{'twosided_P1e-1'}`），默认 `{}`（全跑 12 个工况）。
- `plateau_window`：平台判据窗口轮数 $W$，默认 `5`。
- `plateau_tolerance`：平台判据总脉冲极差上限 $\delta$（m/s），默认 `0.1`。
- `results_folder`：结果子目录名（相对 `twosided_compare/`），默认 `'results'`。
- `run_analysis`：全跑完后是否自动调用 `analyze_twosided_compare()`，默认 `true`。

若全部 `case_metrics.mat` 已存在，单独重跑汇总表与作图：

```matlab
cd('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-ccd-twosided/twosided_compare');
[Summary, Groups, Check] = analyze_twosided_compare();
close all;
```

## 文件与产物清单

- `SCP_twosided_compare.m`：对比实验批处理入口。
- `list_compare_cases.m`：12 个 `twosided` 工况规格定义（入口与分析共用）。
- `run_compare_case.m`：单工况 SCP 运行函数（含在线平台判据与 `apply_init_control_mode`）。
- `extract_compare_metrics.m`：从 `Result`、`RunInfo` 提取轻量逐轮/末轮指标到 `case_metrics.mat`（含 $s_{a1}, s_{a2}, \alpha_{\mathrm{cap}}, \sum\hat\kappa/P, \sum(-y_i)/P, \sum\|s_{\mathrm{main}}\|$ 等）。
- `analyze_twosided_compare.m`：只读加载 12 个 `twosided` 工况及 5 个 `Version1-3-standard-5` 基线，校验 `version_root` 与 `unit_norm_mode`，生成汇总与 7 张图。
- `results/<工况>/`：`scp_run_brief.txt`、`scp_run_detail.txt`、`scp_run_control.txt`、`scp_run_control.mat`、`case_metrics.mat`（无 `full_mat` 与 `scan_mat`）。
- `results/对比汇总.txt` 与 `results/对比汇总.mat`（含 `Summary`、`Groups`、`Check`、`Options`）；`results/logs/` 存放批运行与分析日志。
- `pictures/`（7 张 PNG）：`对比-各轮总脉冲.png`、`对比-相对none差值.png`、`对比-偏差扩散随P.png`、`对比-对偶门槛随P.png`、`对比-双侧松弛与紧性随轮次.png`、`对比-零初值对照.png`、`对比-末轮σ.png`。
