function plot_initial_reference( ...
        ConstData, InitialPropagation, config)
% PLOT_INITIAL_REFERENCE 绘制初始参考轨迹与全局轨迹图。
%
% 图一为五圈大气段状态连在一起随时间变化（与逐轮状态量图一致），另附各圈
% 远地点半径与脉冲；图二为 ECI 全局轨迹（地球球面 + 各圈真空段与大气段出口弧）。字号统一读取 config.plot.font_size；
% 分块不加标题，纵轴范围由 fit_axis_limits 调整。
% config.plot.save_figures 为 true 时，三扇窗分别导出为
% pictures/初始参考轨迹.png、初始远地点与脉冲.png、初始全局轨迹.png。

    font_size = config.plot.font_size;
    line_width = 1.5;
    LU = ConstData.LU;
    VU = ConstData.VU;
    TU = ConstData.TU;
    total_cir = config.scenario.total_cir;
    Passes = InitialPropagation.passes;
    RefAim = InitialPropagation.ref_aim;

    %% 图一：五圈大气段状态连在一起
    % 与逐轮状态量图相同：各圈首尾相接，圈间真空飞行不占时间轴，圈间曲线断开
    StateTiles = build_initial_state_tiles(Passes, ConstData);
    segment_times = cumsum([Passes(1:end - 1).t_f]) * TU;
    fig = figure('Name', '初始-参考轨迹', 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    draw_time_tiles(fig, StateTiles, segment_times, '初始参考轨迹', config);
    if config.plot.save_figures
        save_plot_figure(fig, 'pictures/初始参考轨迹');
    end

    %% 图一（续）：各圈远地点半径与脉冲
    fig = figure('Name', '初始-远地点与脉冲', 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    % 远地点半径：各圈出口后的远地点，末尾补目标值
    ax = subplot(1, 2, 1);
    hold(ax, 'on');
    plot(ax, 1:total_cir, [Passes.ra] * LU / 1e3, 'o-', ...
        'LineWidth', line_width, 'DisplayName', '各圈');
    plot(ax, total_cir + 1, RefAim.ra_end_aim * LU / 1e3, 'ro', ...
        'LineWidth', line_width, 'DisplayName', '目标轨道');
    fit_axis_limits(ax, NaN);
    style_plot_axes(ax, '圈数', '远地点半径 rₐ (km)', config);
    legend(ax, 'show', 'Location', 'best', 'FontSize', font_size);
    % 脉冲：横轴为脉冲序号 0~5，即 P0（第 1 圈入口前）到 P5（第 5 圈结束后入轨）
    ax = subplot(1, 2, 2);
    hold(ax, 'on');
    pulse_value = [[Passes.P], Passes(total_cir).P5] * VU;
    plot(ax, 0:total_cir, pulse_value, 'o-', 'MarkerSize', 7, 'LineWidth', 1.5);
    xlim(ax, [-0.5, total_cir + 0.5]);
    xticks(ax, 0:total_cir);
    fit_axis_limits(ax, NaN);
    style_plot_axes(ax, '脉冲序号', 'P (m/s)', config);
    sgtitle('初始参考：远地点与脉冲', 'FontSize', font_size);
    if config.plot.save_figures
        save_plot_figure(fig, 'pictures/初始远地点与脉冲');
    end

    %% 图二：全局轨迹
    fig = figure('Name', '初始-全局轨迹', 'NumberTitle', 'off');
    [X, Y, Z] = sphere;
    surf(X * 6378.137, Y * 6378.137, Z * 6378.137);
    hold on;
    grid on;
    axis equal;

    ll = length(Passes(1).data.rv_trans_in(:, 1));
    rx_in = Passes(1).data.rv_trans_in(round(ll / 2):end, 1) * LU / 1e3;
    ry_in = Passes(1).data.rv_trans_in(round(ll / 2):end, 2) * LU / 1e3;
    rz_in = Passes(1).data.rv_trans_in(round(ll / 2):end, 3) * LU / 1e3;
    rx_out = Passes(1).data.rv_trans_out(:, 1) * LU / 1e3;
    ry_out = Passes(1).data.rv_trans_out(:, 2) * LU / 1e3;
    rz_out = Passes(1).data.rv_trans_out(:, 3) * LU / 1e3;
    plot3(rx_in(1, 1), ry_in(1, 1), rz_in(1, 1), 'g', 'linewidth', 3, ...
        'Marker', 'p', 'MarkerSize', 10);
    plot3(rx_in, ry_in, rz_in);
    plot3(rx_out, ry_out, rz_out);
    for cir = 2:total_cir
        rx_in = Passes(cir).data.rv_trans_in(:, 1) * LU / 1e3;
        ry_in = Passes(cir).data.rv_trans_in(:, 2) * LU / 1e3;
        rz_in = Passes(cir).data.rv_trans_in(:, 3) * LU / 1e3;
        rx_out = Passes(cir).data.rv_trans_out(:, 1) * LU / 1e3;
        ry_out = Passes(cir).data.rv_trans_out(:, 2) * LU / 1e3;
        rz_out = Passes(cir).data.rv_trans_out(:, 3) * LU / 1e3;
        plot3(rx_in(1, 1), ry_in(1, 1), rz_in(1, 1), 'g', 'linewidth', 3, ...
            'Marker', 'p', 'MarkerSize', 10);
        plot3(rx_in, ry_in, rz_in);
        plot3(rx_out, ry_out, rz_out);
    end
    set(gca, 'FontSize', font_size);
    xlabel('惯性系 X (km)', 'FontSize', font_size);
    ylabel('惯性系 Y (km)', 'FontSize', font_size);
    zlabel('惯性系 Z (km)', 'FontSize', font_size);
    grid on;
    sgtitle('初始全局轨迹', 'FontSize', font_size);
    if config.plot.save_figures
        save_plot_figure(fig, 'pictures/初始全局轨迹');
    end
end


function Tiles = build_initial_state_tiles(Passes, ConstData)
% BUILD_INITIAL_STATE_TILES 把各圈大气段状态拼成横轴为时间的 6 个分块。
% 圈内时间为 tau * t_f * TU，圈与圈首尾相接，圈间插 NaN 让曲线断开。

    scales = [ConstData.LU / 1e3, ConstData.VU / 1e3, 180 / pi, ...
        180 / pi, 180 / pi, 180 / pi];
    names = {'r', 'V', 'γ', 'φ', 'ψ', 'θ'};
    labels = {'r (km)', 'V (km/s)', 'γ (deg)', 'φ (deg)', 'ψ (deg)', 'θ (deg)'};

    time = [];
    values = [];
    offset = 0;
    for cir = 1:numel(Passes)
        t_list = offset + Passes(cir).tau(:) * Passes(cir).t_f * ConstData.TU;
        time = [time; t_list; NaN]; %#ok<AGROW>
        values = [values; Passes(cir).x_atm(:, 1:6) .* scales; nan(1, 6)]; %#ok<AGROW>
        offset = t_list(end);
    end

    tile_list = cell(1, 6);
    for j = 1:6
        tile_list{j} = build_plot_tile(names{j}, labels{j}, ...
            build_plot_curve(names{j}, time, values(:, j), 'line'));
    end
    Tiles = [tile_list{:}];
end
