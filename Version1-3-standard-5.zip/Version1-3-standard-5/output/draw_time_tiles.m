function draw_time_tiles(fig, Tiles, segment_times, figure_title, config)
% DRAW_TIME_TILES 在图窗上画横轴为时间的分块（逐轮图用）。
%
% 输入:
%   fig           - 目标图窗，函数在其上新建分块布局
%   Tiles         - build_plot_tile 输出的结构体数组；为空时写明本轮没有可画数据
%   segment_times - 段分界时刻（s），画竖虚线；单段问题给 []
%   figure_title  - 整扇窗的总标题
%   config        - 读取 config.plot.font_size
%
% 对数纵轴的分块不再为了容差线或参考线拉大范围：下限由 compute_log_display
% 按数据定，零值画在下限处，并用一条点线标明（标题下面写一行说明）。
% 参考线（上限、边界）在线性纵轴分块里并入范围；在对数纵轴分块里只在落入
% 数据范围时才画，范围外的不画。
% 整扇窗只放一个共用图例（finish_tile_window），放在布局底部，不压曲线。

    if isempty(Tiles)
        draw_empty_notice(fig, figure_title, ...
            '本轮没有可画数据（P3 失败或没有对偶解）', config);
        return;
    end

    layout = create_tile_layout(fig, numel(Tiles));
    tile_axes = gobjects(1, numel(Tiles));
    notes = {};
    for j = 1:numel(Tiles)
        Tile = Tiles(j);
        ax = nexttile(layout);
        tile_axes(j) = ax;
        hold(ax, 'on');

        if Tile.log_scale
            LogInfo = compute_log_display(Tile.curves);
        else
            LogInfo = [];
        end
        for c = 1:numel(Tile.curves)
            draw_curve(ax, Tile.curves(c), LogInfo);
        end
        if Tile.log_scale
            set(ax, 'YScale', 'log');
            ylim(ax, [LogInfo.floor_value / 3, LogInfo.top_value * 3]);
            if LogInfo.has_clamped
                yline(ax, LogInfo.floor_value, ':', 'Color', [0.5, 0.5, 0.5], ...
                    'LineWidth', 1.2, 'HandleVisibility', 'off');
                notes{end + 1} = '点线：0 值画在下限'; %#ok<AGROW>
            end
            % 参考线只在落入数据范围时才画
            if isfinite(Tile.reference) && Tile.reference >= LogInfo.floor_value ...
                    && Tile.reference <= LogInfo.top_value
                yline(ax, Tile.reference, '--k', 'LineWidth', 1.2, ...
                    'DisplayName', Tile.reference_label);
            end
        else
            if isfinite(Tile.reference)
                yline(ax, Tile.reference, '--k', 'LineWidth', 1.2, ...
                    'DisplayName', Tile.reference_label);
            end
            fit_axis_limits(ax, Tile.reference);
        end
        if ~isempty(segment_times)
            xline(ax, segment_times, ':', 'Color', [0.5, 0.5, 0.5], ...
                'HandleVisibility', 'off');
        end

        style_plot_axes(ax, '时间 (s)', Tile.y_label, config);
    end
    finish_tile_window(layout, tile_axes, figure_title, notes, config);
end


function draw_curve(ax, Curve, LogInfo)
% DRAW_CURVE 按 style 画一条曲线；对数纵轴（LogInfo 非空）时取绝对值，零值画在下限。

    y = Curve.y;
    if ~isempty(LogInfo)
        y = abs(y);
        y(y < LogInfo.floor_value) = LogInfo.floor_value;   % NaN 不受影响
    end
    gray = [0.6, 0.6, 0.6];
    % Tag 'series' 标出曲线本身，共用图例据此跳过“只有一条曲线”的分块里的曲线
    switch Curve.style
        case 'line'
            plot(ax, Curve.x, y, '-', 'LineWidth', 1.5, ...
                'DisplayName', Curve.label, 'Tag', 'series');
        case 'bold'
            plot(ax, Curve.x, y, '-', 'LineWidth', 2.5, ...
                'DisplayName', Curve.label, 'Tag', 'series');
        case 'thin'
            plot(ax, Curve.x, y, '-', 'Color', gray, 'LineWidth', 0.8, ...
                'DisplayName', Curve.label, 'Tag', 'series');
        case 'dashed'
            plot(ax, Curve.x, y, '--', 'LineWidth', 1.5, ...
                'DisplayName', Curve.label, 'Tag', 'series');
        case 'thin_marker'
            plot(ax, Curve.x, y, '-', 'Color', gray, 'LineWidth', 0.8, ...
                'Marker', 'o', 'MarkerSize', 6, ...
                'DisplayName', Curve.label, 'Tag', 'series');
        case 'dashed_marker'
            plot(ax, Curve.x, y, '--', 'LineWidth', 1.5, ...
                'Marker', 'x', 'MarkerSize', 8, ...
                'DisplayName', Curve.label, 'Tag', 'series');
        case 'line_marker'
            plot(ax, Curve.x, y, '-', 'LineWidth', 1.5, ...
                'Marker', 'o', 'MarkerSize', 6, ...
                'DisplayName', Curve.label, 'Tag', 'series');
        case 'marker'
            plot(ax, Curve.x, y, 'o', 'LineStyle', 'none', ...
                'MarkerSize', 7, 'LineWidth', 1.5, ...
                'DisplayName', Curve.label, 'Tag', 'series');
        case 'marker_gray'
            plot(ax, Curve.x, y, 'o', 'LineStyle', 'none', 'Color', gray, ...
                'MarkerSize', 6, 'LineWidth', 1.2, 'DisplayName', Curve.label, ...
                'Tag', 'series');
        case 'marker_cross'
            plot(ax, Curve.x, y, 'x', 'LineStyle', 'none', ...
                'MarkerSize', 8, 'LineWidth', 1.5, 'DisplayName', Curve.label, ...
                'Tag', 'series');
    end
end
