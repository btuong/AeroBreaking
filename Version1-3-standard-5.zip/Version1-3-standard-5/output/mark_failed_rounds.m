function mark_failed_rounds(ax, iters, status)
% MARK_FAILED_ROUNDS 在当前纵轴下沿给 P3 失败的轮画红叉，并固定纵轴范围。
%
% 要在曲线和纵轴范围都画完之后调用: 红叉的位置取当前 ylim 的下沿，调用后
% ylim 固定不再自动变化。没有失败轮时什么也不做。红叉不进图例，含义由窗口标题下面
% 一行写明（describe_status_marks）。

    iters = iters(:)';
    is_failed = strcmp(status, 'failed');
    if ~any(is_failed)
        return;
    end
    y_limits = ylim(ax);
    ylim(ax, y_limits);
    plot(ax, iters(is_failed), repmat(y_limits(1), 1, nnz(is_failed)), ...
        'rx', 'MarkerSize', 10, 'LineWidth', 2, 'HandleVisibility', 'off');
end
