function Evaluation = evaluate_reduction_ratio( ...
        CurrentSolution, SubproblemDiag, CurrentReference, ...
        TrustRegionState, ConstData, config)
% EVALUATE_REDUCTION_RATIO 算本轮候选解的真实下降、预测下降、比值 ρ，以及逐项账、门槛、K 估计和驻点度量的上界。
%
% 数学形式:
%   ΔJ = J(z̄) − J(z*)，ΔL = J(z̄) − L(z*)，ρ = ΔJ / ΔL = 1 − D/ΔL
%   z̄ 为本轮参考，z* 为本轮候选解；J 为罚函数（evaluate_penalty_function），
%   L(z*) 为 P3 在候选解处的目标值。线性化在参考点上精确，L(z̄) = J(z̄)，
%   所以预测下降直接用 J(z̄)。ΔL ≤ min_predicted_reduction 或任一值非有限时
%   不算 ρ。
%   逐项账：J = Σ_m J_m，L = Σ_m L_m，一项的真实下降 ΔJ_m = J_m(z̄) − J_m(z*)，
%   预测下降 ΔL_m = J_m(z̄) − L_m(z*)，预测误差 D_m = ΔL_m − ΔJ_m = J_m(z*) − L_m(z*)。
%   凸项（kind 为 cost_convex 或 extra_convex）的 D_m 应为 0。
%   目标分三部分 J = C + Γ + Θ，L = C̃ + Γ̃ + Θ̃：C 为性能指标（只含总脉冲），
%   Γ 为附加项（无损凸化引入的控制正则项），Θ 为罚项。各项按类别分成三组:
%       ΔL = 性能指标的预测下降 + 附加项的预测下降 + 罚项的预测下降
%       D  = 性能指标的预测误差 + 附加项的预测误差 + 罚项的预测误差
%       ΔJ = 性能指标的真实下降 + 附加项的真实下降 + 罚项的真实下降
%   三部分之和 ΔL ≥ 0，单独一部分可以为负。
%   其余各量（都只报告，不参与接受、半径更新和停止）:
%       prediction_error   D = ΔL − ΔJ
%       threshold          门槛 (1−ρ1)ΔL，D 不超过它时 ρ ≥ ρ1
%       error_to_threshold D / 门槛
%       step_norm          ‖d‖，以基准半径为单位 = step_ratio·r
%       curvature_estimate K 估计 D / ‖d‖²
%       slack_zero         松弛罚项（slack_penalty）不超过参考处罚项的
%                          slack_zero_ratio 倍（绝对下限 1e-12）
%       stationarity_bound  驻点度量的上界 (r_max/r)·max(ΔL, 0)
%       same_reference     同一参考点上一次求解的对比（见 TrustRegionState.previous_attempt）:
%                          D 与 ΔL 随半径变化的阶 p = log(|X|/|X_上次|) / log(r/r_上次)；
%                          p 接近 2 是二次项为主，接近 1 是一次项为主，接近 0 是与半径
%                          无关的项为主；ΔL 的阶在 0 和 1 之间（ΔL(r) 是凹的）；
%                          动力学余项的四部分（状态×状态、状态×控制、状态×时长、
%                          控制×时长）各自也按这个式子算阶，按理论分别接近 2、1、1、0；
%                          下降比的阶对 1−ρ = D/ΔL 算（ρ 本身趋于 1，对它取对数比
%                          没有意义），= D 的阶 − ΔL 的阶
%       remainder_split    动力学余项按阶拆分（evaluate_remainder_split）
%
% 代码形式:
%   L(z*) = SubproblemDiag.objective_terms.total（上图变量在最优解处取紧，
%   等于 P3 的目标中各绝对值项之和），各项按名称与 J 的同名项相减。
%   类别 cost_convex、cost_nonconvex 归性能指标（group.cost），extra_convex、
%   extra_nonconvex 归附加项（group.extra），equality_penalty、inequality_penalty
%   归罚项（group.penalty）；不属于任何一类的分项报错。
%   三部分的预测下降 = group.cost/extra/penalty.predicted，
%   三部分的预测误差 = group.cost/extra/penalty.error，
%   参考处的罚项 = group.penalty.reference，候选解处的罚项 = group.penalty.candidate，
%   松弛罚项 = slack_penalty。
%   J 用到的量（终端违反量、脉冲、衔接违反量、动力学违反量）取自 P2 可行性检查的同一份报告：
%   候选解直接读 SubproblemDiag.p2_feasibility，参考优先取
%   TrustRegionState.reference_check 和 reference_penalty_function（上一轮已算过），
%   没有缓存时用同一个 check_p2_feasibility 现算，两处不各写一份求值。
%   子项（动力学违反量按状态通道、按圈，衔接违反量按衔接点）的 J 侧取 P2 可行性检查里的
%   逐区间、逐点值乘罚权后求和，L 侧取候选解里的松弛乘罚权后求和；
%   DynamicsReport.values 与 JunctionReport.values 是归一化值，和 sum_abs 同口径。
%   步长比例的通道为 r, V, γ, φ, ψ（全部节点）和 P0~P5。
%
% 本函数依次完成：
%   1. 取参考处的罚函数和 P2 可行性检查（有缓存就用缓存，否则先算）。
%   2. 算候选解处的罚函数。
%   3. 逐项算真实下降、预测下降和预测误差，并按三组汇总。
%   4. 展开子项：动力学违反量按通道和圈，衔接违反量按衔接点。
%   5. 算比值 ρ，补上每项的预测误差占比和凸项一致性标记。
%   6. 算候选解步长占本轮半径的比例。
%   7. 把动力学余项按阶拆开。
%   8. 算门槛、K 估计、驻点度量的上界，和同一参考点上一次求解作对比。

    Evaluation = create_empty_ratio_evaluation('evaluated');
    Evaluation.evaluated = true;

    %% 1. 取参考处的罚函数和 P2 可行性检查（有缓存就用缓存，否则先算）
    if isempty(TrustRegionState.reference_penalty_function) ...
            || isempty(TrustRegionState.reference_check)
        ReferenceCheck = check_p2_feasibility( ...
            CurrentReference, ConstData, config);
        Evaluation.reference = evaluate_penalty_function( ...
            CurrentReference, ReferenceCheck, ConstData, config);
        Evaluation.reference_check = ReferenceCheck;
    else
        Evaluation.reference = TrustRegionState.reference_penalty_function;
        Evaluation.reference_check = TrustRegionState.reference_check;
        Evaluation.reference_from_cache = true;
    end

    %% 2. 算候选解处的罚函数
    Evaluation.candidate = evaluate_penalty_function( ...
        CurrentSolution, SubproblemDiag.p2_feasibility, ConstData, config);

    %% 3. 逐项算真实下降、预测下降和预测误差，并按三组汇总
    P3Terms = SubproblemDiag.objective_terms.terms;
    if ~isequal({P3Terms.name}, {Evaluation.reference.terms.name}) ...
            || ~isequal({P3Terms.kind}, {Evaluation.reference.terms.kind})
        error('SCP:PenaltyTermMismatch', ...
            '罚函数与 P3 的目标的分项名称、类别或顺序不一致。');
    end
    reference_values = [Evaluation.reference.terms.value];
    candidate_values = [Evaluation.candidate.terms.value];
    p3_values = [P3Terms.value];
    Evaluation.term_names = {P3Terms.name};
    % 分项标签取 J 一侧的名字（罚项），分项表描述的是 J 的各项
    Evaluation.term_labels = {Evaluation.reference.terms.label};
    Evaluation.term_kinds = {P3Terms.kind};
    Evaluation.term_reference = reference_values;
    Evaluation.term_candidate = candidate_values;
    Evaluation.term_p3 = p3_values;
    Evaluation.term_actual_reduction = reference_values - candidate_values;
    Evaluation.term_predicted_reduction = reference_values - p3_values;
    Evaluation.term_prediction_error = candidate_values - p3_values;
    Evaluation.p3_value = SubproblemDiag.objective_terms.total;
    Evaluation.actual_reduction = ...
        Evaluation.reference.total - Evaluation.candidate.total;
    Evaluation.predicted_reduction = ...
        Evaluation.reference.total - Evaluation.p3_value;

    % 三组：性能指标、附加项、罚项
    is_cost = ismember(Evaluation.term_kinds, {'cost_convex', 'cost_nonconvex'});
    is_extra = ismember(Evaluation.term_kinds, {'extra_convex', 'extra_nonconvex'});
    is_penalty = ismember(Evaluation.term_kinds, ...
        {'equality_penalty', 'inequality_penalty'});
    unknown = ~(is_cost | is_extra | is_penalty);
    if any(unknown)
        error('SCP:UnknownTermKind', '分项 %s 的类别不属于性能指标、附加项或罚项。', ...
            strjoin(Evaluation.term_names(unknown), '、'));
    end
    Evaluation.group.cost = build_group_ledger(is_cost, ...
        reference_values, candidate_values, p3_values);
    Evaluation.group.extra = build_group_ledger(is_extra, ...
        reference_values, candidate_values, p3_values);
    Evaluation.group.penalty = build_group_ledger(is_penalty, ...
        reference_values, candidate_values, p3_values);
    % P3 在候选解处还剩的松弛罚项：只取罚项各项的 L_m 之和
    Evaluation.slack_penalty = sum(p3_values(is_penalty));

    %% 4. 展开子项：动力学违反量按通道和圈，衔接违反量按衔接点
    Evaluation.subterms = build_penalty_subterms( ...
        Evaluation.reference_check, SubproblemDiag.p2_feasibility, ...
        CurrentSolution, config.objective);

    %% 5. 算比值 ρ，补上每项的预测误差占比和凸项一致性标记
    reductions = [Evaluation.actual_reduction, Evaluation.predicted_reduction];
    if any(~isfinite(reductions))
        Evaluation.reason = 'nonfinite_penalty_function';
    elseif Evaluation.predicted_reduction ...
            <= config.trust_region.min_predicted_reduction
        % 预测下降几乎为零（或为负），比值没有意义
        Evaluation.reason = 'small_predicted_reduction';
    else
        Evaluation.ratio = ...
            Evaluation.actual_reduction / Evaluation.predicted_reduction;
        Evaluation.ratio_available = true;
    end
    if Evaluation.ratio_available
        Evaluation.term_error_share = ...
            Evaluation.term_prediction_error / Evaluation.predicted_reduction;
    else
        Evaluation.term_error_share = nan(size(Evaluation.term_prediction_error));
    end
    % 凸项的 J 和 L 算法一致时 D_m 为 0；max 忽略 NaN，ΔL 不可用时门槛取 1e-9
    error_limit = 1e-9 * max(abs(Evaluation.predicted_reduction), 1);
    is_convex = ismember(Evaluation.term_kinds, {'cost_convex', 'extra_convex'});
    flagged = is_convex & abs(Evaluation.term_prediction_error) > error_limit;
    Evaluation.convex_error_flag = any(flagged);
    Evaluation.convex_error_names = Evaluation.term_names(flagged);

    %% 6. 算候选解步长占本轮半径的比例
    Evaluation = fill_step_ratios(Evaluation, CurrentSolution, ...
        CurrentReference, TrustRegionState, ConstData, config);

    %% 7. 把动力学余项按阶拆开
    Evaluation.remainder_split = evaluate_remainder_split( ...
        CurrentSolution, CurrentReference, SubproblemDiag.p2_feasibility, ...
        ConstData, config);

    %% 8. 算门槛、K 估计、驻点度量的上界，和同一参考点上一次求解作对比
    % 和上一次求解对比时要用本次的余项四部分，所以放在余项拆分之后
    Evaluation = fill_radius_and_stationarity(Evaluation, TrustRegionState, ...
        config);
end


function Ledger = build_group_ledger(mask, reference_values, candidate_values, ...
        p3_values)
% BUILD_GROUP_LEDGER 把 mask 选中的各项汇总成一组小计。
%
% predicted 为这一组的预测下降 ΔL 小计，actual 为真实下降 ΔJ 小计，
% error 为预测误差 D 小计（= predicted − actual）。

    Ledger.reference = sum(reference_values(mask));
    Ledger.candidate = sum(candidate_values(mask));
    Ledger.p3 = sum(p3_values(mask));
    Ledger.predicted = Ledger.reference - Ledger.p3;
    Ledger.actual = Ledger.reference - Ledger.candidate;
    Ledger.error = Ledger.candidate - Ledger.p3;
end


function Subterms = build_penalty_subterms(ReferenceCheck, CandidateCheck, ...
        CurrentSolution, weights)
% BUILD_PENALTY_SUBTERMS 把动力学罚项和衔接罚项两项按位置拆开，给出三处的加权值。
%
% 数学形式:
%   动力学罚项 = w_dyn·Σ_(区间,通道)|g_dyn|，衔接罚项 = w_poi·Σ_(点,通道)|g_poi|。
%   子项是同一个和按通道、按圈（动力学）或按衔接点（衔接）分开的部分，所以
%   同一项的全部子项之和等于该项的值。
%
% 代码形式:
%   参考处和候选解处取 P2 可行性检查报告里的带符号值（DynamicsReport.values 为
%   区间数 x 5，JunctionReport.values 为 5 x 5，归一化单位）取绝对值；
%   P3 处取候选解的松弛变量（dyn_slack 区间数 x 5，point_slack 5 x 5，
%   上图取紧时 |松弛| 就是目标里的绝对值项）。区间的圈号取自 DynamicsReport.interval_cir，
%   区间顺序与 dyn_slack 的行一致（按圈、按区间）。

    channel_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    subterm_list = {};

    %% 动力学违反量：按状态通道
    w_dyn = weights.weight_dyn_slack;
    reference_dynamics = abs(ReferenceCheck.dynamics_report.values);
    candidate_dynamics = abs(CandidateCheck.dynamics_report.values);
    slack_dynamics = abs(CurrentSolution.dyn_slack);
    for s = 1:numel(channel_names)
        subterm_list{end + 1} = create_subterm('dyn_slack', ...
            ['动力学违反量 ' channel_names{s}], ...
            w_dyn * sum(reference_dynamics(:, s)), ...
            w_dyn * sum(candidate_dynamics(:, s)), ...
            w_dyn * sum(slack_dynamics(:, s))); %#ok<AGROW>
    end

    %% 动力学违反量：按圈
    interval_cir = CandidateCheck.dynamics_report.interval_cir;
    for cir = 1:max(interval_cir)
        in_cir = interval_cir == cir;
        subterm_list{end + 1} = create_subterm('dyn_slack', ...
            sprintf('动力学违反量 圈%d', cir), ...
            w_dyn * sum(reference_dynamics(in_cir, :), 'all'), ...
            w_dyn * sum(candidate_dynamics(in_cir, :), 'all'), ...
            w_dyn * sum(slack_dynamics(in_cir, :), 'all')); %#ok<AGROW>
    end

    %% 衔接违反量：按衔接点（第 1 行为初始点，其余为圈间内点）
    w_poi = weights.weight_point_slack;
    reference_junction = abs(ReferenceCheck.junction_report.values);
    candidate_junction = abs(CandidateCheck.junction_report.values);
    slack_junction = abs(CurrentSolution.point_slack);
    for point = 1:size(candidate_junction, 1)
        if point == 1
            label = '衔接违反量 初始点';
        else
            label = sprintf('衔接违反量 内点%d', point - 1);
        end
        subterm_list{end + 1} = create_subterm('point_slack', label, ...
            w_poi * sum(reference_junction(point, :)), ...
            w_poi * sum(candidate_junction(point, :)), ...
            w_poi * sum(slack_junction(point, :))); %#ok<AGROW>
    end

    Subterms = [subterm_list{:}];
end


function Subterm = create_subterm(term_name, label, reference, candidate, p3)
% CREATE_SUBTERM 创建一个子项：所属分项名、显示名和参考、候选解、P3 三处的加权值。

    Subterm = struct('term_name', term_name, 'label', label, ...
        'reference', reference, 'candidate', candidate, 'p3', p3);
end


function Evaluation = fill_step_ratios(Evaluation, CurrentSolution, ...
        CurrentReference, TrustRegionState, ConstData, config)
% FILL_STEP_RATIOS 算候选解相对参考的步长占本轮半径的比例，各通道、各节点都存。
%
% 通道 r, V, gamma, phi, psi 取全部节点的最大值，P 取 P0~P5 的最大值（半径按
% m/s 配置，步长先乘 VU）。最大的一个通道记为 step_ratio，达到
% boundary_tolerance 记为贴边界。

    radius = scale_trust_region_radius(TrustRegionState);
    radius_vector = [radius.r, radius.V, radius.gamma, radius.phi, radius.psi];
    step = abs(CurrentSolution.state - CurrentReference.state);
    Evaluation.step_ratio_node = step ./ radius_vector;
    pulse_step = abs(CurrentSolution.control.P(:) ...
        - CurrentReference.control.P(:)) * ConstData.VU;
    Evaluation.step_ratio_pulse = pulse_step / radius.P;

    channel_names = {'r', 'V', 'gamma', 'phi', 'psi', 'P'};
    channel_ratio = [max(Evaluation.step_ratio_node, [], 1), ...
        max(Evaluation.step_ratio_pulse)];
    Evaluation.step_ratio_channels = channel_ratio;
    [Evaluation.step_ratio, worst] = max(channel_ratio);
    Evaluation.step_ratio_channel = channel_names{worst};
    Evaluation.on_boundary = ...
        Evaluation.step_ratio >= config.trust_region.boundary_tolerance;
end


function Evaluation = fill_radius_and_stationarity(Evaluation, ...
        TrustRegionState, config)
% FILL_RADIUS_AND_STATIONARITY 算 ρ 所在行、预测误差、门槛、K 估计、松弛是否为零、驻点度量的上界，并和同一参考点上一次求解对比（只报告）。
%
% ρ 所在行按经典表：ρ < ρ0 为 'below_rho0'，[ρ0, ρ1) 为 'rho0_rho1'，
% [ρ1, ρ2) 为 'rho1_rho2'，≥ ρ2 为 'above_rho2'；ρ 不可用时为 'unavailable'。
% ρ0、ρ1、ρ2 即 accept_ratio、shrink_ratio、expand_ratio。
% ΔL 比 -min_predicted_reduction 还小时（P3 预测变差），驻点度量的上界不可用；
% 否则 ΔL 取 max(ΔL, 0)。门槛和 D/门槛只在 ΔL 有限时算；max 会把 NaN 当缺失值
% 丢掉，所以非有限值单独保持 NaN。

    TrustConfig = config.trust_region;
    predicted = Evaluation.predicted_reduction;
    Evaluation.radius_scale = TrustRegionState.scale;
    Evaluation.radius_scale_max = TrustConfig.max_scale;
    Evaluation.stationarity_tolerance = config.iter.stationarity_tolerance;

    %% ρ 所在行
    if ~Evaluation.ratio_available
        Evaluation.ratio_band = 'unavailable';
    elseif Evaluation.ratio < TrustConfig.accept_ratio
        Evaluation.ratio_band = 'below_rho0';
    elseif Evaluation.ratio < TrustConfig.shrink_ratio
        Evaluation.ratio_band = 'rho0_rho1';
    elseif Evaluation.ratio < TrustConfig.expand_ratio
        Evaluation.ratio_band = 'rho1_rho2';
    else
        Evaluation.ratio_band = 'above_rho2';
    end
    Evaluation.ratio_held = Evaluation.ratio_available ...
        && Evaluation.ratio >= TrustConfig.shrink_ratio;

    %% 松弛罚项是否为零
    % 参考处罚项接近 0 时，用绝对下限 1e-12 判断候选解处松弛罚项是否为 0
    zero_limit = max(TrustConfig.slack_zero_ratio ...
        * max(Evaluation.group.penalty.reference, 0), 1e-12);
    Evaluation.slack_zero = Evaluation.slack_penalty <= zero_limit;

    %% 预测误差、门槛和 K 估计
    Evaluation.prediction_error = ...
        Evaluation.predicted_reduction - Evaluation.actual_reduction;
    if isfinite(predicted)
        Evaluation.threshold = (1 - TrustConfig.shrink_ratio) * max(predicted, 0);
    end
    if Evaluation.ratio_available
        Evaluation.error_to_threshold = ...
            Evaluation.prediction_error / Evaluation.threshold;
    end
    Evaluation.step_norm = Evaluation.step_ratio * Evaluation.radius_scale;
    if Evaluation.step_norm > 0
        Evaluation.curvature_estimate = ...
            Evaluation.prediction_error / Evaluation.step_norm^2;
    end

    %% 驻点度量的上界
    if isfinite(predicted) && predicted >= -TrustConfig.min_predicted_reduction
        Evaluation.stationarity_bound = ...
            Evaluation.radius_scale_max / Evaluation.radius_scale ...
            * max(predicted, 0);
    end

    %% 同一参考点上一次求解的对比
    Evaluation.same_reference = compare_with_previous_attempt( ...
        Evaluation, TrustRegionState.previous_attempt);
end


function SameReference = compare_with_previous_attempt(Evaluation, Previous)
% COMPARE_WITH_PREVIOUS_ATTEMPT 和同一参考点上一次求解比较 D、ΔL 和动力学余项各部分随半径变化的阶。
%
% 数学形式:
%   p = log(|X| / |X_上次|) / log(r / r_上次)，X 取 D、ΔL、1−ρ = D/ΔL，或动力学
%   余项的四部分（状态×状态、状态×控制、状态×时长、控制×时长，加权后）。
%   1−ρ 只在两次的 ΔL 都为正时算。
%   两次 r 相同、X 为 0 或非有限时 p 记 NaN。
%
% 代码形式:
%   Previous 为空表示上一次求解不在同一参考点上（被接受后置空），available 为假。

    SameReference = create_empty_same_reference();
    if isempty(Previous)
        return;
    end
    SameReference.available = true;
    SameReference.iter = Previous.iter;
    SameReference.radius_scale = Previous.radius_scale;
    SameReference.predicted_reduction = Previous.predicted_reduction;
    SameReference.prediction_error = Previous.prediction_error;
    SameReference.error_order = compute_radius_order( ...
        Evaluation.prediction_error, Previous.prediction_error, ...
        Evaluation.radius_scale, Previous.radius_scale);
    SameReference.reduction_order = compute_radius_order( ...
        Evaluation.predicted_reduction, Previous.predicted_reduction, ...
        Evaluation.radius_scale, Previous.radius_scale);
    SameReference.ratio_gap_order = compute_radius_order( ...
        compute_ratio_gap(Evaluation.prediction_error, Evaluation.predicted_reduction), ...
        compute_ratio_gap(Previous.prediction_error, Previous.predicted_reduction), ...
        Evaluation.radius_scale, Previous.radius_scale);
    % 余项四部分逐个算阶；任一次没拆分时 weighted 为 NaN，阶也是 NaN
    SameReference.remainder_weighted = Previous.remainder_weighted;
    current_weighted = Evaluation.remainder_split.weighted;
    for p = 1:numel(current_weighted)
        SameReference.remainder_orders(p) = compute_radius_order( ...
            current_weighted(p), Previous.remainder_weighted(p), ...
            Evaluation.radius_scale, Previous.radius_scale);
    end
end


function gap = compute_ratio_gap(prediction_error, predicted_reduction)
% COMPUTE_RATIO_GAP 1−ρ = D/ΔL；ΔL 不为正或非有限时为 NaN。

    gap = NaN;
    if isfinite(predicted_reduction) && predicted_reduction > 0
        gap = prediction_error / predicted_reduction;
    end
end


function order = compute_radius_order(value, value_before, radius, radius_before)
% COMPUTE_RADIUS_ORDER 两次求解之间某个量随半径变化的阶；无法定义时为 NaN。

    order = NaN;
    usable = isfinite(value) && isfinite(value_before) ...
        && value ~= 0 && value_before ~= 0 && radius ~= radius_before;
    if usable
        order = log(abs(value) / abs(value_before)) / log(radius / radius_before);
    end
end
