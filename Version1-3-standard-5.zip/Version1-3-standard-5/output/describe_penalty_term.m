function short_name = describe_penalty_term(term_name)
% DESCRIBE_PENALTY_TERM 罚函数分项的短名，终端表格和绘图共用。
%
% term_name 是 evaluate_penalty_function 与 compute_objective_terms 共同的分项名
% （terminal_inclination、terminal_apoapsis、impulse、point_slack、dyn_slack、
% control_reg、unit_norm_penalty）。短名后面由调用处拼“罚项”“违反量”或
% “松弛罚项”；不认识的分项名原样返回。

    switch term_name
        case 'terminal_inclination'
            short_name = '终端倾角';
        case 'terminal_apoapsis'
            short_name = '终端远地点';
        case 'impulse'
            short_name = '脉冲项';
        case 'point_slack'
            short_name = '衔接';
        case 'dyn_slack'
            short_name = '动力学';
        case 'control_reg'
            short_name = '控制正则';
        case 'unit_norm_penalty'
            short_name = '单位范数';
        otherwise
            short_name = term_name;
    end
end
