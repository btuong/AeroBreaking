function MechanismReport = evaluate_control_tightness_mechanisms( ...
        SolverResult, LinearConstraints, ConicConstraints, ...
        CurrentReference, Split, config, u_index)
% EVALUATE_CONTROL_TIGHTNESS_MECHANISMS 计算控制圆盘的余量、抵消和弦上平坦指标。
%
% 数学形式:
%   控制圆盘锥 x_i = (1,u_i)，对偶锥变量 y_i^d 的 u 分量满足
%   y_i = s_reg,i + s_main,i，m_i = ‖y_i‖，μ_i = <x_i,y_i^d>。
%   原始–对偶可行点满足 1 − ‖u_i‖ ≤ μ_i/m_i；m_i = 0 时上界无定义。
%   参考单位方向 ē_i = ū_i/‖ū_i‖ 给出径向需求
%   ρ_main,i = −ē_i^T s_main,i，ρ_reg,i = −ē_i^T s_reg,i。
%   抵消比例 = min(1,m_i/max(‖s_main,i‖,‖s_reg,i‖))，接近零表示两项近乎抵消。
%   活跃速率行的零空间是局部弦的切空间 T_i；‖s_reg,i‖>0 时，
%   弦向平坦比例 = ‖P_T_i s_reg,i‖/‖s_reg,i‖。没有活跃速率行时
%   chord_active = false，其余弦量为 NaN；这只判局部几何，不单独证明因果。
%
% 代码形式:
%   控制锥按 cones.index 对应节点，返回量均为 N x 1，弦切向量为 N x 2。
%   Split 采用 compute_control_dual_split 的符号约定，s_total 即 y_i。
%   对偶不可用时，余量、互补积和抵消量为 NaN；弦活动仍由 primal 计算。
%   只报告，不修改解、参考或任何算法决策。

    num_nodes = CurrentReference.N;
    MechanismReport = create_empty_mechanism_report(num_nodes);
    MechanismReport = compute_margin_and_cancellation( ...
        MechanismReport, Split);
    MechanismReport = compute_cone_complementarity( ...
        MechanismReport, SolverResult, ConicConstraints, num_nodes, Split.available);
    MechanismReport = compute_radial_components( ...
        MechanismReport, CurrentReference, Split);
    MechanismReport = compute_chord_geometry( ...
        MechanismReport, SolverResult.primal, LinearConstraints, ...
        CurrentReference, Split.s_reg, config.validation, u_index);
end


function Report = create_empty_mechanism_report(num_nodes)
% CREATE_EMPTY_MECHANISM_REPORT 创建逐节点紧性机理指标的空结构。

    scalar_fields = {'margin', 'complementarity', 'complementarity_bound', ...
        'radial_main', 'radial_regularizer', 'cancellation_cosine', ...
        'cancellation_strength', 'chord_rank', 'chord_reg_component', ...
        'chord_flatness'};
    for k = 1:numel(scalar_fields)
        Report.(scalar_fields{k}) = nan(num_nodes, 1);
    end
    Report.cancellation_candidate = false(num_nodes, 1);
    Report.chord_active = false(num_nodes, 1);
    Report.chord_flat = false(num_nodes, 1);
    Report.chord_tangent = nan(num_nodes, 2);
end


function Report = compute_margin_and_cancellation(Report, Split)
% COMPUTE_MARGIN_AND_CANCELLATION 计算合力余量与正则/主需求的抵消程度。

    if ~Split.available
        return;
    end
    main_norm = vecnorm(Split.s_main, 2, 2);
    reg_norm = vecnorm(Split.s_reg, 2, 2);
    denominator = max(main_norm, reg_norm);
    Report.margin = vecnorm(Split.s_total, 2, 2);
    valid = denominator > 0;
    Report.cancellation_strength(valid) = min(1, ...
        Report.margin(valid) ./ denominator(valid));
    nonzero = main_norm > 0 & reg_norm > 0;
    Report.cancellation_cosine(nonzero) = sum( ...
        Split.s_main(nonzero, :) .* Split.s_reg(nonzero, :), 2) ...
        ./ (main_norm(nonzero) .* reg_norm(nonzero));
    Report.cancellation_candidate = nonzero ...
        & Report.cancellation_cosine < 0 ...
        & Report.cancellation_strength < 1;
end


function Report = compute_cone_complementarity( ...
        Report, SolverResult, ConicConstraints, num_nodes, dual_available)
% COMPUTE_CONE_COMPLEMENTARITY 由原始锥值和 doty 计算逐节点互补积及上界。

    cone_values = ConicConstraints.mapping * SolverResult.primal(:) ...
        + ConicConstraints.offset;
    if ~dual_available || numel(SolverResult.dual.doty) ~= numel(cone_values)
        return;
    end
    for k = 1:numel(ConicConstraints.cones)
        Cone = ConicConstraints.cones(k);
        if ~strcmp(Cone.name, 'control_disk') || Cone.index > num_nodes
            continue;
        end
        i = Cone.index;
        dual_value = SolverResult.dual.doty(Cone.rows);
        if numel(dual_value) ~= Cone.dimension
            continue;
        end
        Report.complementarity(i) = cone_values(Cone.rows).' * dual_value;
        if Report.margin(i) > 0
            Report.complementarity_bound(i) = ...
                Report.complementarity(i) / Report.margin(i);
        end
    end
end


function Report = compute_radial_components(Report, CurrentReference, Split)
% COMPUTE_RADIAL_COMPONENTS 把主需求和正则项投影到参考控制径向。

    reference_u = [CurrentReference.control.u1(:), ...
        CurrentReference.control.u2(:)];
    reference_norm = vecnorm(reference_u, 2, 2);
    direction = reference_u ./ reference_norm;
    degenerate = ~isfinite(reference_norm) | reference_norm < 1e-6;
    direction(degenerate, :) = repmat([sqrt(2) / 2, sqrt(2) / 2], ...
        sum(degenerate), 1);
    Report.radial_main = -sum(direction .* Split.s_main, 2);
    Report.radial_regularizer = -sum(direction .* Split.s_reg, 2);
end


function Report = compute_chord_geometry( ...
        Report, primal, LinearConstraints, CurrentReference, s_reg, validation, u_index)
% COMPUTE_CHORD_GEOMETRY 求活跃速率行的局部零空间及正则项在其中的分量。

    rows = LinearConstraints.row_groups.control_continuity;
    if isempty(rows)
        return;
    end
    row_value = LinearConstraints.matrix(rows, :) * primal(:);
    lower_gap = row_value - LinearConstraints.lower(rows);
    upper_gap = LinearConstraints.upper(rows) - row_value;
    active_rows = rows(abs(min(lower_gap, upper_gap)) ...
        <= validation.chord_active_tolerance);
    reg_norm = vecnorm(s_reg, 2, 2);
    for i = 1:CurrentReference.N
        incident = active_rows(any( ...
            LinearConstraints.matrix(active_rows, u_index(i, :)) ~= 0, 2));
        if isempty(incident)
            continue;
        end
        tangent = null(full(LinearConstraints.matrix( ...
            incident, u_index(i, :))));
        Report.chord_active(i) = true;
        Report.chord_rank(i) = size(tangent, 2);
        if ~isempty(tangent)
            Report.chord_tangent(i, :) = tangent(:, 1).';
        end
        if reg_norm(i) > 0
            projected = tangent * (tangent.' * s_reg(i, :).');
            Report.chord_reg_component(i) = norm(projected);
            Report.chord_flatness(i) = norm(projected) / reg_norm(i);
            Report.chord_flat(i) = Report.chord_flatness(i) ...
                <= validation.chord_flatness_tolerance;
        end
    end
end
