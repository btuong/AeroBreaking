function figs = plot_radius_scan(ScanRound, config)
% PLOT_RADIUS_SCAN 画一轮参考点的半径扫描: 三扇窗，横轴都是半径 r。
%
% 输入:
%   ScanRound - solve_radius_scan_round 的输出（points 按 r 从大到小，metrics 是评价量）
%   config    - 读取 config.plot 的 font_size、visibility 和 config.trust_region 的 ρ 阈值
%
% 输出 figs: 三扇窗的句柄（1 x 3）。
%
% 画法与全程图一致: 颜色和标记形状表示是哪个量（同名同色同标记，build_analysis_palette），
% 实际量实线加点，门槛、阈值虚线；每扇窗只在底部放一个共用图例；不在图上加文字标注。
% 横轴都是对数（半径按倍数取）；除 ρ 外纵轴也是对数，负值按绝对值画并用向下三角标出，
% 含义写在标题下面一行。每个分块都画三条竖线: 本轮实际半径 r^k（红色虚线）、松弛为零
% 所需的半径（拐点，灰色点线）、能维持的最大半径（灰色点划线），拐点到能维持的最大
% 半径之间就是“合适”的半径。为了每块不超过三四条线，总量、三部分、收益与余项分在三扇窗。
%
% 窗 1「半径扫描-第k轮-下降与下降比」:
%   1. ΔL 与 ΔJ         预测下降和真实下降（ΔJ = ΔL − D，先升后降，顶点是真实下降
%                       最大的半径）
%   2. ΔL、门槛、D      ΔL、门槛 (1−ρ1)ΔL（虚线）、D（理论文档的图 2-4、2-5）
%   3. 下降比 ρ         ρ，ρ0、ρ1、ρ2 三条阈值线；线性纵轴限在 [−1, 1.5]
% 窗 2「半径扫描-第k轮-分三部分」:
%   1. 性能指标部分     这一部分的 ΔL、D、ΔJ
%   2. 附加项部分       这一部分的 ΔL、D、ΔJ（D 不大于 0，为 0 时不画）
%   3. 罚项部分         这一部分的 ΔL、D、ΔJ
%   4. 罚项             参考处的罚项、候选解处的罚项、松弛罚项、修复后的松弛罚项
%                       （做了修复检查才有）
% 窗 3「半径扫描-第k轮-收益与余项」:
%   1. 性能指标的收益   G(r)，有效下降 E(r)（做了修复检查才有），取 _cost
%   2. 附加项的收益     G(r)，有效下降 E(r)，取 _extra；和第 1 块同名同色，由纵轴标签
%                       区分是哪一部分，图例只列一次
%   3. 动力学余项按阶   状态×状态、状态×控制、状态×时长、控制×时长
% 求解失败的半径不画点。G:性能指标在拐点右边可以为负（P3 用性能指标的上升换附加项的
% 下降），属于正常情况，按负值的画法画。
%
% 本函数依次完成：
%   1. 画窗 1: 下降与下降比。
%   2. 画窗 2: 分三部分。
%   3. 画窗 3: 收益与余项。

    %% 1. 画窗 1: 下降与下降比
    figs = gobjects(1, 3);
    figs(1) = plot_reduction_window(ScanRound, config);

    %% 2. 画窗 2: 分三部分
    figs(2) = plot_part_window(ScanRound, config);

    %% 3. 画窗 3: 收益与余项
    figs(3) = plot_gain_window(ScanRound, config);
end


function fig = plot_reduction_window(ScanRound, config)
% PLOT_REDUCTION_WINDOW 窗 1: ΔL 与 ΔJ，ΔL·门槛·D，ρ。

    fig = figure('Name', sprintf('半径扫描-第%d轮-下降与下降比', ScanRound.iter), ...
        'NumberTitle', 'off', 'Visible', config.plot.visibility);
    Points = ScanRound.points([ScanRound.points.success]);
    radius = [Points.radius_scale];
    Palette = build_analysis_palette();
    [layout, tile_axes] = create_scan_tiles(fig, 3);
    notes = {};

    % ΔL 与 ΔJ
    series = [ ...
        scan_series(Palette, 'ΔL', [Points.predicted_reduction], 'predicted_reduction'); ...
        scan_series(Palette, 'ΔJ', [Points.actual_reduction], 'actual_reduction')];
    notes = [notes, draw_scan_tile(tile_axes(1), radius, series, {}, ...
        'ΔL 与 ΔJ', config)];

    % ΔL、门槛、D
    series = [ ...
        scan_series(Palette, 'ΔL', [Points.predicted_reduction], 'predicted_reduction'); ...
        {'门槛', [Points.threshold], Palette.predicted_reduction, true, 'none'}; ...
        scan_series(Palette, 'D', [Points.prediction_error], 'prediction_error')];
    notes = [notes, draw_scan_tile(tile_axes(2), radius, series, {}, ...
        'ΔL、门槛、D', config)];

    % 下降比 ρ 和三条阈值线
    notes = [notes, draw_scan_ratio_tile(tile_axes(3), Points, ...
        Palette.single, config)];

    mark_scan_radii(tile_axes, ScanRound.metrics, Palette);
    finish_tile_window(layout, tile_axes, ...
        sprintf('半径扫描: 第 %d 轮参考点，下降与下降比', ScanRound.iter), ...
        notes, config);
end


function fig = plot_part_window(ScanRound, config)
% PLOT_PART_WINDOW 窗 2: 性能指标、附加项、罚项三部分各一块的 ΔL、D、ΔJ，再加罚项一块。

    fig = figure('Name', sprintf('半径扫描-第%d轮-分三部分', ScanRound.iter), ...
        'NumberTitle', 'off', 'Visible', config.plot.visibility);
    Points = ScanRound.points([ScanRound.points.success]);
    radius = [Points.radius_scale];
    Palette = build_analysis_palette();
    repair_done = isfinite(ScanRound.repair_radius_scale);
    [layout, tile_axes] = create_scan_tiles(fig, 4);
    notes = {};

    % 性能指标部分
    series = [ ...
        scan_series(Palette, 'ΔL', [Points.cost_predicted], 'predicted_reduction'); ...
        scan_series(Palette, 'D', [Points.cost_error], 'prediction_error'); ...
        scan_series(Palette, 'ΔJ', [Points.cost_actual], 'actual_reduction')];
    notes = [notes, draw_scan_tile(tile_axes(1), radius, series, {}, ...
        '性能指标部分', config)];

    % 附加项部分；控制正则线性化后 D 不大于 0，只在控制方向变化时不为零，为 0 时不画这条线
    series = scan_series(Palette, 'ΔL', [Points.extra_predicted], ...
        'predicted_reduction');
    extra_error = [Points.extra_error];
    if any(isfinite(extra_error) & extra_error ~= 0)
        series = [series; scan_series(Palette, 'D', extra_error, ...
            'prediction_error')];
    else
        notes{end + 1} = '附加项部分的 D 为 0，未画';
    end
    series = [series; scan_series(Palette, 'ΔJ', [Points.extra_actual], ...
        'actual_reduction')];
    notes = [notes, draw_scan_tile(tile_axes(2), radius, series, {}, ...
        '附加项部分', config)];

    % 罚项部分
    series = [ ...
        scan_series(Palette, 'ΔL', [Points.penalty_predicted], 'predicted_reduction'); ...
        scan_series(Palette, 'D', [Points.penalty_error], 'prediction_error'); ...
        scan_series(Palette, 'ΔJ', [Points.penalty_actual], 'actual_reduction')];
    notes = [notes, draw_scan_tile(tile_axes(3), radius, series, {}, ...
        '罚项部分', config)];

    % 罚项；做了修复检查时加上修复后的松弛罚项
    series = [ ...
        scan_series(Palette, '参考处的罚项', [Points.reference_penalty], ...
            'reference_penalty'); ...
        scan_series(Palette, '候选解处的罚项', [Points.candidate_penalty], ...
            'candidate_penalty'); ...
        scan_series(Palette, '松弛罚项', [Points.slack_penalty], 'slack_penalty')];
    if repair_done
        series = [series; scan_series(Palette, '修复后的松弛罚项', ...
            [Points.repair_slack_penalty], 'repair_slack_penalty')];
    end
    notes = [notes, draw_scan_tile(tile_axes(4), radius, series, {}, ...
        '罚项', config)];

    mark_scan_radii(tile_axes, ScanRound.metrics, Palette);
    finish_tile_window(layout, tile_axes, ...
        sprintf('半径扫描: 第 %d 轮参考点，分三部分', ScanRound.iter), ...
        notes, config);
end


function fig = plot_gain_window(ScanRound, config)
% PLOT_GAIN_WINDOW 窗 3: 性能指标的收益 G、E，附加项的收益 G、E，动力学余项按阶。

    fig = figure('Name', sprintf('半径扫描-第%d轮-收益与余项', ScanRound.iter), ...
        'NumberTitle', 'off', 'Visible', config.plot.visibility);
    ok = [ScanRound.points.success];
    Points = ScanRound.points(ok);
    radius = [Points.radius_scale];
    Metrics = ScanRound.metrics;
    Palette = build_analysis_palette();
    repair_done = isfinite(ScanRound.repair_radius_scale);
    [layout, tile_axes] = create_scan_tiles(fig, 3);
    notes = {};

    % 性能指标、附加项的收益各一块: G(r)；做了修复检查时加上有效下降 E(r)。两块的
    % 曲线同名同色，由纵轴标签区分；只有 G 一条时它不进图例，纵轴标签写明是 G(r)
    gain_parts = { ...
        '性能指标', Metrics.gain_cost(ok), Metrics.effective_drop_cost(ok); ...
        '附加项', Metrics.gain_extra(ok), Metrics.effective_drop_extra(ok)};
    for j = 1:2
        series = scan_series(Palette, 'G(r)', gain_parts{j, 2}, 'gain');
        y_label = [gain_parts{j, 1} '的收益 G(r)'];
        if repair_done
            series = [series; scan_series(Palette, '有效下降 E(r)', ...
                gain_parts{j, 3}, 'effective_drop')]; %#ok<AGROW>
            y_label = [gain_parts{j, 1} '的收益'];
        end
        notes = [notes, draw_scan_tile(tile_axes(j), radius, series, {}, ...
            y_label, config)]; %#ok<AGROW>
    end

    % 动力学余项按阶
    splits = [Points.remainder_split];
    weighted = reshape([splits.weighted], 4, []);   % 4 x K
    series = [ ...
        scan_series(Palette, '状态×状态', weighted(1, :), 'state_state'); ...
        scan_series(Palette, '状态×控制', weighted(2, :), 'state_control'); ...
        scan_series(Palette, '状态×时长', weighted(3, :), 'state_time'); ...
        scan_series(Palette, '控制×时长', weighted(4, :), 'control_time')];
    notes = [notes, draw_scan_tile(tile_axes(3), radius, series, {}, ...
        '动力学余项按阶', config)];

    mark_scan_radii(tile_axes, Metrics, Palette);
    finish_tile_window(layout, tile_axes, ...
        sprintf('半径扫描: 第 %d 轮参考点，收益与余项', ScanRound.iter), ...
        notes, config);
end


function row = scan_series(Palette, name, values, key)
% SCAN_SERIES 一条实际量曲线的描述行 {名字, 数值, 颜色, 是否为界, 标记}，颜色和标记按 key 从调色板取。

    row = {name, values, Palette.(key), false, Palette.marker.(key)};
end


function [layout, tile_axes] = create_scan_tiles(fig, num_tiles)
% CREATE_SCAN_TILES 在图窗上建分块布局并依次建好各分块的坐标轴。

    layout = create_tile_layout(fig, num_tiles);
    tile_axes = gobjects(1, num_tiles);
    for j = 1:num_tiles
        tile_axes(j) = nexttile(layout);
    end
end


function mark_scan_radii(tile_axes, Metrics, Palette)
% MARK_SCAN_RADII 在每个分块画三条竖线: 本轮实际半径 r^k、松弛为零所需的半径、能维持的最大半径。
%
% 没有的半径（如扫到的半径里松弛都不为零）不画。竖线有名字，进窗口底部的共用图例；
% 坐标范围已由分块收尾定好，三个半径都是扫到的半径，落在范围内。

    lines = { ...
        '本轮半径 r^k', Metrics.actual_radius, Palette.actual_radius, '--', 2; ...
        '松弛为零所需的半径', Metrics.zero_radius, Palette.radius_mark, ':', 2; ...
        '能维持的最大半径', Metrics.hold_radius, Palette.radius_mark, '-.', 1.5};
    for j = 1:numel(tile_axes)
        for m = 1:size(lines, 1)
            if ~isfinite(lines{m, 2})
                continue;
            end
            xline(tile_axes(j), lines{m, 2}, lines{m, 4}, 'Color', lines{m, 3}, ...
                'LineWidth', lines{m, 5}, 'DisplayName', lines{m, 1});
        end
    end
end


function notes = draw_scan_ratio_tile(ax, Points, color, config)
% DRAW_SCAN_RATIO_TILE 画 ρ 随半径: 实线 ρ，虚线 ρ0、ρ1、ρ2；纵轴限在 [-1, 1.5]，超出的点画在边上。
%
% 大半径上 ρ 可以是很大的负数，纵轴不限范围时 ρ0、ρ1、ρ2 附近挤成一团，所以和全程图的
% ρ 分块一样夹在 [-1, 1.5]，超出的点画在上、下边沿，三角朝外。ρ 没算出的半径
% （ΔL 过小）留空。ρ 是分块里唯一的曲线，不进图例，纵轴标签就是它的名字。
% 返回要写在窗口标题下面的说明行。

    notes = {};
    hold(ax, 'on');
    lower_limit = -1;
    upper_limit = 1.5;
    radius = [Points.radius_scale];

    ratio = nan(size(radius));
    available = [Points.ratio_available];
    ratio(available) = [Points(available).ratio];
    % 超出范围的值夹到边上；不能用 max/min 夹取，它们会把 NaN（没算出的半径）当缺失值丢掉
    clipped = ratio;
    clipped(ratio > upper_limit) = upper_limit;
    clipped(ratio < lower_limit) = lower_limit;
    in_range = ratio >= lower_limit & ratio <= upper_limit;
    plot(ax, radius, clipped, '-', 'Color', color, 'LineWidth', 1.5, ...
        'DisplayName', 'ρ', 'Tag', 'series');
    plot(ax, radius(in_range), ratio(in_range), 'o', 'Color', color, ...
        'MarkerFaceColor', color, 'MarkerSize', 6, 'HandleVisibility', 'off');

    % 超出范围的点画在上、下边沿，三角朝外
    above = ratio > upper_limit;
    below = ratio < lower_limit;
    plot(ax, radius(above), repmat(upper_limit, 1, nnz(above)), '^', ...
        'Color', color, 'MarkerFaceColor', color, 'MarkerSize', 8, ...
        'HandleVisibility', 'off');
    plot(ax, radius(below), repmat(lower_limit, 1, nnz(below)), 'v', ...
        'Color', color, 'MarkerFaceColor', color, 'MarkerSize', 8, ...
        'HandleVisibility', 'off');
    if any(above) || any(below)
        notes{end + 1} = '▲▼ ρ 超出纵轴范围（画在边上）';
    end

    draw_ratio_thresholds(ax, config);
    set(ax, 'XScale', 'log');
    ylim(ax, [lower_limit - 0.05, upper_limit + 0.05]);
    finish_scan_axes(ax, radius, '下降比 ρ', config);
end


function notes = draw_scan_tile(ax, radius, series, level_lines, y_label, config)
% DRAW_SCAN_TILE 画一个横轴为 r 的双对数分块。
%
% 输入:
%   series      - 每行 {名字, 1 x K 数值, 颜色, 是否为界, 标记}；界画虚线不带点，其余画
%                 实线，每个半径上画该曲线的实心标记（各量的标记见 build_analysis_palette）
%   level_lines - 每行 {名字, 数值, 线型, 线宽}，画成水平线（如 ρ 的阈值）；没有时传 {}
%
% 图例条目按 series 的顺序另画（add_legend_entry），图例里同时显示线和标记。
% 负值按绝对值画并用向下三角标出，0 值和低于显示下限的值画在下限（用一条点线标明）。
% 纵轴范围把水平线也包进去，免得阈值线落在图外。返回写在标题下面的说明行。
% 图例不在这里放，由 finish_tile_window 在窗口底部放一个共用的。

    notes = {};
    hold(ax, 'on');
    num_series = size(series, 1);
    num_levels = size(level_lines, 1);
    curve_list = cell(1, num_series + num_levels);
    for k = 1:num_series
        curve_list{k} = build_plot_curve(series{k, 1}, radius, ...
            series{k, 2}, 'line');
    end
    for k = 1:num_levels
        curve_list{num_series + k} = build_plot_curve(level_lines{k, 1}, ...
            1, level_lines{k, 2}, 'dashed');
    end
    LogInfo = compute_log_display([curve_list{:}]);

    % 图例条目按给定顺序；实际量打上 Tag 'series'，共用图例据此跳过“只有一条曲线”的
    % 分块里的曲线
    for k = 1:num_series
        if series{k, 4}
            add_legend_entry(ax, series{k, 1}, series{k, 3}, '--', 1.5, ...
                'none', false);
        else
            add_legend_entry(ax, series{k, 1}, series{k, 3}, '-', 1.5, ...
                series{k, 5}, true);
        end
    end

    has_negative = false;
    for k = 1:num_series
        values = series{k, 2};
        color = series{k, 3};
        shown = abs(values);
        shown(shown < LogInfo.floor_value) = LogInfo.floor_value;
        if series{k, 4}
            plot(ax, radius, shown, '--', 'Color', color, 'LineWidth', 1.5, ...
                'HandleVisibility', 'off');
            continue;
        end
        plot(ax, radius, shown, '-', 'Color', color, 'LineWidth', 1.5, ...
            'HandleVisibility', 'off');
        negative = values < 0;
        plot(ax, radius(~negative), shown(~negative), series{k, 5}, ...
            'LineStyle', 'none', 'Color', color, 'MarkerSize', 7, ...
            'MarkerFaceColor', color, 'HandleVisibility', 'off');
        plot(ax, radius(negative), shown(negative), 'v', 'Color', color, ...
            'MarkerSize', 10, 'LineWidth', 1.5, 'MarkerFaceColor', 'w', ...
            'HandleVisibility', 'off');
        has_negative = has_negative || any(negative);
    end
    for k = 1:num_levels
        if level_lines{k, 2} > 0
            yline(ax, level_lines{k, 2}, level_lines{k, 3}, ...
                'LineWidth', level_lines{k, 4}, 'DisplayName', level_lines{k, 1});
        end
    end

    set(ax, 'XScale', 'log', 'YScale', 'log');
    ylim(ax, [LogInfo.floor_value / 3, LogInfo.top_value * 3]);
    if LogInfo.has_clamped
        yline(ax, LogInfo.floor_value, ':', 'Color', [0.5, 0.5, 0.5], ...
            'LineWidth', 1.2, 'HandleVisibility', 'off');
        notes{end + 1} = '点线：0 值画在下限';
    end
    if has_negative
        notes{end + 1} = '▼ 负值（按绝对值画）';
    end
    finish_scan_axes(ax, radius, y_label, config);
end


function finish_scan_axes(ax, radius, y_label, config)
% FINISH_SCAN_AXES 横轴为 r 的分块收尾: 横轴范围与刻度、轴标签。
%
% 横轴两端各留一点边。扫描的半径不超过 12 个时刻度就放在这些半径上；小于 1 的半径
% 若是 1/整数，刻度写成分数（1/8、1/16），比小数短，分块窄的时候不容易挤在一起。

    if ~isempty(radius)
        xlim(ax, [min(radius) / 1.3, max(radius) * 1.3]);
    end
    if ~isempty(radius) && numel(radius) <= 12
        tick_values = unique(radius);   % unique 的结果从小到大
        labels = cell(1, numel(tick_values));
        for k = 1:numel(tick_values)
            inverse = 1 / tick_values(k);
            if tick_values(k) < 1 && abs(inverse - round(inverse)) < 1e-9
                labels{k} = sprintf('1/%d', round(inverse));
            else
                labels{k} = sprintf('%.4g', tick_values(k));
            end
        end
        xticks(ax, tick_values);
        xticklabels(ax, labels);
    end
    style_plot_axes(ax, '半径 r', y_label, config);
end
