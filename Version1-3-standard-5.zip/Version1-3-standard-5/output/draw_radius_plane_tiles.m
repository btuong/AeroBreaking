function draw_radius_plane_tiles(fig, HistorySeries, config)
% DRAW_RADIUS_PLANE_TILES 画半径平面: 横轴半径 r，每次求解画 ΔL、门槛 (1−ρ1)ΔL、D 三个点（实测的 ΔL(r)、D(r)）。
%
% 输入:
%   fig            - 目标图窗
%   HistorySeries  - plot_scp_result 整理好的迭代序列，各轮 plot_data 含 trust_region
%   config         - 读取 config.plot.font_size
%
% 一个分块，横纵轴都是对数。同一参考点（reference_index 相同）上的求解按 r 排序
% 后连线: ΔL 实线、门槛虚线（用 ΔL 的颜色）、D 实线；不同参考点之间不连线。
% 被拒绝后参考点不变、半径变小，同一参考点上的几次求解就是 ΔL(r)、D(r) 曲线上的
% 几个点。ΔL、D 的点用各自的标记形状（与其他分析窗相同），接受实心、拒绝空心；门槛
% 不画点；负值按绝对值画并用向下三角标出。
% 图例在窗口底部（finish_tile_window），颜色与其他分析窗一致（build_analysis_palette）；
% 不在图上加文字标注。
% 没有两个及以上不同半径的求解时由 plot_scp_result 跳过，不进入本函数。

    TrustData = collect_trust_series(HistorySeries);
    status = HistorySeries.status;
    valid = [TrustData.evaluated] & isfinite([TrustData.scale_before]) ...
        & isfinite([TrustData.predicted_reduction]) ...
        & isfinite([TrustData.prediction_error]);
    radius = [TrustData.scale_before];
    reference_index = [TrustData.reference_index];
    Palette = build_analysis_palette();
    % 每行: 名字、各次求解的值、颜色、线型、标记（门槛是界，不画点）
    quantities = { ...
        'ΔL', [TrustData.predicted_reduction], Palette.predicted_reduction, '-', ...
            Palette.marker.predicted_reduction; ...
        '门槛', [TrustData.threshold], Palette.predicted_reduction, '--', 'none'; ...
        'D', [TrustData.prediction_error], Palette.prediction_error, '-', ...
            Palette.marker.prediction_error};

    % 三种量一起定对数纵轴的显示下限
    curve_list = cell(1, size(quantities, 1));
    for q = 1:size(quantities, 1)
        curve_list{q} = build_plot_curve(quantities{q, 1}, radius(valid), ...
            quantities{q, 2}(valid), 'line');
    end
    LogInfo = compute_log_display([curve_list{:}]);

    layout = create_tile_layout(fig, 1);
    ax = nexttile(layout);
    hold(ax, 'on');
    % 图例用的占位对象（线和标记），数据线本身不进图例
    for q = 1:size(quantities, 1)
        add_legend_entry(ax, quantities{q, 1}, quantities{q, 3}, ...
            quantities{q, 4}, Palette.width.normal, quantities{q, 5}, false);
    end

    has_negative = false;
    groups = unique(reference_index(valid));
    for g = 1:numel(groups)
        in_group = valid & reference_index == groups(g);
        [group_radius, order] = sort(radius(in_group));
        group_status = status(in_group);
        group_status = group_status(order);
        for q = 1:size(quantities, 1)
            values = quantities{q, 2}(in_group);
            values = values(order);
            magnitude = abs(values);
            magnitude(magnitude < LogInfo.floor_value) = LogInfo.floor_value;
            color = quantities{q, 3};
            if numel(group_radius) >= 2
                plot(ax, group_radius, magnitude, quantities{q, 4}, ...
                    'Color', color, 'LineWidth', 1.5, 'HandleVisibility', 'off');
            end
            negative = values < 0;
            if ~strcmp(quantities{q, 5}, 'none')
                marked = magnitude;
                marked(negative) = NaN;
                mark_history_status(ax, group_radius, group_status, marked, ...
                    color, quantities{q, 5});
            end
            plot(ax, group_radius(negative), magnitude(negative), 'v', ...
                'Color', color, 'MarkerSize', 8, 'LineWidth', 1.5, ...
                'HandleVisibility', 'off');
            has_negative = has_negative || any(negative);
        end
    end

    set(ax, 'XScale', 'log', 'YScale', 'log');
    radius_values = unique(radius(valid));
    xlim(ax, [min(radius_values) / 1.3, max(radius_values) * 1.3]);
    if numel(radius_values) <= 12
        xticks(ax, radius_values);
    end
    ylim(ax, [LogInfo.floor_value / 3, LogInfo.top_value * 3]);
    notes = {describe_status_marks(status), '同一参考点上的求解连线'};
    if LogInfo.has_clamped
        yline(ax, LogInfo.floor_value, ':', 'Color', [0.5, 0.5, 0.5], ...
            'LineWidth', 1.2, 'HandleVisibility', 'off');
        notes{end + 1} = '点线：0 值画在下限';
    end
    if has_negative
        notes{end + 1} = '▼ 负值（按绝对值画）';
    end
    style_plot_axes(ax, '半径 r', 'ΔL、门槛 (1-ρ1)ΔL、D', config);
    finish_tile_window(layout, ax, '半径平面', notes, config);
end
