function [r_eci, v_eci] = transform_ecf2eci(a, w, r_ecf, v_ecf)
% TRANSFORM_ECF2ECI 将 ECF 地固系状态转换到 ECI 惯性系。
%
% 输入:
%   a     - 地固系 OX 轴相对惯性系 OX1 轴的夹角 (rad)
%   w     - 地球自转角速率 (rad/s，与时间单位同口径)
%   r_ecf - 3x1 ECF 位置
%   v_ecf - 3x1 ECF 相对速度
%
% 输出:
%   r_eci, v_eci - 3x1 ECI 位置与惯性速度

    R = [cos(a), sin(a), 0;
        -sin(a), cos(a), 0;
        0, 0, 1];

    r_eci = R' * r_ecf;
    v_eci = R' * (v_ecf + cross([0; 0; w], r_ecf));
end
