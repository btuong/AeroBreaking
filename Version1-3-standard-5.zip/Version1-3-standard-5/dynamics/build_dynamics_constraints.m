function DynamicsBlock = build_dynamics_constraints( ...
        DynamicsContract, VariableIndex, CurrentReference, ConstData, config)
% BUILD_DYNAMICS_CONSTRAINTS 构建大气段梯形离散动力学等式（含松弛变量）。
%
% 数学形式:
%   每圈内相邻节点 i, i+1（M 圈共 N − M 个区间）、状态 s ∈ {r, V, γ, φ, ψ}：
%       x_s(i+1) − x_s(i) = (Δτ_i/2)·[F_s(i) + F_s(i+1)],    Δτ_i = τ_(i+1) − τ_i
%   F_s = t_f·f_s(x, u) 为 dx_s/dτ，t_f 为所在圈飞行时间（TU），r: LU，V: VU，角度: rad。
%   P3 将 F_s 在参考点一阶线性化（h_s + Σ_v J_s,v·(v − v̄)，见
%   linearize_atmospheric_dynamics），并加不限符号的松弛 ν_s,k ∈ R：
%       x_s(i+1) − x_s(i) + ν_s,k
%           = (Δτ_i/2)·Σ_(j∈{i,i+1}) [h_s(j) + Σ_v J_s,v(j)·(v_j − v̄_j)]
%   k 为区间序号（跨圈按圈顺序累计）；t_f 为每圈一个变量，两节点共用该圈 t_f。
%   松弛罚项 w_dyn·|ν_s,k| 在 P3 的目标中。
%
% 代码形式（每个区间 5 行，行序 r, V, γ, φ, ψ；总行数 5·(N − M)）:
%   变量移到左侧、常数移到右侧，lower = upper = beq：
%       x_s(i+1) − x_s(i) + ν_s,k − (Δτ_i/2)·Σ_v [J_s,v(i)·v_i + J_s,v(i+1)·v_(i+1)]
%           = (Δτ_i/2)·[h_s(i) + h_s(i+1)]
%             − (Δτ_i/2)·Σ_v [J_s,v(i)·v̄_i + J_s,v(i+1)·v̄_(i+1)]
%   变量列与系数:
%       x_s(i+1), x_s(i)  VariableIndex.<s>(i+1), (i)                +1, −1
%       ν_s,k             VariableIndex.dyn_slack_<s>(k)              +1
%       v_i, v_(i+1)      VariableIndex.<v>(i), (i+1)     −(Δτ_i/2)·J_s,v(i), −(Δτ_i/2)·J_s,v(i+1)
%       t_f               VariableIndex.t_f(圈号)         −(Δτ_i/2)·[J_s,t_f(i) + J_s,t_f(i+1)]
%   符号对应: h_s → ci.const / ci1.const，J_s,v → ci.<v> / ci1.<v>（节点 i / i+1），
%   v̄ → state_k / control_k / t_f_k，右端 → beq(row)。系数为 0 的依赖不写入，
%   以保持稀疏模式。

    total_cir = config.scenario.total_cir;
    N = CurrentReference.N;
    PointsBounds = CurrentReference.PointsBounds;
    tau = CurrentReference.tau;

    state_k = CurrentReference.state;
    control_k = CurrentReference.control;
    t_f_k_list = CurrentReference.t_f;

    num_states = DynamicsContract.num_states;
    state_names = DynamicsContract.state_names;
    state_specs = DynamicsContract.states;

    num_dyn_points = N - total_cir;
    num_rows = num_states * num_dyn_points;
    beq = zeros(num_rows, 1);

    % 变量名 -> 变量索引映射
    var_index = struct();
    for s = 1:num_states
        var_index.(state_names{s}) = VariableIndex.(state_names{s});
    end
    var_index.u1 = VariableIndex.u1;
    var_index.u2 = VariableIndex.u2;
    var_index.t_f = VariableIndex.t_f;

    % 松弛变量名 -> 索引映射
    slack_index = struct();
    for s = 1:num_states
        name = state_names{s};
        slack_index.(name) = VariableIndex.(['dyn_slack_' name]);
    end

    row_index = [];
    column_index = [];
    value = [];

    row_ptr = 0;
    dyn_err_counter = 0;

    for cirnum = 1:total_cir
        current_begin = PointsBounds(cirnum).begin;
        current_end = PointsBounds(cirnum).end;
        t_f_k = t_f_k_list(cirnum);

        for i = current_begin:(current_end - 1)
            dtau = tau(i + 1) - tau(i);
            dyn_err_counter = dyn_err_counter + 1;

            state_i = state_k(i, :);
            state_i1 = state_k(i + 1, :);
            control_i.u1 = control_k.u1(i);
            control_i.u2 = control_k.u2(i);
            control_i1.u1 = control_k.u1(i + 1);
            control_i1.u2 = control_k.u2(i + 1);

            coeffs_i = DynamicsContract.linearize( ...
                ConstData, state_i, control_i, t_f_k);
            coeffs_i1 = DynamicsContract.linearize( ...
                ConstData, state_i1, control_i1, t_f_k);

            for d = 1:num_states
                spec = state_specs(d);
                name = spec.name;
                row_ptr = row_ptr + 1;
                row = row_ptr;

                ci = coeffs_i{d};
                ci1 = coeffs_i1{d};

                % x_s(i+1) - x_s(i) + dyn_slack_s(k)
                row_index = [row_index; row; row; row];
                column_index = [column_index; ...
                    var_index.(name)(i + 1); ...
                    var_index.(name)(i); ...
                    slack_index.(name)(dyn_err_counter)];
                value = [value; 1; -1; 1];

                % -（dtau/2) * J(i)*x(i) - (dtau/2) * J(i+1)*x(i+1)
                for k_dep = 1:numel(spec.deps)
                    vname = spec.deps{k_dep};
                    if strcmp(vname, 't_f')
                        coef_sum = ci.t_f + ci1.t_f;
                        if coef_sum ~= 0
                            row_index = [row_index; row];
                            column_index = [column_index; ...
                                var_index.t_f(cirnum)];
                            value = [value; -(dtau / 2) * coef_sum];
                        end
                    else
                        coef_i = ci.(vname);
                        coef_i1 = ci1.(vname);
                        if coef_i ~= 0
                            row_index = [row_index; row];
                            column_index = [column_index; ...
                                var_index.(vname)(i)];
                            value = [value; -(dtau / 2) * coef_i];
                        end
                        if coef_i1 ~= 0
                            row_index = [row_index; row];
                            column_index = [column_index; ...
                                var_index.(vname)(i + 1)];
                            value = [value; -(dtau / 2) * coef_i1];
                        end
                    end
                end

                % 右端常数：参考处展开的余项
                rhs = (dtau / 2) * (ci.const + ci1.const);
                for k_dep = 1:numel(spec.deps)
                    vname = spec.deps{k_dep};
                    if strcmp(vname, 't_f')
                        rhs = rhs - (dtau / 2) * (ci.t_f + ci1.t_f) * t_f_k;
                    elseif strcmp(vname, 'u1')
                        rhs = rhs - (dtau / 2) * (ci.(vname) * control_i.u1 ...
                            + ci1.(vname) * control_i1.u1);
                    elseif strcmp(vname, 'u2')
                        rhs = rhs - (dtau / 2) * (ci.(vname) * control_i.u2 ...
                            + ci1.(vname) * control_i1.u2);
                    else
                        state_col = find(strcmp(state_names, vname));
                        if ~isempty(state_col)
                            rhs = rhs - (dtau / 2) ...
                                * (ci.(vname) * state_k(i, state_col) ...
                                + ci1.(vname) * state_k(i + 1, state_col));
                        end
                    end
                end

                beq(row) = rhs;
            end
        end
    end

    DynamicsBlock.name = 'dynamics';
    DynamicsBlock.row_index = row_index;
    DynamicsBlock.column_index = column_index;
    DynamicsBlock.value = value;
    DynamicsBlock.lower = beq;
    DynamicsBlock.upper = beq;

    if numel(DynamicsBlock.lower) ~= num_rows
        error('SCP:InvalidDynamicsConstraintCount', ...
            '动力学约束行数与网格规模不一致。');
    end
end
