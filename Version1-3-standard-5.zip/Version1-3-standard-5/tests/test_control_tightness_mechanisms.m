function tests = test_control_tightness_mechanisms
% TEST_CONTROL_TIGHTNESS_MECHANISMS 核验抵消、弦上平坦和互补积的节点指标。

    tests = functiontests(localfunctions);
end


function test_summary_marks_incomplete_comparison(testCase)
% 有轮次记录但主报告不可用时，不得标成证据完整或零抵消。

    Diagnosis.case_name = 'missing_dual';
    Diagnosis.reg_type = 'sum';
    Diagnosis.w_reg = 1e-3;
    Diagnosis.rounds = struct('iter', 1, ...
        'with_rate', struct('evaluated', true, 'dual_available', false), ...
        'without_rate', struct('dual_available', false), ...
        'alternate_success', false, 'alternate_status', 'UNKNOWN');

    Summary = build_case_summary(Diagnosis);

    verifyTrue(testCase, Summary.executed);
    verifyFalse(testCase, Summary.success);
    verifyFalse(testCase, Summary.rounds.main_usable);
    verifyEqual(testCase, Summary.rounds.alternate_status, 'UNKNOWN');
end


function test_missing_dual_preserves_primal_chord_report(testCase)
% 对偶缺失时不得中止只读诊断，互补积保持 NaN，primal 弦活动仍可计算。

    SolverResult.primal = [0.6; 0.8; 0.7; 0.8];
    SolverResult.dual.doty = [];
    ConicConstraints.mapping = sparse([ ...
        0, 0, 0, 0; 1, 0, 0, 0; 0, 1, 0, 0; ...
        0, 0, 0, 0; 0, 0, 1, 0; 0, 0, 0, 1]);
    ConicConstraints.offset = [1; 0; 0; 1; 0; 0];
    ConicConstraints.cones = make_control_cones();
    Split.s_reg = [0.1, 0; 0, 0.1];
    Split.s_main = nan(2, 2);
    Split.s_total = nan(2, 2);
    Split.available = false;
    Reference.N = 2;
    Reference.control.u1 = [1; 1];
    Reference.control.u2 = [0; 0];
    config.validation.chord_active_tolerance = 1e-8;
    config.validation.chord_flatness_tolerance = 0.05;
    LinearConstraints.row_groups.control_continuity = 1;
    LinearConstraints.matrix = sparse([1, 0, -1, 0]);
    LinearConstraints.lower = -0.1;
    LinearConstraints.upper = 0.1;

    Report = evaluate_control_tightness_mechanisms( ...
        SolverResult, LinearConstraints, ConicConstraints, Reference, Split, ...
        config, [1, 2; 3, 4]);

    verifyTrue(testCase, all(Report.chord_active));
    verifyEqual(testCase, Report.chord_flat, [true; false]);
    verifyEqual(testCase, Report.complementarity, [NaN; NaN]);
    verifyEqual(testCase, Report.margin, [NaN; NaN]);
end


function test_violated_rate_row_is_not_active(testCase)
% 把不可行边界误当作活跃边界会制造并不存在的弦。

    SolverResult.primal = [0.6; 0.8; 0.6; 0.8];
    SolverResult.dual.doty = zeros(6, 1);
    ConicConstraints.mapping = sparse([ ...
        0, 0, 0, 0; 1, 0, 0, 0; 0, 1, 0, 0; ...
        0, 0, 0, 0; 0, 0, 1, 0; 0, 0, 0, 1]);
    ConicConstraints.offset = [1; 0; 0; 1; 0; 0];
    ConicConstraints.cones = make_control_cones();
    Split.s_reg = [0.1, 0; 0, 0.1];
    Split.s_main = zeros(2, 2);
    Split.s_total = Split.s_reg;
    Split.available = true;
    Reference.N = 2;
    Reference.control.u1 = [1; 1];
    Reference.control.u2 = [0; 0];
    config.validation.chord_active_tolerance = 1e-8;
    config.validation.chord_flatness_tolerance = 0.05;
    LinearConstraints.row_groups.control_continuity = 1;
    LinearConstraints.matrix = sparse([1, 0, -1, 0]);
    LinearConstraints.lower = -0.1;
    LinearConstraints.upper = 0.1;

    Report = evaluate_control_tightness_mechanisms( ...
        SolverResult, LinearConstraints, ConicConstraints, Reference, Split, ...
        config, [1, 2; 3, 4]);

    verifyFalse(testCase, any(Report.chord_active));
end


function test_control_report_contains_mechanism_metrics(testCase)
% 主链接入遗漏或把指标放到未保存的临时对象时，本测试失败。

    SolverResult.primal = [0.6; 0.8; 0.6; 0.8];
    SolverResult.dual.y = -0.2;
    SolverResult.dual.slx = zeros(4, 1);
    SolverResult.dual.sux = zeros(4, 1);
    SolverResult.dual.snx = zeros(4, 1);
    SolverResult.dual.doty = [2; -1.2; -1.6; 2; -1.2; -1.6];
    ConicConstraints.mapping = sparse([ ...
        0, 0, 0, 0; 1, 0, 0, 0; 0, 1, 0, 0; ...
        0, 0, 0, 0; 0, 0, 1, 0; 0, 0, 0, 1]);
    ConicConstraints.offset = [1; 0; 0; 1; 0; 0];
    ConicConstraints.cones = make_control_cones();
    VariableIndex.u1 = [1; 3];
    VariableIndex.u2 = [2; 4];
    objective = [-0.2; 0; -0.2; 0];
    LinearConstraints.row_groups.dynamics = 1;
    LinearConstraints.row_groups.control_continuity = zeros(0, 1);
    LinearConstraints.matrix = sparse([1, 0, 1, 0]);
    LinearConstraints.lower = 0;
    LinearConstraints.upper = 0;
    Reference.N = 2;
    Reference.PointsBounds = struct('begin', 1, 'end', 2);
    Reference.tau = [0; 1];
    Reference.control.u1 = [1; 1];
    Reference.control.u2 = [0; 0];
    config.objective.control_reg_type = 'sum';
    config.objective.weight_control_reg = 0.2;
    config.validation.lossless_tightness_tolerance = 1e-6;
    config.validation.chord_active_tolerance = 1e-8;
    config.validation.chord_flatness_tolerance = 0.05;

    Report = evaluate_control_report(SolverResult, VariableIndex, objective, ...
        LinearConstraints, ConicConstraints, Reference, config);

    verifyEqual(testCase, Report.tightness_margin, [0; 0], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.cone_complementarity, [0; 0], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.cancellation_cosine, [-1; -1], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.radial_regularizer, [0.2; 0.2], 'AbsTol', 1e-14);
end


function test_rate_constraint_switch_defaults_and_disables_block(testCase)
% 默认行数改变或关闭开关后仍保留速率行时，本测试失败。

    config = scp_config_default();
    config.scenario.total_cir = 1;
    Reference.PointsBounds = struct('begin', 1, 'end', 3);
    VariableIndex.u1 = (1:3).';
    VariableIndex.u2 = (4:6).';

    DefaultBlock = build_control_continuity_block( ...
        VariableIndex, Reference, config);
    verifyTrue(testCase, config.constraints.enable_control_continuity);
    config.constraints.enable_control_continuity = false;
    DisabledBlock = build_control_continuity_block( ...
        VariableIndex, Reference, config);

    verifyTrue(testCase, config.constraints.enable_control_continuity == false);
    verifyEqual(testCase, numel(DefaultBlock.lower), 2);
    verifyEmpty(testCase, DisabledBlock.lower);
    verifyEmpty(testCase, DisabledBlock.row_index);
end


function test_complementarity_and_radial_demand(testCase)
% 错误的锥符号、参考方向或合力范数应使这些断言失败。

    SolverResult.primal = [0.6; 0.8; 0.3; 0.4];
    SolverResult.dual.doty = [2; -1.2; -1.6; 4; -0.6; -0.8];
    ConicConstraints.mapping = sparse([ ...
        0, 0, 0, 0; 1, 0, 0, 0; 0, 1, 0, 0; ...
        0, 0, 0, 0; 0, 0, 1, 0; 0, 0, 0, 1]);
    ConicConstraints.offset = [1; 0; 0; 1; 0; 0];
    ConicConstraints.cones = make_control_cones();
    Split.s_reg = [-0.2, 0; -0.1, 0];
    Split.s_main = [0.2, 0; 0.1, 0];
    Split.s_total = zeros(2, 2);
    Split.available = true;
    Reference.N = 2;
    Reference.control.u1 = [1; 1];
    Reference.control.u2 = [0; 0];
    config.validation.chord_active_tolerance = 1e-8;
    config.validation.chord_flatness_tolerance = 0.05;
    LinearConstraints.row_groups.control_continuity = zeros(0, 1);
    LinearConstraints.matrix = sparse(0, 4);
    LinearConstraints.lower = zeros(0, 1);
    LinearConstraints.upper = zeros(0, 1);

    Report = evaluate_control_tightness_mechanisms( ...
        SolverResult, LinearConstraints, ConicConstraints, Reference, Split, config, ...
        [1, 2; 3, 4]);

    verifyEqual(testCase, Report.margin, [0; 0], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.complementarity, [0; 3.5], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.radial_main, [-0.2; -0.1], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.radial_regularizer, [0.2; 0.1], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.cancellation_cosine, [-1; -1], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.cancellation_strength, [0; 0], 'AbsTol', 1e-14);
end


function test_active_chord_detects_u2_regularizer_flatness(testCase)
% 把弦方向或正则方向弄错都会破坏 u2 平坦、u1 不平坦的对比。

    SolverResult.primal = [0.6; 0.8; 0.7; 0.8];
    SolverResult.dual.doty = zeros(6, 1);
    ConicConstraints.mapping = sparse([ ...
        0, 0, 0, 0; 1, 0, 0, 0; 0, 1, 0, 0; ...
        0, 0, 0, 0; 0, 0, 1, 0; 0, 0, 0, 1]);
    ConicConstraints.offset = [1; 0; 0; 1; 0; 0];
    ConicConstraints.cones = make_control_cones();
    Split.s_reg = [0.1, 0; 0, 0.1];
    Split.s_main = zeros(2, 2);
    Split.s_total = Split.s_reg;
    Split.available = true;
    Reference.N = 2;
    Reference.control.u1 = [1; 1];
    Reference.control.u2 = [0; 0];
    config.validation.chord_active_tolerance = 1e-8;
    config.validation.chord_flatness_tolerance = 0.05;
    LinearConstraints.row_groups.control_continuity = 1;
    LinearConstraints.matrix = sparse([1, 0, -1, 0]);
    LinearConstraints.lower = -0.1;
    LinearConstraints.upper = 0.1;

    Report = evaluate_control_tightness_mechanisms( ...
        SolverResult, LinearConstraints, ConicConstraints, Reference, Split, config, ...
        [1, 2; 3, 4]);

    verifyTrue(testCase, all(Report.chord_active));
    verifyEqual(testCase, Report.chord_rank, [1; 1]);
    verifyEqual(testCase, abs(Report.chord_tangent), [0, 1; 0, 1], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.chord_reg_component, [0; 0.1], 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.chord_flat, [true; false]);
end


function cones = make_control_cones()
% MAKE_CONTROL_CONES 构造两个 [1;u1;u2] 控制圆盘锥。

    cones = repmat(struct('name', 'control_disk', 'dimension', 3, ...
        'rows', [], 'index', 0), 2, 1);
    cones(1).rows = (1:3).';
    cones(1).index = 1;
    cones(2).rows = (4:6).';
    cones(2).index = 2;
end
