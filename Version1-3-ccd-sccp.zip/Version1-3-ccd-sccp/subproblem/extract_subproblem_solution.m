function CurrentSolution = extract_subproblem_solution( ...
        SolverResult, VariableIndex, CurrentReference, ~, config)
% EXTRACT_SUBPROBLEM_SOLUTION 从 MOSEK 解向量提取 P3 的解（按物理含义分字段）。
%
% CurrentSolution 字段（全部为装配坐标的归一化物理量）：
%   N, tau, PointsBounds       - 节点数、归一化时间与各圈节点范围（继承参考）
%   state                      - N x 5 [r, V, gamma, phi, psi]
%   control.u1, control.u2         - N x 1 倾侧角分量
%   control.P                    - 6 x 1 脉冲 P0~P5
%   t_f                        - 5 x 1 各圈飞行时间
%   xff                        - 5 x 1 末圈远地点终态
%   i                          - 终态轨道倾角
%   dyn_slack, point_slack     - 动力学松弛、衔接松弛 (num_dyn x 5), (5 x 5)
%   unit_norm_slack            - 'sccp' 模式下单位范数共用松弛 η（标量），'regularized' 下为空
%   objective                  - MOSEK 目标值，即 P3 的目标 L（性能指标加附加项加松弛罚项）
%
% 本函数不保存 primal/dual、索引表或锥映射（留在 SolverResult/诊断中）。

    if nargin < 5 || isempty(config)
        config = struct();
    end
    UnitNorm = describe_unit_norm(config);

    if ~SolverResult.success
        error('SCP:UnavailableSubproblemSolution', ...
            '求解失败时不能提取凸子问题解。');
    end

    primal = SolverResult.primal(:);
    num_variables = max(collect_index_values(VariableIndex));
    if numel(primal) ~= num_variables
        error('SCP:InvalidPrimalSize', ...
            'MOSEK 解向量长度必须等于决策变量总数。');
    end
    if any(~isfinite(primal))
        error('SCP:NonfinitePrimalSolution', ...
            'MOSEK 解向量包含 NaN 或 Inf。');
    end

    %% 状态与控制
    CurrentSolution.N = CurrentReference.N;
    CurrentSolution.tau = CurrentReference.tau;
    CurrentSolution.PointsBounds = CurrentReference.PointsBounds;
    CurrentSolution.state = [ ...
        primal(VariableIndex.r), ...
        primal(VariableIndex.V), ...
        primal(VariableIndex.gamma), ...
        primal(VariableIndex.phi), ...
        primal(VariableIndex.psi)];

    CurrentSolution.control.u1 = primal(VariableIndex.u1);
    CurrentSolution.control.u2 = primal(VariableIndex.u2);
    CurrentSolution.control.P = primal(VariableIndex.P);

    %% 时间与终态
    CurrentSolution.t_f = primal(VariableIndex.t_f);
    CurrentSolution.xff = primal(VariableIndex.xff);
    CurrentSolution.i = primal(VariableIndex.xff_i);
    CurrentSolution.objective = SolverResult.objective;

    %% 松弛
    CurrentSolution.dyn_slack = [ ...
        primal(VariableIndex.dyn_slack_r), ...
        primal(VariableIndex.dyn_slack_V), ...
        primal(VariableIndex.dyn_slack_gamma), ...
        primal(VariableIndex.dyn_slack_phi), ...
        primal(VariableIndex.dyn_slack_psi)];

    CurrentSolution.point_slack = [ ...
        primal(VariableIndex.poi_slack_r), ...
        primal(VariableIndex.poi_slack_V), ...
        primal(VariableIndex.poi_slack_gamma), ...
        primal(VariableIndex.poi_slack_phi), ...
        primal(VariableIndex.poi_slack_psi)];
    if UnitNorm.is_sccp
        CurrentSolution.unit_norm_slack = primal(VariableIndex.unit_norm_slack);
    else
        CurrentSolution.unit_norm_slack = [];
    end

    %% 契约检查
    if size(CurrentSolution.state, 1) ~= CurrentSolution.N
        error('SCP:InvalidExtractedStateSize', ...
            '提取状态节点数必须等于 N。');
    end
    if any(~isfinite(CurrentSolution.state), 'all') ...
            || any(~isfinite(CurrentSolution.t_f)) ...
            || ~isfinite(CurrentSolution.objective)
        error('SCP:NonfiniteExtractedSolution', ...
            '提取的解包含 NaN 或 Inf。');
    end
end
