function draw_empty_notice(fig, figure_title, message, config)
% DRAW_EMPTY_NOTICE 在图窗中央写一行说明，用于本轮没有可画数据的情况。

    font_size = config.plot.font_size;
    ax = axes(fig);
    axis(ax, 'off');
    text(ax, 0.5, 0.5, message, 'HorizontalAlignment', 'center', ...
        'FontSize', font_size);
    title(ax, figure_title, 'FontSize', font_size, 'Visible', 'on');
end
