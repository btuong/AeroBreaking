function Regularizer = describe_control_regularizer(config)
% DESCRIBE_CONTROL_REGULARIZER 按 config.objective.control_reg_type 返回控制正则（附加项 Γ）的类型、类别和显示名。
%
% 数学形式:
%   控制 u_i = (u1_i, u2_i) = (cos σ_i, sin σ_i)，ω_i 为按圈梯形积分权，w 为 weight_control_reg。
%   五种附加项 Γ（罚函数 J 用的原函数）及其被推向的 σ（最小化时）:
%       'sum'   Γ = w·Σ ω_i·(u1_i + u2_i)    线性，σ → −135°
%       'u1'    Γ = w·Σ ω_i·u1_i             线性，σ → 180°
%       'u2'    Γ = w·Σ ω_i·u2_i             线性，σ → −90°
%       'norm'     Γ = −w·Σ ω_i·‖u_i‖         凹函数，P3 中取参考控制处的线性化，σ 无固定方向
%       'norm_gap' Γ = w·Σ ω_i·(1 − ‖u_i‖)    非负凹函数（违约距离），P3 中线性化为 w·Σ ω_i·(1 − ē_i^T·u_i)，σ 无固定方向
%       'none'     Γ = 0                       不加附加项（忽略 w）
%   线性三种与 'none' 在 P3 中的项和原函数相同，预测误差为 0；'norm' 与 'norm_gap' 的预测误差不大于 0。
%
% 代码形式:
%   Regularizer 的字段:
%       type             类型字符串，与 config.objective.control_reg_type 一致
%       kind             附加项的类别：线性三种与 'none' 为 'extra_convex'，'norm' 与 'norm_gap' 为 'extra_nonconvex'
%       target_sigma_deg 被推向的 σ（deg）：sum −135、u1 180、u2 −90，norm、norm_gap 与 none 为 NaN
%       label            图表和表格用的中文名：'u1+u2'、'u1'、'u2'、'‖u‖'、'1-‖u‖'、'不加'
%   config 中没有 control_reg_type 字段时按 'norm' 处理（旧运行存下的配置没有这个字段）；
%   未知类型报错。build_objective、evaluate_penalty_function、compute_objective_terms
%   都从这里取类别，不各自写一遍。

    type = 'norm';
    if isfield(config.objective, 'control_reg_type')
        type = config.objective.control_reg_type;
    end

    switch type
        case 'sum'
            kind = 'extra_convex';
            target_sigma_deg = -135;
            label = 'u1+u2';
        case 'u1'
            kind = 'extra_convex';
            target_sigma_deg = 180;
            label = 'u1';
        case 'u2'
            kind = 'extra_convex';
            target_sigma_deg = -90;
            label = 'u2';
        case 'norm'
            kind = 'extra_nonconvex';
            target_sigma_deg = NaN;
            label = '‖u‖';
        case 'norm_gap'
            kind = 'extra_nonconvex';
            target_sigma_deg = NaN;
            label = '1-‖u‖';
        case 'none'
            kind = 'extra_convex';
            target_sigma_deg = NaN;
            label = '不加';
        otherwise
            error('SCP:UnknownControlRegularizer', ...
                '未知的控制正则类型 control_reg_type = ''%s''，可选 sum、u1、u2、norm、norm_gap、none。', ...
                char(string(type)));
    end

    Regularizer = struct('type', type, 'kind', kind, ...
        'target_sigma_deg', target_sigma_deg, 'label', label);
end
