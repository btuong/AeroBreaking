function tests = test_unit_norm_ccd()
% TEST_UNIT_NORM_CCD 核验单位范数约束 ‖u‖ = 1 的两种处理方式：regularized（无损凸化，默认）与 ccd（凹凸分解）。
%
% 覆盖：模式开关与描述函数、P3 的变量布局与装配、J 与目标分项、解的提取、控制量报告
% 与对偶分解、初始参考的归一化、输出层在 ccd 下的全流程，以及默认模式不变。
% 运行前要把本版本各模块加到路径上（SCP.m 开头添加的那组模块）。

    tests = functiontests(localfunctions);
end


function setupOnce(testCase)
% SETUPONCE 生成问题数据、初始参考和 ccd 模式下的 3 轮记录，供各用例共用（testCase.TestData）。

    testData = testCase.TestData;
    testData.config_ccd = build_test_config('ccd', 1, 1, false);
    testData.config_reg = build_test_config('regularized', 1, 1, false);

    [ConstData, InitialState] = initialize_problem(testData.config_ccd);
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, testData.config_ccd);
    testData.ConstData = ConstData;
    testData.InitialReference = InitialReference;
    testData.InitialPropagation = InitialPropagation;

    config = testData.config_ccd;
    [RunState, ~] = initialize_scp_run(InitialReference, InitialPropagation, config);
    History = repmat(create_empty_iteration_record(), 3, 1);
    for iter = 1:3
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
        History(iter) = IterationRecord;
    end
    testData.ccd_history = History;
    testCase.TestData = testData;
end


function config = build_test_config(mode, penalty_weight, slack_max, keep_bounds)
% BUILD_TEST_CONFIG 默认配置加上单位范数模式的设置，并关掉绘图、打印、保存和梯形递推检查。

    config = scp_config_default();
    config.unit_norm.mode = mode;
    config.unit_norm.ccd_penalty_weight = penalty_weight;
    config.unit_norm.ccd_slack_max = slack_max;
    config.unit_norm.ccd_keep_control_bounds = keep_bounds;

    config.plot.enable_initial = false;
    config.plot.enable_iteration = false;
    config.plot.enable_final = false;
    config.output.print_pre_iteration = false;
    config.output.print_iteration = false;
    config.output.print_summary = false;
    config.output.save.brief_text = false;
    config.output.save.detail_text = false;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    config.output.save.control_text = false;
    config.output.save.control_mat = false;
    config.validation.enable_trapezoid_check = false;
end


%% ===== 任务 1：模式开关与描述函数 =====

function test_describe_unit_norm_modes(testCase)
% 默认配置按 regularized 处理，ccd 的字段与配置一致，非法取值报错。

    config = scp_config_default();
    UnitNorm = describe_unit_norm(config);
    verifyEqual(testCase, UnitNorm.mode, 'regularized');
    verifyFalse(testCase, UnitNorm.is_ccd);
    verifyEqual(testCase, UnitNorm.term_name, 'control_reg');
    verifyEqual(testCase, UnitNorm.term_kind, 'extra_nonconvex');
    verifyEqual(testCase, UnitNorm.penalty_weight, 0);
    verifyEqual(testCase, UnitNorm.term_label, '控制正则项');

    % 旧运行存下的配置没有 unit_norm 字段，按 regularized 处理
    legacy = rmfield(config, 'unit_norm');
    LegacyUnitNorm = describe_unit_norm(legacy);
    verifyEqual(testCase, LegacyUnitNorm.mode, 'regularized');
    verifyFalse(testCase, LegacyUnitNorm.is_ccd);

    config.unit_norm.mode = 'ccd';
    config.unit_norm.ccd_penalty_weight = 7;
    config.unit_norm.ccd_slack_max = 0.3;
    config.unit_norm.ccd_keep_control_bounds = true;
    UnitNorm = describe_unit_norm(config);
    verifyTrue(testCase, UnitNorm.is_ccd);
    verifyEqual(testCase, UnitNorm.penalty_weight, 7);
    verifyEqual(testCase, UnitNorm.slack_max, 0.3);
    verifyTrue(testCase, UnitNorm.keep_control_bounds);
    verifyEqual(testCase, UnitNorm.term_name, 'unit_norm_penalty');
    verifyEqual(testCase, UnitNorm.term_label, '单位范数罚项');
    verifyEqual(testCase, UnitNorm.term_kind, 'inequality_penalty');

    config.unit_norm.mode = 'foo';
    verifyError(testCase, @() describe_unit_norm(config), 'SCP:UnknownUnitNormMode');

    config.unit_norm.mode = 'ccd';
    config.unit_norm.ccd_penalty_weight = 0;
    verifyError(testCase, @() describe_unit_norm(config), 'SCP:InvalidUnitNormConfig');
    config.unit_norm.ccd_penalty_weight = 7;
    config.unit_norm.ccd_slack_max = -1;
    verifyError(testCase, @() describe_unit_norm(config), 'SCP:InvalidUnitNormConfig');
end


%% ===== 任务 2：P3 的装配 =====

function test_regularized_variable_layout_unchanged(testCase)
% 默认模式下没有 ε，变量数和 t_f 的位置与改前相同。

    config = scp_config_default();
    [ConstData, InitialState] = initialize_problem(config);
    [InitialReference, ~] = generate_initial_reference(ConstData, InitialState, config);
    N = InitialReference.N;

    [VariableIndex, num_variables] = build_variable_index(InitialReference, ConstData, config);
    verifyEmpty(testCase, VariableIndex.unit_norm_slack);
    verifyEqual(testCase, num_variables, 17 * N + 25);
    verifyEqual(testCase, VariableIndex.t_f(:), ((17 * N + 21):(17 * N + 25)).');
end


function test_ccd_variable_layout(testCase)
% ccd 下多出 N 个 ε，排在 t_f 之后，t_f 的位置不变。

    testData = testCase.TestData;
    N = testData.InitialReference.N;

    [VariableIndex, num_variables] = build_variable_index( ...
        testData.InitialReference, testData.ConstData, testData.config_ccd);
    verifyEqual(testCase, num_variables, 18 * N + 25);
    verifyEqual(testCase, VariableIndex.unit_norm_slack(:), ((17 * N + 26):(18 * N + 25)).');
    verifyEqual(testCase, VariableIndex.t_f(:), ((17 * N + 21):(17 * N + 25)).');
end


function test_ccd_assembled_p3_matches_formulas(testCase)
% ccd 下 P3 的内逼近行、控制锥、边界和目标系数与方案里的公式一致。

    testData = testCase.TestData;
    config = testData.config_ccd;
    ConstData = testData.ConstData;
    Reference = testData.InitialReference;
    N = Reference.N;
    TrustRegionState = initialize_trust_region_state(config);

    [VariableIndex, ~] = build_variable_index(Reference, ConstData, config);
    LinearConstraints = build_linear_constraints(VariableIndex, Reference, ConstData, config);
    ConicConstraints = build_conic_constraints(VariableIndex, Reference, ConstData, config);
    VariableBounds = build_variable_bounds( ...
        VariableIndex, Reference, TrustRegionState, ConstData, config);
    [objective, objective_offset] = build_objective(VariableIndex, Reference, ConstData, config);
    omega = compute_integration_weights(Reference.tau, Reference.PointsBounds);

    % 内逼近行：每行两个非零系数等于 −ē_i，upper 全为 −1，lower 全为 −Inf
    rows = LinearConstraints.row_groups.unit_norm_inner;
    verifyEqual(testCase, numel(rows), N);
    A = full(LinearConstraints.matrix(rows, :));
    u1_reference = Reference.control.u1(:);
    u2_reference = Reference.control.u2(:);
    e1 = u1_reference ./ hypot(u1_reference, u2_reference);
    e2 = u2_reference ./ hypot(u1_reference, u2_reference);
    verifyEqual(testCase, A(sub2ind(size(A), (1:N).', VariableIndex.u1(:))), -e1, 'AbsTol', 1e-15);
    verifyEqual(testCase, A(sub2ind(size(A), (1:N).', VariableIndex.u2(:))), -e2, 'AbsTol', 1e-15);
    verifyEqual(testCase, nnz(A), 2 * N);
    verifyEqual(testCase, LinearConstraints.upper(rows), -ones(N, 1));
    verifyTrue(testCase, all(isinf(LinearConstraints.lower(rows)) & LinearConstraints.lower(rows) < 0));

    % 第 i 个 control_disk 锥
    is_disk = strcmp({ConicConstraints.cones.name}, 'control_disk');
    Disks = ConicConstraints.cones(is_disk);
    verifyNumElements(testCase, Disks, N);
    F = full(ConicConstraints.mapping);
    g = ConicConstraints.offset;
    for i = 1:N
        verifyEqual(testCase, Disks(i).index, i);
        verifyEqual(testCase, Disks(i).tightness_role, 'epigraph');
        r = Disks(i).rows;
        verifyEqual(testCase, r, (3 * i - 2:3 * i).');
        verifyEqual(testCase, F(r(1), VariableIndex.unit_norm_slack(i)), 1);
        verifyEqual(testCase, F(r(2), VariableIndex.u1(i)), 1);
        verifyEqual(testCase, F(r(3), VariableIndex.u2(i)), 1);
        verifyEqual(testCase, g(r), [1; 0; 0]);
    end

    % 边界：ε_i ∈ [0, 1]；u1_i、u2_i ∈ [−2, 2]
    verifyEqual(testCase, VariableBounds.lower(VariableIndex.unit_norm_slack(:)), zeros(N, 1));
    verifyEqual(testCase, VariableBounds.upper(VariableIndex.unit_norm_slack(:)), ones(N, 1));
    verifyEqual(testCase, VariableBounds.lower(VariableIndex.u1(:)), -2 * ones(N, 1));
    verifyEqual(testCase, VariableBounds.upper(VariableIndex.u1(:)), 2 * ones(N, 1));
    verifyEqual(testCase, VariableBounds.lower(VariableIndex.u2(:)), -2 * ones(N, 1));
    verifyEqual(testCase, VariableBounds.upper(VariableIndex.u2(:)), 2 * ones(N, 1));

    % 目标：c(ε) = p·ω，c(u1) = c(u2) = 0，c_fix = 0
    verifyEqual(testCase, objective(VariableIndex.unit_norm_slack(:)), omega, 'RelTol', 1e-15);
    verifyEqual(testCase, reshape(objective(VariableIndex.u1), [], 1), zeros(N, 1));
    verifyEqual(testCase, reshape(objective(VariableIndex.u2), [], 1), zeros(N, 1));
    verifyEqual(testCase, objective_offset, 0);

    % 保留箱形边界时 u1、u2 ∈ [−1, 1]
    config_keep = config;
    config_keep.unit_norm.ccd_keep_control_bounds = true;
    BoundsKeep = build_variable_bounds( ...
        VariableIndex, Reference, TrustRegionState, ConstData, config_keep);
    verifyEqual(testCase, BoundsKeep.lower(VariableIndex.u1(:)), -ones(N, 1));
    verifyEqual(testCase, BoundsKeep.upper(VariableIndex.u1(:)), ones(N, 1));
    verifyEqual(testCase, BoundsKeep.lower(VariableIndex.u2(:)), -ones(N, 1));
    verifyEqual(testCase, BoundsKeep.upper(VariableIndex.u2(:)), ones(N, 1));

    % 退化节点：参考控制第 3 个节点为 (0, 0) 时方向取 (1, 1)/√2
    Degenerate = Reference;
    Degenerate.control.u1(3) = 0;
    Degenerate.control.u2(3) = 0;
    LinearDegenerate = build_linear_constraints(VariableIndex, Degenerate, ConstData, config);
    row3 = full(LinearDegenerate.matrix(LinearDegenerate.row_groups.unit_norm_inner(3), :));
    verifyEqual(testCase, row3(VariableIndex.u1(3)), -sqrt(2) / 2, 'AbsTol', 1e-15);
    verifyEqual(testCase, row3(VariableIndex.u2(3)), -sqrt(2) / 2, 'AbsTol', 1e-15);

    % regularized：没有 unit_norm_inner 行块，control_disk 的行号仍是 [2; 3]
    config_reg = testData.config_reg;
    [IndexReg, ~] = build_variable_index(Reference, ConstData, config_reg);
    LinearReg = build_linear_constraints(IndexReg, Reference, ConstData, config_reg);
    ConicReg = build_conic_constraints(IndexReg, Reference, ConstData, config_reg);
    verifyFalse(testCase, isfield(LinearReg.row_groups, 'unit_norm_inner'));
    DisksReg = ConicReg.cones(strcmp({ConicReg.cones.name}, 'control_disk'));
    verifyEqual(testCase, DisksReg(1).rows, (1:3).');
    verifyEqual(testCase, DisksReg(1).tightness_role, 'lossless');
    FReg = full(ConicReg.mapping);
    verifyEqual(testCase, FReg(1, :), zeros(1, numel(FReg(1, :))));
    verifyEqual(testCase, FReg(2, IndexReg.u1(1)), 1);
    verifyEqual(testCase, FReg(3, IndexReg.u2(1)), 1);
end


%% ===== 任务 3：J、目标分项与解的提取 =====

function test_regularized_term_list_unchanged(testCase)
% regularized 下 J 与 L 的分项名、类别与改前相同。

    testData = testCase.TestData;
    config = testData.config_reg;
    ConstData = testData.ConstData;
    Reference = testData.InitialReference;
    TrustRegionState = initialize_trust_region_state(config);
    expected_names = {'terminal_inclination', 'terminal_apoapsis', 'impulse', ...
        'point_slack', 'dyn_slack', 'control_reg'};
    expected_kinds = {'equality_penalty', 'equality_penalty', 'cost_nonconvex', ...
        'equality_penalty', 'equality_penalty', 'extra_nonconvex'};

    P2Feasibility = check_p2_feasibility(Reference, ConstData, config);
    PenaltyFunction = evaluate_penalty_function(Reference, P2Feasibility, ConstData, config);
    verifyEqual(testCase, {PenaltyFunction.terms.name}, expected_names);
    verifyEqual(testCase, {PenaltyFunction.terms.kind}, expected_kinds);

    [VariableIndex, ~] = build_variable_index(Reference, ConstData, config);
    objective = build_objective(VariableIndex, Reference, ConstData, config);
    LinearConstraints = build_linear_constraints(VariableIndex, Reference, ConstData, config);
    VariableBounds = build_variable_bounds( ...
        VariableIndex, Reference, TrustRegionState, ConstData, config);
    ConicConstraints = build_conic_constraints(VariableIndex, Reference, ConstData, config);
    SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ConicConstraints, config);
    ObjectiveTerms = compute_objective_terms( ...
        objective, SolverResult.primal, VariableIndex, config);
    verifyEqual(testCase, {ObjectiveTerms.terms.name}, expected_names);
    verifyEqual(testCase, {ObjectiveTerms.terms.kind}, expected_kinds);
    Solution = extract_subproblem_solution(SolverResult, VariableIndex, Reference, ConstData, config);
    verifyEmpty(testCase, Solution.unit_norm_slack);
end


function test_ccd_circle_term_matches_true_function(testCase)
% ccd 下 J 的最后一项是单位范数罚项，等于 p·Σω_i·max(‖u_i‖−1, 0)；Γ = 0。

    testData = testCase.TestData;
    config = testData.config_ccd;
    p = config.unit_norm.ccd_penalty_weight;

    verifyNumElements(testCase, testData.ccd_history, 3);
    for k = 1:numel(testData.ccd_history)
        Record = testData.ccd_history(k);
        Evaluation = Record.trust.evaluation;
        Report = Record.subproblem.control_report;
        verifyEqual(testCase, Evaluation.term_names{end}, 'unit_norm_penalty');
        verifyEqual(testCase, Evaluation.term_kinds{end}, 'inequality_penalty');
        % 候选解处的 J 用控制量报告里的 ω 和 ‖u‖ 重算
        expected = p * sum(Report.omega .* max(Report.u_norm - 1, 0));
        verifyEqual(testCase, Evaluation.term_candidate(end), expected, 'AbsTol', 1e-12);
        verifyEqual(testCase, Evaluation.group.extra.candidate, 0);
        verifyFalse(testCase, isempty(Record.solution.unit_norm_slack));
        verifyNumElements(testCase, Record.solution.unit_norm_slack, Record.solution.N);
    end
end


%% ===== 任务 4：控制量报告、对偶分解、乘子与初始参考 =====

function test_ccd_zero_step_feasible_on_unit_norm(testCase)
% 初始参考和每个被接受轮之后的参考，零步长对 ccd 的 P3 可行（u = ū，ε = max(‖ū‖−1, 0)）。

    testData = testCase.TestData;
    config = testData.config_ccd;
    ConstData = testData.ConstData;
    TrustRegionState = initialize_trust_region_state(config);

    References = {testData.InitialReference};
    for k = 1:numel(testData.ccd_history)
        Record = testData.ccd_history(k);
        if Record.trust.accept_candidate
            References{end + 1} = Record.reference_after; %#ok<AGROW>
        end
    end
    verifyGreaterThan(testCase, numel(References), 1);

    for r = 1:numel(References)
        Reference = References{r};
        N = Reference.N;
        [VariableIndex, num_variables] = build_variable_index(Reference, ConstData, config);
        LinearConstraints = build_linear_constraints(VariableIndex, Reference, ConstData, config);
        ConicConstraints = build_conic_constraints(VariableIndex, Reference, ConstData, config);
        VariableBounds = build_variable_bounds( ...
            VariableIndex, Reference, TrustRegionState, ConstData, config);
        z = zeros(num_variables, 1);
        z(VariableIndex.u1) = Reference.control.u1(:);
        z(VariableIndex.u2) = Reference.control.u2(:);
        u_norm = hypot(Reference.control.u1(:), Reference.control.u2(:));
        z(VariableIndex.unit_norm_slack) = max(u_norm - 1, 0);

        % control_disk 各锥的可行性残差
        cone_values = ConicConstraints.mapping * z + ConicConstraints.offset;
        for i = 1:N
            Cone = ConicConstraints.cones(strcmp({ConicConstraints.cones.name}, 'control_disk') ...
                & [ConicConstraints.cones.index] == i);
            residual = norm(cone_values(Cone.rows(2:3))) - cone_values(Cone.rows(1));
            verifyLessThanOrEqual(testCase, residual, 1e-12);
        end
        % unit_norm_inner 各行 A·z − upper 的残差：初始参考在圆上，≤ 1e-12；被接受轮之后的参考
        % 取自 P3 的解，内逼近行的残差在求解器的原始可行性容差以内，≤ config.solver.co_tol_pfeas
        rows = LinearConstraints.row_groups.unit_norm_inner;
        residual = max(LinearConstraints.matrix(rows, :) * z - LinearConstraints.upper(rows));
        if r == 1
            tolerance = 1e-12;
        else
            tolerance = config.solver.co_tol_pfeas;
        end
        verifyLessThanOrEqual(testCase, residual, tolerance, ...
            sprintf('参考 %d（1 为初始参考，其余为被接受轮之后的参考）', r));
        % 0 ≤ ε ≤ ε_max
        verifyGreaterThanOrEqual(testCase, min(z(VariableIndex.unit_norm_slack)), 0);
        verifyLessThanOrEqual(testCase, ...
            max(z(VariableIndex.unit_norm_slack)), config.unit_norm.ccd_slack_max);
    end
end


function test_ccd_candidates_stay_outside_and_term_is_exact(testCase)
% 3 轮里每轮 min‖u‖ ≥ 1，ε 取紧，单位范数罚项的预测误差为 0；单位范数内逼近行和控制锥
% 在候选解处的原始残差 ≤ 1e-6。

    testData = testCase.TestData;
    config = testData.config_ccd;
    p = config.unit_norm.ccd_penalty_weight;

    for k = 1:numel(testData.ccd_history)
        Record = testData.ccd_history(k);
        Report = Record.subproblem.control_report;
        Evaluation = Record.trust.evaluation;
        verifyGreaterThanOrEqual(testCase, min(Report.u_norm), 1 - 1e-8);
        verifyGreaterThanOrEqual(testCase, ...
            min(Report.unit_norm_slack - max(Report.u_norm - 1, 0)), -1e-7);
        verifyLessThanOrEqual(testCase, ...
            abs(Evaluation.term_prediction_error(end)), 1e-6 * max(1, p));
        verifyFalse(testCase, Evaluation.convex_error_flag);
    end

    % 原始残差直接按候选解的解向量算。不用 P3 解检查的总通过标志：它的阈值 1e-7
    % 在 regularized 下也会被终端、衔接行的原始残差偶尔超过，与 ccd 无关
    for k = 1:numel(testData.ccd_history)
        Record = testData.ccd_history(k);
        Reference = Record.reference_before;
        [VariableIndex, ~] = build_variable_index(Reference, testData.ConstData, config);
        LinearConstraints = build_linear_constraints( ...
            VariableIndex, Reference, testData.ConstData, config);
        ConicConstraints = build_conic_constraints( ...
            VariableIndex, Reference, testData.ConstData, config);
        primal = Record.subproblem.solver.primal(:);

        rows = LinearConstraints.row_groups.unit_norm_inner(:);
        verifyLessThanOrEqual(testCase, ...
            max(LinearConstraints.matrix(rows, :) * primal - LinearConstraints.upper(rows)), 1e-6);
        cone_values = ConicConstraints.mapping * primal + ConicConstraints.offset;
        disks = ConicConstraints.cones(strcmp({ConicConstraints.cones.name}, 'control_disk'));
        leading = zeros(numel(disks), 1);
        vector_norm = zeros(numel(disks), 1);
        for i = 1:numel(disks)
            leading(i) = cone_values(disks(i).rows(1));
            vector_norm(i) = norm(cone_values(disks(i).rows(2:end)));
        end
        verifyLessThanOrEqual(testCase, max(vector_norm - leading), 1e-6);
    end
end


function test_ccd_dual_split_residual(testCase)
% 对偶可用的轮：驻点残差 ≤ 1e-6，s_inner,i = ē_i·y_i，κ̂_i = p·ω_i − slx(ε_i) + sux(ε_i)。

    testData = testCase.TestData;
    config = testData.config_ccd;
    p = config.unit_norm.ccd_penalty_weight;

    num_checked = 0;
    for k = 1:numel(testData.ccd_history)
        Record = testData.ccd_history(k);
        Report = Record.subproblem.control_report;
        if ~Report.dual_available
            continue;
        end
        num_checked = num_checked + 1;
        verifyLessThanOrEqual(testCase, ...
            max(abs(Report.stationarity_residual), [], 'all'), 1e-6);

        % 重建这一轮的索引和行块，取 y 在 unit_norm_inner 行上的值
        Reference = Record.reference_before;
        [VariableIndex, ~] = build_variable_index(Reference, testData.ConstData, config);
        LinearConstraints = build_linear_constraints(VariableIndex, Reference, ...
            testData.ConstData, config);
        rows = LinearConstraints.row_groups.unit_norm_inner(:);
        y_inner = Record.subproblem.solver.dual.y(rows);
        % ē_i = −A(i, u_i)（行 i 只含 u_i 的两个分量）
        A = full(LinearConstraints.matrix(rows, :));
        e1 = -A(sub2ind(size(A), (1:numel(rows)).', VariableIndex.u1(:)));
        e2 = -A(sub2ind(size(A), (1:numel(rows)).', VariableIndex.u2(:)));
        y_tol = 1e-12 * max(1, max(abs(y_inner)));
        verifyEqual(testCase, Report.s_inner(:, 1), e1 .* y_inner, 'AbsTol', y_tol);
        verifyEqual(testCase, Report.s_inner(:, 2), e2 .* y_inner, 'AbsTol', y_tol);
        verifyEqual(testCase, Report.lambda_inner, abs(y_inner), 'AbsTol', y_tol);

        % κ̂_i = p·ω_i − slx(ε_i) + sux(ε_i)（ε_i 列的驻点条件，ε 不进 A 和 F 的其余行）。
        % 求解器返回的对偶解在原始坐标下有 1e-6 量级的绝对误差，所以除绝对容差外再用相对容差
        slx = Record.subproblem.solver.dual.slx(VariableIndex.unit_norm_slack(:));
        sux = Record.subproblem.solver.dual.sux(VariableIndex.unit_norm_slack(:));
        verifyEqual(testCase, Report.cone_dual_leading, ...
            p * Report.omega - slx + sux, 'AbsTol', 1e-9 * max(1, p), 'RelTol', 1e-3);
    end
    verifyGreaterThan(testCase, num_checked, 0);
end


function test_ccd_slack_cap_is_reported(testCase)
% p 远低于向外需求、ε_max = 0.1 时 P3 仍有界，触上界的节点被报告。

    testData = testCase.TestData;
    config = build_test_config('ccd', 1e-6, 0.1, false);
    ConstData = testData.ConstData;
    [RunState, ~] = initialize_scp_run( ...
        testData.InitialReference, testData.InitialPropagation, config);
    [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
        RunState.current_reference, RunState.trust_region, ConstData, config, 1);

    verifyTrue(testCase, SubproblemDiag.success);
    Report = SubproblemDiag.control_report;
    verifyTrue(testCase, any(Report.slack_capped));
    verifyEqual(testCase, Report.summary_total.num_slack_capped, sum(Report.slack_capped));
    verifyGreaterThanOrEqual(testCase, max(Report.unit_norm_slack), 0.1 - 1e-9);
end


function test_ccd_initial_reference_normalized(testCase)
% ccd 下 initialize_scp_run 把当前参考的控制归一化到圆上；regularized 下保持原值。

    testData = testCase.TestData;
    InitialReference = testData.InitialReference;
    % 第 1、2、3 个节点的模长改为 0.5、1、1.5（方向不变，仍为 45°），第 4 个节点改为零向量
    InitialReference.control.u1(1:3) = [0.5; 1; 1.5] * sqrt(2) / 2;
    InitialReference.control.u2(1:3) = [0.5; 1; 1.5] * sqrt(2) / 2;
    InitialReference.control.u1(4) = 0;
    InitialReference.control.u2(4) = 0;

    [RunStateCcd, ~] = initialize_scp_run( ...
        InitialReference, testData.InitialPropagation, testData.config_ccd);
    norm_ccd = hypot(RunStateCcd.current_reference.control.u1, ...
        RunStateCcd.current_reference.control.u2);
    verifyEqual(testCase, norm_ccd, ones(size(norm_ccd)), 'AbsTol', 1e-12);
    % 零向量节点得到 (1, 1)/√2
    verifyEqual(testCase, RunStateCcd.current_reference.control.u1(4), sqrt(2) / 2, 'AbsTol', 1e-12);
    verifyEqual(testCase, RunStateCcd.current_reference.control.u2(4), sqrt(2) / 2, 'AbsTol', 1e-12);
    % RunState.initial_reference 保持原样
    verifyEqual(testCase, RunStateCcd.initial_reference.control.u1(1), 0.5 * sqrt(2) / 2, 'AbsTol', 1e-15);
    verifyEqual(testCase, RunStateCcd.initial_reference.control.u1(4), 0);

    [RunStateReg, ~] = initialize_scp_run( ...
        InitialReference, testData.InitialPropagation, testData.config_reg);
    verifyEqual(testCase, RunStateReg.current_reference.control.u1, InitialReference.control.u1);
    verifyEqual(testCase, RunStateReg.current_reference.control.u2, InitialReference.control.u2);
end


function test_empty_control_report_has_unit_norm_fields(testCase)
% 未评价的控制量报告和汇总含全部新字段。

    Report = create_empty_control_report('solver_failed');
    verifyTrue(testCase, isfield(Report, 's_inner'));
    verifyTrue(testCase, isfield(Report, 'lambda_inner'));
    verifyTrue(testCase, isfield(Report, 'unit_norm_slack'));
    verifyTrue(testCase, isfield(Report, 'slack_capped'));
    verifyTrue(testCase, isfield(Report, 'cone_dual_leading'));
    Summary = create_empty_control_summary();
    verifyTrue(testCase, isfield(Summary, 'max_inward_gap'));
    verifyTrue(testCase, isfield(Summary, 'max_outward_gap'));
    verifyTrue(testCase, isfield(Summary, 'num_slack_capped'));
    verifyTrue(testCase, isfield(Report.summary_total, 'max_inward_gap'));
end


%% ===== 任务 5：输出层 =====

function test_ccd_entry_outputs_run(testCase)
% ccd 全输出的跑通检查：ccd 配置（p = 1）跑 2 轮，开逐轮图和全程图（不显示、不导出），
% 存简略、详细、控制量文本和控制量 MAT，流程同 SCP.m。详细文件每轮有“单位范数”一行，
% 控制量文本头部有“单位范数处理: ccd”。保存目录用版本根下的临时目录，测试结束删除。

    testData = testCase.TestData;
    ConstData = testData.ConstData;
    config = build_test_config('ccd', 1, 1, false);
    config.iter.max_scp_iter = 2;
    config.plot.enable_iteration = true;
    config.plot.enable_final = true;
    config.plot.visibility = 'off';
    config.plot.save_figures = false;
    config.output.save.brief_text = true;
    config.output.save.detail_text = true;
    config.output.save.control_text = true;
    config.output.save.control_mat = true;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    save_directory = 'results/tmp_entry_check';
    config.output.save.directory = save_directory;

    version_root = fileparts(fileparts(mfilename('fullpath')));
    output_directory = fullfile(version_root, save_directory);
    cleanup = onCleanup(@() remove_directory(output_directory));

    % 流程同 SCP.m：初始化、2 轮主循环、收尾、绘图、整理结果、保存
    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        testData.InitialReference, testData.InitialPropagation, config);
    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ConstData, config, iter);
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);
    end
    close_figures = onCleanup(@() close('all'));
    FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory);
    PlotReport = plot_scp_result(FinalizedRun, ConstData, config);
    Result = build_scp_result(FinalizedRun);
    SaveReport = save_scp_result(FinalizedRun, ConstData, config);
    verifyTrue(testCase, SaveReport.success);

    % 详细文件：每轮的乘子表（multipliers 块全部展开）里有一行“单位范数内逼近”
    detail_text = fileread(SaveReport.files(strcmp({SaveReport.files.name}, 'detail_text')).path);
    num_rounds = numel(FinalizedRun.history);
    verifyEqual(testCase, numel(regexp(detail_text, '单位范数内逼近', 'match')), num_rounds);
    % 控制量文本头部有“单位范数处理: ccd”
    control_text = fileread(SaveReport.files(strcmp({SaveReport.files.name}, 'control_text')).path);
    verifyNotEmpty(testCase, regexp(control_text, '^单位范数处理: ccd \| p ', 'match', 'once', 'lineanchors'));
    % 控制量 MAT 里 ControlExport 带三个新字段
    Saved = load(SaveReport.files(strcmp({SaveReport.files.name}, 'control_mat')).path, 'ControlExport');
    verifyEqual(testCase, Saved.ControlExport.unit_norm_mode, 'ccd');
    verifyEqual(testCase, Saved.ControlExport.ccd_penalty_weight, 1);
    verifyEqual(testCase, Saved.ControlExport.ccd_slack_max, 1);
    verifyTrue(testCase, PlotReport.success);
end


function remove_directory(directory)
% REMOVE_DIRECTORY 删除测试用的临时目录（不存在时不做任何事）。

    if isfolder(directory)
        rmdir(directory, 's');
    end
end
