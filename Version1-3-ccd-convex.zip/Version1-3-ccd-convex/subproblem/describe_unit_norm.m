function UnitNorm = describe_unit_norm(config)
% DESCRIBE_UNIT_NORM 按 config.unit_norm 返回单位范数约束 ‖u‖ = 1 的处理方式、类别和显示名。
%
% 数学形式:
%   控制 u_i = (u1_i, u2_i) = (cos σ_i, sin σ_i)，P1 要求 u1_i² + u2_i² = 1。P3 中两种处理:
%       'regularized'（默认）无损凸化：‖u_i‖ ≤ 1 作硬约束（锥角色 lossless），目标里加控制正则项
%                   Γ（按 config.objective.control_reg_type，见 describe_control_regularizer）把解推回圆周
%       'ccd_lu'    凹凸分解（Lu 2020 原文 Eqs. (40)、(71)-(74)）：凸的一半 ‖u_i‖ ≤ 1 原样保留
%                   并逐点松弛为 ‖u_i‖ ≤ 1 + ε_i；松弛 ε_i 罚 p·ε_i（不乘时间测度积分权 ω_i）；
%                   凹的一半 −(‖u_i‖² − 1) ≤ 0 在参考控制 ū_i 处平方线性化为
%                   −2·ū1_i·u1_i − 2·ū2_i·u2_i ≤ −(1 + ‖ū_i‖²)。没有控制正则项（Γ = 0）；
%                   圆约束组在 J = C + Θ 里是罚项 Θ 的一项 p·Σ max(‖u_i‖ − 1, 0)，类别 inequality_penalty
%   p 为 ccd_penalty_weight，ε_max 为 ccd_slack_max。
%
% 代码形式:
%   UnitNorm 的字段:
%       mode                      模式字符串，与 config.unit_norm.mode 一致
%       is_ccd_lu                 是否为 ccd_lu 模式（逻辑量）
%       penalty_weight            p；非 ccd_lu 时为 0
%       slack_max                 ε_max；非 ccd_lu 时为 0
%       keep_control_bounds       ccd_lu 下是否保留 u1、u2 的 ±1 边界；非 ccd_lu 时为 false
%       normalize_initial_control ccd_lu 下是否对非零初始参考控制做归一化；非 ccd_lu 时为 false
%       term_name                 圆约束组在目标分项里的名字：regularized 为 'control_reg'，
%                                 ccd_lu 为 'unit_norm_penalty'
%       term_label                显示名：'控制正则项' 或 '单位范数罚项'
%       term_kind                 分项类别：regularized 取 describe_control_regularizer(config).kind，
%                                 ccd_lu 为 'inequality_penalty'
%   config 中没有 unit_norm 字段时按 'regularized' 处理（旧运行存下的配置没有这个字段）；
%   未知模式报错 SCP:UnknownUnitNormMode；ccd_lu 下 p 或 ε_max 非有限正实数报错
%   SCP:InvalidUnitNormConfig。

    mode = 'regularized';
    if isfield(config, 'unit_norm') && isfield(config.unit_norm, 'mode')
        mode = config.unit_norm.mode;
    end

    switch mode
        case 'regularized'
            is_ccd_lu = false;
            penalty_weight = 0;
            slack_max = 0;
            keep_control_bounds = false;
            normalize_initial_control = false;
            term_name = 'control_reg';
            term_label = '控制正则项';
            term_kind = describe_control_regularizer(config).kind;
        case 'ccd_lu'
            is_ccd_lu = true;
            unit_norm_config = config.unit_norm;
            penalty_weight = unit_norm_config.ccd_penalty_weight;
            slack_max = unit_norm_config.ccd_slack_max;
            if isfield(unit_norm_config, 'ccd_keep_control_bounds')
                keep_control_bounds = logical(unit_norm_config.ccd_keep_control_bounds);
            else
                keep_control_bounds = false;
            end
            if isfield(unit_norm_config, 'ccd_normalize_initial_control')
                normalize_initial_control = ...
                    logical(unit_norm_config.ccd_normalize_initial_control);
            else
                normalize_initial_control = true;
            end
            if ~(isscalar(penalty_weight) && isnumeric(penalty_weight) ...
                    && isreal(penalty_weight) && isfinite(penalty_weight) ...
                    && penalty_weight > 0) ...
                    || ~(isscalar(slack_max) && isnumeric(slack_max) ...
                    && isreal(slack_max) && isfinite(slack_max) ...
                    && slack_max > 0)
                error('SCP:InvalidUnitNormConfig', ...
                    ['ccd_lu 模式要求 ccd_penalty_weight（p）和 ccd_slack_max（ε 上界）' ...
                    '都是有限正实数，当前为 %s 和 %s。'], ...
                    mat2str(penalty_weight), mat2str(slack_max));
            end
            term_name = 'unit_norm_penalty';
            term_label = '单位范数罚项';
            term_kind = 'inequality_penalty';
        otherwise
            error('SCP:UnknownUnitNormMode', ...
                '未知的单位范数处理方式 unit_norm.mode = ''%s''，可选 regularized、ccd_lu。', ...
                char(string(mode)));
    end

    UnitNorm = struct('mode', mode, 'is_ccd_lu', is_ccd_lu, ...
        'penalty_weight', penalty_weight, 'slack_max', slack_max, ...
        'keep_control_bounds', keep_control_bounds, ...
        'normalize_initial_control', normalize_initial_control, ...
        'term_name', term_name, 'term_label', term_label, 'term_kind', term_kind);
end
