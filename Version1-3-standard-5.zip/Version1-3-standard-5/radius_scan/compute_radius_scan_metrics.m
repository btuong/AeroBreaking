function Metrics = compute_radius_scan_metrics(Points, actual_index, Attempt, ...
        repair_check, config)
% COMPUTE_RADIUS_SCAN_METRICS 由一轮的扫描记录算评价量: 拐点、能维持的最大半径、分区、G(r)、有效下降、ΔJ 比、阶段度量。
%
% 目标分三部分 J = C + Γ + Θ（性能指标、附加项、罚项）。G、有效下降、阶段度量按
% 性能指标和附加项各算一份（下标 C、Γ，字段后缀 _cost、_extra）；拐点、分区、ΔJ 比、
% 检查式和复现自检按 J 或 ΔL 算，只有一份。
%
% 数学形式（r 都是扫到的半径，只在解出的半径里取；d_0 为拐点处的最优步长）:
%   拐点 r_0          松弛为零的最小半径（松弛为零所需的半径）
%   能维持的最大半径  满足 ρ ≥ ρ1 的最大半径 r_h
%   分区              r > r_h（或没有能维持的半径）为“偏大”；否则 r < r_0（或松弛都
%                     不为零）为“偏小”；其余 r_0 ≤ r ≤ r_h 为“合适”
%   G_C(r)            = ΔL:性能指标(r) − ΔL:性能指标(r_0) = C̃(d_0) − C̃(d(r))，扣掉
%                     纯修复后性能指标的预测下降（拐点左边只修罚项，修复会抬升性能
%                     指标，拐点处的值算作修复的代价）
%   G_Γ(r)            = ΔL:附加项(r) − ΔL:附加项(r_0) = Γ̃(d_0) − Γ̃(d(r))
%                     原来的 G 含附加项，等于现在的 G_C + G_Γ
%   修复后的值        以半径 r 的候选解为参考、按修复半径再解一次 P3，那次 P3 的
%                     性能指标 C̃ 和附加项 Γ̃（repair_cost_p3、repair_extra_p3）
%   有效下降 E_C(r)   = C̃(d_0) − 修复后的性能指标，E_Γ(r) = Γ̃(d_0) − 修复后的附加项；
%                     只在修复后松弛为零（留下的罚项修得掉）时算，是 G 的实测对照
%   G 之和随 r 不减   拐点及其右边（松弛为零的半径上）P3 最小化的是 C̃ + Γ̃，所以
%                     G_C + G_Γ 随 r 不减；G_C 单独可以为负（P3 用性能指标的上升换
%                     附加项的下降）。容差同弦的检查
%   ΔJ 比             ΔJ(r^k) / max_r ΔJ(r)，r^k 是这一轮运行时实际用的半径；最大 ΔJ
%                     不为正时为 NaN
%   阶段度量          ΔL:性能指标(r_top) 和 ΔL:附加项(r_top)，r_top 为扫到的最大半径
%                     （默认就是 r_max），这两部分各自的驻点度量
%   检查式 (2.15)     ΔL(r) 随 r 不减，且不小于弦 (r/r_top)·ΔL(r_top)
%   复现自检          扫描复用主链的构建、求解和求值函数，r^k 那一行应复现运行时这一轮
%                     的 ΔL、D：相对差 |X_扫描 − X_运行| / max(|ΔL_运行|, 1e-12) 都不超过
%                     1e-6 记为复现；对不上说明扫描和运行用的设置不同（如求解器容差）
%
% 输入:
%   Points       - 1 x K 扫描记录，按 r 从大到小
%   actual_index - Points 里 r^k 那一项的下标
%   Attempt      - 运行时这一轮的记录（ScanRound.attempt: subproblem_success、
%                  predicted_reduction、prediction_error、ratio）
%   repair_check - 是否做了修复检查（没做时有效下降全为 NaN）
%   config       - 读取 config.trust_region.shrink_ratio
%
% 输出 Metrics: zero_radius、zero_index、hold_radius、order_text、check_text、
% violation_text、gain_sum_text、zones（1 x K 元胞，没解出的为 ''）、gain_cost、
% gain_extra、effective_drop_cost、effective_drop_extra、repairable（1 x K，修复后
% 松弛为零）、best_index、max_actual_reduction、actual_radius、actual_zone、
% actual_ratio、actual_share、actual_gain_cost、actual_gain_extra、
% actual_effective_drop_cost、actual_effective_drop_extra、stage_radius、stage_cost、
% stage_extra、replay_available、replay_reduction_gap、replay_error_gap、replay_ok、
% run_ratio。没有的量为 NaN。
%
% 本函数依次完成：
%   1. 找拐点和能维持的最大半径，说明两者的先后。
%   2. 给每个半径分区。
%   3. 算 G(r) 和有效下降 E(r)，性能指标和附加项各一份。
%   4. 算 ΔJ 比、本轮实际半径的各量和阶段度量。
%   5. 检查式 (2.15)，和拐点右边 G_C + G_Γ 随 r 不减。
%   6. 复现自检: r^k 那一行和运行时这一轮比 ΔL、D。

    shrink_ratio = config.trust_region.shrink_ratio;
    ok = [Points.success];
    radius = [Points.radius_scale];
    num_points = numel(Points);

    %% 1. 找拐点和能维持的最大半径，说明两者的先后
    held = ok & [Points.ratio_available] & [Points.ratio] >= shrink_ratio;
    Metrics.hold_radius = NaN;
    if any(held)
        Metrics.hold_radius = max(radius(held));
    end
    zeroed = ok & [Points.slack_zero];
    Metrics.zero_radius = NaN;
    Metrics.zero_index = NaN;
    if any(zeroed)
        [Metrics.zero_radius, position] = min(radius(zeroed));
        zero_candidates = find(zeroed);
        Metrics.zero_index = zero_candidates(position);
    end
    if isnan(Metrics.hold_radius)
        Metrics.order_text = '扫到的半径里没有能维持的';
    elseif isnan(Metrics.zero_radius) || Metrics.zero_radius > Metrics.hold_radius
        Metrics.order_text = '能维持的范围内松弛不能为零';
    else
        Metrics.order_text = '能维持的范围内松弛能为零';
    end

    %% 2. 给每个半径分区
    Metrics.zones = repmat({''}, 1, num_points);
    for k = find(ok)
        if isnan(Metrics.hold_radius) || radius(k) > Metrics.hold_radius
            Metrics.zones{k} = '偏大';
        elseif isnan(Metrics.zero_radius) || radius(k) < Metrics.zero_radius
            Metrics.zones{k} = '偏小';
        else
            Metrics.zones{k} = '合适';
        end
    end

    %% 3. 算 G(r) 和有效下降 E(r)，性能指标和附加项各一份
    cost_predicted = [Points.cost_predicted];
    extra_predicted = [Points.extra_predicted];
    Metrics.gain_cost = nan(1, num_points);
    Metrics.gain_extra = nan(1, num_points);
    Metrics.effective_drop_cost = nan(1, num_points);
    Metrics.effective_drop_extra = nan(1, num_points);
    Metrics.repairable = ok & [Points.repair_slack_zero];
    knee = Metrics.zero_index;
    if ~isnan(knee)
        Metrics.gain_cost(ok) = cost_predicted(ok) - cost_predicted(knee);
        Metrics.gain_extra(ok) = extra_predicted(ok) - extra_predicted(knee);
        if repair_check
            % 拐点处 P3 的性能指标 C̃(d_0)、附加项 Γ̃(d_0) 当作起点
            usable = Metrics.repairable;
            repair_cost = [Points.repair_cost_p3];
            repair_extra = [Points.repair_extra_p3];
            Metrics.effective_drop_cost(usable) = ...
                Points(knee).cost_p3 - repair_cost(usable);
            Metrics.effective_drop_extra(usable) = ...
                Points(knee).extra_p3 - repair_extra(usable);
        end
    end

    %% 4. 算 ΔJ 比、本轮实际半径的各量和阶段度量
    actual_reduction = [Points.actual_reduction];
    Metrics.best_index = NaN;
    Metrics.max_actual_reduction = NaN;
    if any(ok)
        candidates = find(ok);
        [Metrics.max_actual_reduction, position] = max(actual_reduction(ok));
        Metrics.best_index = candidates(position);
    end
    Actual = Points(actual_index);
    Metrics.actual_radius = Actual.radius_scale;
    Metrics.actual_zone = Metrics.zones{actual_index};
    Metrics.actual_ratio = NaN;
    if Actual.ratio_available
        Metrics.actual_ratio = Actual.ratio;
    end
    Metrics.actual_share = NaN;
    if Actual.success && Metrics.max_actual_reduction > 0
        Metrics.actual_share = Actual.actual_reduction / Metrics.max_actual_reduction;
    end
    Metrics.actual_gain_cost = Metrics.gain_cost(actual_index);
    Metrics.actual_gain_extra = Metrics.gain_extra(actual_index);
    Metrics.actual_effective_drop_cost = Metrics.effective_drop_cost(actual_index);
    Metrics.actual_effective_drop_extra = Metrics.effective_drop_extra(actual_index);
    Metrics.stage_radius = NaN;
    Metrics.stage_cost = NaN;
    Metrics.stage_extra = NaN;
    if any(ok)
        [Metrics.stage_radius, position] = max(radius(ok));
        candidates = find(ok);
        Metrics.stage_cost = cost_predicted(candidates(position));
        Metrics.stage_extra = extra_predicted(candidates(position));
    end

    %% 5. 检查式 (2.15)，和拐点右边 G_C + G_Γ 随 r 不减
    [Metrics.check_text, Metrics.violation_text] = check_reduction_chord( ...
        radius(ok), [Points(ok).predicted_reduction]);
    zero_ok = ok & [Points.slack_zero];
    Metrics.gain_sum_text = check_gain_sum(radius(zero_ok), ...
        Metrics.gain_cost(zero_ok) + Metrics.gain_extra(zero_ok));

    %% 6. 复现自检: r^k 那一行和运行时这一轮比 ΔL、D
    % 运行时 P3 失败或扫描在 r^k 上没解出时没有可比的
    Metrics.run_ratio = Attempt.ratio;
    Metrics.replay_available = Actual.success && Attempt.subproblem_success;
    Metrics.replay_reduction_gap = NaN;
    Metrics.replay_error_gap = NaN;
    Metrics.replay_ok = false;
    if Metrics.replay_available
        scale = max(abs(Attempt.predicted_reduction), 1e-12);
        Metrics.replay_reduction_gap = ...
            abs(Actual.predicted_reduction - Attempt.predicted_reduction) / scale;
        Metrics.replay_error_gap = ...
            abs(Actual.prediction_error - Attempt.prediction_error) / scale;
        Metrics.replay_ok = Metrics.replay_reduction_gap <= 1e-6 ...
            && Metrics.replay_error_gap <= 1e-6;
    end
end


function [check_text, violation_text] = check_reduction_chord(radius, reduction)
% CHECK_REDUCTION_CHORD 检查 ΔL(r) 随 r 不减，且不小于弦 (r/r_top)·ΔL(r_top)；不满足时列出半径。

    check_text = '求解成功的半径不足两个，无法检查';
    violation_text = '';
    if numel(radius) < 2
        return;
    end
    [sorted_radius, order] = sort(radius, 'ascend');
    reduction = reduction(order);
    tolerance = 1e-8 * max(max(abs(reduction)), 1);
    not_monotone = [false, diff(reduction) < -tolerance];
    top_radius = sorted_radius(end);
    chord = sorted_radius / top_radius * reduction(end);
    below_chord = reduction < chord - tolerance;
    if ~any(not_monotone) && ~any(below_chord)
        check_text = sprintf( ...
            'ΔL(r) 随 r 单调不减，且都不小于弦 (r/%.4g)·ΔL(%.4g)', ...
            top_radius, top_radius);
        return;
    end
    check_text = '不满足';
    parts = {};
    if any(not_monotone)
        parts{end + 1} = ['不单调不减: r = ' format_radius_list( ...
            sorted_radius(not_monotone))];
    end
    if any(below_chord)
        parts{end + 1} = ['低于弦: r = ' format_radius_list( ...
            sorted_radius(below_chord))];
    end
    violation_text = strjoin(parts, '; ');
end


function text = check_gain_sum(radius, gain_sum)
% CHECK_GAIN_SUM 检查松弛为零的半径上 G_C + G_Γ 随 r 不减；满足写“是”，否则列出下降处的半径。
%
% 容差与弦的检查相同: 1e-8·max(max|G_C + G_Γ|, 1)。

    if numel(radius) < 2
        text = '松弛为零的半径不足两个，无法检查';
        return;
    end
    [sorted_radius, order] = sort(radius, 'ascend');
    gain_sum = gain_sum(order);
    tolerance = 1e-8 * max(max(abs(gain_sum)), 1);
    decreased = [false, diff(gain_sum) < -tolerance];
    if ~any(decreased)
        text = '是';
    else
        text = ['否, 下降处 r = ' format_radius_list(sorted_radius(decreased))];
    end
end


function text = format_radius_list(radius)
% FORMAT_RADIUS_LIST 半径列表的文本，逗号分隔。

    text = strjoin(arrayfun(@(r) sprintf('%.4g', r), radius, ...
        'UniformOutput', false), ', ');
end
