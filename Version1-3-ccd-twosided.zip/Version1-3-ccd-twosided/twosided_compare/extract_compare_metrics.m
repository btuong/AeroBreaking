function Metrics = extract_compare_metrics( ...
        Result, RunInfo, case_name, Case, elapsed_seconds)
% EXTRACT_COMPARE_METRICS 从单次双侧 CCD 对比运行提取逐轮指标并存为轻量结构体。
%
% 在 Version1-3-standard-5 的 extract_compare_metrics 基础上，扩展记录 twosided 专属字段：
%   共用松弛 s_a1/s_a2、理论共用帽半角上限 alpha_cap_deg、节点转角中位数与 95 分位、
%   不紧节点数（>1e-6 与 >1e-3）、以及命题 C2 对偶门槛比 sum_kappa_over_P、
%   sum_y_inner_over_P（注：本版本 ControlReport.lambda_inner 已直接存 Dual.y，负号取正
%   即 -y_i）与主问题需求总和 sum_s_main_norm。没有候选解的轮次数值量保持 NaN。
%
% 输入:
%   Result          - run_compare_case 返回的 Result
%   RunInfo         - run_compare_case 返回的平台与用时信息
%   case_name       - 工况名
%   Case            - list_compare_cases 返回的工况结构体
%   elapsed_seconds - 工况运行耗时 (s)
%
% 输出:
%   Metrics         - 工况标量信息与 K x 1 逐轮指标结构体

    History = Result.history;
    K = numel(History);

    %% ===== 工况标识与运行摘要 =====
    Metrics.case_name = case_name;
    Metrics.type = Case.type;
    Metrics.w = Case.w;
    if strcmp(Case.type, 'twosided')
        Metrics.mode = 'twosided';
        Metrics.P = Case.p;
        Metrics.p = Case.p;
        circle_name = 'unit_norm_penalty';
    else
        Metrics.mode = 'regularized';
        Metrics.P = NaN;
        Metrics.p = NaN;
        circle_name = 'control_reg';
    end
    Metrics.keep_control_bounds = logical(Case.keep_control_bounds);
    Metrics.enable_control_continuity = logical(Case.enable_control_continuity);
    Metrics.init_control_mode = char(string(Case.init_control_mode));
    Metrics.elapsed_seconds = elapsed_seconds;
    Metrics.status = Result.status;
    if K >= 1
        Metrics.first_status = History(1).subproblem.solver.status;
    else
        Metrics.first_status = 'not_attempted';
    end
    Metrics.stop_reason_raw = Result.stop_reason;
    if strcmp(Result.stop_reason, 'max_iterations')
        Metrics.stop_reason = 'max_iter';
    else
        Metrics.stop_reason = Result.stop_reason;
    end
    Metrics.stop_detail = Result.stop_detail;
    Metrics.num_attempted = Result.num_attempted;
    Metrics.num_accepted = Result.num_accepted;
    if Result.has_accepted_solution
        Metrics.final_index = Result.final_iteration.iter;
    else
        Metrics.final_index = NaN;
    end
    Metrics.plateau_start_iter = RunInfo.plateau_start_iter;
    Metrics.plateau_mean_impulse = RunInfo.plateau_mean_impulse;
    Metrics.plateau_range = RunInfo.plateau_range;
    Metrics.iter_seconds = RunInfo.iter_seconds;

    %% ===== 预分配逐轮数组 =====
    Metrics.accepted = false(K, 1);
    Metrics.candidate_available = false(K, 1);
    Metrics.feasible = false(K, 1);
    Metrics.convex_error_flag = false(K, 1);
    Metrics.convex_error_names = {};
    scalar_names = {'total_impulse_m_s', 'apoapsis_km', 'inclination_deg', ...
        'max_ratio', 'J', 'C', 'Gamma', 'Theta', 'delta_L', 'rho', ...
        'delta_L_gamma', 'delta_J_gamma', 'error_gamma', 'step_max', ...
        's_a1', 's_a2', 'max_eps', 'alpha_cap_deg', ...
        'max_tight_gap', 'max_inward_gap', 'max_outward_gap', ...
        'num_untight', 'num_untight_1e3', 'num_slack_capped', ...
        'num_bound_active', 'turn_median_deg', 'turn_p95_deg', ...
        'sum_kappa_over_P', 'sum_y_inner_over_P', 'sum_s_inner_over_2P', ...
        'sum_s_main_norm', 'circle_predicted', 'circle_actual', 'circle_error'};
    for n = 1:numel(scalar_names)
        Metrics.(scalar_names{n}) = nan(K, 1);
    end

    %% ===== 逐轮提取指标 =====
    % 转角及上一参考模长相对上一接受解；首轮相对初始参考（可能为 0.3 倍或 0）
    previous_control = Result.initial_reference.control;
    for k = 1:K
        Record = History(k);
        Metrics.candidate_available(k) = logical(Record.trust.candidate_available);
        Metrics.accepted(k) = Metrics.candidate_available(k) ...
            && logical(Record.trust.accept_candidate);
        if ~Metrics.candidate_available(k)
            continue;
        end

        P2Feasibility = Record.subproblem.p2_feasibility;
        Metrics.total_impulse_m_s(k) = P2Feasibility.performance_report.value;
        Metrics.apoapsis_km(k) = P2Feasibility.terminal_report.metrics(1).actual_value;
        Metrics.inclination_deg(k) = P2Feasibility.terminal_report.metrics(2).actual_value;
        Metrics.max_ratio(k) = P2Feasibility.max_ratio;
        Metrics.feasible(k) = logical(P2Feasibility.feasible);
        Metrics.step_max(k) = Record.subproblem.convergence_report.max_value;

        Control = Record.solution.control;
        prev_u_norm = hypot(previous_control.u1(:), previous_control.u2(:));
        curr_u_norm = hypot(Control.u1(:), Control.u2(:));
        valid_turn = prev_u_norm > 1e-9 & curr_u_norm > 1e-9;
        if any(valid_turn)
            turn_deg = abs(wrap_angle_deg( ...
                atan2d(Control.u2(valid_turn), Control.u1(valid_turn)) ...
                - atan2d(previous_control.u2(valid_turn), previous_control.u1(valid_turn))));
            Metrics.turn_median_deg(k) = median(turn_deg);
            Metrics.turn_p95_deg(k) = compute_percentile_linear(turn_deg, 95);
        end

        ControlReport = Record.subproblem.control_report;
        if ControlReport.evaluated
            Metrics.max_tight_gap(k) = max(abs(ControlReport.tight_gap));
            Metrics.num_untight(k) = sum(abs(ControlReport.tight_gap) > 1e-6);
            Metrics.num_untight_1e3(k) = sum(abs(ControlReport.tight_gap) > 1e-3);
            Metrics.max_inward_gap(k) = ControlReport.summary_total.max_inward_gap;
            Metrics.max_outward_gap(k) = ControlReport.summary_total.max_outward_gap;
            Metrics.num_slack_capped(k) = ControlReport.summary_total.num_slack_capped;
            if numel(ControlReport.unit_norm_slack) >= 2 ...
                    && all(~isnan(ControlReport.unit_norm_slack(1:2)))
                s1 = ControlReport.unit_norm_slack(1);
                s2 = ControlReport.unit_norm_slack(2);
                Metrics.s_a1(k) = s1;
                Metrics.s_a2(k) = s2;
                Metrics.max_eps(k) = max(s1, s2);
                cos_alpha = max(-1, min(1, (2 - s2) / (2 * (1 + s1))));
                Metrics.alpha_cap_deg(k) = acosd(cos_alpha);
            end
            if ControlReport.dual_available
                % 内点法非活跃边界常留 1e-11 残值，用 1e-6 判定实际活跃边界
                Metrics.num_bound_active(k) = ...
                    sum(vecnorm(ControlReport.s_bound, 2, 2) > 1e-6);
                Metrics.sum_s_main_norm(k) = sum(ControlReport.s_main_norm, 'omitnan');
                if strcmp(Case.type, 'twosided')
                    Metrics.sum_kappa_over_P(k) = ...
                        sum(ControlReport.cone_dual_leading, 'omitnan') / Case.p;
                    % 本版本 lambda_inner 直接为 Dual.y(inner_rows) <= 0，故取 -lambda_inner
                    Metrics.sum_y_inner_over_P(k) = ...
                        sum(-ControlReport.lambda_inner, 'omitnan') / Case.p;
                    valid_u = prev_u_norm > 1e-9;
                    if any(valid_u)
                        s_inner_norm = vecnorm(ControlReport.s_inner(valid_u, :), 2, 2);
                        Metrics.sum_s_inner_over_2P(k) = ...
                            sum(s_inner_norm ./ (2 * prev_u_norm(valid_u)), 'omitnan') / Case.p;
                    end
                end
            end
        end

        if Metrics.accepted(k)
            previous_control = Control;
        end

        Evaluation = Record.trust.evaluation;
        if ~Evaluation.evaluated
            continue;
        end
        Metrics.J(k) = Evaluation.candidate.total;
        Metrics.C(k) = Evaluation.group.cost.candidate;
        Metrics.Gamma(k) = Evaluation.group.extra.candidate;
        Metrics.Theta(k) = Evaluation.group.penalty.candidate;
        Metrics.delta_L(k) = Evaluation.predicted_reduction;
        Metrics.rho(k) = Evaluation.ratio;
        Metrics.delta_L_gamma(k) = Evaluation.group.extra.predicted;
        Metrics.delta_J_gamma(k) = Evaluation.group.extra.actual;
        Metrics.error_gamma(k) = Evaluation.group.extra.error;
        Metrics.convex_error_flag(k) = Evaluation.convex_error_flag;
        Metrics.convex_error_names = union(Metrics.convex_error_names, ...
            Evaluation.convex_error_names);
        circle_index = find(strcmp(Evaluation.term_names, circle_name), 1);
        if ~isempty(circle_index)
            Metrics.circle_predicted(k) = ...
                Evaluation.term_predicted_reduction(circle_index);
            Metrics.circle_actual(k) = ...
                Evaluation.term_actual_reduction(circle_index);
            Metrics.circle_error(k) = Evaluation.term_prediction_error(circle_index);
        end
    end
end


function value = compute_percentile_linear(values, percent)
% COMPUTE_PERCENTILE_LINEAR 对有限样本按线性插值求百分位数，空输入返回 NaN。

    values = sort(values(~isnan(values(:))));
    count = numel(values);
    if count == 0
        value = NaN;
        return;
    end
    position = 1 + (count - 1) * percent / 100;
    lower_index = floor(position);
    upper_index = ceil(position);
    value = values(lower_index) ...
        + (position - lower_index) * (values(upper_index) - values(lower_index));
end
