function fit_axis_limits(ax, reference)
% FIT_AXIS_LIMITS 调整纵轴范围：把参考线包进来并留边，数据几乎不变时撑开范围。
%
% MATLAB 自动纵轴范围不考虑 yline，参考线常落在边框上看不见；数据变化极小
% （如 ||u|| 恒为 1）时，刻度会显示很多位小数。本函数在曲线画完后调用。
%
% 输入:
%   ax        - 已画好曲线的坐标轴
%   reference - 参考线数值（上限、目标或容差），没有时给 NaN

    y_limits = ylim(ax);
    low = y_limits(1);
    high = y_limits(2);
    has_reference = isfinite(reference);

    if strcmp(get(ax, 'YScale'), 'log')
        % 对数轴：参考线上下各留半个数量级
        if has_reference && reference > 0
            low = min(low, reference / 3);
            high = max(high, reference * 3);
        end
        ylim(ax, [low, high]);
        return;
    end

    if has_reference
        low = min(low, reference);
        high = max(high, reference);
    end
    % 范围小于量级的千分之一时按千分之一撑开，避免刻度出现很多位小数
    min_span = max(1e-3 * max(abs([low, high])), 1e-12);
    if high - low < min_span
        center = 0.5 * (low + high);
        low = center - 0.5 * min_span;
        high = center + 0.5 * min_span;
    end
    % 上下各留 5% 边距，参考线不压在边框上
    margin = 0.05 * (high - low);
    ylim(ax, [low - margin, high + margin]);
end
