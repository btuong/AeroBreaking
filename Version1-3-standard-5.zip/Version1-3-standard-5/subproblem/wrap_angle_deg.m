function wrapped = wrap_angle_deg(angle_deg)
% WRAP_ANGLE_DEG 把角度（deg）规约到 (-180, 180]。

    wrapped = 180 - mod(180 - angle_deg, 360);
end
