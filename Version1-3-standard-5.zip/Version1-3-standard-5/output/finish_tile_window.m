function finish_tile_window(layout, tile_axes, figure_title, notes, config)
% FINISH_TILE_WINDOW 分块全部画完后收尾：放共用图例，写总标题（可附说明行）。
%
% 输入:
%   layout       - 本窗的分块布局
%   tile_axes    - 本窗全部分块的坐标轴
%   figure_title - 整扇窗的总标题
%   notes        - 元胞，说明短句（如“实心点：接受   空心点：拒绝”“点线：0 值画在下限”）；
%                  重复和空的项自动去掉，没有时只写总标题
%   config       - 读取 config.plot.font_size
%
% 说明短句放接受/拒绝标记的含义、点线表示的 0 值、画在范围外的参考线等，这些不进
% 图例，免得图例变长。短句按图窗宽度依次并成几行写在标题下面，一行放不下才换行，
% 省得标题占掉太多高度。

    font_size = config.plot.font_size;
    place_shared_legend(tile_axes, config);
    notes = notes(~cellfun(@isempty, notes));
    if isempty(notes)
        title(layout, figure_title, 'FontSize', font_size);
        return;
    end
    notes = unique(notes, 'stable');
    figure_pixels = get(ancestor(tile_axes(1), 'figure'), 'Position');
    max_width = floor(figure_pixels(3) / (0.67 * font_size)) - 2;
    title(layout, [{figure_title}, pack_note_lines(notes, max_width)], ...
        'FontSize', font_size);
end


function lines = pack_note_lines(notes, max_width)
% PACK_NOTE_LINES 把说明短句依次并成行，每行显示宽度不超过 max_width，短句之间空三格。

    separator = '   ';
    lines = notes(1);
    for k = 2:numel(notes)
        joined = [lines{end} separator notes{k}];
        if measure_display_width(joined) > max_width
            lines{end + 1} = notes{k}; %#ok<AGROW>
        else
            lines{end} = joined;
        end
    end
end
