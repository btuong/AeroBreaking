function Summary = summarize_control_reg_weight_switch(results_root)
% SUMMARIZE_CONTROL_REG_WEIGHT_SWITCH 汇总积分权开关对照的小存档，并重算一致性核对。
%
% 只读每工况 case_metrics.mat 与 scp_run_control.mat，不重跑 SCP。
% 输入 results_root 默认是 regularizer_converge/results_weight_switch；
% 输出写入同目录的 对照汇总.txt、对照汇总.mat。

    if nargin < 1 || isempty(results_root)
        results_root = fullfile(fileparts(mfilename('fullpath')), ...
            'results_weight_switch');
    end
    version_root = fileparts(fileparts(mfilename('fullpath')));
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));
    addpath(fullfile(version_root, 'setup'), fullfile(version_root, 'subproblem'));
    cases = dir(fullfile(results_root, '*_omega_*'));
    cases = cases([cases.isdir]);
    summary_list = cell(numel(cases), 1);
    for k = 1:numel(cases)
        data = load(fullfile(results_root, cases(k).name, 'case_metrics.mat'), 'Metrics');
        control = load(fullfile(results_root, cases(k).name, ...
            'scp_run_control.mat'), 'ControlExport');
        Metrics = data.Metrics;
        Metrics.max_control_regularizer_error = compute_regularizer_error( ...
            control.ControlExport, Metrics.type);
        summary_list{k} = summarize_case(Metrics);
    end
    Summary = vertcat(summary_list{:});
    [~, order] = sortrows([{Summary.type}', num2cell([Summary.use_integration_weights]')], ...
        [1, -2]);
    Summary = Summary(order);
    write_summary(fullfile(results_root, '对照汇总.txt'), Summary);
    save(fullfile(results_root, '对照汇总.mat'), 'Summary');
end


function max_error = compute_regularizer_error(ControlExport, type)
% COMPUTE_REGULARIZER_ERROR 从实际控制重算 Γ，与逐节点 P3 正则贡献之和核对。

    max_error = 0;
    for k = 1:numel(ControlExport.attempts)
        Report = ControlExport.attempts(k).control_report;
        if ~Report.evaluated
            continue;
        end
        if ControlExport.use_integration_weights
            node_weights = Report.omega(:);
        else
            node_weights = ones(Report.num_nodes, 1);
        end
        switch type
            case 'norm'
                expected = -ControlExport.w_reg * (node_weights' * Report.u_norm);
            case 'sum'
                expected = ControlExport.w_reg * (node_weights' * (Report.u1 + Report.u2));
            case 'u1'
                expected = ControlExport.w_reg * (node_weights' * Report.u1);
            case 'u2'
                expected = ControlExport.w_reg * (node_weights' * Report.u2);
        end
        max_error = max(max_error, abs(expected - sum(Report.gamma_node)));
    end
end


function Summary = summarize_case(Metrics)
% SUMMARIZE_CASE 取单个工况的运行状态、末轮指标与全程紧性。

    Summary.case_name = Metrics.case_name;
    Summary.type = Metrics.type;
    Summary.w = Metrics.w;
    Summary.use_integration_weights = Metrics.use_integration_weights;
    Summary.num_attempted = Metrics.num_attempted;
    Summary.num_accepted = Metrics.num_accepted;
    Summary.stop_reason = Metrics.stop_reason;
    Summary.max_control_regularizer_error = Metrics.max_control_regularizer_error;
    final_index = Metrics.final_index;
    Summary.final_impulse = Metrics.total_impulse_m_s(final_index);
    Summary.final_gamma = Metrics.Gamma(final_index);
    Summary.final_max_gap = Metrics.max_tight_gap(final_index);
    Summary.final_untight = Metrics.num_untight(final_index);
    Summary.final_feasible = Metrics.feasible(final_index);
    Summary.final_apoapsis = Metrics.apoapsis_km(final_index);
    Summary.final_inclination = Metrics.inclination_deg(final_index);
    Summary.max_gap = max(Metrics.max_tight_gap, [], 'omitnan');
    Summary.rounds_untight = sum(Metrics.num_untight > 0);
    Summary.max_untight = max(Metrics.num_untight, [], 'omitnan');
    Summary.max_step = max(Metrics.step_max, [], 'omitnan');
end


function write_summary(text_path, Summary)
% WRITE_SUMMARY 写开关两状态的物理指标、紧性与差值。

    file_id = fopen(text_path, 'w', 'n', 'UTF-8');
    if file_id < 0
        error('WeightSwitch:SummaryOpenFailed', '无法写入对照汇总：%s', text_path);
    end
    cleanup = onCleanup(@() fclose(file_id));
    fprintf(file_id, ['控制正则积分权开关对照：ω=1 为原式 w·Σω_i·(·)_i；' ...
        'ω=0 为 w·Σ(·)_i。w=1e-4，fixed r=1，各10轮。\n']);
    fprintf(file_id, ['仅控制正则附加项改变；gap=1−||u||；' ...
        '正则误差为重算 Γ 减逐节点 P3 正则贡献之和。P2可行/终端量取最后接受轮。\n\n']);
    fprintf(file_id, ['工况              ω   尝试/接受  末轮总脉冲(m/s)  末轮Gamma  ' ...
        '全程maxgap  末轮maxgap  不紧轮/最多节点  P2可行  远地点(km)  倾角(deg)  正则误差\n']);
    for k = 1:numel(Summary)
        S = Summary(k);
        fprintf(file_id, ['%-17s %d   %2d/%2d      %14.10f  %11.4e  ' ...
            '%10.3e  %10.3e  %2d/%3d          %d       %11.6f  %9.5f  %.3e\n'], ...
            S.case_name, S.use_integration_weights, S.num_attempted, S.num_accepted, ...
            S.final_impulse, S.final_gamma, S.max_gap, S.final_max_gap, ...
            S.rounds_untight, S.max_untight, S.final_feasible, ...
            S.final_apoapsis, S.final_inclination, S.max_control_regularizer_error);
    end
    fprintf(file_id, '\n关闭相对开启的差值（同类型、同 w、同轮数）：\n');
    types = unique({Summary.type}, 'stable');
    for k = 1:numel(types)
        On = Summary(strcmp({Summary.type}, types{k}) & [Summary.use_integration_weights]);
        Off = Summary(strcmp({Summary.type}, types{k}) & ~[Summary.use_integration_weights]);
        fprintf(file_id, '%s: Δ末轮总脉冲 = %+.10f m/s；Δ末轮Gamma = %+.6e；maxgap %.3e -> %.3e\n', ...
            types{k}, Off.final_impulse - On.final_impulse, ...
            Off.final_gamma - On.final_gamma, On.max_gap, Off.max_gap);
    end
end
