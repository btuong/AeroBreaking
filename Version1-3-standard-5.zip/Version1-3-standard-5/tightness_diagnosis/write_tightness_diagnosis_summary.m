function write_tightness_diagnosis_summary(text_path, Summary)
% WRITE_TIGHTNESS_DIAGNOSIS_SUMMARY 写代表工况的紧性机理观测文本。

    file_id = fopen(text_path, 'w', 'n', 'UTF-8');
    if file_id < 0
        error('Diagnosis:SummaryOpenFailed', '无法写入紧性诊断汇总：%s', text_path);
    end
    cleanup = onCleanup(@() fclose(file_id));
    fprintf(file_id, ['紧性机理观测：m = ‖s_main+s_reg‖；抵消比例 = m/max(‖s_main‖,‖s_reg‖)；' ...
        '弦向平坦比例 = ‖P_T s_reg‖/‖s_reg‖，接近 0 表示平坦。\n']);
    fprintf(file_id, ['候选条件不是因果证明；无速率约束为同一参考、同一半径下的额外 P3，' ...
        '不推进参考。互补积上界误差 = gap − μ/m，应不超过数值误差。\n']);
    fprintf(file_id, '速率活动容差 1e-8；弦向平坦阈值 0.05；显著不紧阈值 gap>1e-6。\n');
    for c = 1:numel(Summary)
        Case = Summary(c);
        fprintf(file_id, '\n=== %s ===\n', Case.name);
        if ~Case.executed
            fprintf(file_id, '失败: %s\n', Case.message);
            continue;
        end
        if ~Case.success
            fprintf(file_id, '警告: 部分轮次的主报告或对照求解不可用；这些轮次不计零值证据。\n');
        end
        fprintf(file_id, ['轮  有约束maxgap 无约束maxgap 有约束minm 无约束minm ' ...
            '抵消节点 强抵消 弦平坦不紧 上界最大误差 驻点残差\n']);
        for k = 1:numel(Case.rounds)
            R = Case.rounds(k);
            if ~R.main_usable
                fprintf(file_id, '%2d  主报告/对偶不可用；对照状态: %s\n', ...
                    R.iter, R.alternate_status);
                continue;
            end
            if ~R.alternate_success
                fprintf(file_id, '%2d  无速率约束对照不可用: %s\n', ...
                    R.iter, R.alternate_status);
            end
            fprintf(file_id, '%2d  %.3e  %.3e  %.3e  %.3e  %5d %5d %7d  %.3e  %.3e\n', ...
                R.iter, R.with_max_gap, R.without_max_gap, R.with_min_margin, ...
                R.without_min_margin, R.cancellation_nodes, ...
                R.strong_cancellation_nodes, R.chord_flat_untight_nodes, ...
                R.bound_max_error, R.max_abs_stationarity_residual);
            for j = 1:size(R.untight_table, 1)
                row = R.untight_table(j, :);
                fprintf(file_id, ['  不紧节点 %4d gap %.3e m %.3e mu %.3e cos %.4f ' ...
                    '比例 %.3e rho_main %.3e rho_reg %.3e 弦平坦 %.3e\n'], ...
                    row(1), row(2), row(3), row(4), row(5), row(6), ...
                    row(7), row(8), row(9));
                fprintf(file_id, ['    去速率乘子: m_nonrate %.3e cos_nonrate %.4f；' ...
                    '无速率重解: gap %.3e m %.3e\n'], ...
                    row(10), row(11), row(12), row(13));
            end
        end
    end
end
