function Result = build_scp_result(FinalizedRun)
% BUILD_SCP_RESULT 将冻结的 SCP 运行对象映射为对外稳定结果。
%
% 不提供单一含混的 success 字段；以下状态相互独立：
%   has_accepted_solution / mission_completed / scp_converged /
%   convergence_stop_reached / last_attempt_success / stop / stop_reason / stop_detail。
%
% PublicIteration 投影字段：iter, solution, subproblem（含步长检查、
% P3 解检查与 P2 可行性检查）, trust（含接受决策）, trapezoid_solution,
% trapezoid_check, stop；由同轮 IterationRecord 与 IterationDiagnostics 配对生成。
% 内部参考快照与完整性标记只留在 FinalizedRun。
%
% 本函数依次完成：
%   1. 映射运行状态。
%   2. 映射初始数据和最终有效解。
%   3. 映射最终接受轮状态。
%   4. 映射最后尝试和公共历史。

    %% 1. 映射运行状态
    Result.schema_version = 1;
    Result.status = FinalizedRun.status;
    Result.has_accepted_solution = FinalizedRun.has_accepted_solution;
    Result.num_attempted = FinalizedRun.num_attempted;
    Result.num_accepted = FinalizedRun.num_accepted;
    Result.last_attempt_success = FinalizedRun.last_attempt_success;
    Result.stop = FinalizedRun.stop;
    Result.stop_reason = FinalizedRun.stop_reason;
    Result.stop_detail = FinalizedRun.stop_detail;
    Result.convergence_stop_reached = FinalizedRun.convergence_stop_reached;

    %% 2. 映射初始数据和最终有效解
    Result.initial_reference = FinalizedRun.initial_reference;
    Result.initial_propagation = FinalizedRun.initial_propagation;
    Result.final_solution = FinalizedRun.final_solution;
    Result.final_trapezoid_solution = FinalizedRun.final_trapezoid_solution;
    Result.final_reference = FinalizedRun.final_reference;

    %% 3. 映射最终接受轮状态
    Result.scp_converged = FinalizedRun.scp_converged;
    Result.mission_completed = false;   % 任务完成口径未决（知识库 D1）
    if FinalizedRun.has_accepted_solution
        Result.final_iteration = build_public_iteration_result( ...
            FinalizedRun.final_iteration, FinalizedRun.final_diagnostics);
    else
        Result.final_iteration = [];
    end

    %% 4. 映射最后尝试和公共历史
    if isempty(FinalizedRun.last_iteration)
        Result.last_iteration = [];
    else
        Result.last_iteration = build_public_iteration_result( ...
            FinalizedRun.last_iteration, FinalizedRun.last_diagnostics);
    end
    Result.history = build_public_iteration_history( ...
        FinalizedRun.history, FinalizedRun.diagnostics);
end


function PublicIteration = build_public_iteration_result( ...
        IterationRecord, IterationDiagnostics)
% BUILD_PUBLIC_ITERATION_RESULT 映射同轮记录与诊断的稳定字段。

    if IterationRecord.iter ~= IterationDiagnostics.iter
        error('SCP:MismatchedIterationDiagnostics', ...
            '迭代记录与诊断的轮次必须一致。');
    end
    PublicIteration.iter = IterationRecord.iter;
    PublicIteration.solution = IterationRecord.solution;
    PublicIteration.subproblem = IterationRecord.subproblem;
    PublicIteration.trust = IterationRecord.trust;
    PublicIteration.trapezoid_solution = IterationDiagnostics.trapezoid_solution;
    PublicIteration.trapezoid_check = IterationDiagnostics.trapezoid_check;
    PublicIteration.stop = IterationRecord.stop;
end


function PublicHistory = build_public_iteration_history( ...
        History, Diagnostics)
% BUILD_PUBLIC_ITERATION_HISTORY 按原始轮次顺序映射公共历史。

    if isempty(History)
        PublicHistory = struct([]);
        return;
    end
    PublicHistory = repmat(build_public_iteration_result( ...
        History(1), Diagnostics(1)), numel(History), 1);
    for index = 2:numel(History)
        PublicHistory(index) = build_public_iteration_result( ...
            History(index), Diagnostics(index));
    end
end
