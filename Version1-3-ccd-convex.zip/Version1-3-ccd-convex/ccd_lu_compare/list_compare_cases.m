function Cases = list_compare_cases(case_filter)
% LIST_COMPARE_CASES 列出文献 [20] 原文凹凸分解（ccd_lu）对比实验的全部 12 个工况。
%
% 工况分四组:
%   1. 主扫描（6 档）: ccd_lu_p1e-5 .. ccd_lu_p1e0（50 轮，不保留箱形边界，归一化初值）
%   2. 等总权配对（2 档）: ccd_lu_peq_1e-1（p = 0.5/661）、ccd_lu_peq_1e0（p = 5/661）
%   3. 保留边界对照（1 档）: ccd_lukeep_p1e-2（50 轮，保留 u ∈ [-1, 1]）
%   4. 初值专项（3 档）: ccd_lu_init0_p1e-2、ccd_lu_init0p3_nonorm_p1e-2、
%      ccd_lu_init0p3_nonorm_keep_p1e-2（各 10 轮）
%
% 输入（可省略）:
%   case_filter - 工况名元胞数组；为空或省略时返回全部 12 个工况
%
% 输出 Cases（1 x n 结构体数组）:
%   name                - 工况名
%   type                - 'ccd_lu'
%   group               - 分组标识：'main_scan'、'equal_weight'、'keep_bounds'、'init_study'
%   max_iter            - 迭代上限（50 或 10）
%   p                   - 单位范数松弛罚权（不乘 ω_i）
%   keep_control_bounds - 是否保留 u1、u2 的 [-1, 1] 箱形边界
%   normalize_init      - 是否启用 ccd_normalize_initial_control
%   init_control_mode   - 初始控制构造方式：'default'、'scale_0p3'、'zero'

    case_list = {};

    %% 1. 主扫描（6 档，50 轮）
    for exponent = -5:0
        case_list{end + 1} = make_case( ... %#ok<AGROW>
            sprintf('ccd_lu_p1e%d', exponent), 'main_scan', 50, ...
            str2double(sprintf('1e%d', exponent)), false, true, 'default');
    end

    %% 2. 等总权配对（2 档，50 轮，对应 standard-5 的 ccd_p1e-1 与 ccd_p1e0）
    case_list{end + 1} = make_case('ccd_lu_peq_1e-1', 'equal_weight', 50, ...
        0.5 / 661, false, true, 'default');
    case_list{end + 1} = make_case('ccd_lu_peq_1e0', 'equal_weight', 50, ...
        5 / 661, false, true, 'default');

    %% 3. 保留箱形边界对照（1 档，50 轮）
    case_list{end + 1} = make_case('ccd_lukeep_p1e-2', 'keep_bounds', 50, ...
        str2double('1e-2'), true, true, 'default');

    %% 4. 初值专项（3 档，10 轮）
    case_list{end + 1} = make_case('ccd_lu_init0_p1e-2', 'init_study', 10, ...
        str2double('1e-2'), false, true, 'zero');
    case_list{end + 1} = make_case('ccd_lu_init0p3_nonorm_p1e-2', 'init_study', 10, ...
        str2double('1e-2'), false, false, 'scale_0p3');
    case_list{end + 1} = make_case('ccd_lu_init0p3_nonorm_keep_p1e-2', 'init_study', 10, ...
        str2double('1e-2'), true, false, 'scale_0p3');

    Cases = [case_list{:}];
    if nargin >= 1 && ~isempty(case_filter)
        Cases = Cases(ismember({Cases.name}, case_filter));
    end
end


function Case = make_case(name, group, max_iter, p, ...
        keep_control_bounds, normalize_init, init_control_mode)
% MAKE_CASE 组装单个实验工况结构体。

    Case = struct( ...
        'name', name, ...
        'type', 'ccd_lu', ...
        'group', group, ...
        'max_iter', max_iter, ...
        'p', p, ...
        'keep_control_bounds', logical(keep_control_bounds), ...
        'normalize_init', logical(normalize_init), ...
        'init_control_mode', init_control_mode);
end
