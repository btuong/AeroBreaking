function [Summary, Groups, Check] = analyze_sccp_compare( ...
        results_root, pictures_root, delta, window)
% ANALYZE_SCCP_COMPARE 汇总 SCCP 对比实验：校验基线与存档、算指标、写汇总、作图。
%
% 只读 sccp_compare/results/<工况>/ 下的 case_metrics.mat、scp_run_control.mat，以及
% 只读引用 ../Version1-3-standard-5/ccd_compare/results/ 下 5 个基线工况
% （none、norm_w1e-4、normgap_w1e-3..5，加载时强制校验 version_root ==
% 'Version1-3-standard-5' 与 unit_norm_mode == 'regularized'）。
% 节点分组以 none 末轮（第 50 轮）q_i = ‖s_main,i‖ / ω_i < 1e-6 为退化节点 D，
% 其余为 E，所有工况共用。
%
% 输入（均可省略）:
%   results_root  - SCCP 结果所在目录，默认 <本文件夹>/results
%   pictures_root - 图输出目录，默认 <本文件夹>/pictures
%   delta         - 差值稳定阈值 δ (m/s)，默认 0.1
%   window        - 差值稳定窗口轮数，默认 5
%
% 输出:
%   Summary - 1 x 18 结构体数组（5 基线 + 13 SCCP 工况）
%   Groups  - 共用节点分组（D/E）
%   Check   - 基线校验与 SCCP 自检指标
%   写 results/对比汇总.txt、results/对比汇总.mat 与 pictures/*.png。
%
% 本函数依次完成：
%   1. 补路径并确定目录和参数。
%   2. 只读加载基线与全部 13 个 SCCP 工况并校验存档版本。
%   3. 按 none 基线末轮确定节点分组（D/E）。
%   4. 逐工况计算末轮、E/D 扩散、命题 C1 转角、冻结与对偶指标。
%   5. 计算相对 none 与 normgap_w1e-4 的差值及稳定性。
%   6. 执行基线与 SCCP 自检。
%   7. 写汇总文本与汇总 MAT。
%   8. 导出对比图窗。

    %% 1. 补路径并确定目录和参数
    compare_root = fileparts(mfilename('fullpath'));
    version_root = fileparts(compare_root);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));
    addpath(fullfile(version_root, 'subproblem'), ...
        fullfile(version_root, 'output'), compare_root);

    if nargin < 1 || isempty(results_root)
        results_root = fullfile(compare_root, 'results');
    end
    if nargin < 2 || isempty(pictures_root)
        pictures_root = fullfile(compare_root, 'pictures');
    end
    if nargin < 3 || isempty(delta)
        delta = 0.1;
    end
    if nargin < 4 || isempty(window)
        window = 5;
    end

    baseline_root = fullfile(fileparts(version_root), ...
        'Version1-3-standard-5', 'ccd_compare', 'results');
    Options = struct( ...
        'delta', delta, ...
        'window', window, ...
        'baseline_root', baseline_root, ...
        'reference_case', 'normgap_w1e-4');

    %% 2. 只读加载基线与全部 13 个 SCCP 工况并校验存档版本
    BaselineCases = list_baseline_specs();
    SccpCases = list_compare_cases();
    BaselineData = load_case_group(BaselineCases, baseline_root, ...
        'Version1-3-standard-5', 'regularized', 'baseline');
    SccpData = load_case_group(SccpCases, results_root, ...
        'Version1-3-ccd-sccp', 'sccp', 'sccp');
    CaseData = [BaselineData, SccpData];

    %% 3. 按 none 基线末轮确定节点分组（D/E）
    Groups = determine_node_groups(CaseData);

    %% 4. 逐工况计算末轮、E/D 扩散、命题 C1 转角、冻结与对偶指标
    Summary = compute_all_indicators(CaseData, Groups, Options);

    %% 5. 计算相对 none 与 normgap_w1e-4 的差值及稳定性
    Summary = add_difference_indicators(Summary, Groups, Options);

    %% 6. 执行基线与 SCCP 自检
    Check = check_run(Summary, BaselineData, SccpData);

    %% 7. 写汇总文本与汇总 MAT
    write_compare_text(fullfile(results_root, '对比汇总.txt'), ...
        Summary, Groups, Check, Options);
    save(fullfile(results_root, '对比汇总.mat'), ...
        'Summary', 'Groups', 'Check', 'Options');

    %% 8. 导出对比图窗
    plot_compare_figures(Summary, Groups, Options, pictures_root);
end


%% ===== 读取与校验 =====

function Specs = list_baseline_specs()
% LIST_BASELINE_SPECS 列出只读复用的 5 个 regularizer/ccd_compare 基线工况。

    items = { ...
        struct('name', 'none', 'type', 'none', 'w', NaN), ...
        struct('name', 'norm_w1e-4', 'type', 'norm', 'w', str2double('1e-4')), ...
        struct('name', 'normgap_w1e-3', 'type', 'norm_gap', 'w', str2double('1e-3')), ...
        struct('name', 'normgap_w1e-4', 'type', 'norm_gap', 'w', str2double('1e-4')), ...
        struct('name', 'normgap_w1e-5', 'type', 'norm_gap', 'w', str2double('1e-5'))};
    Specs = [items{:}];
end


function CaseData = load_case_group(Cases, root_dir, expected_version, ...
        expected_mode, source_tag)
% LOAD_CASE_GROUP 读取一组工况并校验 ControlExport 版本目录与单位范数模式。

    data_list = cell(1, numel(Cases));
    for c = 1:numel(Cases)
        Case = Cases(c);
        Data = build_empty_case_data(Case, source_tag);
        case_directory = fullfile(root_dir, Case.name);
        metrics_path = fullfile(case_directory, 'case_metrics.mat');
        control_path = fullfile(case_directory, 'scp_run_control.mat');
        error_path = fullfile(case_directory, 'case_error.txt');

        if isfile(metrics_path) && isfile(control_path)
            Loaded = load(metrics_path);
            Control = load(control_path);
            Export = Control.ControlExport;
            if ~strcmp(Export.version_root, expected_version)
                error('SCCPCompare:VersionMismatch', ...
                    '工况 %s 的 version_root 为 %s，预期为 %s。', ...
                    Case.name, Export.version_root, expected_version);
            end
            if ~strcmp(Export.unit_norm_mode, expected_mode)
                error('SCCPCompare:ModeMismatch', ...
                    '工况 %s 的 unit_norm_mode 为 %s，预期为 %s。', ...
                    Case.name, Export.unit_norm_mode, expected_mode);
            end

            Data.version_root = Export.version_root;
            Data.unit_norm_mode = Export.unit_norm_mode;
            Data.Metrics = Loaded.Metrics;
            attempts = Export.attempts;
            if isempty(attempts)
                solved = false(0, 1);
            else
                solved = arrayfun(@(a) logical(a.control_report.evaluated), attempts);
            end
            Data.attempts = attempts(solved);
            if Loaded.Metrics.num_accepted > 0
                Data.state = 'ok';
            else
                Data.state = 'no_solution';
            end
        elseif isfile(error_path)
            Data.state = 'failed';
            Data.error_message = strtrim(fileread(error_path));
        end
        data_list{c} = Data;
    end
    CaseData = [data_list{:}];
end


function Data = build_empty_case_data(Case, source_tag)
% BUILD_EMPTY_CASE_DATA 初始化单条工况加载容器。

    Data = struct();
    Data.name = Case.name;
    Data.source = source_tag;
    Data.type = Case.type;
    Data.mode = 'regularized';
    Data.w = NaN;
    Data.c_eta = NaN;
    Data.enable_control_continuity = true;
    Data.init_control_mode = 'default';
    if strcmp(source_tag, 'sccp')
        Data.mode = 'sccp';
        Data.c_eta = Case.c_eta;
        Data.enable_control_continuity = logical(Case.enable_control_continuity);
        Data.init_control_mode = Case.init_control_mode;
    elseif isfield(Case, 'w')
        Data.w = Case.w;
    end
    Data.version_root = '';
    Data.unit_norm_mode = '';
    Data.state = 'missing';
    Data.Metrics = [];
    Data.attempts = [];
    Data.error_message = '';
end


function Groups = determine_node_groups(CaseData)
% DETERMINE_NODE_GROUPS 以 none 基线末轮的 q_i = ‖s_main,i‖/ω_i 划分退化节点 D 与 E。

    Groups = struct('available', false, 'N', NaN, 'tau', [], 'cir', [], ...
        'q', [], 'D', [], 'E', [], 'num_D', NaN, 'num_E', NaN, ...
        'threshold', 1e-6);
    none_index = find(strcmp({CaseData.name}, 'none') ...
        & strcmp({CaseData.state}, 'ok'), 1);
    if isempty(none_index)
        return;
    end
    Report = pick_final_report(CaseData(none_index));
    Groups.N = Report.num_nodes;
    Groups.tau = Report.tau;
    Groups.cir = Report.cir;
    if ~Report.dual_available
        Groups.D = false(Groups.N, 1);
        Groups.E = true(Groups.N, 1);
        Groups.num_D = 0;
        Groups.num_E = Groups.N;
        return;
    end
    Groups.available = true;
    Groups.q = Report.s_main_norm ./ Report.omega;
    Groups.D = Groups.q < Groups.threshold;
    Groups.E = ~Groups.D;
    Groups.num_D = sum(Groups.D);
    Groups.num_E = sum(Groups.E);
end


function Report = pick_final_report(Data)
% PICK_FINAL_REPORT 取一个工况最后被接受那次尝试的控制量报告。

    accepted = [Data.attempts.accepted];
    Report = Data.attempts(find(accepted, 1, 'last')).control_report;
end


%% ===== 逐工况指标计算 =====

function Summary = compute_all_indicators(CaseData, Groups, Options)
% COMPUTE_ALL_INDICATORS 计算全部 18 个工况的汇总与逐轮分析指标。

    max_rounds = max(arrayfun(@count_attempted, CaseData));
    if isempty(max_rounds) || max_rounds < 1
        max_rounds = 1;
    end
    none_index = find(strcmp({CaseData.name}, 'none') ...
        & strcmp({CaseData.state}, 'ok'), 1);
    none_sigma = [];
    if ~isempty(none_index)
        none_sigma = pick_final_report(CaseData(none_index)).sigma_deg;
    end
    summary_list = cell(1, numel(CaseData));
    for c = 1:numel(CaseData)
        summary_list{c} = compute_case_indicators( ...
            CaseData(c), Groups, none_sigma, max_rounds, Options);
    end
    Summary = [summary_list{:}];
end


function count = count_attempted(Data)
% COUNT_ATTEMPTED 返回工况实际尝试轮数；缺失时返回 0。

    if isempty(Data.Metrics) || ~isfield(Data.Metrics, 'num_attempted')
        count = 0;
    else
        count = Data.Metrics.num_attempted;
    end
end


function Indicator = compute_case_indicators( ...
        Data, Groups, none_sigma, max_rounds, Options)
% COMPUTE_CASE_INDICATORS 计算单个工况的末轮指标、E/D 扩散、转角与对偶统计。

    Indicator = create_empty_indicator(Data, max_rounds);
    if ~isempty(Data.Metrics)
        Metrics = Data.Metrics;
        Indicator.num_attempted = Metrics.num_attempted;
        Indicator.num_accepted = Metrics.num_accepted;
        Indicator.stop_reason = Metrics.stop_reason;
        Indicator.plateau_start = Metrics.plateau_start_iter;
        Indicator.elapsed_seconds = Metrics.elapsed_seconds;
        Indicator.mean_round_seconds = mean(Metrics.iter_seconds, 'omitnan');
        if isfield(Metrics, 'first_status')
            Indicator.first_status = Metrics.first_status;
        elseif ~isempty(Data.attempts) && Data.attempts(1).iter == 1
            Indicator.first_status = 'OPTIMAL/NEAR';
        end
    end
    if ~strcmp(Data.state, 'ok')
        return;
    end

    Attempts = Data.attempts;
    Metrics = Data.Metrics;
    final_position = find([Attempts.accepted], 1, 'last');
    Report = Attempts(final_position).control_report;
    final_iter = Attempts(final_position).iter;
    Indicator.final_iter = final_iter;
    window = Options.window;
    E = Groups.E;
    D = Groups.D;

    %% 逐轮标量序列（按尝试轮号 1..K 放置）
    K_len = numel(Metrics.accepted);
    iters_metrics = (1:K_len)';
    Indicator.impulse_series = place_series(Metrics.total_impulse_m_s, iters_metrics, max_rounds);
    Indicator.gap_series = place_series(Metrics.max_tight_gap, iters_metrics, max_rounds);
    Indicator.inward_series = place_series(Metrics.max_inward_gap, iters_metrics, max_rounds);
    Indicator.outward_series = place_series(Metrics.max_outward_gap, iters_metrics, max_rounds);
    Indicator.rho_series = place_series(Metrics.rho, iters_metrics, max_rounds);
    Indicator.delta_L_series = place_series(Metrics.delta_L, iters_metrics, max_rounds);
    Indicator.circle_error_series = place_series(Metrics.circle_error, iters_metrics, max_rounds);
    if strcmp(Data.mode, 'sccp')
        Indicator.eta_series = place_series(Metrics.eta, iters_metrics, max_rounds);
        Indicator.alpha_series = place_series(Metrics.cap_angle_deg, iters_metrics, max_rounds);
        Indicator.dual_ratio_series = place_series(Metrics.dual_inner_sum_ratio, iters_metrics, max_rounds);
        Indicator.dual_all_ratio_series = place_series(Metrics.dual_inner_sum_all_ratio, iters_metrics, max_rounds);
    end

    %% 逐轮 E/D 扩散、命题 C1 转角、零点与 45±15° 滞留统计
    [init_u1, init_u2] = resolve_initial_control(Metrics, Groups.N);
    prev_u1 = init_u1;
    prev_u2 = init_u2;
    stay_pos45_all = true(Groups.N, 1);
    last_pos45 = false(Groups.N, 1);

    for a = 1:numel(Attempts)
        k = Attempts(a).iter;
        R = Attempts(a).control_report;
        inward_vec = max(1 - R.u_norm, 0);
        abs_gap_vec = abs(R.tight_gap);

        Indicator.inward_E_series(k) = max(inward_vec(E));
        Indicator.inward_D_series(k) = max(inward_vec(D));
        Indicator.min_u_E_series(k) = min(R.u_norm(E));
        Indicator.min_u_D_series(k) = min(R.u_norm(D));
        Indicator.untight_E_series(k) = sum(abs_gap_vec(E) > 1e-6);
        Indicator.untight_D_series(k) = sum(abs_gap_vec(D) > 1e-6);
        Indicator.untight_E_1e3_series(k) = sum(abs_gap_vec(E) > 1e-3);
        Indicator.untight_D_1e3_series(k) = sum(abs_gap_vec(D) > 1e-3);
        Indicator.D_zero_count_series(k) = sum(R.u_norm(D) <= 1e-6);

        prev_norm = hypot(prev_u1, prev_u2);
        valid_E = E & prev_norm > 1e-9 & R.u_norm > 1e-9;
        if any(valid_E)
            prev_sigma_E = atan2d(prev_u2(valid_E), prev_u1(valid_E));
            turn_E = abs(wrap_angle_deg(R.sigma_deg(valid_E) - prev_sigma_E));
            Indicator.turn_E_median_series(k) = median(turn_E);
            Indicator.turn_E_p95_series(k) = compute_percentile_set(turn_E, 95);
            Indicator.turn_E_max_series(k) = max(turn_E);
            alpha_k = Indicator.alpha_series(k);
            if ~isnan(alpha_k)
                Indicator.exceed_E_series(k) = sum(turn_E > alpha_k + 0.5);
            end
        end

        valid_D = D & prev_norm > 1e-9 & R.u_norm > 1e-9;
        if any(valid_D)
            prev_sigma_D = atan2d(prev_u2(valid_D), prev_u1(valid_D));
            turn_D = abs(wrap_angle_deg(R.sigma_deg(valid_D) - prev_sigma_D));
            Indicator.turn_D_median_series(k) = median(turn_D);
            Indicator.turn_D_max_series(k) = max(turn_D);
        end

        pos45_mask = R.u_norm > 1e-9 & abs(wrap_angle_deg(R.sigma_deg - 45)) <= 15;
        stay_pos45_all = stay_pos45_all & pos45_mask;
        if a == final_position
            last_pos45 = pos45_mask;
        end
        if Attempts(a).accepted
            prev_u1 = R.u1(:);
            prev_u2 = R.u2(:);
        end
    end

    %% 末轮与全程汇总（总脉冲、E/D 扩散、滞留）
    series = Indicator.impulse_series;
    range_index = max(1, final_iter - window + 1):final_iter;
    Indicator.impulse_final = series(final_iter);
    Indicator.impulse_mean_last = mean(series(range_index), 'omitnan');
    Indicator.impulse_range_last = max(series(range_index), [], 'omitnan') ...
        - min(series(range_index), [], 'omitnan');
    if final_iter > 10
        Indicator.impulse_decrease_last10 = ...
            (series(final_iter - 10) - series(final_iter)) / 10;
    end

    Indicator.gap_final = Metrics.max_tight_gap(final_iter);
    Indicator.gap_max_all = max(Metrics.max_tight_gap, [], 'omitnan');
    Indicator.inward_final = Metrics.max_inward_gap(final_iter);
    Indicator.outward_final = Metrics.max_outward_gap(final_iter);
    Indicator.num_untight_final = Metrics.num_untight(final_iter);
    if isfield(Metrics, 'num_untight_1e3')
        Indicator.num_untight_1e3_final = Metrics.num_untight_1e3(final_iter);
    else
        Indicator.num_untight_1e3_final = sum(abs(Report.tight_gap) > 1e-3);
    end
    Indicator.num_capped_max = max(Metrics.num_slack_capped, [], 'omitnan');
    if isnan(Indicator.num_capped_max)
        Indicator.num_capped_max = 0;
    end

    if strcmp(Data.mode, 'sccp')
        Indicator.eta_final = Indicator.eta_series(final_iter);
        Indicator.eta_max_all = max(Indicator.eta_series, [], 'omitnan');
        Indicator.eta_min_all = min(Indicator.eta_series, [], 'omitnan');
        Indicator.eta_per_node_final = Indicator.eta_final / Groups.N;
        Indicator.alpha_final = Indicator.alpha_series(final_iter);

        Indicator.dual_ratio_round1 = Indicator.dual_ratio_series(1);
        Indicator.dual_ratio_final = Indicator.dual_ratio_series(final_iter);
        Indicator.dual_ratio_min = min(Indicator.dual_ratio_series, [], 'omitnan');
        Indicator.dual_ratio_max = max(Indicator.dual_ratio_series, [], 'omitnan');
        Indicator.dual_all_ratio_round1 = Indicator.dual_all_ratio_series(1);
        Indicator.dual_all_ratio_final = Indicator.dual_all_ratio_series(final_iter);
    end

    Indicator.inward_E_final = Indicator.inward_E_series(final_iter);
    Indicator.inward_E_max_all = max(Indicator.inward_E_series, [], 'omitnan');
    Indicator.untight_E_final = Indicator.untight_E_series(final_iter);
    Indicator.untight_E_1e3_final = Indicator.untight_E_1e3_series(final_iter);
    Indicator.inward_D_final = Indicator.inward_D_series(final_iter);
    Indicator.inward_D_max_all = max(Indicator.inward_D_series, [], 'omitnan');
    Indicator.untight_D_final = Indicator.untight_D_series(final_iter);
    Indicator.untight_D_1e3_final = Indicator.untight_D_1e3_series(final_iter);

    Indicator.num_stay_pos45_E_all = sum(stay_pos45_all(E));
    Indicator.num_stay_pos45_D_all = sum(stay_pos45_all(D));
    Indicator.num_pos45_E_final = sum(last_pos45(E));
    Indicator.num_pos45_D_final = sum(last_pos45(D));

    %% 圆约束组账与下降比
    Indicator.circle_predicted_final = Metrics.circle_predicted(final_iter);
    Indicator.circle_actual_final = Metrics.circle_actual(final_iter);
    Indicator.circle_error_final = Metrics.circle_error(final_iter);
    finite_err = Metrics.circle_error(isfinite(Metrics.circle_error));
    if ~isempty(finite_err)
        Indicator.circle_error_absmax = max(abs(finite_err));
        Indicator.circle_error_max_pos = max(finite_err);
        Indicator.circle_error_min = min(finite_err);
        Indicator.circle_error_pos_count = sum(finite_err > 1e-12);
        Indicator.circle_error_neg_count = sum(finite_err < -1e-12);
        Indicator.circle_error_zero_count = sum(abs(finite_err) <= 1e-12);
    end

    delta_L_vals = Metrics.delta_L;
    rho_vals = Metrics.rho;
    delta_J_vals = rho_vals .* delta_L_vals;
    Indicator.rho_mean_last = mean(rho_vals(range_index), 'omitnan');
    Indicator.delta_L_mean_last = mean(delta_L_vals(range_index), 'omitnan');
    Indicator.delta_J_mean_last = mean(delta_J_vals(range_index), 'omitnan');

    %% 末轮 E 上乘子分布
    omega = Report.omega;
    kappa_over_omega = Report.cone_dual_leading ./ omega;
    smain_over_omega = Report.s_main_norm ./ omega;
    Indicator.kappa_stats = describe_values(kappa_over_omega(E));
    Indicator.smain_stats = describe_values(smain_over_omega(E));
    if strcmp(Data.mode, 'sccp')
        Indicator.lambda_inner_stats = describe_values( ...
            Report.lambda_inner(E) ./ omega(E));
    end

    %% 末轮 σ 偏差
    Indicator.final_sigma = Report.sigma_deg;
    if ~isempty(none_sigma)
        deviation = abs(wrap_angle_deg(Indicator.final_sigma - none_sigma));
        Indicator.sigma_dev_E_median = median(deviation(E));
        Indicator.sigma_dev_D_median = median(deviation(D));
    end

    %% 全程自检量
    Indicator.min_u_norm_all = min(arrayfun( ...
        @(a) min(a.control_report.u_norm), Attempts));
    Indicator.max_u_norm_all = max(arrayfun( ...
        @(a) max(a.control_report.u_norm), Attempts));
    Indicator.max_outward_all = max(arrayfun( ...
        @(a) a.control_report.summary_total.max_outward_gap, Attempts));
    Indicator.stationarity_max = max(arrayfun( ...
        @(a) max(abs(a.control_report.stationarity_residual), [], 'all'), ...
        Attempts));
    Indicator.final_report_ok = Report.evaluated;
end


function [init_u1, init_u2] = resolve_initial_control(Metrics, N)
% RESOLVE_INITIAL_CONTROL 读取初始参考控制；基线未存该字段时取默认 45 度。

    if isfield(Metrics, 'initial_u1') && isfield(Metrics, 'initial_u2') ...
            && numel(Metrics.initial_u1) == N
        init_u1 = Metrics.initial_u1(:);
        init_u2 = Metrics.initial_u2(:);
    else
        init_u1 = (sqrt(2) / 2) * ones(N, 1);
        init_u2 = (sqrt(2) / 2) * ones(N, 1);
    end
end


function Stats = describe_values(values)
% DESCRIBE_VALUES 返回数组的中位数、5%/95% 分位、最小值、最大值。

    values = values(~isnan(values(:)));
    Stats = struct('median', NaN, 'p5', NaN, 'p95', NaN, ...
        'min', NaN, 'max', NaN);
    if isempty(values)
        return;
    end
    Stats.median = median(values);
    quantiles = compute_percentile_set(values, [5, 95]);
    Stats.p5 = quantiles(1);
    Stats.p95 = quantiles(2);
    Stats.min = min(values);
    Stats.max = max(values);
end


function Indicator = create_empty_indicator(Data, max_rounds)
% CREATE_EMPTY_INDICATOR 创建字段齐全的空工况指标结构体。

    Indicator = struct();
    Indicator.name = Data.name;
    Indicator.source = Data.source;
    Indicator.type = Data.type;
    Indicator.mode = Data.mode;
    Indicator.w = Data.w;
    Indicator.c_eta = Data.c_eta;
    Indicator.enable_control_continuity = Data.enable_control_continuity;
    Indicator.init_control_mode = Data.init_control_mode;
    Indicator.first_status = '-';
    Indicator.version_root = Data.version_root;
    Indicator.unit_norm_mode = Data.unit_norm_mode;
    Indicator.state = Data.state;
    Indicator.error_message = Data.error_message;
    Indicator.num_attempted = NaN;
    Indicator.num_accepted = NaN;
    Indicator.final_iter = NaN;
    Indicator.stop_reason = '';
    Indicator.plateau_start = NaN;
    Indicator.elapsed_seconds = NaN;
    Indicator.mean_round_seconds = NaN;

    series_fields = { ...
        'impulse_series', 'gap_series', 'inward_series', 'outward_series', ...
        'eta_series', 'alpha_series', 'rho_series', 'delta_L_series', ...
        'circle_error_series', 'dual_ratio_series', 'dual_all_ratio_series', ...
        'inward_E_series', 'inward_D_series', 'min_u_E_series', 'min_u_D_series', ...
        'untight_E_series', 'untight_D_series', 'untight_E_1e3_series', ...
        'untight_D_1e3_series', 'D_zero_count_series', ...
        'turn_E_median_series', 'turn_E_p95_series', 'turn_E_max_series', ...
        'exceed_E_series', 'turn_D_median_series', 'turn_D_max_series'};
    for k = 1:numel(series_fields)
        Indicator.(series_fields{k}) = nan(max_rounds, 1);
    end

    Indicator.impulse_final = NaN;
    Indicator.impulse_mean_last = NaN;
    Indicator.impulse_range_last = NaN;
    Indicator.impulse_decrease_last10 = NaN;
    Indicator.gap_final = NaN;
    Indicator.gap_max_all = NaN;
    Indicator.inward_final = NaN;
    Indicator.outward_final = NaN;
    Indicator.num_untight_final = NaN;
    Indicator.num_untight_1e3_final = NaN;
    Indicator.num_capped_max = NaN;
    Indicator.eta_final = NaN;
    Indicator.eta_max_all = NaN;
    Indicator.eta_min_all = NaN;
    Indicator.eta_per_node_final = NaN;
    Indicator.alpha_final = NaN;
    Indicator.inward_E_final = NaN;
    Indicator.inward_E_max_all = NaN;
    Indicator.untight_E_final = NaN;
    Indicator.untight_E_1e3_final = NaN;
    Indicator.inward_D_final = NaN;
    Indicator.inward_D_max_all = NaN;
    Indicator.untight_D_final = NaN;
    Indicator.untight_D_1e3_final = NaN;
    Indicator.num_stay_pos45_E_all = NaN;
    Indicator.num_stay_pos45_D_all = NaN;
    Indicator.num_pos45_E_final = NaN;
    Indicator.num_pos45_D_final = NaN;

    Indicator.circle_predicted_final = NaN;
    Indicator.circle_actual_final = NaN;
    Indicator.circle_error_final = NaN;
    Indicator.circle_error_absmax = NaN;
    Indicator.circle_error_max_pos = NaN;
    Indicator.circle_error_min = NaN;
    Indicator.circle_error_pos_count = 0;
    Indicator.circle_error_neg_count = 0;
    Indicator.circle_error_zero_count = 0;
    Indicator.rho_mean_last = NaN;
    Indicator.delta_L_mean_last = NaN;
    Indicator.delta_J_mean_last = NaN;

    Indicator.dual_ratio_round1 = NaN;
    Indicator.dual_ratio_final = NaN;
    Indicator.dual_ratio_min = NaN;
    Indicator.dual_ratio_max = NaN;
    Indicator.dual_all_ratio_round1 = NaN;
    Indicator.dual_all_ratio_final = NaN;
    Indicator.kappa_stats = struct('median', NaN, 'p5', NaN, 'p95', NaN, ...
        'min', NaN, 'max', NaN);
    Indicator.smain_stats = Indicator.kappa_stats;
    Indicator.lambda_inner_stats = Indicator.kappa_stats;

    Indicator.final_sigma = [];
    Indicator.sigma_dev_E_median = NaN;
    Indicator.sigma_dev_D_median = NaN;
    Indicator.sigma_ref_E_median = NaN;
    Indicator.d_ref_final = NaN;
    Indicator.d_series = nan(max_rounds, 1);
    Indicator.d_final = NaN;
    Indicator.d_mean_last = NaN;
    Indicator.d_range_last = NaN;
    Indicator.d_stable = NaN;
    Indicator.d_stable_round = NaN;

    Indicator.min_u_norm_all = NaN;
    Indicator.max_u_norm_all = NaN;
    Indicator.max_outward_all = NaN;
    Indicator.stationarity_max = NaN;
    Indicator.final_report_ok = false;
end


function series = place_series(values, iters, max_rounds)
% PLACE_SERIES 按轮号把序列值放入长度 max_rounds 的列向量。

    series = nan(max_rounds, 1);
    series(iters) = values(:);
end


function values_out = compute_percentile_set(values, percents)
% COMPUTE_PERCENTILE_SET 线性插值求指定百分位。

    values = sort(values(~isnan(values(:))));
    count = numel(values);
    values_out = nan(size(percents));
    if count == 0
        return;
    end
    for k = 1:numel(percents)
        position = 1 + (count - 1) * percents(k) / 100;
        lower_index = floor(position);
        upper_index = ceil(position);
        values_out(k) = values(lower_index) ...
            + (position - lower_index) * (values(upper_index) - values(lower_index));
    end
end


%% ===== 差值与自检 =====

function Summary = add_difference_indicators(Summary, Groups, Options)
% ADD_DIFFERENCE_INDICATORS 计算相对 none 与 normgap_w1e-4 的差值、稳定性及 σ 偏差。

    ItemList = arrayfun(@(S) S, Summary, 'UniformOutput', false);
    names = {Summary.name};
    none_index = find(strcmp(names, 'none') & strcmp({Summary.state}, 'ok'), 1);
    ref_index = find(strcmp(names, Options.reference_case) ...
        & strcmp({Summary.state}, 'ok'), 1);

    for c = 1:numel(ItemList)
        if ~strcmp(Summary(c).state, 'ok')
            continue;
        end
        S = Summary(c);
        if ~isempty(none_index)
            S = fill_difference(S, ...
                S.impulse_series - Summary(none_index).impulse_series, Options);
        end
        if strcmp(S.mode, 'sccp') && ~isempty(ref_index)
            diff_ref = S.impulse_series - Summary(ref_index).impulse_series;
            S.d_ref_final = diff_ref(S.final_iter);
        end
        ItemList{c} = S;
    end
    Summary = [ItemList{:}];

    if ~isempty(ref_index) && Groups.available
        ref_sigma = Summary(ref_index).final_sigma;
        for c = 1:numel(Summary)
            if ~strcmp(Summary(c).mode, 'sccp') ...
                    || ~strcmp(Summary(c).state, 'ok')
                continue;
            end
            deviation = abs(wrap_angle_deg( ...
                Summary(c).final_sigma - ref_sigma));
            Summary(c).sigma_ref_E_median = median(deviation(Groups.E));
        end
    end
end


function S = fill_difference(S, difference, Options)
% FILL_DIFFERENCE 填充差值序列、末 5 轮极差及稳定轮号。

    final_iter = S.final_iter;
    range_index = max(1, final_iter - Options.window + 1):final_iter;
    last_values = difference(range_index);
    S.d_series = difference;
    S.d_final = difference(final_iter);
    S.d_mean_last = mean(last_values, 'omitnan');
    S.d_range_last = max(last_values, [], 'omitnan') ...
        - min(last_values, [], 'omitnan');
    S.d_stable = double(S.d_range_last <= Options.delta);
    within = abs(difference(1:final_iter) - difference(final_iter)) ...
        <= Options.delta;
    last_outside = find(~within & ~isnan(difference(1:final_iter)), 1, 'last');
    if isempty(last_outside)
        S.d_stable_round = 1;
    else
        S.d_stable_round = last_outside + 1;
    end
end


function Check = check_run(Summary, BaselineData, SccpData)
% CHECK_RUN 校验基线版本标识，并统计全部 SCCP 轮次的预测误差、残差与圆盘可行性。

    Check = struct();
    Check.baseline_names = {BaselineData.name};
    Check.baseline_versions = {BaselineData.version_root};
    Check.baseline_modes = {BaselineData.unit_norm_mode};
    Check.baseline_verified = all(strcmp(Check.baseline_versions, ...
        'Version1-3-standard-5')) && all(strcmp(Check.baseline_modes, ...
        'regularized'));

    Check.sccp_names = {SccpData.name};
    Check.sccp_versions = {SccpData.version_root};
    Check.sccp_modes = {SccpData.unit_norm_mode};

    is_sccp = strcmp({Summary.mode}, 'sccp') & strcmp({Summary.state}, 'ok');
    Sccp = Summary(is_sccp);
    Check.sccp_num_cases = numel(Sccp);
    if isempty(Sccp)
        Check.sccp_circle_error_absmax = NaN;
        Check.sccp_circle_error_max_pos = NaN;
        Check.sccp_circle_error_min = NaN;
        Check.sccp_circle_error_pos_count = 0;
        Check.sccp_circle_error_neg_count = 0;
        Check.sccp_circle_error_zero_count = 0;
        Check.sccp_stationarity_max = NaN;
        Check.sccp_min_u_norm = NaN;
        Check.sccp_max_u_norm = NaN;
        Check.sccp_max_outward_gap = NaN;
        Check.sccp_capped_total = 0;
        return;
    end

    Check.sccp_circle_error_absmax = max([Sccp.circle_error_absmax]);
    Check.sccp_circle_error_max_pos = max([Sccp.circle_error_max_pos]);
    Check.sccp_circle_error_min = min([Sccp.circle_error_min]);
    Check.sccp_circle_error_pos_count = sum([Sccp.circle_error_pos_count]);
    Check.sccp_circle_error_neg_count = sum([Sccp.circle_error_neg_count]);
    Check.sccp_circle_error_zero_count = sum([Sccp.circle_error_zero_count]);
    Check.sccp_stationarity_max = max([Sccp.stationarity_max]);
    Check.sccp_min_u_norm = min([Sccp.min_u_norm_all]);
    Check.sccp_max_u_norm = max([Sccp.max_u_norm_all]);
    Check.sccp_max_outward_gap = max([Sccp.max_outward_all]);
    Check.sccp_capped_total = sum([Sccp.num_capped_max]);
end


%% ===== 写汇总文本 =====

function write_compare_text(text_path, Summary, Groups, Check, Options)
% WRITE_COMPARE_TEXT 写入六节纯数据汇总文本。

    file_id = fopen(text_path, 'w', 'n', 'UTF-8');
    cleanup = onCleanup(@() fclose(file_id));

    write_run_list(file_id, Summary);
    write_baseline_and_self_check(file_id, Check, Options);
    write_final_and_diffusion_tables(file_id, Summary, Groups);
    write_cap_and_freezing_tables(file_id, Summary, Groups);
    write_init_special_tables(file_id, Summary);
    write_multipliers_ledger_and_series(file_id, Summary, Groups);

    fprintf(file_id, ['\n（δ = %g m/s，window = %d；节点分组: none 末轮 ' ...
        '|D| = %g，|E| = %g，N = %g）\n'], Options.delta, Options.window, ...
        Groups.num_D, Groups.num_E, Groups.N);
end


function write_run_list(file_id, Summary)
% WRITE_RUN_LIST 第 1 节：全部 18 个工况（5 基线 + 13 SCCP）的运行清单。

    fprintf(file_id, '=== 1 运行清单 ===\n');
    headers = {'工况', '模式', 'w 或 C_eta', '速率', '初值', '轮数', '接受', ...
        '首轮状态', '停止原因', '用时(s)', '末轮脉冲', '末轮η', '末轮max|1-‖u‖|'};
    rows = cell(numel(Summary), numel(headers));
    for c = 1:numel(Summary)
        S = Summary(c);
        if strcmp(S.mode, 'sccp')
            coef = sprintf('C=%.0e', S.c_eta);
        elseif ~isnan(S.w)
            coef = sprintf('w=%.0e', S.w);
        else
            coef = '-';
        end
        rows(c, :) = { ...
            S.name, S.mode, coef, yes_no_text(S.enable_control_continuity), ...
            S.init_control_mode, format_value(S.num_attempted, '%d'), ...
            format_value(S.num_accepted, '%d'), char_or_dash(S.first_status), ...
            char_or_dash(S.stop_reason), format_value(S.elapsed_seconds, '%.1f'), ...
            format_value(S.impulse_final, '%.4f'), ...
            format_value(S.eta_final, '%.3e'), ...
            format_value(S.gap_final, '%.3e')};
    end
    write_table(file_id, headers, rows);
end


function write_baseline_and_self_check(file_id, Check, Options)
% WRITE_BASELINE_AND_SELF_CHECK 第 2 节：只读基线版本校验与全部 SCCP 轮次自检。

    fprintf(file_id, '\n=== 2 基线校验与自检 ===\n');
    fprintf(file_id, '只读基线目录: %s\n', Options.baseline_root);
    fprintf(file_id, '基线统一校验结果 (version_root==Version1-3-standard-5 & mode==regularized): %s\n', ...
        yes_no_text(Check.baseline_verified));
    headers = {'基线工况', 'version_root', 'unit_norm_mode'};
    rows = cell(numel(Check.baseline_names), 3);
    for k = 1:numel(Check.baseline_names)
        rows(k, :) = {Check.baseline_names{k}, ...
            char_or_dash(Check.baseline_versions{k}), ...
            char_or_dash(Check.baseline_modes{k})};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n全部 SCCP 工况全部轮次自检（可用工况数 = %d）:\n', ...
        Check.sccp_num_cases);
    fprintf(file_id, '  圆约束组预测误差 max|D_unit| = %.3e\n', ...
        Check.sccp_circle_error_absmax);
    fprintf(file_id, '  圆约束组 D_unit 最大正值 = %+.3e，最小值 = %+.3e\n', ...
        Check.sccp_circle_error_max_pos, Check.sccp_circle_error_min);
    fprintf(file_id, '  圆约束组 D_unit 符号轮次计数: 正(>1e-12)=%d，负(<-1e-12)=%d，零(|D|<=1e-12)=%d\n', ...
        Check.sccp_circle_error_pos_count, Check.sccp_circle_error_neg_count, ...
        Check.sccp_circle_error_zero_count);
    fprintf(file_id, '  u 列驻点残差全程最大值 = %.3e\n', Check.sccp_stationarity_max);
    fprintf(file_id, '  圆盘可行性 max(‖u_i‖-1, 0) 全程最大值 = %.3e（max‖u‖ = %.12f）\n', ...
        Check.sccp_max_outward_gap, Check.sccp_max_u_norm);
    fprintf(file_id, '  min(‖u_i‖) 全程最小值 = %.12f\n', Check.sccp_min_u_norm);
    fprintf(file_id, '  触及 η 上界 (1e4) 工况/轮次累计 = %d\n', Check.sccp_capped_total);
end


function write_final_and_diffusion_tables(file_id, Summary, Groups)
% WRITE_FINAL_AND_DIFFUSION_TABLES 第 3 节：末轮总脉冲表与 E/D 节点不紧扩散表。

    fprintf(file_id, '\n=== 3 末轮表与 E/D 分组不紧扩散（|E|=%d, |D|=%d） ===\n', ...
        Groups.num_E, Groups.num_D);
    fprintf(file_id, '(3a) 总脉冲与相对 none 同轮差值 d:\n');
    headers = {'工况', '末轮', '末轮总脉冲', '末5轮均值', '末10轮降幅/轮', ...
        '末5轮极差', 'd 末轮', 'd 末5轮极差', '稳定轮', '稳定', '减 normgap_w1e-4'};
    rows = cell(numel(Summary), numel(headers));
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.final_iter, '%d'), ...
            format_value(S.impulse_final, '%.4f'), ...
            format_value(S.impulse_mean_last, '%.4f'), ...
            format_value(S.impulse_decrease_last10, '%.4f'), ...
            format_value(S.impulse_range_last, '%.4f'), ...
            format_value_plus(S.d_final), format_value_plus(S.d_range_last), ...
            format_value(S.d_stable_round, '%d'), stable_text(S.d_stable), ...
            format_value_plus(S.d_ref_final)};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(3b) 全程与末轮 E/D 不紧扩散及对偶门槛比:\n');
    headers = {'工况', '末轮η', '全程maxη', 'E末轮max(1-‖u‖)', ...
        'E全程max(1-‖u‖)', 'E末轮>1e-6', 'E末轮>1e-3', ...
        'D末轮max(1-‖u‖)', 'D全程max(1-‖u‖)', 'D末轮>1e-6', 'D末轮>1e-3', ...
        'Σy/NC_η(轮1)', 'Σy/NC_η(末轮)'};
    rows = cell(numel(Summary), numel(headers));
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, ...
            format_value(S.eta_final, '%.3e'), format_value(S.eta_max_all, '%.3e'), ...
            format_value(S.inward_E_final, '%.3e'), format_value(S.inward_E_max_all, '%.3e'), ...
            format_value(S.untight_E_final, '%d'), format_value(S.untight_E_1e3_final, '%d'), ...
            format_value(S.inward_D_final, '%.3e'), format_value(S.inward_D_max_all, '%.3e'), ...
            format_value(S.untight_D_final, '%d'), format_value(S.untight_D_1e3_final, '%d'), ...
            format_value(S.dual_ratio_round1, '%.4f'), ...
            format_value(S.dual_ratio_final, '%.4f')};
    end
    write_table(file_id, headers, rows);
end


function write_cap_and_freezing_tables(file_id, Summary, Groups)
% WRITE_CAP_AND_FREEZING_TABLES 第 4 节：命题 C1 帽半角与实际转角对比及 45±15° 冻结统计。

    fprintf(file_id, '\n=== 4 命题 C1 转角上限与冻结行为 ===\n');
    fprintf(file_id, '(4a) 关键轮 η、理论帽半角 α = arccos(1 - η/(2N)) 与 E 节点单步转角 (deg):\n');
    headers = {'工况', '轮次', 'η', 'η/N', 'α(deg)', ...
        'E中位', 'E 95%', 'E最大', '超α+0.5°数', 'E max(1-‖u‖)', 'D max(1-‖u‖)'};
    row_list = {};
    is_sccp = strcmp({Summary.mode}, 'sccp') & strcmp({Summary.state}, 'ok');
    for c = find(is_sccp)
        S = Summary(c);
        if S.num_attempted <= 10
            key_rounds = [1, 2, 5, 10];
        else
            key_rounds = [1, 2, 5, 10, 20, 50];
        end
        key_rounds = key_rounds(key_rounds <= S.num_attempted);
        if ~isnan(S.final_iter) && ~ismember(S.final_iter, key_rounds)
            key_rounds = sort([key_rounds, S.final_iter]);
        end
        for k = key_rounds
            eta_k = S.eta_series(k);
            row_list{end + 1, 1} = {S.name, sprintf('%d', k), ...
                format_value(eta_k, '%.3e'), ...
                format_value(eta_k / Groups.N, '%.3e'), ...
                format_value(S.alpha_series(k), '%.4f'), ...
                format_value(S.turn_E_median_series(k), '%.4f'), ...
                format_value(S.turn_E_p95_series(k), '%.4f'), ...
                format_value(S.turn_E_max_series(k), '%.4f'), ...
                format_value(S.exceed_E_series(k), '%d'), ...
                format_value(S.inward_E_series(k), '%.3e'), ...
                format_value(S.inward_D_series(k), '%.3e')}; %#ok<AGROW>
        end
    end
    if ~isempty(row_list)
        rows = vertcat(row_list{:});
        write_table(file_id, headers, rows);
    end

    fprintf(file_id, '\n(4b) 全程与末轮留在 45°±15° 内节点数及末轮 σ 偏差:\n');
    headers = {'工况', 'E全程45±15°', 'D全程45±15°', 'E末轮45±15°', ...
        'D末轮45±15°', 'E|Δσ|中位(相对none)', 'D|Δσ|中位(相对none)', ...
        'E|Δσ|中位(相对normgap)'};
    rows = cell(numel(Summary), numel(headers));
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, ...
            format_value(S.num_stay_pos45_E_all, '%d'), ...
            format_value(S.num_stay_pos45_D_all, '%d'), ...
            format_value(S.num_pos45_E_final, '%d'), ...
            format_value(S.num_pos45_D_final, '%d'), ...
            format_value(S.sigma_dev_E_median, '%.3f'), ...
            format_value(S.sigma_dev_D_median, '%.3f'), ...
            format_value(S.sigma_ref_E_median, '%.3f')};
    end
    write_table(file_id, headers, rows);
end


function write_init_special_tables(file_id, Summary)
% WRITE_INIT_SPECIAL_TABLES 第 5 节：零初值与圆内初值专项比较（第 1、2、5、10 轮及逐轮序列）。

    fprintf(file_id, '\n=== 5 初值专项对比（C_eta = 1e-4） ===\n');
    init_names = {'sccp_c1e-4', 'sccp_init0p3_c1e-4', ...
        'sccp_init0_c1e-4', 'sccp_init0_nr_c1e-4'};
    fprintf(file_id, '(5a) 第 1、2、5、10 轮明细:\n');
    headers = {'工况', '轮次', '总脉冲(m/s)', 'η', 'η/N', ...
        'D max(1-‖u‖)', 'D min‖u‖', 'D 原点数(≤1e-6)', 'E max(1-‖u‖)', 'E min‖u‖'};
    row_list = {};
    for i = 1:numel(init_names)
        idx = find(strcmp({Summary.name}, init_names{i}) ...
            & strcmp({Summary.state}, 'ok'), 1);
        if isempty(idx)
            continue;
        end
        S = Summary(idx);
        N_nodes = numel(S.final_sigma);
        for k = [1, 2, 5, 10]
            if k > S.num_attempted
                continue;
            end
            row_list{end + 1, 1} = {S.name, sprintf('%d', k), ...
                format_value(S.impulse_series(k), '%.4f'), ...
                format_value(S.eta_series(k), '%.4e'), ...
                format_value(S.eta_series(k) / N_nodes, '%.4e'), ...
                format_value(S.inward_D_series(k), '%.3e'), ...
                format_value(S.min_u_D_series(k), '%.6f'), ...
                format_value(S.D_zero_count_series(k), '%d'), ...
                format_value(S.inward_E_series(k), '%.3e'), ...
                format_value(S.min_u_E_series(k), '%.6f')}; %#ok<AGROW>
        end
    end
    if ~isempty(row_list)
        write_table(file_id, headers, vertcat(row_list{:}));
    end

    fprintf(file_id, '\n(5b) 第 1–10 轮逐轮轨迹（总脉冲、η、D min‖u‖、D max(1-‖u‖)、E max(1-‖u‖)）:\n');
    specs = { ...
        'impulse_series', '总脉冲 (m/s)', '%.3f'; ...
        'eta_series', 'η', '%.2e'; ...
        'min_u_D_series', 'D min‖u‖', '%.5f'; ...
        'inward_D_series', 'D max(1-‖u‖)', '%.2e'; ...
        'inward_E_series', 'E max(1-‖u‖)', '%.2e'};
    round_headers = [{'工况'}, arrayfun(@(k) sprintf('轮%d', k), 1:10, ...
        'UniformOutput', false)];
    for s = 1:size(specs, 1)
        fprintf(file_id, '\n%s:\n', specs{s, 2});
        rows = cell(numel(init_names), 11);
        for i = 1:numel(init_names)
            idx = find(strcmp({Summary.name}, init_names{i}), 1);
            rows{i, 1} = init_names{i};
            for k = 1:10
                if isempty(idx) || ~strcmp(Summary(idx).state, 'ok') ...
                        || k > numel(Summary(idx).(specs{s, 1}))
                    rows{i, k + 1} = '-';
                else
                    rows{i, k + 1} = format_value( ...
                        Summary(idx).(specs{s, 1})(k), specs{s, 3});
                end
            end
        end
        write_table(file_id, round_headers, rows);
    end
end


function write_multipliers_ledger_and_series(file_id, Summary, Groups)
% WRITE_MULTIPLIERS_LEDGER_AND_SERIES 第 6 节：圆约束账、乘子与逐轮序列。

    fprintf(file_id, '\n=== 6 圆约束账、乘子与逐轮序列 ===\n');
    fprintf(file_id, '(6a) 圆约束组逐项账与末 5 轮 ρ/ΔL 均值:\n');
    headers = {'工况', 'ΔL末轮', 'ΔJ末轮', 'D末轮', '全程max|D|', ...
        '全程max正D', '全程minD', '末5轮ρ', '末5轮ΔL'};
    rows = cell(numel(Summary), numel(headers));
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, ...
            format_value_plus(S.circle_predicted_final), ...
            format_value_plus(S.circle_actual_final), ...
            format_value_plus(S.circle_error_final), ...
            format_value(S.circle_error_absmax, '%.3e'), ...
            format_value_plus(S.circle_error_max_pos), ...
            format_value_plus(S.circle_error_min), ...
            format_value(S.rho_mean_last, '%.4f'), ...
            format_value_plus(S.delta_L_mean_last)};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(6b) SCCP 对偶门槛比与末轮 E 上乘子统计:\n');
    is_sccp = strcmp({Summary.mode}, 'sccp');
    Sccp = Summary(is_sccp);
    headers = {'工况', '2NC_η', 'Σy/NC_η(轮1)', 'Σy/NC_η(末轮)', ...
        'Σ(-y_all)/NC_η(轮1)', 'Σ(-y_all)/NC_η(末轮)', ...
        'κ̂/ω中位', '‖s_main‖/ω中位', 'λ_inner/ω中位', 'λ_inner/ω最大'};
    rows = cell(numel(Sccp), numel(headers));
    for c = 1:numel(Sccp)
        S = Sccp(c);
        rows(c, :) = {S.name, ...
            format_value(2 * Groups.N * S.c_eta, '%.3e'), ...
            format_value(S.dual_ratio_round1, '%.4f'), ...
            format_value(S.dual_ratio_final, '%.4f'), ...
            format_value(S.dual_all_ratio_round1, '%.4f'), ...
            format_value(S.dual_all_ratio_final, '%.4f'), ...
            format_value(S.kappa_stats.median, '%.3e'), ...
            format_value(S.smain_stats.median, '%.3e'), ...
            format_value(S.lambda_inner_stats.median, '%.3e'), ...
            format_value(S.lambda_inner_stats.max, '%.3e')};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(6c) 主扫描与基线逐轮序列（共 50 轮）:\n');
    num_rounds = numel(Summary(1).impulse_series);
    round_headers = [{'工况'}, arrayfun(@(k) sprintf('轮%d', k), 1:num_rounds, ...
        'UniformOutput', false)];
    series_specs = { ...
        'impulse_series', '各轮总脉冲 (m/s)', '%.3f'; ...
        'gap_series', '各轮 max|1-‖u‖|', '%.1e'; ...
        'eta_series', '各轮 η（sccp）', '%.1e'; ...
        'alpha_series', '各轮理论帽半角 α (deg)', '%.2f'; ...
        'turn_E_median_series', '各轮 E 节点转角中位数 (deg)', '%.2f'};
    for s = 1:size(series_specs, 1)
        fprintf(file_id, '\n%s:\n', series_specs{s, 2});
        rows = cell(numel(Summary), num_rounds + 1);
        for c = 1:numel(Summary)
            values = Summary(c).(series_specs{s, 1});
            rows{c, 1} = Summary(c).name;
            for k = 1:num_rounds
                rows{c, k + 1} = format_value(values(k), series_specs{s, 3});
            end
        end
        write_table(file_id, round_headers, rows);
    end
end


function text = yes_no_text(value)
% YES_NO_TEXT 逻辑量转“是”“否”。

    if value
        text = '是';
    else
        text = '否';
    end
end


function text = stable_text(flag)
% STABLE_TEXT 稳定标志转文字，NaN 写为 '-'。

    if isnan(flag)
        text = '-';
    elseif flag > 0
        text = '是';
    else
        text = '否';
    end
end


function text = format_value(value, spec)
% FORMAT_VALUE 标量格式化，NaN 写成 '-'，Inf 写成 'Inf'。

    if isnan(value)
        text = '-';
    elseif isinf(value)
        text = 'Inf';
    else
        text = sprintf(spec, value);
    end
end


function text = format_value_plus(value)
% FORMAT_VALUE_PLUS 带正负号科学计数，NaN 写成 '-'。

    text = format_value(value, '%+.3e');
end


function text = char_or_dash(value)
% CHAR_OR_DASH 空字符写成 '-'。

    if isempty(value)
        text = '-';
    else
        text = value;
    end
end


function write_table(file_id, headers, rows)
% WRITE_TABLE 按显示宽度对齐写表：首列左对齐，其余列右对齐，列间两空格。

    all_rows = [headers; rows];
    num_columns = size(all_rows, 2);
    widths = zeros(1, num_columns);
    for c = 1:num_columns
        widths(c) = max(cellfun(@display_width, all_rows(:, c)));
    end
    for r = 1:size(all_rows, 1)
        parts = cell(1, num_columns);
        for c = 1:num_columns
            padding = blanks(widths(c) - display_width(all_rows{r, c}));
            if c == 1
                parts{c} = [all_rows{r, c}, padding];
            else
                parts{c} = [padding, all_rows{r, c}];
            end
        end
        fprintf(file_id, '%s\n', strjoin(parts, '  '));
    end
end


function width = display_width(text)
% DISPLAY_WIDTH 计算字符显示宽度：全角中文字符占两格，其余占一格。

    width = sum(1 + (double(text) >= 11904));
end


%% ===== 绘图 =====

function plot_compare_figures(Summary, Groups, Options, pictures_root)
% PLOT_COMPARE_FIGURES 导出全部对比图（字号 16、底部共用图例）。
%
% 本函数依次完成：
%   1. 各轮总脉冲对比图。
%   2. 相对 none 同轮差值对比图。
%   3. E/D 节点不紧扩散随 C_eta 对比图。
%   4. 命题 C1 转角与冻结比例对比图。
%   5. 初值影响对比图（前 10 轮）。
%   6. 末轮 σ 叠画图。
%   7. 逐轮最大不紧量与 η 演变图。

    if ~isfolder(pictures_root)
        mkdir(pictures_root);
    end
    plot_round_impulse_figure(Summary, pictures_root);
    plot_difference_rounds_figure(Summary, Options, pictures_root);
    plot_ed_diffusion_figure(Summary, pictures_root);
    plot_cap_and_freezing_figure(Summary, Groups, pictures_root);
    plot_initial_mode_figure(Summary, Groups, pictures_root);
    plot_final_sigma_figure(Summary, Groups, pictures_root);
    plot_tightness_and_eta_figure(Summary, pictures_root);
end


function plot_round_impulse_figure(Summary, pictures_root)
% PLOT_ROUND_IMPULSE_FIGURE 对比-各轮总脉冲：4 个分块，共用纵轴范围与底部图例。

    font_size = 16;
    fig = new_figure('对比-各轮总脉冲', [80, 80, 1750, 520]);
    layout = tiledlayout(fig, 1, 4, 'TileSpacing', 'compact', 'Padding', 'compact');

    main_names = {'none', 'normgap_w1e-3', 'normgap_w1e-4', 'normgap_w1e-5', ...
        'sccp_c1e-8', 'sccp_c1e-7', 'sccp_c1e-6', 'sccp_c1e-5', ...
        'sccp_c1e-4', 'sccp_c1e-3', 'sccp_c1e-2', 'sccp_c1e0', ...
        'sccp_nr_c1e-7', 'sccp_nr_c1e-5'};
    limits = padded_limits(collect_field_values(Summary, main_names, 'impulse_series'));

    tile_specs = { ...
        {'none', 'normgap_w1e-3', 'normgap_w1e-4', 'normgap_w1e-5'}, 'regularized', false; ...
        {'none', 'sccp_c1e-8', 'sccp_c1e-7', 'sccp_c1e-6', 'sccp_c1e-5'}, 'sccp，低 C_η', true; ...
        {'none', 'sccp_c1e-4', 'sccp_c1e-3', 'sccp_c1e-2', 'sccp_c1e0'}, 'sccp，高 C_η', true; ...
        {'sccp_c1e-7', 'sccp_nr_c1e-7', 'sccp_c1e-5', 'sccp_nr_c1e-5'}, '无速率约束对照', false};

    handles = gobjects(1, 0);
    for t = 1:size(tile_specs, 1)
        ax = nexttile(layout);
        hold(ax, 'on');
        tile_handles = draw_named_cases(ax, Summary, 'impulse_series', ...
            tile_specs{t, 1}, tile_specs{t, 3});
        if t < 4
            handles = [handles, tile_handles]; %#ok<AGROW>
        else
            % 第 4 块仅把新出现的 nr 两条加入图例
            nr_mask = arrayfun(@(h) contains(h.DisplayName, 'nr '), tile_handles);
            handles = [handles, tile_handles(nr_mask)]; %#ok<AGROW>
        end
        ylim(ax, limits);
        style_axes(ax, ['总脉冲 (m/s)，' tile_specs{t, 2}], '迭代轮次', font_size);
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-各轮总脉冲.png'));
end


function plot_difference_rounds_figure(Summary, Options, pictures_root)
% PLOT_DIFFERENCE_ROUNDS_FIGURE 对比-相对none差值：4 个分块，画 0 与 ±δ 虚线。

    font_size = 16;
    fig = new_figure('对比-相对none差值', [80, 80, 1750, 520]);
    layout = tiledlayout(fig, 1, 4, 'TileSpacing', 'compact', 'Padding', 'compact');

    reg_names = {'normgap_w1e-3', 'normgap_w1e-4', 'normgap_w1e-5'};
    all_names = [reg_names, {'sccp_c1e-8', 'sccp_c1e-7', 'sccp_c1e-6', 'sccp_c1e-5', ...
        'sccp_c1e-4', 'sccp_c1e-3', 'sccp_c1e-2', 'sccp_c1e0', ...
        'sccp_nr_c1e-7', 'sccp_nr_c1e-5'}];
    zoom_limits = padded_limits([collect_field_values(Summary, reg_names, 'd_series'); ...
        {Options.delta; -Options.delta}]);
    full_limits = padded_limits([collect_field_values(Summary, all_names, 'd_series'); ...
        {Options.delta; -Options.delta}]);

    tile_specs = { ...
        reg_names, 'regularized 放大', zoom_limits, true; ...
        {'sccp_c1e-8', 'sccp_c1e-7', 'sccp_c1e-6', 'sccp_c1e-5'}, 'sccp，低 C_η', full_limits, true; ...
        {'sccp_c1e-4', 'sccp_c1e-3', 'sccp_c1e-2', 'sccp_c1e0'}, 'sccp，高 C_η', full_limits, true; ...
        {'sccp_c1e-7', 'sccp_nr_c1e-7', 'sccp_c1e-5', 'sccp_nr_c1e-5'}, '无速率约束对照', full_limits, false};

    handles = gobjects(1, 0);
    for t = 1:size(tile_specs, 1)
        ax = nexttile(layout);
        hold(ax, 'on');
        yline(ax, 0, 'k-', 'LineWidth', 1.0, 'HandleVisibility', 'off');
        yline(ax, Options.delta, '--', 'Color', [0.55 0.55 0.55], ...
            'LineWidth', 1.2, 'HandleVisibility', 'off');
        yline(ax, -Options.delta, '--', 'Color', [0.55 0.55 0.55], ...
            'LineWidth', 1.2, 'HandleVisibility', 'off');
        tile_handles = draw_named_cases(ax, Summary, 'd_series', ...
            tile_specs{t, 1}, false);
        if tile_specs{t, 4}
            handles = [handles, tile_handles]; %#ok<AGROW>
        else
            nr_mask = arrayfun(@(h) contains(h.DisplayName, 'nr '), tile_handles);
            handles = [handles, tile_handles(nr_mask)]; %#ok<AGROW>
        end
        ylim(ax, tile_specs{t, 3});
        style_axes(ax, ['d (m/s)，' tile_specs{t, 2}], '迭代轮次', font_size);
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-相对none差值.png'));
end


function plot_ed_diffusion_figure(Summary, pictures_root)
% PLOT_ED_DIFFUSION_FIGURE 对比-ED不紧扩散：全程/末轮 E 与 D 节点最大不紧量随 C_eta。

    font_size = 16;
    fig = new_figure('对比-ED不紧扩散', [100, 100, 1250, 540]);
    layout = tiledlayout(fig, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    floor_val = 1e-12;

    main_names = {'sccp_c1e-8', 'sccp_c1e-7', 'sccp_c1e-6', 'sccp_c1e-5', ...
        'sccp_c1e-4', 'sccp_c1e-3', 'sccp_c1e-2', 'sccp_c1e0'};
    nr_names = {'sccp_nr_c1e-7', 'sccp_nr_c1e-5'};
    [c_main, e_all, e_fin, d_all, d_fin] = collect_ed_arrays(Summary, main_names, floor_val);
    [c_nr, e_nr_all, e_nr_fin, d_nr_all, d_nr_fin] = collect_ed_arrays(Summary, nr_names, floor_val);
    none_idx = find(strcmp({Summary.name}, 'none') & strcmp({Summary.state}, 'ok'), 1);

    handles = gobjects(1, 0);
    for t = 1:2
        ax = nexttile(layout);
        hold(ax, 'on');
        if t == 1
            y_all = e_all; y_fin = e_fin;
            y_nr_all = e_nr_all; y_nr_fin = e_nr_fin;
            ref_val = Summary(none_idx).inward_E_final;
            y_label = 'E 节点 max(1-‖u‖)';
        else
            y_all = d_all; y_fin = d_fin;
            y_nr_all = d_nr_all; y_nr_fin = d_nr_fin;
            ref_val = Summary(none_idx).inward_D_final;
            y_label = 'D 节点 max(1-‖u‖)';
        end
        h1 = plot(ax, c_main, y_all, '-o', 'Color', [0.13 0.35 0.65], ...
            'MarkerFaceColor', [0.13 0.35 0.65], 'MarkerSize', 8, ...
            'LineWidth', 1.8, 'DisplayName', '全程最大（带速率）');
        h2 = plot(ax, c_main, y_fin, '-s', 'Color', [0.80 0.25 0.20], ...
            'MarkerFaceColor', [0.80 0.25 0.20], 'MarkerSize', 8, ...
            'LineWidth', 1.8, 'DisplayName', '末轮（带速率）');
        h3 = plot(ax, c_nr, y_nr_all, '--^', 'Color', [0.13 0.35 0.65], ...
            'MarkerFaceColor', 'none', 'MarkerSize', 9, ...
            'LineWidth', 1.5, 'DisplayName', '全程最大（无速率）');
        h4 = plot(ax, c_nr, y_nr_fin, '--d', 'Color', [0.80 0.25 0.20], ...
            'MarkerFaceColor', 'none', 'MarkerSize', 9, ...
            'LineWidth', 1.5, 'DisplayName', '末轮（无速率）');
        h5 = yline(ax, max(ref_val, floor_val), ':', 'Color', [0.35 0.35 0.35], ...
            'LineWidth', 1.5, 'DisplayName', 'none 末轮');
        set(ax, 'XScale', 'log', 'YScale', 'log');
        ylim(ax, [1e-12, 2]);
        style_axes(ax, y_label, 'C_η', font_size);
        if t == 1
            handles = [h1, h2, h3, h4, h5];
        end
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-ED不紧扩散.png'));
end


function plot_cap_and_freezing_figure(Summary, Groups, pictures_root)
% PLOT_CAP_AND_FREEZING_FIGURE 对比-命题C1转角与冻结：理论帽半角、E 转角与 45±15° 比例。

    font_size = 16;
    fig = new_figure('对比-命题C1转角与冻结', [80, 80, 1650, 540]);
    layout = tiledlayout(fig, 1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');

    main_names = {'sccp_c1e-8', 'sccp_c1e-7', 'sccp_c1e-6', 'sccp_c1e-5', ...
        'sccp_c1e-4', 'sccp_c1e-3', 'sccp_c1e-2', 'sccp_c1e0'};
    c_vals = nan(numel(main_names), 1);
    alpha_r2 = nan(numel(main_names), 1);
    max_r2 = nan(numel(main_names), 1);
    p95_r2 = nan(numel(main_names), 1);
    med_r2 = nan(numel(main_names), 1);
    alpha_r10 = nan(numel(main_names), 1);
    max_r10 = nan(numel(main_names), 1);
    p95_r10 = nan(numel(main_names), 1);
    med_r10 = nan(numel(main_names), 1);
    stay_E_pct = nan(numel(main_names), 1);
    stay_D_pct = nan(numel(main_names), 1);

    for k = 1:numel(main_names)
        idx = find(strcmp({Summary.name}, main_names{k}) ...
            & strcmp({Summary.state}, 'ok'), 1);
        if isempty(idx)
            continue;
        end
        S = Summary(idx);
        c_vals(k) = S.c_eta;
        alpha_r2(k) = S.alpha_series(2);
        max_r2(k) = S.turn_E_max_series(2);
        p95_r2(k) = S.turn_E_p95_series(2);
        med_r2(k) = S.turn_E_median_series(2);
        alpha_r10(k) = S.alpha_series(10);
        max_r10(k) = S.turn_E_max_series(10);
        p95_r10(k) = S.turn_E_p95_series(10);
        med_r10(k) = S.turn_E_median_series(10);
        stay_E_pct(k) = 100 * S.num_stay_pos45_E_all / Groups.num_E;
        stay_D_pct(k) = 100 * S.num_stay_pos45_D_all / Groups.num_D;
    end

    floor_deg = 1e-4;
    handles = gobjects(1, 0);

    % 分块 1：第 2 轮；分块 2：第 10 轮
    round_sets = { ...
        alpha_r2, max_r2, p95_r2, med_r2, '第 2 轮转角 (deg)'; ...
        alpha_r10, max_r10, p95_r10, med_r10, '第 10 轮转角 (deg)'};
    for t = 1:2
        ax = nexttile(layout);
        hold(ax, 'on');
        a_v = clamp_positive(round_sets{t, 1}, floor_deg);
        m_v = clamp_positive(round_sets{t, 2}, floor_deg);
        p_v = clamp_positive(round_sets{t, 3}, floor_deg);
        d_v = clamp_positive(round_sets{t, 4}, floor_deg);

        h1 = plot(ax, c_vals, a_v, 'k--', 'LineWidth', 2.2, ...
            'DisplayName', '理论帽半角 α');
        h2 = plot(ax, c_vals, m_v, '-^', 'Color', [0.80 0.25 0.20], ...
            'MarkerFaceColor', [0.80 0.25 0.20], 'MarkerSize', 7, ...
            'LineWidth', 1.5, 'DisplayName', 'E 实际转角 max');
        h3 = plot(ax, c_vals, p_v, '-s', 'Color', [0.13 0.55 0.63], ...
            'MarkerFaceColor', [0.13 0.55 0.63], 'MarkerSize', 7, ...
            'LineWidth', 1.5, 'DisplayName', 'E 实际转角 95%');
        h4 = plot(ax, c_vals, d_v, '-o', 'Color', [0.20 0.55 0.25], ...
            'MarkerFaceColor', [0.20 0.55 0.25], 'MarkerSize', 7, ...
            'LineWidth', 1.5, 'DisplayName', 'E 实际转角中位');
        set(ax, 'XScale', 'log', 'YScale', 'log');
        ylim(ax, [1e-4, 220]);
        style_axes(ax, round_sets{t, 5}, 'C_η', font_size);
        if t == 1
            handles = [h1, h2, h3, h4];
        end
    end

    % 分块 3：全程留在 45°±15° 内比例
    ax = nexttile(layout);
    hold(ax, 'on');
    h5 = plot(ax, c_vals, stay_E_pct, '-d', 'Color', [0.13 0.30 0.60], ...
        'MarkerFaceColor', [0.13 0.30 0.60], 'MarkerSize', 8, ...
        'LineWidth', 1.8, 'DisplayName', 'E 全程留 45°±15°');
    h6 = plot(ax, c_vals, stay_D_pct, '--v', 'Color', [0.85 0.45 0.10], ...
        'MarkerFaceColor', [0.85 0.45 0.10], 'MarkerSize', 8, ...
        'LineWidth', 1.8, 'DisplayName', 'D 全程留 45°±15°');
    set(ax, 'XScale', 'log');
    ylim(ax, [-5, 105]);
    style_axes(ax, '全程留 45°±15° 节点比例 (%)', 'C_η', font_size);
    handles = [handles, h5, h6];

    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-命题C1转角与冻结.png'));
end


function plot_initial_mode_figure(Summary, Groups, pictures_root)
% PLOT_INITIAL_MODE_FIGURE 对比-初值影响：前 10 轮总脉冲、η、D min‖u‖ 与 E 不紧量。

    font_size = 16;
    fig = new_figure('对比-初值影响', [100, 100, 1300, 900]);
    layout = tiledlayout(fig, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

    init_names = {'sccp_c1e-4', 'sccp_init0p3_c1e-4', ...
        'sccp_init0_c1e-4', 'sccp_init0_nr_c1e-4'};
    floor_val = 1e-12;
    rounds = 1:10;

    tile_specs = { ...
        'impulse_series', '总脉冲 (m/s)', 'linear', []; ...
        'eta_series', '共用松弛 η', 'log', Groups.N; ...
        'min_u_D_series', 'D 节点 min‖u‖', 'linear', 1; ...
        'inward_E_series', 'E 节点 max(1-‖u‖)', 'log', []};

    handles = gobjects(1, 0);
    for t = 1:size(tile_specs, 1)
        ax = nexttile(layout);
        hold(ax, 'on');
        field_name = tile_specs{t, 1};
        y_scale = tile_specs{t, 3};
        ref_line = tile_specs{t, 4};

        if ~isempty(ref_line)
            yline(ax, ref_line, '--', 'Color', [0.35 0.35 0.35], ...
                'LineWidth', 1.3, 'HandleVisibility', 'off');
        end
        plotted_vals = [];
        for i = 1:numel(init_names)
            idx = find(strcmp({Summary.name}, init_names{i}) ...
                & strcmp({Summary.state}, 'ok'), 1);
            if isempty(idx)
                continue;
            end
            S = Summary(idx);
            Style = case_style(S);
            y_vals = S.(field_name)(rounds);
            if strcmp(y_scale, 'log')
                y_vals = clamp_positive(y_vals, floor_val);
            end
            plotted_vals = [plotted_vals; y_vals(:)]; %#ok<AGROW>
            h = plot(ax, rounds, y_vals, Style.line, 'Color', Style.color, ...
                'Marker', Style.marker, 'MarkerFaceColor', marker_face(Style), ...
                'MarkerSize', 7, 'LineWidth', 1.6, 'DisplayName', Style.label);
            if t == 1
                handles(end + 1) = h; %#ok<AGROW>
            end
        end
        if strcmp(y_scale, 'log')
            set(ax, 'YScale', 'log');
            all_y = [plotted_vals; ref_line(:)];
            all_y = all_y(isfinite(all_y) & all_y > 0);
            if ~isempty(all_y)
                ylim(ax, [min(all_y) * 0.6, max(all_y) * 1.8]);
            end
        else
            ylim(ax, padded_limits([plotted_vals; ref_line(:)]));
        end
        xlim(ax, [0.5, 10.5]);
        xticks(ax, 1:10);
        style_axes(ax, tile_specs{t, 2}, '迭代轮次', font_size);
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-初值影响.png'));
end


function plot_final_sigma_figure(Summary, Groups, pictures_root)
% PLOT_FINAL_SIGMA_FIGURE 对比-末轮σ：每圈分块，叠画 none、normgap_w1e-4 与代表 SCCP。

    if ~Groups.available
        return;
    end
    font_size = 16;
    names = {'none', 'normgap_w1e-4', 'sccp_c1e-6', 'sccp_c1e-4'};
    y_limits = [-190, 190];
    fig = new_figure('对比-末轮σ', [60, 80, 1750, 520]);
    layout = tiledlayout(fig, 1, max(Groups.cir), ...
        'TileSpacing', 'compact', 'Padding', 'compact');

    handles = gobjects(1, 0);
    for cir = 1:max(Groups.cir)
        ax = nexttile(layout);
        hold(ax, 'on');
        in_cir = Groups.cir == cir;
        ylim(ax, y_limits);
        handle_shade = gobjects(1);
        if any(Groups.D & in_cir)
            intervals = build_group_intervals(Groups.tau(in_cir), Groups.D(in_cir));
            for k = 1:size(intervals, 1)
                handle_shade = patch(ax, ...
                    [intervals(k, 1); intervals(k, 2); intervals(k, 2); intervals(k, 1)], ...
                    [y_limits(1); y_limits(1); y_limits(2); y_limits(2)], ...
                    [0.85 0.85 0.85], 'EdgeColor', 'none', 'FaceAlpha', 0.5, ...
                    'HandleVisibility', 'off');
            end
            handle_shade.DisplayName = 'D 节点';
        end
        for k = 1:numel(names)
            idx = find(strcmp({Summary.name}, names{k}) ...
                & strcmp({Summary.state}, 'ok'), 1);
            if isempty(idx)
                continue;
            end
            Style = case_style(Summary(idx));
            h = plot(ax, Groups.tau(in_cir), Summary(idx).final_sigma(in_cir), ...
                Style.line, 'Color', Style.color, 'LineWidth', 1.6, ...
                'DisplayName', Style.label);
            if cir == 1
                handles(end + 1) = h; %#ok<AGROW>
            end
        end
        if cir == 1 && any(Groups.D & in_cir)
            handles = [handle_shade, handles]; %#ok<AGROW>
        end
        style_axes(ax, sprintf('σ (deg)，第 %d 圈', cir), '圈内 τ', font_size);
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-末轮σ.png'));
end


function plot_tightness_and_eta_figure(Summary, pictures_root)
% PLOT_TIGHTNESS_AND_ETA_FIGURE 对比-紧性与eta：上排 max|1-‖u‖|，下排 η 随轮次演变。

    font_size = 16;
    fig = new_figure('对比-紧性与eta', [80, 80, 1650, 900]);
    layout = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
    floor_val = 1e-12;

    groups = { ...
        {'sccp_c1e-8', 'sccp_c1e-7', 'sccp_c1e-6', 'sccp_c1e-5'}, '低 C_η'; ...
        {'sccp_c1e-4', 'sccp_c1e-3', 'sccp_c1e-2', 'sccp_c1e0'}, '高 C_η'; ...
        {'sccp_c1e-7', 'sccp_nr_c1e-7', 'sccp_c1e-5', 'sccp_nr_c1e-5'}, '无速率对照'};

    handles = gobjects(1, 0);
    for g = 1:size(groups, 1)
        ax = nexttile(layout, g);
        hold(ax, 'on');
        tile_handles = draw_named_cases(ax, Summary, 'gap_series', ...
            groups{g, 1}, false, floor_val);
        set(ax, 'YScale', 'log');
        style_axes(ax, ['max|1-‖u‖|，' groups{g, 2}], '', font_size);
        if g < 3
            handles = [handles, tile_handles]; %#ok<AGROW>
        else
            nr_mask = arrayfun(@(h) contains(h.DisplayName, 'nr '), tile_handles);
            handles = [handles, tile_handles(nr_mask)]; %#ok<AGROW>
        end

        ax = nexttile(layout, 3 + g);
        hold(ax, 'on');
        draw_named_cases(ax, Summary, 'eta_series', groups{g, 1}, false, floor_val);
        set(ax, 'YScale', 'log');
        style_axes(ax, ['η，' groups{g, 2}], '迭代轮次', font_size);
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-紧性与eta.png'));
end


%% ===== 绘图辅助 =====

function [c_vals, e_all, e_fin, d_all, d_fin] = collect_ed_arrays( ...
        Summary, names, floor_val)
% COLLECT_ED_ARRAYS 提取指定工况列表的 C_eta 与 E/D 全程及末轮不紧量。

    n = numel(names);
    c_vals = nan(n, 1);
    e_all = nan(n, 1);
    e_fin = nan(n, 1);
    d_all = nan(n, 1);
    d_fin = nan(n, 1);
    for k = 1:n
        idx = find(strcmp({Summary.name}, names{k}) ...
            & strcmp({Summary.state}, 'ok'), 1);
        if isempty(idx)
            continue;
        end
        S = Summary(idx);
        c_vals(k) = S.c_eta;
        e_all(k) = clamp_positive(S.inward_E_max_all, floor_val);
        e_fin(k) = clamp_positive(S.inward_E_final, floor_val);
        d_all(k) = clamp_positive(S.inward_D_max_all, floor_val);
        d_fin(k) = clamp_positive(S.inward_D_final, floor_val);
    end
end


function values = clamp_positive(values, floor_val)
% CLAMP_POSITIVE 对非 NaN 元素取下限 floor_val（用于对数坐标），保持 NaN 不变。

    valid = ~isnan(values);
    values(valid) = max(values(valid), floor_val);
end


function values = collect_field_values(Summary, names, field_name)
% COLLECT_FIELD_VALUES 收集给定工况集合的某个序列字段到列元胞数组。

    values = cell(0, 1);
    for k = 1:numel(names)
        idx = find(strcmp({Summary.name}, names{k}) ...
            & strcmp({Summary.state}, 'ok'), 1);
        if ~isempty(idx) && isfield(Summary(idx), field_name)
            values{end + 1, 1} = Summary(idx).(field_name)(:); %#ok<AGROW>
        end
    end
end


function handles = draw_named_cases(ax, Summary, field_name, names, ...
        skip_none, floor_value)
% DRAW_NAMED_CASES 按给定工况名序列绘图，返回纳入图例的句柄数组。

    if nargin < 6
        floor_value = [];
    end
    handles = gobjects(1, 0);
    for k = 1:numel(names)
        idx = find(strcmp({Summary.name}, names{k}) ...
            & strcmp({Summary.state}, 'ok'), 1);
        if isempty(idx)
            continue;
        end
        S = Summary(idx);
        vals = S.(field_name);
        if all(isnan(vals))
            continue;
        end
        if ~isempty(floor_value)
            has_val = ~isnan(vals);
            vals(has_val) = max(vals(has_val), floor_value);
        end
        Style = case_style(S);
        rounds = 1:numel(vals);
        step = max(1, floor(numel(rounds) / 10));
        marker_idx = 1:step:numel(rounds);
        h = plot(ax, rounds, vals, Style.line, 'Color', Style.color, ...
            'Marker', Style.marker, 'MarkerIndices', marker_idx, ...
            'MarkerFaceColor', marker_face(Style), 'MarkerSize', 6, ...
            'LineWidth', 1.6, 'DisplayName', Style.label);
        if isfield(S, 'plateau_start') && ~isnan(S.plateau_start)
            xline(ax, S.plateau_start, ':', 'Color', Style.color, ...
                'LineWidth', 1.2, 'HandleVisibility', 'off');
        end
        if ~(skip_none && strcmp(S.name, 'none'))
            handles(end + 1) = h; %#ok<AGROW>
        end
    end
end


function Style = case_style(S)
% CASE_STYLE 为基线与全部 13 个 SCCP 工况分配固定颜色、标记、线型与图例名。

    if strcmp(S.name, 'none')
        Style = struct('color', [0.35 0.35 0.35], 'marker', 'none', ...
            'line', '--', 'filled', false, 'label', 'none');
    elseif strcmp(S.type, 'norm_gap')
        markers = {'d', 'o', 's'};
        idx = find([1e-3, 1e-4, 1e-5] == S.w, 1);
        Style = struct('color', [0.75 0.40 0.65], 'marker', markers{idx}, ...
            'line', '-', 'filled', true, ...
            'label', sprintf('normgap w=1e%d', round(log10(S.w))));
    elseif strcmp(S.type, 'norm')
        Style = struct('color', [0.55 0.35 0.55], 'marker', 'o', ...
            'line', ':', 'filled', false, 'label', 'norm w=1e-4');
    elseif strcmp(S.init_control_mode, 'scale_0p3')
        Style = struct('color', [0.13 0.55 0.63], 'marker', 's', ...
            'line', '-', 'filled', true, 'label', '初值 0.3（带速率）');
    elseif strcmp(S.init_control_mode, 'zero') && S.enable_control_continuity
        Style = struct('color', [0.85 0.45 0.10], 'marker', '^', ...
            'line', '-', 'filled', true, 'label', '零初值（带速率）');
    elseif strcmp(S.init_control_mode, 'zero') && ~S.enable_control_continuity
        Style = struct('color', [0.75 0.15 0.15], 'marker', 'd', ...
            'line', '--', 'filled', false, 'label', '零初值（无速率）');
    elseif ~S.enable_control_continuity
        if abs(S.c_eta - 1e-7) < 1e-12
            Style = struct('color', [0.10 0.50 0.72], 'marker', '^', ...
                'line', '--', 'filled', false, 'label', 'nr C_η=1e-7');
        else
            Style = struct('color', [0.18 0.63 0.40], 'marker', 'v', ...
                'line', '--', 'filled', false, 'label', 'nr C_η=1e-5');
        end
    else
        exponents = [-8, -7, -6, -5, -4, -3, -2, 0];
        colors = [ ...
            0.12 0.25 0.55; ...
            0.10 0.50 0.72; ...
            0.15 0.65 0.65; ...
            0.18 0.63 0.40; ...
            0.55 0.70 0.20; ...
            0.90 0.65 0.15; ...
            0.90 0.38 0.10; ...
            0.70 0.12 0.15];
        markers = {'o', 's', '^', 'd', 'v', 'p', 'h', '*'};
        exp_val = round(log10(S.c_eta));
        idx = find(exponents == exp_val, 1);
        Style = struct('color', colors(idx, :), 'marker', markers{idx}, ...
            'line', '-', 'filled', true, ...
            'label', sprintf('C_η=1e%d', exp_val));
        if strcmp(S.name, 'sccp_c1e-4') && strcmp(S.init_control_mode, 'default')
            % 保持默认标签在主扫描里简洁，初值图里也可识别
            Style.label = 'C_η=1e-4';
        end
    end
end


function face = marker_face(Style)
% MARKER_FACE 标记填充色：实心取线色，空心取 none。

    if Style.filled
        face = Style.color;
    else
        face = 'none';
    end
end


function limits = padded_limits(values)
% PADDED_LIMITS 计算有限数值范围并上下各留 5% 边距。

    if iscell(values)
        values = vertcat(values{:});
    end
    values = values(isfinite(values));
    if isempty(values)
        limits = [0, 1];
        return;
    end
    span = max(values) - min(values);
    if span == 0
        span = max(1, abs(values(1)));
    end
    limits = [min(values) - 0.05 * span, max(values) + 0.05 * span];
end


function intervals = build_group_intervals(tau, mask)
% BUILD_GROUP_INTERVALS 把一圈内连续节点掩码合成为 τ 区间矩阵 [起点, 终点]。

    intervals = zeros(0, 2);
    if isempty(tau) || ~any(mask)
        return;
    end
    tau = tau(:);
    mask = logical(mask(:));
    midpoint = (tau(1:end - 1) + tau(2:end)) / 2;
    lower_edge = [tau(1) - (midpoint(1) - tau(1)); midpoint(:)];
    upper_edge = [midpoint(:); tau(end) + (tau(end) - midpoint(end))];
    change = diff([false; mask; false]);
    start_index = find(change == 1);
    stop_index = find(change == -1) - 1;
    intervals = [lower_edge(start_index), upper_edge(stop_index)];
end


function fig = new_figure(name, position)
% NEW_FIGURE 新建不可见图窗。

    fig = figure('Name', name, 'NumberTitle', 'off', 'Visible', 'off', ...
        'Position', position);
end


function style_axes(ax, y_label, x_label, font_size)
% STYLE_AXES 统一设置字号 16、网格与坐标轴标签。

    set(ax, 'FontSize', font_size, 'Box', 'on');
    grid(ax, 'on');
    ylabel(ax, y_label, 'FontSize', font_size);
    if ~isempty(x_label)
        xlabel(ax, x_label, 'FontSize', font_size);
    end
end


function place_shared_legend(ax, handles, font_size)
% PLACE_SHARED_LEGEND 在多分块图窗底部放共用图例。

    if isempty(handles)
        return;
    end
    legend_object = legend(ax, handles, 'Orientation', 'horizontal', ...
        'NumColumns', min(numel(handles), 6), 'FontSize', font_size);
    legend_object.Layout.Tile = 'south';
end


function finish_figure(fig, png_path)
% FINISH_FIGURE 导出 PNG 并关闭图窗。

    save_plot_figure(fig, png_path);
    close(fig);
end
