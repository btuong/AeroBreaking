function draw_numerics_scatter(fig, Numerics, figure_title, config)
% DRAW_NUMERICS_SCATTER 画 A 逐行的“行内跨度 - 相对残差”散点图，按约束块着色。
%
% 横轴为行内跨度（最大系数 / 最小非零系数），纵轴为该行在原始矩阵上的相对
% 残差，两轴均为对数。竖参考线在 max_row_span（系数有风险），横参考线在
% residual_reference（求解器精度量级）。点都在横线以下说明本轮精度正常；右上
% 角的点说明系数悬殊已经伤到精度；左上角的点说明问题不在系数量级。
% 残差为 0 的行画在 eps 处。
%
% 输入:
%   fig          - 目标图窗
%   Numerics     - build_iteration_plot_data 输出的 PlotData.numerics
%   figure_title - 整扇窗的总标题
%   config       - 读取 config.plot.font_size

    if isempty(Numerics.relative)
        draw_empty_notice(fig, figure_title, ...
            '本轮 P3 失败，没有返回解，无法计算残差', config);
        return;
    end

    font_size = config.plot.font_size;
    ax = axes(fig);
    hold(ax, 'on');
    residual = max(Numerics.relative, eps);   % 对数轴画不出 0

    % 每个约束块一种颜色；不属于任何块的行记为“其他”
    block_ids = unique(Numerics.block(:)).';
    colors = lines(numel(block_ids));
    for b = 1:numel(block_ids)
        in_block = Numerics.block == block_ids(b);
        if block_ids(b) == 0
            name = '其他';
        else
            name = Numerics.block_names{block_ids(b)};
        end
        scatter(ax, Numerics.span(in_block), residual(in_block), 18, ...
            colors(b, :), 'filled', 'MarkerFaceAlpha', 0.6, ...
            'DisplayName', name);
    end

    set(ax, 'XScale', 'log', 'YScale', 'log');
    if isfinite(Numerics.span_reference)
        xline(ax, Numerics.span_reference, '--k', 'LineWidth', 1.2, ...
            'DisplayName', '跨度上限');
    end
    if isfinite(Numerics.residual_reference)
        yline(ax, Numerics.residual_reference, ':k', 'LineWidth', 1.2, ...
            'DisplayName', '求解器精度');
    end

    % 两条参考线都包进坐标范围，上下左右各留约半个数量级
    fit_log_limits(ax, 'x', [Numerics.span(:); Numerics.span_reference]);
    fit_log_limits(ax, 'y', [residual(:); Numerics.residual_reference]);

    style_plot_axes(ax, '行内跨度', '相对残差', config);
    legend(ax, 'show', 'Location', 'bestoutside', 'FontSize', font_size, ...
        'Interpreter', 'none');
    title(ax, figure_title, 'FontSize', font_size, 'Interpreter', 'none');
end


function fit_log_limits(ax, axis_name, values)
% FIT_LOG_LIMITS 对数轴范围取数据与参考线的最小、最大值，两端各放宽 3 倍。

    values = values(isfinite(values) & values > 0);
    if isempty(values)
        return;
    end
    limits = [min(values) / 3, max(values) * 3];
    if axis_name == 'x'
        xlim(ax, limits);
    else
        ylim(ax, limits);
    end
end
