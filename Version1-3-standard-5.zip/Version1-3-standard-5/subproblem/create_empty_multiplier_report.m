function Report = create_empty_multiplier_report()
% CREATE_EMPTY_MULTIPLIER_REPORT 创建字段齐全的“未评价”P3 乘子报告。
%
% 字段与 evaluate_p3_multipliers 的输出一致；未评价时数值为 NaN 或空，
% reason 写明原因。

    Report.evaluated = false;
    Report.reason = 'not_evaluated';

    % 按约束类统计：罚项类（动力学、衔接、终端倾角、终端远地点）带罚权 w 和
    % |y|/w，其余硬约束类只给 max|y|，weight 和 ratio 为 NaN
    Report.classes = struct('name', {}, 'label', {}, 'weight', {}, ...
        'num_rows', {}, 'max_abs', {}, 'ratio', {}, 'worst_row', {}, ...
        'location', {});

    % 逐区间的动力学乘子比 |y|/w_dyn（区间数 x 5，列为 r, V, gamma, phi, psi）
    % 和逐衔接点的乘子比 |y|/w_poi（5 x 5，行为初始点和 4 个内点）
    Report.dynamics_ratio = [];
    Report.junction_ratio = [];

    % 信赖域乘子：通道依次为 r, V, gamma, phi, psi, P
    Report.trust_channel_names = {'r', 'V', 'gamma', 'phi', 'psi', 'P'};
    Report.trust_active_count = nan(1, 6);   % 各通道信赖域界生效的变量个数
    Report.trust_slope_channel = nan(1, 6);  % 各通道 Σ(slx+sux)·b
    Report.trust_slope_total = NaN;          % 各通道之和，即 dΔL/dr（只存不显示）
    Report.trust_share = nan(1, 6);          % 各通道占 trust_slope_total 的比例
    Report.trust_active_node = [];           % N x 5 逻辑矩阵，节点信赖域界是否生效
    Report.trust_active_pulse = [];          % 6 x 1 逻辑向量，脉冲信赖域界是否生效
    Report.active_dual_tolerance = NaN;      % 判定“生效”用的乘子下限
end
