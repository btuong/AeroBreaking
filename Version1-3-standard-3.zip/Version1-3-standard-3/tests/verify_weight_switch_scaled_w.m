function verify_weight_switch_scaled_w()
% VERIFY_WEIGHT_SWITCH_SCALED_W 验证关闭积分权 ω_i 后缩小 w_reg 的解表现。
%
% 在 control_reg_use_integration_weights = false（ω=0）下，分别取：
%   1) w_reg = 1e-4 / 300        （缩小 300 倍，对应近地点有效段放大倍数）；
%   2) w_reg = 1e-4 * 5 / 661    （缩小 132.2 倍，与 ω=1 等总权重 Σ = 5e-4）；
% 对 norm、sum、u1、u2 各跑 10 轮（fixed、r=1、tolerance=0，不写 results/），
% 并读取 regularizer_converge/results_weight_switch/ 中原 w=1e-4 的 ω=1、ω=0 存档对照。

    %% 1. 准备路径与基准参数
    tests_dir = fileparts(mfilename('fullpath'));
    version_root = fileparts(tests_dir);
    [~, version_name] = fileparts(version_root);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));

    modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
        'trust_region', 'validation', 'iteration', 'output', 'tests'};
    for k = 1:numel(modules)
        addpath(fullfile(version_root, modules{k}));
    end
    rehash;

    base_w = 1e-4;
    scale_300 = 300;
    scale_eq_sum = 661 / 5;   % 661 节点与 5 圈积分权总和之比
    reg_types = {'norm', 'sum', 'u1', 'u2'};
    archive_root = fullfile(version_root, 'regularizer_converge', 'results_weight_switch');

    fprintf('=== %s: 关闭 ω_i 后缩小 w_reg 验证 (10 轮, fixed r=1) ===\n', version_name);
    fprintf('基准 w_reg = %.1e | /300 = %.4e | /132.2 (等总权) = %.4e\n\n', ...
        base_w, base_w / scale_300, base_w / scale_eq_sum);

    header = sprintf('%-18s | %5s | %10s | %9s | %10s | %9s | %9s | %4s | %8s | %7s', ...
        'case', 'ok', 'DV(m/s)', 'dDV_vs_o1', 'Gamma@10', 'maxGapAll', 'maxGap@10', ...
        'feas', 'rat_med', 'rat>1');
    fprintf('%s\n%s\n', header, repmat('-', 1, strlength(header)));

    %% 2. 逐正则类型运行并对照存档
    for t = 1:numel(reg_types)
        reg_type = reg_types{t};

        % 读取原存档 ω=1 与 ω=0 (w=1e-4)
        base_o1 = load_archived_case(archive_root, sprintf('%s_omega_1', reg_type));
        base_o0 = load_archived_case(archive_root, sprintf('%s_omega_0', reg_type));

        % 现跑 ω=0 缩小 300 倍与缩小 132.2 倍
        scaled_300 = run_scaled_case(reg_type, base_w / scale_300, false);
        scaled_eq = run_scaled_case(reg_type, base_w / scale_eq_sum, false);

        print_row(sprintf('%s_o1_1e-4', reg_type), base_o1, base_o1.dv_last);
        print_row(sprintf('%s_o0_1e-4', reg_type), base_o0, base_o1.dv_last);
        print_row(sprintf('%s_o0_div300', reg_type), scaled_300, base_o1.dv_last);
        print_row(sprintf('%s_o0_div132', reg_type), scaled_eq, base_o1.dv_last);
        fprintf('\n');
    end
end


function Summary = load_archived_case(archive_root, case_name)
% LOAD_ARCHIVED_CASE 从既有权重开关存档读取 10 轮汇总指标。

    metrics_file = fullfile(archive_root, case_name, 'case_metrics.mat');
    loaded = load(metrics_file, 'Metrics');
    M = loaded.Metrics;
    idx = M.final_index;

    % 从控制量文本读取第 10 轮 ratio 中位数与 ratio>1 节点数
    [ratio_med, ratio_gt1] = read_control_ratio_from_txt( ...
        fullfile(archive_root, case_name, 'scp_run_control.txt'));

    Summary = struct( ...
        'ok_iters', M.num_accepted, ...
        'num_attempted', M.num_attempted, ...
        'dv_last', M.total_impulse_m_s(idx), ...
        'gamma_last', M.Gamma(idx), ...
        'max_gap_all', max(M.max_tight_gap), ...
        'max_gap_last', M.max_tight_gap(idx), ...
        'feasible_last', logical(M.feasible(idx)), ...
        'apoapsis_km', M.apoapsis_km(idx), ...
        'inclination_deg', M.inclination_deg(idx), ...
        'ratio_med', ratio_med, ...
        'ratio_gt1', ratio_gt1);
end


function [ratio_med, ratio_gt1] = read_control_ratio_from_txt(txt_path)
% READ_CONTROL_RATIO_FROM_TXT 从 scp_run_control.txt 读取全程第 10 轮的 ratio 统计。

    ratio_med = NaN;
    ratio_gt1 = NaN;
    if ~isfile(txt_path)
        return;
    end
    lines = readlines(txt_path);
    for k = 1:numel(lines)
        line_str = strtrim(lines(k));
        if startsWith(line_str, '全程') && contains(line_str, 'e')
            tokens = regexp(char(line_str), '\s+', 'split');
            if numel(tokens) >= 4
                val_med = str2double(tokens{2});
                val_gt1 = str2double(tokens{4});
                if isfinite(val_med) && isfinite(val_gt1)
                    ratio_med = val_med;
                    ratio_gt1 = val_gt1;
                end
            end
        end
    end
end


function Summary = run_scaled_case(reg_type, w_reg, use_weights)
% RUN_SCALED_CASE 按给定正则方式、权重与积分权开关跑 10 轮 SCP。

    config = scp_config_default();
    config.iter.max_scp_iter = 10;
    config.iter.tolerance = 0;
    config.objective.control_reg_type = reg_type;
    config.objective.weight_control_reg = w_reg;
    config.objective.control_reg_use_integration_weights = use_weights;

    % 关闭全部绘图、终端明细与文件保存，避免覆盖 results/
    config.plot.enable_initial = false;
    config.plot.enable_iteration = false;
    config.plot.enable_final = false;
    config.output.print_pre_iteration = false;
    config.output.print_iteration = false;
    config.output.print_summary = false;
    config.output.save.brief_text = false;
    config.output.save.detail_text = false;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    config.output.save.control_text = false;
    config.output.save.control_mat = false;
    config.validation.enable_trapezoid_check = false;

    [ConstData, InitialState] = initialize_problem(config);
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, config);
    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);

    max_gap_all = 0;
    ok_iters = 0;
    dv_last = NaN;
    gamma_last = NaN;
    max_gap_last = NaN;
    feasible_last = false;
    apoapsis_km = NaN;
    inclination_deg = NaN;
    ratio_med = NaN;
    ratio_gt1 = NaN;

    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);

        if TrustResult.candidate_available && TrustResult.accept_candidate
            ok_iters = ok_iters + 1;
            CR = SubproblemDiag.control_report;
            max_gap_all = max(max_gap_all, max(abs(CR.tight_gap)));
            max_gap_last = max(abs(CR.tight_gap));
            P2F = SubproblemDiag.p2_feasibility;
            dv_last = P2F.performance_report.value;
            apoapsis_km = P2F.terminal_report.metrics(1).actual_value;
            inclination_deg = P2F.terminal_report.metrics(2).actual_value;
            feasible_last = logical(P2F.feasible);
            gamma_last = TrustResult.evaluation.group.extra.candidate;
            ratio_med = median(CR.reg_ratio, 'omitnan');
            ratio_gt1 = sum(CR.reg_ratio > 1);
        end
    end

    Summary = struct( ...
        'ok_iters', ok_iters, ...
        'num_attempted', RunState.num_attempted, ...
        'dv_last', dv_last, ...
        'gamma_last', gamma_last, ...
        'max_gap_all', max_gap_all, ...
        'max_gap_last', max_gap_last, ...
        'feasible_last', feasible_last, ...
        'apoapsis_km', apoapsis_km, ...
        'inclination_deg', inclination_deg, ...
        'ratio_med', ratio_med, ...
        'ratio_gt1', ratio_gt1);
end


function print_row(label, S, dv_ref)
% PRINT_ROW 打印单行工况对照指标。

    fprintf('%-18s | %2d/%2d | %10.4f | %+9.4f | %10.3e | %9.2e | %9.2e | %4d | %8.3f | %4d/661\n', ...
        label, S.ok_iters, S.num_attempted, S.dv_last, S.dv_last - dv_ref, ...
        S.gamma_last, S.max_gap_all, S.max_gap_last, double(S.feasible_last), ...
        S.ratio_med, round(S.ratio_gt1));
end
