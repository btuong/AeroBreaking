function ConvergenceReport = compute_scp_convergence( ...
        CurrentSolution, CurrentReference, config)
% COMPUTE_SCP_CONVERGENCE 计算本轮凸解相对当前参考的 SCP 收敛度量。
%
% 项目既定判据：相邻两次迭代解的原始量最大差
%   err = max( max|Δu1|, max|Δu2|, max|ΔP|, max|Δx| ) < tolerance
% 各通道均为归一化单位下的原始差值（不同量纲混合比较，知识库 D7
% 记录了该判据的尺度问题，属既定实现口径）。
%
% 判据只用上面四个通道。为了打印时定位，另存：
%   metrics(k).max_index - 最大差所在位置：u1、u2、state 为节点号，P 为脉冲序号
%   state_channels       - 状态 5 个通道（r, V, gamma, phi, psi）各自的最大差
%                          difference 和所在节点 max_index，不参与判据
%   t_f_channel          - 各圈飞行时间差的最大值与所在圈。t_f 是决策变量但
%                          不在判据内（既定口径），只作显示通道，不参与判据
%
% 本函数只计算收敛报告，不修改参考、不设置停止状态、不判断接受。

    tolerance = config.iter.tolerance;

    [u1_difference, u1_node] = max(abs( ...
        CurrentSolution.control.u1 - CurrentReference.control.u1));
    [u2_difference, u2_node] = max(abs( ...
        CurrentSolution.control.u2 - CurrentReference.control.u2));
    [P_difference, P_index] = max(abs( ...
        CurrentSolution.control.P - CurrentReference.control.P));

    % 状态差按通道取最大，再取各通道中的最大作为 state 通道
    state_abs = abs(CurrentSolution.state - CurrentReference.state);
    [channel_difference, channel_node] = max(state_abs, [], 1);
    [state_difference, worst_channel] = max(channel_difference);

    metrics = [ ...
        create_convergence_metric('u1', u1_difference, u1_node); ...
        create_convergence_metric('u2', u2_difference, u2_node); ...
        create_convergence_metric('P', P_difference, P_index); ...
        create_convergence_metric('state', state_difference, ...
            channel_node(worst_channel))];

    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    channel_list = cell(1, numel(state_names));
    for s = 1:numel(state_names)
        channel_list{s} = create_convergence_metric(state_names{s}, ...
            channel_difference(s), channel_node(s));
    end

    % t_f 是决策变量但不在判据内；按圈记最大差与位置，供打印单列显示通道
    [tf_difference, tf_cir] = max(abs( ...
        CurrentSolution.t_f - CurrentReference.t_f));
    t_f_channel = create_convergence_metric('t_f', tf_difference, tf_cir);

    [max_value, max_index] = max([metrics.difference]);
    ConvergenceReport.converged = max_value < tolerance;
    ConvergenceReport.metrics = metrics;
    ConvergenceReport.state_channels = [channel_list{:}];
    ConvergenceReport.t_f_channel = t_f_channel;
    ConvergenceReport.max_value = max_value;
    ConvergenceReport.max_name = metrics(max_index).name;
    ConvergenceReport.tolerance = tolerance;
end


function Metric = create_convergence_metric(name, difference, max_index)
% CREATE_CONVERGENCE_METRIC 创建单通道原始量差收敛指标，并记下最大差所在位置。

    Metric = struct();
    Metric.name = name;
    Metric.difference = difference;
    Metric.max_index = max_index;
    Metric.unit = 'normalized';
    Metric.active = true;
end
