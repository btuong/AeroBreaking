function print_initial_summary( ...
        ConstData, InitialReference, InitialPropagation)
% PRINT_INITIAL_SUMMARY 打印任务参数与初始参考轨迹摘要（迭代前输出）。
%
% 只读初始化对象；初始参考不编号为第 0 次接受迭代或最终结果。

    LU = ConstData.LU;
    VU = ConstData.VU;

    fprintf('\n========== 初始参考摘要 ==========\n');
    fprintf('目标轨道远地点 ra_aim: %.2f km\n', ...
        ConstData.R_aaim * LU / 1e3);
    fprintf('目标轨道近地点 rp_aim: %.2f km\n', ...
        ConstData.R_paim * LU / 1e3);
    fprintf('目标轨道倾角 i_aim:  %.2f deg\n', ...
        rad2deg(ConstData.i_aim));

    Passes = InitialPropagation.passes;
    fprintf('\n打靶得到的各圈初始脉冲:\n');
    for cir = 1:numel(Passes)
        fprintf('  第 %d 圈初始脉冲: %.2f m/s\n', ...
            cir, Passes(cir).P * VU);
    end
    fprintf('  最后入轨脉冲:   %.2f m/s\n', ...
        Passes(end).P5 * VU);

    fprintf('\n各圈减速后远地点 ra (km):\n');
    ra_values = [Passes.ra] * LU / 1e3;
    fprintf('  %.2f  %.2f  %.2f  %.2f  %.2f\n\n', ra_values);

    fprintf('最终结束点轨道倾角: %.4f rad (%.2f deg)\n', ...
        InitialPropagation.i, rad2deg(InitialPropagation.i));
    fprintf('初始参考节点数 N = %d\n', InitialReference.N);
    fprintf('==================================\n');
end
