# Version1-3-standard-5 凹凸分解模式

自 `Version1-3-standard-3` 复制（2026-11-23；复制了模块、入口、README、知识库、`tests/` 和 `tightness_diagnosis/` 的代码，不含结果和实验文件夹，复制时代码与 standard-3 相同）。新增可切换的凹凸分解（CCD，Lu 2020）模式处理单位范数约束 ‖u‖=1：`config.unit_norm.mode = 'ccd'` 下每个控制节点多一个松弛 ε_i，凸的一半 ‖u_i‖ ≤ 1 + ε_i 原样保留并罚 p·ω_i·ε_i，反凸的一半 ‖u_i‖ ≥ 1 在参考控制处线性化为 ē_i^T·u_i ≥ 1；没有控制正则项，J = C + Θ，Θ 多一项单位范数罚项。u1、u2 的 ±1 箱形边界在 ccd 下默认随凸的一半放宽到 ±(1 + ε 上界)，`ccd_keep_control_bounds = true` 时保留。默认的 `'regularized'` 行为不变，判停、信赖域、动力学都不动。主代码改了约 20 个文件，清单见 `Version1-3-standard-5/README.md` 的「阶段5-1」一节。

验证（2026-11-24）：默认入口 10 轮的简略、详细文件与 standard-3 的存档逐字节相同，控制量文本只差版本名一行；`none`、`norm_w1e-4` 各 50 轮与阶段3-1 存档的逐轮总脉冲最大差为 0；三个测试文件 23 个用例全部通过（含规格第 4 节的玩具问题、零步长可行性、圆约束组预测误差）。

阶段5-1 的对比实验（`Version1-3-standard-5/ccd_compare/`，口径同阶段3-1：fixed、r = 1、50 轮）共 13 个工况：regularized 五个，ccd 六档 p = 1e-3…1e2（默认 p = 1），保留箱形边界的对照两档。末轮总脉冲 regularized 为 88.85～88.87 m/s，ccd 为 96.32（p = 0.1）到 128.68（p = 100），p ≤ 1e-2 时为 78.8～79.3 但有节点触到 ε 上界；圆约束组的预测误差在 ccd 下不超过 1e-8，在 regularized 下不大于 0。数据见 [阶段报告](../Version1-3-standard-5/docs/算法改进_阶段5-1_凹凸分解模式.md)。
