function LogInfo = compute_log_display(Curves)
% COMPUTE_LOG_DISPLAY 对数纵轴的显示范围：下限由数据定，不随容差线拉大。
%
% 为什么要有这个函数：以前的下限取容差的千分之一（容差 1e-3 时为 1e-6），
% 真实值远小于这个下限（如 1e-11）时，整条曲线都被截在 1e-6 上，看起来
% “全挤在最下面”。现在下限只看数据本身：比最小的正值低一个数量级，但最多比
% 最大值低 14 个数量级，更小的值（含零）都画在下限处，由绘图函数用一条
% 点线标明“这里是 0”，不与真实小值混淆。
%
% 输入:
%   Curves - build_plot_curve 输出的结构体数组，取其中的 y 数据（取绝对值）
%
% 输出 LogInfo:
%   floor_value - 显示下限
%   top_value   - 数据最大值（没有正值时为下限的 10 倍）
%   has_clamped - 是否有有限值不大于下限（零值或被截断的极小值）

    values = [];
    for c = 1:numel(Curves)
        values = [values; abs(Curves(c).y(:))]; %#ok<AGROW>
    end
    values = values(isfinite(values));
    positive = values(values > 0);
    if isempty(positive)
        LogInfo.floor_value = 1e-12;
        LogInfo.top_value = 1e-11;
        LogInfo.has_clamped = ~isempty(values);
        return;
    end
    top_value = max(positive);
    floor_value = max(min(positive) / 10, top_value * 1e-14);
    LogInfo.floor_value = floor_value;
    LogInfo.top_value = top_value;
    LogInfo.has_clamped = any(values <= floor_value);
end
