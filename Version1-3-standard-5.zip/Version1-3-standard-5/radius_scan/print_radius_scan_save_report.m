function print_radius_scan_save_report(SaveReport)
% PRINT_RADIUS_SCAN_SAVE_REPORT 打印半径扫描保存了哪些文件；保存出错时给出警告和原因。
%
% 输入 SaveReport 为 save_radius_scan 或 save_radius_scan_summary 的输出（files 每行
% {文件说明, 路径}）。保存开关都关、也没出错时什么也不打印。

    if isempty(SaveReport.files) && SaveReport.success
        return;
    end
    fprintf('\n');
    for k = 1:size(SaveReport.files, 1)
        fprintf('%s: %s\n', SaveReport.files{k, 1}, SaveReport.files{k, 2});
    end
    if ~SaveReport.success
        fprintf('警告: 扫描结果保存未完成 (%s)\n', SaveReport.error_message);
    end
end
