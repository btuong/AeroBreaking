function IterationDiagnostics = postprocess_scp_iteration( ...
        ~, IterationRecord, ConstData, config)
% POSTPROCESS_SCP_ITERATION 本轮结束后只读地做梯形递推检查、打印日志、画图。
%
% 只读：不修改 RunState、IterationRecord、参考、信赖域或停止状态。
% 梯形递推检查只作诊断，不参与接受、信赖域更新或停止；递推失败、
% 路径超限只改变诊断报告，不回滚已接受的解。
%
% 本函数依次完成：
%   1. 梯形递推检查：从被接受解的初始状态递推整条轨迹。
%   2. 打印本轮日志。
%   3. 画本轮优化解的状态、控制、松弛和路径约束图。

    %% 1. 梯形递推检查：从被接受解的初始状态递推整条轨迹
    if ~config.validation.enable_trapezoid_check
        % 配置关闭了逐轮梯形递推检查
        TrapezoidSolution = [];
        TrapezoidCheck = build_skipped_trapezoid_check('diagnostics_disabled');
    elseif ~IterationRecord.trust.accept_candidate
        % 本轮没有被接受的解（被拒绝或求解失败），没有东西可递推
        TrapezoidSolution = [];
        TrapezoidCheck = build_skipped_trapezoid_check('not_accepted');
    else
        [TrapezoidSolution, TrapezoidCheck] = check_trapezoid_solution( ...
            IterationRecord.trust.accepted_solution, ConstData, config);
    end
    IterationDiagnostics = build_iteration_diagnostics( ...
        IterationRecord.iter, TrapezoidSolution, TrapezoidCheck);

    %% 2. 打印本轮日志
    if config.output.print_iteration
        print_scp_iteration(IterationRecord, IterationDiagnostics, ...
            ConstData, config);
    end

    %% 3. 画本轮优化解的状态、控制、松弛和路径约束图
    if config.plot.enable_iteration
        try
            plot_scp_iteration(IterationRecord, ConstData, config);
        catch exception
            warning('SCP:IterationPlotFailed', ...
                '第 %d 轮逐轮图绘制失败：%s（出错位置：%s 第 %d 行）', ...
                IterationRecord.iter, exception.message, ...
                exception.stack(1).name, exception.stack(1).line);
        end
    end
end
