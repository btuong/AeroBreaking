function coe = transform_rv2elements(R, V, mu)
% TRANSFORM_RV2ELEMENTS 由 ECI 状态矢量计算经典轨道根数。
%
% 输出 coe = [a, e, incl, RA, w, TA]，双曲线轨道 a 为负值。

    eps = 1e-6;

    r = norm(R);
    v = norm(V);

    vr = dot(R, V) / r;

    H = cross(R, V);
    h = norm(H);

    incl = acos(H(3) / h);

    N = cross([0, 0, 1], H);
    n = norm(N);

    if incl ~= 0
        RA = acos(N(1) / n);
        if N(2) < 0
            RA = 2 * pi - RA;
        end
    else
        RA = 0;
    end

    E = 1 / mu * ((v^2 - mu / r) * R - r * vr * V);
    e = norm(E);

    if incl ~= 0
        if e > eps
            if dot(N, E) / n / e > 1
                w = acos(1);
            else
                w = acos(dot(N, E) / n / e);
            end
            if E(3) < 0
                w = 2 * pi - w;
            end
        else
            w = 0;
        end
    else
        if e > eps
            w = acos(E(1) / e);
            if E(2) < 0
                w = 2 * pi - w;
            end
        else
            w = 0;
        end
    end

    if incl ~= 0
        if e > eps
            if dot(E, R) / e / r > 1
                TA = acos(1);
            else
                TA = acos(dot(E, R) / e / r);
            end
            if vr < 0
                TA = 2 * pi - TA;
            end
        else
            if dot(N, R) / n / r > 1
                TA = acos(1);
            else
                TA = acos(dot(N, R) / n / r);
            end
            if R(3) < 0
                TA = 2 * pi - TA;
            end
        end
    else
        if e > eps
            if dot(E, R) / e / r > 1
                TA = acos(1);
            else
                TA = acos(dot(E, R) / e / r);
            end
            if vr < 0
                TA = 2 * pi - TA;
            end
        else
            TA = acos(R(1) / r);
            if R(2) < 0
                TA = 2 * pi - TA;
            end
        end
    end

    a = h^2 / mu / (1 - e^2);

    coe = [a, e, incl, RA, w, TA];
end
