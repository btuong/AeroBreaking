function tests = test_unit_norm_twosided
% TEST_UNIT_NORM_TWOSIDED 核验 twosided 模式配置、P3 装配、罚函数、对偶分解与输出。

    tests = functiontests(localfunctions);
end


function test_describe_unit_norm_modes(testCase)
% 默认、缺字段、twosided 及非法配置均应按规格返回或抛错。

    default_config = scp_config_default();
    DefaultInfo = describe_unit_norm(default_config);
    verifyEqual(testCase, DefaultInfo.mode, 'regularized');
    verifyFalse(testCase, DefaultInfo.is_twosided);
    verifyEqual(testCase, DefaultInfo.penalty_weight, 0);
    verifyEqual(testCase, DefaultInfo.slack_max, 0);
    verifyFalse(testCase, DefaultInfo.keep_control_bounds);
    verifyEqual(testCase, DefaultInfo.term_name, 'control_reg');
    verifyEqual(testCase, DefaultInfo.term_label, '控制正则项');
    verifyEqual(testCase, DefaultInfo.term_kind, 'extra_nonconvex');

    legacy_config = rmfield(default_config, 'unit_norm');
    LegacyInfo = describe_unit_norm(legacy_config);
    verifyEqual(testCase, LegacyInfo.mode, 'regularized');
    verifyFalse(testCase, LegacyInfo.is_twosided);

    twosided_config = default_config;
    twosided_config.unit_norm.mode = 'twosided';
    twosided_config.unit_norm.twosided_penalty_weight = 120;
    twosided_config.unit_norm.twosided_slack_max = 3;
    twosided_config.unit_norm.twosided_keep_control_bounds = true;
    TwosidedInfo = describe_unit_norm(twosided_config);
    verifyEqual(testCase, TwosidedInfo.mode, 'twosided');
    verifyTrue(testCase, TwosidedInfo.is_twosided);
    verifyEqual(testCase, TwosidedInfo.penalty_weight, 120);
    verifyEqual(testCase, TwosidedInfo.slack_max, 3);
    verifyTrue(testCase, TwosidedInfo.keep_control_bounds);
    verifyEqual(testCase, TwosidedInfo.term_name, 'unit_norm_penalty');
    verifyEqual(testCase, TwosidedInfo.term_label, '单位范数罚项');
    verifyEqual(testCase, TwosidedInfo.term_kind, 'inequality_penalty');

    bad_mode_config = default_config;
    bad_mode_config.unit_norm.mode = 'invalid_mode';
    verifyError(testCase, @() describe_unit_norm(bad_mode_config), ...
        'SCP:UnknownUnitNormMode');

    bad_weight_cases = {0, -5, NaN, Inf, 1 + 1i, [1, 2], 'bad', []};
    for k = 1:numel(bad_weight_cases)
        bad_config = twosided_config;
        bad_config.unit_norm.twosided_penalty_weight = bad_weight_cases{k};
        verifyError(testCase, @() describe_unit_norm(bad_config), ...
            'SCP:InvalidUnitNormConfig');

        bad_config = twosided_config;
        bad_config.unit_norm.twosided_slack_max = bad_weight_cases{k};
        verifyError(testCase, @() describe_unit_norm(bad_config), ...
            'SCP:InvalidUnitNormConfig');
    end
end


function test_variable_layout_and_p3_assembly(testCase)
% 核验 regularized 布局不变，及 twosided 的变量、边界、锥、线性行和目标装配。

    reg_config = scp_config_default();
    [ConstData, InitialState] = initialize_problem(reg_config);
    [InitialReference, ~] = generate_initial_reference( ...
        ConstData, InitialState, reg_config);
    TrustRegionState = initialize_trust_region_state(reg_config);
    N = InitialReference.N;

    % regularized 布局与 row_groups 不变
    [RegIndex, num_reg_vars] = build_variable_index( ...
        InitialReference, ConstData, reg_config);
    verifyEqual(testCase, num_reg_vars, 17 * N + 25);
    verifyEmpty(testCase, RegIndex.unit_norm_slack);
    RegLinear = build_linear_constraints( ...
        RegIndex, InitialReference, ConstData, reg_config);
    verifyFalse(testCase, isfield(RegLinear.row_groups, 'unit_norm_inner'));

    % twosided 布局、边界、锥、线性行与目标
    two_config = reg_config;
    two_config.unit_norm.mode = 'twosided';
    two_config.unit_norm.twosided_penalty_weight = 100;
    two_config.unit_norm.twosided_slack_max = 2;
    two_config.unit_norm.twosided_keep_control_bounds = false;

    [TwoIndex, num_two_vars] = build_variable_index( ...
        InitialReference, ConstData, two_config);
    verifyEqual(testCase, num_two_vars, 17 * N + 27);
    verifyEqual(testCase, numel(TwoIndex.unit_norm_slack), 2);
    verifyEqual(testCase, TwoIndex.unit_norm_slack(:), ...
        [TwoIndex.t_f(end) + 1; TwoIndex.t_f(end) + 2]);

    BoundsRelaxed = build_variable_bounds( ...
        TwoIndex, InitialReference, TrustRegionState, ConstData, two_config);
    s_max = two_config.unit_norm.twosided_slack_max;
    verifyEqual(testCase, BoundsRelaxed.lower(TwoIndex.u1), ...
        -(1 + s_max) * ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, BoundsRelaxed.upper(TwoIndex.u1), ...
        (1 + s_max) * ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, BoundsRelaxed.lower(TwoIndex.u2), ...
        -(1 + s_max) * ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, BoundsRelaxed.upper(TwoIndex.u2), ...
        (1 + s_max) * ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, BoundsRelaxed.lower(TwoIndex.unit_norm_slack), ...
        [0; 0], 'AbsTol', 1e-14);
    verifyEqual(testCase, BoundsRelaxed.upper(TwoIndex.unit_norm_slack), ...
        [s_max; s_max], 'AbsTol', 1e-14);

    keep_config = two_config;
    keep_config.unit_norm.twosided_keep_control_bounds = true;
    BoundsKept = build_variable_bounds( ...
        TwoIndex, InitialReference, TrustRegionState, ConstData, keep_config);
    verifyEqual(testCase, BoundsKept.lower(TwoIndex.u1), -ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, BoundsKept.upper(TwoIndex.u1), ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, BoundsKept.lower(TwoIndex.u2), -ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, BoundsKept.upper(TwoIndex.u2), ones(N, 1), 'AbsTol', 1e-14);

    Conic = build_conic_constraints(TwoIndex, InitialReference, ConstData, two_config);
    is_disk = strcmp({Conic.cones.name}, 'control_disk');
    verifyEqual(testCase, sum(is_disk), N);
    disk_cones = Conic.cones(is_disk);
    verifyTrue(testCase, all(strcmp({disk_cones.tightness_role}, 'none')));
    for i = 1:N
        rows = disk_cones(i).rows;
        verifyEqual(testCase, full(Conic.mapping(rows(1), TwoIndex.unit_norm_slack(1))), 1);
        verifyEqual(testCase, full(Conic.mapping(rows(2), TwoIndex.u1(i))), 1);
        verifyEqual(testCase, full(Conic.mapping(rows(3), TwoIndex.u2(i))), 1);
        verifyEqual(testCase, nnz(Conic.mapping(rows, :)), 3);
        verifyEqual(testCase, Conic.offset(rows), [1; 0; 0]);
    end

    % 把第 3 节点参考控制改为 (0, 0)，显式检验零参考点不做替换
    RefZero3 = InitialReference;
    RefZero3.control.u1(3) = 0;
    RefZero3.control.u2(3) = 0;
    TwoLinear = build_linear_constraints(TwoIndex, RefZero3, ConstData, two_config);
    verifyTrue(testCase, isfield(TwoLinear.row_groups, 'unit_norm_inner'));
    inner_rows = TwoLinear.row_groups.unit_norm_inner;
    verifyEqual(testCase, numel(inner_rows), N);
    verifyEqual(testCase, TwoLinear.lower(inner_rows), -inf(N, 1));
    u1_ref = RefZero3.control.u1(:);
    u2_ref = RefZero3.control.u2(:);
    verifyEqual(testCase, TwoLinear.upper(inner_rows), ...
        -(1 + u1_ref.^2 + u2_ref.^2), 'AbsTol', 1e-14);

    A_inner = TwoLinear.matrix(inner_rows, :);
    for i = 1:N
        verifyEqual(testCase, full(A_inner(i, TwoIndex.u1(i))), -2 * u1_ref(i), 'AbsTol', 1e-14);
        verifyEqual(testCase, full(A_inner(i, TwoIndex.u2(i))), -2 * u2_ref(i), 'AbsTol', 1e-14);
        verifyEqual(testCase, full(A_inner(i, TwoIndex.unit_norm_slack(2))), -1, 'AbsTol', 1e-14);
    end
    verifyEqual(testCase, full(A_inner(3, [TwoIndex.u1(3), TwoIndex.u2(3)])), [0, 0], 'AbsTol', 1e-14);
    verifyEqual(testCase, full(A_inner(3, TwoIndex.unit_norm_slack(2))), -1, 'AbsTol', 1e-14);
    verifyEqual(testCase, TwoLinear.upper(inner_rows(3)), -1, 'AbsTol', 1e-14);

    [objective, objective_offset] = build_objective( ...
        TwoIndex, RefZero3, ConstData, two_config);
    verifyEqual(testCase, objective(TwoIndex.unit_norm_slack), [100; 100], 'AbsTol', 1e-14);
    verifyEqual(testCase, objective(TwoIndex.u1), zeros(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, objective(TwoIndex.u2), zeros(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, objective_offset, 0, 'AbsTol', 1e-14);
end


function test_penalty_function_and_3_rounds(testCase)
% 核验 3 轮 twosided 运行的罚函数、附加项为 0、预测误差符号、零步长可行性及 gamma_node=0。

    reg_config = scp_config_default();
    [ConstData, InitialState] = initialize_problem(reg_config);
    [InitialReference, InitialPropagation] = generate_initial_reference( ...
        ConstData, InitialState, reg_config);

    % regularized 分项列表不变
    RegCheck = check_p2_feasibility(InitialReference, ConstData, reg_config);
    RegPenalty = evaluate_penalty_function(InitialReference, RegCheck, ConstData, reg_config);
    verifyEqual(testCase, {RegPenalty.terms.name}, ...
        {'terminal_inclination', 'terminal_apoapsis', 'impulse', ...
        'point_slack', 'dyn_slack', 'control_reg'});

    % twosided 跑 3 轮
    two_config = reg_config;
    two_config.unit_norm.mode = 'twosided';
    two_config.unit_norm.twosided_penalty_weight = 100;
    two_config.unit_norm.twosided_slack_max = 2;
    two_config.iter.max_scp_iter = 3;

    [RunState, ~] = initialize_scp_run(InitialReference, InitialPropagation, two_config);
    P = two_config.unit_norm.twosided_penalty_weight;
    for iter = 1:3
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, two_config, iter);
        verifyTrue(testCase, SubproblemDiag.success);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, two_config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, two_config, iter);

        Eval = IterationRecord.trust.evaluation;
        verifyEqual(testCase, Eval.group.extra.candidate, 0, 'AbsTol', 1e-14);
        verifyEqual(testCase, Eval.group.extra.p3, 0, 'AbsTol', 1e-14);
        verifyEqual(testCase, Eval.group.extra.reference, 0, 'AbsTol', 1e-14);

        idx_unit = strcmp(Eval.term_names, 'unit_norm_penalty');
        verifyEqual(testCase, sum(idx_unit), 1);
        u1 = CurrentSolution.control.u1(:);
        u2 = CurrentSolution.control.u2(:);
        u_norm = hypot(u1, u2);
        expected_j_unit = P * (max([u_norm - 1; 0]) + max([1 - u_norm.^2; 0]));
        verifyEqual(testCase, Eval.term_candidate(idx_unit), expected_j_unit, 'AbsTol', 1e-12);
        % 理论上 J_unit - L_unit <= 0；数值求解器允许的锥与线性可行性残差经罚权 P 放大后为误差上界
        FeasMetrics = SubproblemDiag.p3_check.solver_feasibility_report.metrics;
        inner_res = FeasMetrics(strcmp({FeasMetrics.name}, 'A.unit_norm_inner')).value;
        feas_margin = P * (SubproblemDiag.p3_check.reformulation_report.max_feasibility_residual ...
            + inner_res);
        verifyLessThanOrEqual(testCase, Eval.term_prediction_error(idx_unit), ...
            feas_margin + 1e-6);
        verifyEqual(testCase, SubproblemDiag.control_report.gamma_node, ...
            zeros(InitialReference.N, 1), 'AbsTol', 1e-14);
    end

    % 验证多种参考点下零步长严格可行且 L^k(0) == J(ū)
    [TwoIndex, num_vars] = build_variable_index(InitialReference, ConstData, two_config);
    TrustState = initialize_trust_region_state(two_config);
    xff_ref = evaluate_coast_exit_to_apoapsis( ...
        [ConstData.R_atm, InitialReference.state(InitialReference.PointsBounds(5).end, 2:5), 0], ...
        ConstData);
    v_aim = sqrt(2 * ConstData.mu / ConstData.R_aaim ...
        - 2 * ConstData.mu / (ConstData.R_aaim + ConstData.R_paim));
    scales = [0.5, 1.0, 1.5, 0.0];
    for s = 1:numel(scales)
        RefTest = InitialReference;
        RefTest.control.P(6) = v_aim - xff_ref(2);
        RefTest.control.u1 = scales(s) * InitialReference.control.u1;
        RefTest.control.u2 = scales(s) * InitialReference.control.u2;

        [obj, obj_off] = build_objective(TwoIndex, RefTest, ConstData, two_config);
        Lin = build_linear_constraints(TwoIndex, RefTest, ConstData, two_config);
        Bnd = build_variable_bounds(TwoIndex, RefTest, TrustState, ConstData, two_config);
        Con = build_conic_constraints(TwoIndex, RefTest, ConstData, two_config);
        P2Ref = check_p2_feasibility(RefTest, ConstData, two_config);
        JRef = evaluate_penalty_function(RefTest, P2Ref, ConstData, two_config);

        x_zero = zeros(num_vars, 1);
        x_zero(TwoIndex.r) = RefTest.state(:, 1);
        x_zero(TwoIndex.V) = RefTest.state(:, 2);
        x_zero(TwoIndex.gamma) = RefTest.state(:, 3);
        x_zero(TwoIndex.phi) = RefTest.state(:, 4);
        x_zero(TwoIndex.psi) = RefTest.state(:, 5);
        x_zero(TwoIndex.u1) = RefTest.control.u1;
        x_zero(TwoIndex.u2) = RefTest.control.u2;
        x_zero(TwoIndex.P) = RefTest.control.P;
        x_zero(TwoIndex.t_P) = abs(RefTest.control.P);
        x_zero(TwoIndex.t_f) = RefTest.t_f;

        dyn_val = P2Ref.dynamics_report.values;
        poi_val = P2Ref.junction_report.values;
        state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
        for c = 1:numel(state_names)
            x_zero(TwoIndex.(['dyn_slack_' state_names{c}])) = -dyn_val(:, c);
            x_zero(TwoIndex.(['t_dyn_slack_' state_names{c}])) = abs(dyn_val(:, c));
            x_zero(TwoIndex.(['poi_slack_' state_names{c}])) = -poi_val(:, c);
            x_zero(TwoIndex.(['t_poi_slack_' state_names{c}])) = abs(poi_val(:, c));
        end

        x_zero(TwoIndex.xff) = xff_ref(1:5);
        x_zero(TwoIndex.xff_i) = xff_ref(6);
        x_zero(TwoIndex.t_raf) = abs(xff_ref(1) - ConstData.R_aaim);
        x_zero(TwoIndex.t_if) = abs(xff_ref(6) - ConstData.i_aim);
        x_zero(TwoIndex.P(6)) = v_aim - xff_ref(2);
        x_zero(TwoIndex.t_P(6)) = abs(x_zero(TwoIndex.P(6)));

        u_n = hypot(RefTest.control.u1, RefTest.control.u2);
        s_a1_zero = max([u_n - 1; 0]);
        s_a2_zero = max([1 - u_n.^2; 0]);
        x_zero(TwoIndex.unit_norm_slack) = [s_a1_zero; s_a2_zero];

        % 变量界、线性约束、锥约束严格可行
        verifyGreaterThanOrEqual(testCase, x_zero - Bnd.lower, -1e-12);
        verifyGreaterThanOrEqual(testCase, Bnd.upper - x_zero, -1e-12);
        ax = Lin.matrix * x_zero;
        verifyGreaterThanOrEqual(testCase, ax - Lin.lower, -1e-9);
        verifyGreaterThanOrEqual(testCase, Lin.upper - ax, -1e-9);
        cone_val = Con.mapping * x_zero + Con.offset;
        for c = 1:numel(Con.cones)
            cv = cone_val(Con.cones(c).rows);
            verifyGreaterThanOrEqual(testCase, cv(1) - norm(cv(2:end), 2), -1e-12);
        end
        L_zero = obj.' * x_zero + obj_off;
        verifyEqual(testCase, L_zero, JRef.total, 'AbsTol', 1e-10);
    end
end


function test_dual_split_and_multiplier_bounds(testCase)
% 核验 twosided 对偶驻点残差、s_inner 公式以及未触上界时的乘子和上界。

    config = scp_config_default();
    config.unit_norm.mode = 'twosided';
    config.unit_norm.twosided_penalty_weight = 100;
    config.unit_norm.twosided_slack_max = 2;

    [ConstData, InitialState] = initialize_problem(config);
    [InitialReference, ~] = generate_initial_reference(ConstData, InitialState, config);
    TrustState = initialize_trust_region_state(config);

    [VarIdx, ~] = build_variable_index(InitialReference, ConstData, config);
    [obj, obj_off] = build_objective(VarIdx, InitialReference, ConstData, config);
    Lin = build_linear_constraints(VarIdx, InitialReference, ConstData, config);
    Bnd = build_variable_bounds(VarIdx, InitialReference, TrustState, ConstData, config);
    Con = build_conic_constraints(VarIdx, InitialReference, ConstData, config);
    SolverResult = solve_convex_subproblem(obj, Lin, Bnd, Con, config, obj_off);
    verifyTrue(testCase, SolverResult.success);

    Report = evaluate_control_report(SolverResult, VarIdx, obj, Lin, Con, ...
        InitialReference, config);
    verifyTrue(testCase, Report.dual_available);
    verifyLessThanOrEqual(testCase, max(abs(Report.stationarity_residual(:))), 1e-6);

    u_ref = [InitialReference.control.u1(:), InitialReference.control.u2(:)];
    expected_s_inner = 2 * u_ref .* Report.lambda_inner;
    verifyEqual(testCase, Report.s_inner, expected_s_inner, 'AbsTol', 1e-10);

    P = config.unit_norm.twosided_penalty_weight;
    if ~Report.slack_capped(1)
        verifyLessThanOrEqual(testCase, sum(Report.cone_dual_leading), P + 1e-4);
    end
    if ~Report.slack_capped(2)
        verifyLessThanOrEqual(testCase, sum(-Report.lambda_inner), P + 1e-4);
    end
end


function test_slack_cap_and_empty_report(testCase)
% 核验触上界报告计算逻辑及空报告字段完整性。

    EmptyReport = create_empty_control_report('solver_failed');
    verifyEqual(testCase, EmptyReport.unit_norm_slack, [NaN; NaN]);
    verifyEqual(testCase, EmptyReport.slack_capped, [false; false]);
    verifyTrue(testCase, isnan(EmptyReport.summary_total.num_slack_capped));
    verifyTrue(testCase, isnan(EmptyReport.summary_total.max_inward_gap));
    verifyTrue(testCase, isnan(EmptyReport.summary_total.max_outward_gap));

    % 构造触及 s_max 上界的最小测试夹具
    SolverResult.primal = [0.6; 0.8; 0.5; 0.0; 1.0; 2.0];
    SolverResult.dual.y = zeros(1, 1);
    SolverResult.dual.slx = zeros(6, 1);
    SolverResult.dual.sux = zeros(6, 1);
    SolverResult.dual.snx = zeros(6, 1);
    SolverResult.dual.doty = zeros(6, 1);
    VariableIndex.u1 = [1; 3];
    VariableIndex.u2 = [2; 4];
    VariableIndex.unit_norm_slack = [5; 6];
    objective = [0; 0; 0; 0; 100; 100];
    LinearConstraints.row_groups.dynamics = zeros(0, 1);
    LinearConstraints.row_groups.control_continuity = zeros(0, 1);
    LinearConstraints.row_groups.unit_norm_inner = 1;
    LinearConstraints.matrix = sparse([0, 0, 0, 0, 0, -1]);
    LinearConstraints.lower = -inf;
    LinearConstraints.upper = -1;
    ConicConstraints.mapping = sparse([ ...
        0, 0, 0, 0, 1, 0; 1, 0, 0, 0, 0, 0; 0, 1, 0, 0, 0, 0; ...
        0, 0, 0, 0, 1, 0; 0, 0, 1, 0, 0, 0; 0, 0, 0, 1, 0, 0]);
    ConicConstraints.offset = [1; 0; 0; 1; 0; 0];
    ConicConstraints.cones = repmat(struct('name', 'control_disk', ...
        'dimension', 3, 'rows', [], 'index', 0), 2, 1);
    ConicConstraints.cones(1).rows = (1:3).';
    ConicConstraints.cones(1).index = 1;
    ConicConstraints.cones(2).rows = (4:6).';
    ConicConstraints.cones(2).index = 2;

    Reference.N = 2;
    Reference.PointsBounds = struct('begin', 1, 'end', 2);
    Reference.tau = [0; 1];
    Reference.control.u1 = [1; 0];
    Reference.control.u2 = [0; 0];

    config = scp_config_default();
    config.unit_norm.mode = 'twosided';
    config.unit_norm.twosided_penalty_weight = 100;
    config.unit_norm.twosided_slack_max = 2;

    Report = evaluate_control_report(SolverResult, VariableIndex, objective, ...
        LinearConstraints, ConicConstraints, Reference, config);
    verifyEqual(testCase, sort(fieldnames(EmptyReport)), sort(fieldnames(Report)));
    verifyEqual(testCase, sort(fieldnames(EmptyReport.summary_total)), ...
        sort(fieldnames(Report.summary_total)));
    verifyEqual(testCase, Report.unit_norm_slack, [1.0; 2.0]);
    verifyEqual(testCase, Report.slack_capped, [false; true]);
    verifyEqual(testCase, Report.summary_total.num_slack_capped, 1);
    verifyEqual(testCase, Report.summary_total.max_inward_gap, 0.5, 'AbsTol', 1e-14);
    verifyEqual(testCase, Report.summary_total.max_outward_gap, 0, 'AbsTol', 1e-14);
end


function test_twosided_entry_outputs_run(testCase)
% 2 轮全输出测试：核验绘图、detail.txt 和 control.txt 均正常生成且含关键字段。

    [~, tmp_name] = fileparts(tempname);
    rel_dir = fullfile('results', ['tmp_' tmp_name]);
    version_root = fileparts(fileparts(mfilename('fullpath')));
    abs_dir = fullfile(version_root, rel_dir);
    mkdir(abs_dir);
    cleanup_dir = onCleanup(@() rmdir(abs_dir, 's')); %#ok<NASGU>
    cleanup_figs = onCleanup(@() close('all')); %#ok<NASGU>

    config = scp_config_default();
    config.unit_norm.mode = 'twosided';
    config.unit_norm.twosided_penalty_weight = 100;
    config.unit_norm.twosided_slack_max = 2;
    config.iter.max_scp_iter = 2;
    config.plot.visibility = 'off';
    config.plot.enable_initial = false;
    config.plot.enable_iteration = false;
    config.plot.enable_final = true;
    config.plot.save_figures = false;
    config.output.print_pre_iteration = false;
    config.output.print_iteration = false;
    config.output.print_summary = false;
    config.output.save.brief_text = true;
    config.output.save.detail_text = true;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    config.output.save.control_text = true;
    config.output.save.control_mat = true;
    config.output.save.directory = rel_dir;
    config.output.save.filename_prefix = 'twosided_test';

    [ConstData, InitialState] = initialize_problem(config);
    [InitialReference, InitialPropagation] = generate_initial_reference( ...
        ConstData, InitialState, config);
    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);

    for iter = 1:config.iter.max_scp_iter
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);
    end

    FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory);
    PlotReport = plot_scp_result(FinalizedRun, ConstData, config);
    verifyTrue(testCase, PlotReport.success);

    SaveReport = save_scp_result(FinalizedRun, ConstData, config);
    verifyTrue(testCase, SaveReport.success);

    detail_text = fileread(fullfile(abs_dir, 'twosided_test_detail.txt'));
    verifyTrue(testCase, contains(detail_text, '单位范数内逼近'));

    control_text = fileread(fullfile(abs_dir, 'twosided_test_control.txt'));
    verifyTrue(testCase, contains(control_text, '单位范数处理: twosided'));
end
