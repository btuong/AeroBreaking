function P2Feasibility = check_p2_feasibility(Solution, ConstData, config)
% CHECK_P2_FEASIBILITY 做 P2 可行性检查：把节点值代入 P2，用原非线性函数算动力学违反量、衔接违反量、终端违反量、节点路径约束和性能指标。
%
% 检查分两部分。一是逐区间的梯形动力学：每个区间从它两端的节点值代入原大气动力学，
% 只做代数计算。二是与积分的对照：衔接和终端要从节点值出发积分真空段（原映射），
% 再与下一圈入口节点或目标值比较。每个区间、每个衔接点都从节点值出发，不传递误差；
% 不读松弛和线性化系数。
%
% 终端映射的余项（积分得到的终端量减 P3 的终端量）也属于第二部分，但只有 P3 的解
% 带终端变量：本函数把这一项置为未评价，候选解的这一项由 solve_scp_subproblem
% 调 evaluate_terminal_remainder 补上；参考点没有这一项。
%
% 本函数依次完成：
%   1. 按原关系重算终端状态与末次脉冲。
%   2. 逐区间算动力学违反量。
%   3. 逐衔接点算衔接违反量。
%   4. 用原终端函数检查终端约束。
%   5. 在每个节点用原路径函数检查路径约束。
%   6. 算性能指标（总脉冲）。
%   7. 汇总各项检查，判断是否对 P2 可行。

    %% 1. 按原关系重算终端状态与末次脉冲
    P2Solution = compute_dependent_quantities(Solution, ConstData, config);

    %% 2. 逐区间算动力学违反量
    DynamicsReport = evaluate_dynamics_violation(P2Solution, ConstData, config);

    %% 3. 逐衔接点算衔接违反量
    JunctionReport = evaluate_junction_violation(P2Solution, ConstData, config);

    %% 4. 用原终端函数检查终端约束
    TerminalReport = evaluate_terminal_constraints(P2Solution, ConstData, config);

    %% 5. 在每个节点用原路径函数检查路径约束
    PathReport = evaluate_path_constraints(P2Solution, ConstData, config);

    %% 6. 算性能指标（总脉冲）
    PerformanceReport = evaluate_performance_index(P2Solution, ConstData, config);

    %% 7. 汇总各项检查，判断是否对 P2 可行
    P2Feasibility = build_p2_feasibility(DynamicsReport, JunctionReport, ...
        TerminalReport, PathReport, PerformanceReport);
end


function P2Feasibility = build_p2_feasibility( ...
        DynamicsReport, JunctionReport, TerminalReport, PathReport, PerformanceReport)
% BUILD_P2_FEASIBILITY 汇总五份报告，按各物理通道的最大违反量判断是否对 P2 可行。

    P2Feasibility.dynamics_report = DynamicsReport;
    P2Feasibility.junction_report = JunctionReport;
    P2Feasibility.terminal_report = TerminalReport;
    P2Feasibility.path_report = PathReport;
    P2Feasibility.performance_report = PerformanceReport;
    % 终端映射的余项：只有候选解有，由 solve_scp_subproblem 填；只报告，不计入 feasible
    P2Feasibility.terminal_remainder_report = struct('success', false, ...
        'evaluated', false, 'metrics', struct([]), 'failed_names', {{}});
    reports = {DynamicsReport, JunctionReport, TerminalReport, PathReport};
    P2Feasibility.feasible = all(cellfun(@(R) R.success, reports));
    P2Feasibility.failed_names = [DynamicsReport.failed_names, ...
        JunctionReport.failed_names, TerminalReport.failed_names, ...
        PathReport.failed_names];
    ratios = cellfun(@(R) R.max_ratio, reports);
    [P2Feasibility.max_ratio, index] = max(ratios);
    P2Feasibility.max_name = reports{index}.max_name;
    P2Feasibility.evaluated = true;
end
