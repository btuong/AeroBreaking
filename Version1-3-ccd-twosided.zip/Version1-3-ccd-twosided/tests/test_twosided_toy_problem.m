function tests = test_twosided_toy_problem
% TEST_TWOSIDED_TOY_PROBLEM 用独立玩具 SOCP 核验文章 [15] 双侧共用松弛的门槛与零初值行为。

    tests = functiontests(localfunctions);
end


function test_toy_proposition_c2_threshold(testCase)
% 6 节点内外拉并存模型：核验 P > max(P_in, P_out) 收敛紧解及 P < P_out 偏出圆外。

    % 2 个 D 节点（i=1,2）、2 个内拉节点（i=3,4: alpha=0.5）、2 个外推节点（i=5,6: alpha=2）
    % 目标 C_i = 0.5*beta*||u_i - alpha_i*d_i||^2（beta=2 -> C_i = ||u_i - alpha_i*d_i||^2）
    % P_in = 0.5 * sum((-nu_i)^+) = 0.5*(1+1) = 1，P_out = sum(nu_i^+) = 2+2 = 4
    d_angles = deg2rad([10, 40, 80, 120, 160, 200]).';
    d_vecs = [cos(d_angles), sin(d_angles)];
    alphas = [1; 1; 0.5; 0.5; 2.0; 2.0];
    is_d_node = [true; true; false; false; false; false];
    p_in = 1.0;
    p_out = 4.0;

    % 情形 1：P = 6 > max(P_in, P_out)，从偏转 15 deg 的单位参考点出发多轮收敛到紧解
    init_angles = d_angles + deg2rad(15);
    u_ref = [cos(init_angles), sin(init_angles)];
    P_high = 6.0;
    s_max = 2.0;
    for iter = 1:15
        Sol = solve_toy_twosided(u_ref, d_vecs, alphas, is_d_node, P_high, s_max);
        verifyTrue(testCase, Sol.success);
        step = max(abs(Sol.u(:) - u_ref(:)));
        u_ref = Sol.u;
        if step < 1e-8
            break;
        end
    end
    u_norm = hypot(Sol.u(:, 1), Sol.u(:, 2));
    verifyLessThanOrEqual(testCase, max(abs(1 - u_norm)), 1e-5);
    verifyEqual(testCase, sum(1 - u_norm > 1e-5), 0);
    verifyEqual(testCase, sum(u_norm - 1 > 1e-5), 0);

    % 情形 2：P = 2 < P_out，从平衡参考 u_ref = d_vecs 出发，外推节点偏到圆外且 D 节点可在帽内自由
    P_low = 2.0;
    SolLow = solve_toy_twosided(d_vecs, d_vecs, alphas, is_d_node, P_low, s_max);
    verifyTrue(testCase, SolLow.success);
    u_norm_low = hypot(SolLow.u(:, 1), SolLow.u(:, 2));
    verifyGreaterThan(testCase, SolLow.s_a1, 1e-2);
    verifyGreaterThan(testCase, min(u_norm_low(5:6)), 1 + 1e-2);
    % D 节点处于松弛帽内（无需紧贴单位圆），且满足帽的上下界约束
    for i = find(is_d_node).'
        verifyLessThanOrEqual(testCase, u_norm_low(i), 1 + SolLow.s_a1 + 1e-8);
        verifyGreaterThanOrEqual(testCase, ...
            2 * (d_vecs(i, :) * SolLow.u(i, :).'), ...
            (1 + sum(d_vecs(i, :).^2)) - SolLow.s_a2 - 1e-8);
    end
end


function test_toy_zero_init_feasible_and_d_node_stays_zero(testCase)
% 从 u_ref = (0, 0) 出发第 0 步 P3 可行，s_a2 >= 1，且 D 节点停在原点。

    d_angles = deg2rad([0, 60, 120, 180, 240, 300]).';
    d_vecs = [cos(d_angles), sin(d_angles)];
    alphas = [1; 1; 0.5; 0.5; 2.0; 2.0];
    is_d_node = [true; true; false; false; false; false];
    u_zero = zeros(6, 2);

    Sol = solve_toy_twosided(u_zero, d_vecs, alphas, is_d_node, 100, 2);
    verifyTrue(testCase, Sol.success);
    verifyGreaterThanOrEqual(testCase, Sol.s_a2, 1 - 1e-8);
    d_norms = hypot(Sol.u(is_d_node, 1), Sol.u(is_d_node, 2));
    verifyLessThanOrEqual(testCase, max(d_norms), 1e-6);
end


function Sol = solve_toy_twosided(u_ref, d_vecs, alphas, is_d_node, P_weight, s_max)
% SOLVE_TOY_TWOSIDED 用项目 solve_convex_subproblem 求解 6 节点玩具双侧 CCD 子问题。
%
% 决策变量布局（N = 6，M = 4 个非 D 节点）:
%   1..N        : u1_i
%   N+1..2N     : u2_i
%   2N+1..2N+2  : [s_a1; s_a2]
%   2N+3..2N+2+M: r_i（||u_i - alpha_i*d_i||_2）
%   2N+3+M..    : t_i（满足 t_i >= r_i^2，用旋转锥的等效 3 维标准二次锥表达）

    N = size(u_ref, 1);
    active_nodes = find(~is_d_node);
    M = numel(active_nodes);

    idx_u1 = (1:N).';
    idx_u2 = N + (1:N).';
    idx_sa = 2 * N + (1:2).';
    idx_r = 2 * N + 2 + (1:M).';
    idx_t = 2 * N + 2 + M + (1:M).';
    num_vars = 2 * N + 2 + 2 * M;

    % 目标：sum_{i not in D} t_i + P*(s_a1 + s_a2)
    objective = zeros(num_vars, 1);
    objective(idx_sa) = P_weight;
    objective(idx_t) = 1;

    % 线性约束：unit_norm_inner，-2*u_ref*u - s_a2 <= -(1 + ||u_ref||^2)
    rows = (1:N).';
    LinearConstraints.matrix = sparse( ...
        [rows; rows; rows], ...
        [idx_u1; idx_u2; repmat(idx_sa(2), N, 1)], ...
        [-2 * u_ref(:, 1); -2 * u_ref(:, 2); -ones(N, 1)], N, num_vars);
    LinearConstraints.lower = -inf(N, 1);
    LinearConstraints.upper = -(1 + sum(u_ref.^2, 2));

    % 变量边界：u ∈ [-(1+s_max), 1+s_max]，s_a ∈ [0, s_max]，r, t >= 0
    VariableBounds.lower = -inf(num_vars, 1);
    VariableBounds.upper = inf(num_vars, 1);
    VariableBounds.lower([idx_u1; idx_u2]) = -(1 + s_max);
    VariableBounds.upper([idx_u1; idx_u2]) = 1 + s_max;
    VariableBounds.lower(idx_sa) = 0;
    VariableBounds.upper(idx_sa) = s_max;
    VariableBounds.lower([idx_r; idx_t]) = 0;

    % 锥约束：N 个 control_disk + M 个距离锥 r_i >= ||u_i - target|| + M 个平方锥
    total_cones = N + 2 * M;
    total_cone_rows = 3 * N + 6 * M;
    f_row = [];
    f_col = [];
    f_val = [];
    g = zeros(total_cone_rows, 1);
    cones = repmat(struct('name', '', 'type', 'quadratic', ...
        'dimension', 3, 'rows', [], 'tightness_role', 'none', 'index', 0), ...
        total_cones, 1);

    row_cursor = 0;
    cone_cursor = 0;
    for i = 1:N
        cone_cursor = cone_cursor + 1;
        r_range = row_cursor + (1:3).';
        f_row = [f_row; r_range]; %#ok<AGROW>
        f_col = [f_col; idx_sa(1); idx_u1(i); idx_u2(i)]; %#ok<AGROW>
        f_val = [f_val; 1; 1; 1]; %#ok<AGROW>
        g(r_range) = [1; 0; 0];
        cones(cone_cursor).name = 'control_disk';
        cones(cone_cursor).rows = r_range;
        cones(cone_cursor).index = i;
        row_cursor = row_cursor + 3;
    end

    for k = 1:M
        i = active_nodes(k);
        target = alphas(i) * d_vecs(i, :);

        % [r_k; u1_i - target(1); u2_i - target(2)] in Q^3
        cone_cursor = cone_cursor + 1;
        r_range = row_cursor + (1:3).';
        f_row = [f_row; r_range]; %#ok<AGROW>
        f_col = [f_col; idx_r(k); idx_u1(i); idx_u2(i)]; %#ok<AGROW>
        f_val = [f_val; 1; 1; 1]; %#ok<AGROW>
        g(r_range) = [0; -target(1); -target(2)];
        cones(cone_cursor).name = 'toy_dist';
        cones(cone_cursor).rows = r_range;
        cones(cone_cursor).index = k;
        row_cursor = row_cursor + 3;

        % [0.5*(1+t_k); 0.5*(1-t_k); r_k] in Q^3  <=>  t_k >= r_k^2
        cone_cursor = cone_cursor + 1;
        r_range = row_cursor + (1:3).';
        f_row = [f_row; r_range(1); r_range(2); r_range(3)]; %#ok<AGROW>
        f_col = [f_col; idx_t(k); idx_t(k); idx_r(k)]; %#ok<AGROW>
        f_val = [f_val; 0.5; -0.5; 1]; %#ok<AGROW>
        g(r_range) = [0.5; 0.5; 0];
        cones(cone_cursor).name = 'toy_square';
        cones(cone_cursor).rows = r_range;
        cones(cone_cursor).index = k;
        row_cursor = row_cursor + 3;
    end

    ConicConstraints.mapping = sparse(f_row, f_col, f_val, ...
        total_cone_rows, num_vars);
    ConicConstraints.offset = g;
    ConicConstraints.cones = cones;

    config = scp_config_default();
    SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ConicConstraints, config, 0);

    Sol.success = SolverResult.success;
    if Sol.success
        Sol.u = [SolverResult.primal(idx_u1), SolverResult.primal(idx_u2)];
        Sol.s_a1 = SolverResult.primal(idx_sa(1));
        Sol.s_a2 = SolverResult.primal(idx_sa(2));
    else
        Sol.u = nan(N, 2);
        Sol.s_a1 = NaN;
        Sol.s_a2 = NaN;
    end
end
