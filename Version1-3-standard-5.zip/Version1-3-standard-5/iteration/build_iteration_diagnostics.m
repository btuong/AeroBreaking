function IterationDiagnostics = build_iteration_diagnostics( ...
        iter, TrapezoidSolution, TrapezoidCheck)
% BUILD_ITERATION_DIAGNOSTICS 把本轮梯形递推轨迹和检查报告填进诊断对象。

    IterationDiagnostics = create_empty_iteration_diagnostics();
    IterationDiagnostics.iter = iter;
    IterationDiagnostics.trapezoid_solution = TrapezoidSolution;
    IterationDiagnostics.trapezoid_check = TrapezoidCheck;
    IterationDiagnostics.complete = true;
end
