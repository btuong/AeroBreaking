function c_P = linearize_coast_to_entry_first(rv0, P0, ConstData)
% LINEARIZE_COAST_TO_ENTRY_FIRST 中心差分计算入口状态对初始脉冲 P0 的偏导。
%
% 数学形式:
%   对真空映射 x_in = Φ_0(P_0)（初始 ECI 状态 rv0 固定，P_0 为初始脉冲，VU；
%   x_in = [r, V, γ, φ, ψ]^T 为第 1 圈入口状态），在 P̄_0 处求中心差分偏导：
%       Φ_0,P = dΦ_0/dP_0 ∈ R^5,    步长 0.001/VU（单侧步长）
%
% 代码形式:
%   输出 c_P 为 5×1 列向量，即 Φ_0,P，行序 r, V, γ, φ, ψ。

    delta_P = 0.001 / ConstData.VU;
    c_P = (evaluate_coast_to_entry_first(rv0, P0 + delta_P, ConstData) ...
        - evaluate_coast_to_entry_first(rv0, P0 - delta_P, ConstData)) ...
        / (2 * delta_P);
end
