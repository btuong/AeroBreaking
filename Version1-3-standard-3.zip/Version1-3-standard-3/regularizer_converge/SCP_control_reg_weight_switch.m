% 控制正则逐节点积分权开关对照：同一正则方式与 w 下分别保留 ω_i、改为全 1。
% 默认 sum/u1/u2/norm × w=1e-4，各运行 10 轮；只改控制正则附加项的节点权。
% 可选工作区变量: results_folder（默认 results_weight_switch）、max_iter（默认 10）。
% 输出: 每工况 case_metrics.mat、控制量小 MAT 与文本，以及 results_root/对照汇总.txt、.mat。

%% ===== 环境准备 =====
tic;
converge_root = fileparts(mfilename('fullpath'));
version_root = fileparts(converge_root);
previous_path = path;
restore_path = onCleanup(@() path(previous_path));
modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
    'trust_region', 'validation', 'iteration', 'output'};
for k = 1:numel(modules)
    addpath(fullfile(version_root, modules{k}));
end
addpath(converge_root);
rehash;
if ~exist('results_folder', 'var')
    results_folder = 'results_weight_switch';
end
if ~exist('max_iter', 'var')
    max_iter = 10;
end
results_root = fullfile(converge_root, results_folder);

%% ===== 运行开关对照 =====
types = {'sum', 'u1', 'u2', 'norm'};
switches = [true, false];
summary_list = cell(numel(types) * numel(switches), 1);
plateau = struct('window', max_iter + 1, 'tolerance', 0.1);
case_index = 0;
for t = 1:numel(types)
    for s = 1:numel(switches)
        case_index = case_index + 1;
        use_weights = switches(s);
        case_name = sprintf('%s_omega_%d', types{t}, use_weights);
        case_directory = fullfile(results_root, case_name);
        fprintf('[CASE] %s start\n', case_name);
        config = scp_config_default();
        config.iter.max_scp_iter = max_iter;
        config.iter.tolerance = 0;
        config.objective.control_reg_type = types{t};
        config.objective.weight_control_reg = 1e-4;
        config.objective.control_reg_use_integration_weights = use_weights;
        config.plot.enable_initial = false;
        config.plot.enable_iteration = false;
        config.plot.enable_final = false;
        config.output.print_pre_iteration = false;
        config.output.print_iteration = false;
        config.output.print_summary = false;
        config.output.save.brief_text = true;
        config.output.save.detail_text = true;
        config.output.save.control_text = true;
        config.output.save.control_mat = true;
        config.output.save.scan_mat = false;
        config.output.save.full_mat = false;
        config.output.save.directory = ...
            ['regularizer_converge/' results_folder '/' case_name];
        [Result, ~, SaveReport, RunInfo] = run_converge_case(config, plateau);
        if ~SaveReport.success
            error('WeightSwitch:SaveFailed', '工况 %s 的结果文件没有写成。', case_name);
        end
        Metrics = extract_converge_metrics( ...
            Result, RunInfo, case_name, types{t}, 1e-4, NaN);
        Metrics.use_integration_weights = use_weights;
        save(fullfile(case_directory, 'case_metrics.mat'), 'Metrics');
        fprintf('[CASE] %s done: 末轮总脉冲 %.10f m/s\n', ...
            case_name, Metrics.total_impulse_m_s(Metrics.final_index));
    end
end
Summary = summarize_control_reg_weight_switch(results_root);
fprintf('ALL_DONE (%.1f s)\n', toc);
