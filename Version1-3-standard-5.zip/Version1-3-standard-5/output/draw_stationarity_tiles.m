function draw_stationarity_tiles(fig, HistorySeries, config)
% DRAW_STATIONARITY_TILES 画余项与驻点度量: 动力学余项按阶、驻点度量。
%
% 输入:
%   fig            - 目标图窗
%   HistorySeries  - plot_scp_result 整理好的迭代序列，各轮 plot_data 含 trust_region
%   config         - 读取 config.plot.font_size 与 config.iter.stationarity_tolerance
%
% 两个分块（横轴为迭代序号，对数纵轴）:
%   1. 动力学余项按阶: 二次、一次（状态×控制 + 状态×时长）、与半径无关三条线，颜色和
%      标记沿用半径扫描图里对应部分（状态×状态、状态×控制、控制×时长）。
%   2. 驻点度量: ΔL（下界）与 (r_max/r)ΔL（上界）画实线，ε 画虚线。
% 标记约定与其他全程图一致: 接受实心、拒绝空心、P3 失败红叉，含义写在标题下面一行；
% 整扇窗只在底部放一个共用图例（finish_tile_window）；不在图上加文字标注。没算出的轮
% 留空，不补零。

    iters = HistorySeries.iter;
    status = HistorySeries.status;
    TrustData = collect_trust_series(HistorySeries);
    pick = @(field) [TrustData.(field)];
    Palette = build_analysis_palette();
    series = @(name, values, key) build_log_series(name, values, ...
        Palette.(key), false, Palette.marker.(key), Palette.width.normal);

    layout = create_tile_layout(fig, 2);
    tile_axes = gobjects(1, 2);
    for j = 1:2
        tile_axes(j) = nexttile(layout);
    end
    notes = {describe_status_marks(status)};

    notes = [notes, draw_log_history_tile(tile_axes(1), iters, status, ...
        [series('二次', pick('remainder_second'), 'state_state'), ...
        series('一次', pick('remainder_first'), 'state_control'), ...
        series('与半径无关', pick('remainder_zero'), 'control_time')], ...
        '动力学余项按阶', config)];

    % 驻点度量: ε 是常数，对每一轮都画，让对数纵轴的范围把它包进来；
    % ΔL 为负时按 0 画（max 会把 NaN 变成 0，所以只改有限值，没算出的轮保持留空）
    tolerance = config.iter.stationarity_tolerance * ones(1, numel(iters));
    lower_bound = pick('predicted_reduction');
    lower_bound(isfinite(lower_bound)) = max(lower_bound(isfinite(lower_bound)), 0);
    notes = [notes, draw_log_history_tile(tile_axes(2), iters, status, ...
        [series('ΔL', lower_bound, 'predicted_reduction'), ...
        series('(r_max/r)ΔL', pick('stationarity_bound'), 'stationarity_bound'), ...
        build_log_series('ε', tolerance, Palette.tolerance, true, 'none', ...
            Palette.width.bound)], ...
        '驻点度量', config)];

    finish_tile_window(layout, tile_axes, '余项与驻点度量', notes, config);
end
