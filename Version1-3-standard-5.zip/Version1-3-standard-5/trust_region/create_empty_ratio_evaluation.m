function Evaluation = create_empty_ratio_evaluation(reason)
% CREATE_EMPTY_RATIO_EVALUATION 创建字段齐全的“未评价”下降比评价结果。
%
% 字段与 evaluate_reduction_ratio 的输出一致；未评价时数值为 NaN，
% 罚函数结构为空，reason 写明未评价的原因。
%
% 叫法：违反量、罚项是原函数一侧（P2、罚问题 J），松弛、松弛罚项是线性化函数一侧
% （P3 的目标 L）。目标分三部分：性能指标 C（总脉冲）、附加项 Γ（控制正则项）、罚项 Θ；
% 预测下降 ΔL = 性能指标的预测下降 + 附加项的预测下降 + 罚项的预测下降，预测误差 D、
% 真实下降 ΔJ 同样分成三部分。

    Evaluation.evaluated = false;
    Evaluation.reason = reason;
    Evaluation.reference = [];                 % 参考处的罚函数 J（evaluate_penalty_function）
    Evaluation.candidate = [];                 % 候选解处的罚函数 J
    Evaluation.reference_from_cache = false;   % 参考处的值是否取自上一轮的计算
    Evaluation.reference_check = [];           % 参考处的 P2 可行性检查（算 J 用的就是这一份）
    Evaluation.p3_value = NaN;                 % P3 的目标 L 在候选解处的值

    % 逐项账：同一项在参考、候选解、P3 三处的值，以及下降和预测误差
    Evaluation.term_names = {};
    Evaluation.term_labels = {};
    % 类别：性能指标 'cost_nonconvex'、'cost_convex'；附加项 'extra_convex'、
    % 'extra_nonconvex'；罚项 'equality_penalty'、'inequality_penalty'
    Evaluation.term_kinds = {};
    Evaluation.term_reference = [];            % J_m(z^k)
    Evaluation.term_candidate = [];            % J_m(z^k + d^k)
    Evaluation.term_p3 = [];                   % L_m(d^k)
    Evaluation.term_actual_reduction = [];     % 各项 J(参考) − J(候选解)，即真实下降 ΔJ_m
    Evaluation.term_predicted_reduction = [];  % 各项 J(参考) − L(候选解)，即预测下降 ΔL_m
    Evaluation.term_prediction_error = [];     % D_m = ΔL_m − ΔJ_m = J_m(候选解) − L_m(候选解)
    Evaluation.term_error_share = [];          % D_m / ΔL，ΔL 不可用时为 NaN
    empty_group = struct('reference', NaN, 'candidate', NaN, 'p3', NaN, ...
        'predicted', NaN, 'actual', NaN, 'error', NaN);
    % 三组小计：cost 性能指标，extra 附加项，penalty 罚项
    Evaluation.group = struct('cost', empty_group, 'extra', empty_group, ...
        'penalty', empty_group);
    Evaluation.slack_penalty = NaN;            % 松弛罚项：候选解处罚项各项的 L_m 之和
    Evaluation.convex_error_flag = false;      % 凸项（性能指标或附加项）的 D_m 不为 0
    Evaluation.convex_error_names = {};
    Evaluation.subterms = struct('term_name', {}, 'label', {}, ...
        'reference', {}, 'candidate', {}, 'p3', {});

    Evaluation.actual_reduction = NaN;         % 真实下降 ΔJ
    Evaluation.predicted_reduction = NaN;      % 预测下降 ΔL
    Evaluation.ratio = NaN;                    % ρ = ΔJ / ΔL
    Evaluation.ratio_available = false;

    % 预测误差、门槛和 K 估计（只报告）
    Evaluation.prediction_error = NaN;         % D = ΔL − ΔJ
    Evaluation.threshold = NaN;                % 门槛 (1−ρ1)ΔL
    Evaluation.error_to_threshold = NaN;       % D / 门槛，ρ 没算出时为 NaN
    Evaluation.step_norm = NaN;                % ‖d‖，以基准半径为单位
    Evaluation.curvature_estimate = NaN;       % K 估计 D / ‖d‖²

    % 步长占半径的比例
    Evaluation.step_ratio = NaN;               % 候选解步长 / 本轮半径 的最大值
    Evaluation.step_ratio_channel = '';
    Evaluation.step_ratio_channels = nan(1, 6);  % 通道 r, V, gamma, phi, psi, P 各自的最大值
    Evaluation.step_ratio_node = [];           % N x 5，逐节点 |候选解 − 参考| / 半径
    Evaluation.step_ratio_pulse = [];          % 6 x 1，逐脉冲 |候选解 − 参考| / 半径
    Evaluation.on_boundary = false;            % 候选解是否贴在信赖域边界上

    % 半径与驻点度量（只报告）
    Evaluation.radius_scale = NaN;             % 本轮半径 r（基准半径的倍数）
    Evaluation.radius_scale_max = NaN;         % r_max
    Evaluation.ratio_band = 'unavailable';     % ρ 落在经典表的哪一行
    Evaluation.slack_zero = false;             % 松弛罚项已降为 0
    Evaluation.ratio_held = false;             % ρ ≥ ρ1
    Evaluation.stationarity_bound = NaN;       % 驻点度量的上界 (r_max/r)ΔL
    Evaluation.stationarity_tolerance = NaN;   % ε

    % 同一参考点上一次求解的对比，和动力学余项按阶拆分
    Evaluation.same_reference = create_empty_same_reference();
    Evaluation.remainder_split = create_empty_remainder_split();
end
