function StopDecision = create_empty_stop_decision()
% CREATE_EMPTY_STOP_DECISION 创建统一的空停止判定。
%
% stationary、feasible、step_converged 是收敛的三项（只报告），
% stop_basis 写明其中哪几项是本项目的停止依据。

    StopDecision.stop = false;
    StopDecision.reason = 'not_evaluated';
    StopDecision.detail = '';
    StopDecision.facts = struct();
    StopDecision.stationary = false;       % 驻点：驻点度量的上界不超过 ε
    StopDecision.feasible = false;         % 对 P2 可行：候选解的 P2 可行性检查通过
    StopDecision.step_converged = false;   % 步长：相邻解差小于阈值
    StopDecision.stop_basis = {'step'};    % 本项目的停止依据（只有步长）
end
