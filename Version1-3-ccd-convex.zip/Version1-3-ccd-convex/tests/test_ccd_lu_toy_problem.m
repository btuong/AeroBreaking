function tests = test_ccd_lu_toy_problem()
% TEST_CCD_LU_TOY_PROBLEM 单节点玩具问题核验 Lu 2020 原文平方内逼近行为与零初值不可行特性。
%
% 玩具问题：min_u −q·d^T·u，q = 1，d = (1, 0)，‖u‖ = 1，从 θ₀ = 30° 出发，不设信赖域。
% 每轮解 3 变量 [u1; u2; ε] 的 SOCP：目标 [−q·d; p]，锥 (1 + ε, u1, u2) ∈ Q³，
% 平方内逼近行 −2·ū^T·u ≤ −(1 + ‖ū‖_2^2)，边界 u ∈ [−(1 + ε_max), 1 + ε_max]、ε ∈ [0, ε_max]。
% 调用项目 solve_convex_subproblem。
% 运行前要把本版本各模块加到路径上（SCP.m 开头添加的那组模块）。

    tests = functiontests(localfunctions);
end


function test_toy_square_linearization_above_demand(testCase)
% q=1, d=(1,0), p=5, θ₀=30° 跑 10 轮：每轮 ‖u_k‖ ≥ 1、ε_k = ‖u_k‖−1 严格递减趋于 0、|ρ−1| ≤ 1e-4。

    q = 1;
    d = [1; 0];
    p = 5;
    slack_max = 1;
    u_bar = [cosd(30); sind(30)];
    epsilon_previous = inf;

    for k = 1:10
        [SolverResult, Out] = solve_toy_square_round(q, d, p, slack_max, u_bar);
        verifyTrue(testCase, SolverResult.success);
        u_norm = norm(Out.u);
        verifyGreaterThanOrEqual(testCase, u_norm, 1 - 1e-9);
        verifyEqual(testCase, Out.epsilon, u_norm - 1, 'AbsTol', 1e-8);
        if k <= 5
            verifyLessThanOrEqual(testCase, abs(Out.rho - 1), 1e-4);
        end
        if k > 1
            verifyLessThan(testCase, Out.epsilon, epsilon_previous);
        end
        verifyFalse(testCase, Out.capped);
        epsilon_previous = Out.epsilon;
        u_bar = Out.u;
    end
    verifyLessThan(testCase, epsilon_previous, 2e-4);
end


function test_toy_below_demand_hits_cap(testCase)
% p = 0.5 < q 时触到 ε_max。

    q = 1;
    d = [1; 0];
    p = 0.5;
    slack_max = 0.5;
    u_bar = [cosd(30); sind(30)];

    for k = 1:3
        [SolverResult, Out] = solve_toy_square_round(q, d, p, slack_max, u_bar);
        verifyTrue(testCase, SolverResult.success);
        verifyEqual(testCase, Out.epsilon, slack_max, 'AbsTol', 1e-7);
        verifyTrue(testCase, Out.capped);
        if k == 1
            verifyEqual(testCase, Out.rho, 1, 'AbsTol', 1e-6);
        end
        u_bar = Out.u;
    end
end


function test_toy_zero_init_infeasible(testCase)
% 从 ū₀ = (0, 0) 出发调用 solve_convex_subproblem，断言 ~SolverResult.success（0 ≤ −1 不可行）。

    q = 1;
    d = [1; 0];
    p = 5;
    slack_max = 1;
    u_bar = [0; 0];

    [SolverResult, ~] = solve_toy_square_round(q, d, p, slack_max, u_bar);
    verifyFalse(testCase, SolverResult.success);
end


function [SolverResult, Out] = solve_toy_square_round(q, d, p, slack_max, u_bar)
% SOLVE_TOY_SQUARE_ROUND 用平方内逼近行 −2·ū^T·u ≤ −(1 + ‖ū‖²) 解一轮玩具 SOCP。

    config = scp_config_default();
    objective = [-q * d(:); p];
    LinearConstraints.matrix = sparse([-2 * u_bar(1), -2 * u_bar(2), 0]);
    LinearConstraints.lower = -Inf;
    LinearConstraints.upper = -(1 + u_bar(1)^2 + u_bar(2)^2);
    LinearConstraints.row_groups = struct('unit_norm_inner', 1);

    ConicConstraints.mapping = sparse([0, 0, 1; 1, 0, 0; 0, 1, 0]);
    ConicConstraints.offset = [1; 0; 0];
    ConicConstraints.cones = struct('name', 'control_disk', 'type', 'quadratic', ...
        'dimension', 3, 'rows', (1:3).', 'tightness_role', 'epigraph', 'index', 1);

    u_limit = 1 + slack_max;
    VariableBounds.lower = [-u_limit; -u_limit; 0];
    VariableBounds.upper = [u_limit; u_limit; slack_max];

    SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ConicConstraints, config);
    Out = struct('u', nan(2, 1), 'epsilon', NaN, 'L', NaN, 'J', NaN, ...
        'rho', NaN, 'capped', false);
    if ~SolverResult.success
        return;
    end

    Out.u = SolverResult.primal(1:2);
    Out.epsilon = SolverResult.primal(3);
    Out.L = SolverResult.objective;
    Out.J = -q * (d(:).' * Out.u) + p * max(norm(Out.u) - 1, 0);
    J_ref = -q * (d(:).' * u_bar(:)) + p * max(norm(u_bar) - 1, 0);
    Out.rho = (J_ref - Out.J) / (J_ref - Out.L);
    Out.capped = Out.epsilon >= slack_max - 1e-9 * max(1, slack_max);
end
