% 对照：regularized 模式下 3 轮的原始矩阵残差和 P3 解检查（一次性脚本，不进主链）。
version_root = 'E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-standard-5';
cd(version_root);
addpath('setup','dynamics','constraints','subproblem','trust_region','validation','iteration','output');
config = scp_config_default();
config.plot.enable_initial = false; config.plot.enable_iteration = false; config.plot.enable_final = false;
config.output.print_pre_iteration = false; config.output.print_iteration = false; config.output.print_summary = false;
config.output.save.brief_text = false; config.output.save.detail_text = false; config.output.save.scan_mat = false;
config.output.save.full_mat = false; config.output.save.control_text = false; config.output.save.control_mat = false;
config.validation.enable_trapezoid_check = false;
[ConstData, InitialState] = initialize_problem(config);
[InitialReference, InitialPropagation] = generate_initial_reference(ConstData, InitialState, config);
[RunState, ~] = initialize_scp_run(InitialReference, InitialPropagation, config);
for iter = 1:3
    [Sol, Diag] = solve_scp_subproblem(RunState.current_reference, RunState.trust_region, ConstData, config, iter);
    TR = update_trust_region(Sol, Diag, RunState.current_reference, RunState.trust_region, ConstData, config, iter);
    [RunState, Rec] = advance_scp_iteration(RunState, Sol, Diag, TR, ConstData, config, iter);
    M = Diag.p3_check.solver_feasibility_report.metrics;
    fprintf('--- regularized iter %d: status %s, feasibility_report.success = %d, p3_check.success = %d, max con residual %.3e, mosek pfeas con %.2e\n', ...
        iter, Diag.solver.status, Diag.p3_check.solver_feasibility_report.success, Diag.p3_check.success, max([M(~endsWith({M.name}, '_norm_inf')).value]), Diag.solver.mosek_report.primal_violation_con);
    for m = 1:numel(M)
        if M(m).evaluated && ~M(m).satisfied
            fprintf('    FAILED metric %-28s value %.3e rel %.3e tol %.3e\n', M(m).name, M(m).value, M(m).relative_value, M(m).tolerance);
        end
    end
end
disp('DIAG_DONE');
