function x_in_atm = evaluate_coast_pass_to_entry(x_ci_N, P1, ConstData)
% EVALUATE_COAST_PASS_TO_ENTRY 真空映射：出口到远地点、脉冲后到下一圈大气入口。
%
% 输入:
%   x_ci_N - 1x5 第 cir 圈大气出口的 ECF 球坐标状态
%   P1     - 出口远地点处施加的脉冲（VU）
%
% 输出:
%   x_in_atm - 1x5 下一圈大气入口的 ECF 球坐标状态
%
% 时间链口径：ECF 转换取 gast=0（z 轴旋转对称下与真实转角等价）。

    mu = ConstData.mu;
    we = ConstData.we;
    RM = ConstData.RM;
    TU = ConstData.TU;
    J2 = ConstData.J2;
    R_atm = ConstData.R_atm;

    [r0, v0] = transform_state2rv(x_ci_N);
    [r0, v0] = transform_ecf2eci(0, we, r0, v0);

    % 大气出口积分到远地点
    opts = odeset('Events', @event_apoapsis, 'RelTol', 1e-12, ...
        'AbsTol', 1e-12);
    [~, rv_trans_out] = ode45( ...
        @(t, x) evaluate_vacuum_dynamics(mu, J2, RM, x), ...
        [0, 3000000 / TU], [r0, v0], opts);

    r1 = rv_trans_out(end, 1:3);
    v1 = rv_trans_out(end, 4:6);
    v2 = v1 + v1 / norm(v1) * P1;

    % 远地点积分到下一次进入大气层
    opts = odeset('Events', @(t, y) event_atmosphere_entry_rv(t, y, R_atm), ...
        'RelTol', 1e-12, 'AbsTol', 1e-12);
    [~, rv_trans_in] = ode45( ...
        @(t, x) evaluate_vacuum_dynamics(mu, J2, RM, x), ...
        [0, 3000000 / TU], [r1, v2], opts);
    [r_in_atm, v_in_atm] = transform_eci2ecf(0, we, ...
        rv_trans_in(end, 1:3)', rv_trans_in(end, 4:6)');
    x_in_atm = transform_rv2state(r_in_atm, v_in_atm);
    x_in_atm = x_in_atm(1:5);
end
