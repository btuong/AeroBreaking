function PerformanceReport = evaluate_performance_index(Solution, ConstData, ~)
% EVALUATE_PERFORMANCE_INDEX 用重算后的末次脉冲算性能指标对应的物理量：总脉冲 Σ|P_k|。
%
% 报告不含罚项，也不含控制正则；components 为 P0~P5 (m/s)。

    components = abs(Solution.control.P(:)) * ConstData.VU;
    PerformanceReport.value = sum(components);
    PerformanceReport.unit = 'm/s';
    PerformanceReport.components = components;
    PerformanceReport.normalized_value = PerformanceReport.value / ConstData.VU;
    PerformanceReport.evaluated = true;
end
