function Series = build_log_series(name, values, color, is_bound, marker, line_width)
% BUILD_LOG_SERIES 创建对数纵轴分块里的一条曲线：名字、各轮数值、颜色、是否为界、标记、线宽。
%
% is_bound 为真时画虚线（界、门槛、阈值），不带标记；否则画实线（实际量），每轮的点
% 用 marker 形状（接受实心、拒绝空心）。values 为 1 x K，没算出的轮写 NaN，画图时留空。
% marker 省略时为 'o'；line_width 省略时为 1.5（同级曲线），总量和分项同块时由调用方
% 分别给粗、细线宽（build_analysis_palette 的 width）。

    if nargin < 5 || isempty(marker)
        marker = 'o';
    end
    if nargin < 6 || isempty(line_width)
        line_width = 1.5;
    end
    Series = struct('name', name, 'values', values(:)', 'color', color, ...
        'is_bound', is_bound, 'marker', marker, 'line_width', line_width);
end
