function print_iteration_overview(file_id, PublicHistory)
% PRINT_ITERATION_OVERVIEW 向终端或文件打印所有真实尝试的紧凑概况表（每行不超过 78 个显示列）。
%
% 输入:
%   file_id       - 1 写终端，其余为 fopen 得到的文件号
%   PublicHistory - Result.history，每个元素含 iter、trust、subproblem
%
% 列: 轮、决策、r（本轮求解所用的信赖域半径）、ρ、ΔL（预测下降）、D（预测误差）、
% J(候选解)（候选解处的罚函数）、驻点上界（驻点度量的上界 (r_max/r)ΔL）、
% 违反比（P2 可行性检查的最大违反量/容差）。ΔL、D 留 4 位有效数字，其余 2 位。
% 求解失败的轮只有决策和 r，其余列显示 '-'；ρ 未算时显示 '-'。
% 停止原因见运行结论，不在表中重复。
% 终端摘要和简略文件共用本函数。

    fprintf(file_id, '\n迭代概况:\n');
    widths = [4, 6, 6, 7, 10, 10, 8, 8, 8];
    print_overview_row(file_id, {'轮', '决策', 'r', 'ρ', 'ΔL', 'D', ...
        'J(候选解)', '驻点上界', '违反比'}, widths);

    if isempty(PublicHistory)
        fprintf(file_id, '  无真实尝试\n');
        return;
    end

    for index = 1:numel(PublicHistory)
        Iteration = PublicHistory(index);
        if Iteration.trust.candidate_available ...
                && Iteration.trust.accept_candidate
            decision_text = '接受';
        elseif Iteration.trust.candidate_available
            decision_text = '拒绝';
        else
            decision_text = '无候选';
        end
        Evaluation = Iteration.trust.evaluation;
        radius_text = sprintf('%.4g', ...
            Iteration.trust.trust_region_update.scale_before);
        if ~Evaluation.evaluated
            % 没有候选解，罚函数、下降和驻点度量都不存在
            cells = {sprintf('%d', Iteration.iter), decision_text, ...
                radius_text, '-', '-', '-', '-', '-', '-'};
        else
            if Evaluation.ratio_available
                ratio_text = sprintf('%.3f', Evaluation.ratio);
            else
                ratio_text = '-';
            end
            cells = {sprintf('%d', Iteration.iter), decision_text, ...
                radius_text, ratio_text, ...
                sprintf('%.3e', Evaluation.predicted_reduction), ...
                sprintf('%.3e', Evaluation.prediction_error), ...
                sprintf('%.1e', Evaluation.candidate.total), ...
                sprintf('%.1e', Evaluation.stationarity_bound), ...
                sprintf('%.1e', Iteration.subproblem.p2_feasibility.max_ratio)};
        end
        print_overview_row(file_id, cells, widths);
    end
end


function print_overview_row(file_id, cells, widths)
% PRINT_OVERVIEW_ROW 按显示宽度打印一行：首列和决策列左对齐，其余右对齐，列间空一格。

    parts = cell(1, numel(cells));
    for c = 1:numel(cells)
        num_spaces = max(widths(c) - measure_display_width(cells{c}), 0);
        if c <= 2
            parts{c} = [cells{c}, blanks(num_spaces)];
        else
            parts{c} = [blanks(num_spaces), cells{c}];
        end
    end
    fprintf(file_id, '  %s\n', strjoin(parts, ' '));
end
