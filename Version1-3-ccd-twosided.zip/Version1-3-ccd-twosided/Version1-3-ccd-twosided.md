# Version1-3-ccd-twosided 双侧共用松弛 CCD 模式

自 `Version1-3-standard-3` 复制（2026-11-24，复制时代码与 standard-3 相同）。在保持默认 `'regularized'` 模式与 R1 口径完全不变的前提下，实现文章 [15]（Ning et al., *Aerospace Science and Technology*, 2026）的双侧共用松弛凹凸分解（CCD）单位范数约束处理方式（`config.unit_norm.mode = 'twosided'`，不含原文推力裕度项）。

## 核心实现与接口

- **配置与描述**：`setup/scp_config_default.m` 新增 `config.unit_norm`（`mode = 'regularized'`、`twosided_penalty_weight = 100`、`twosided_slack_max = 2`、`twosided_keep_control_bounds = false`）；新增 `subproblem/describe_unit_norm.m` 统一解析并校验配置。
- **P3 装配与求解提取**：
  - `build_variable_index.m`：`'twosided'` 下在 `t_f` 后追加 2 个全局共用松弛 `unit_norm_slack`（`s_a1`, `s_a2`，总变量数 `17*N + 27`）；`'regularized'` 下为 `zeros(0, 1)`（总变量数 `17*N + 25`）。
  - `build_variable_bounds.m`：`'twosided'` 且 `~keep_control_bounds` 时将 `u1, u2` 边界放宽为 `±(1 + s_max)`，并对 `unit_norm_slack` 施加 `[0, s_max]`。
  - `build_conic_constraints.m`（第 4 个输入改为 `config`）：`'twosided'` 下全部 $N$ 个 `control_disk` 锥共享 `unit_norm_slack(1)`，表示 $(1+s_{a1}, u_{1,i}, u_{2,i})\in\mathcal{Q}^3$，且 `tightness_role = 'none'`。
  - `build_linear_constraints.m`：`'twosided'` 下新增 `unit_norm_inner` 行块（$N$ 行），装配 $-2\bar u_{1,i}u_{1,i}-2\bar u_{2,i}u_{2,i}-s_{a2}\le-(1+\|\bar u_i\|_2^2)$，不在 $\|\bar u_i\|<10^{-6}$ 处做方向替换。
  - `build_objective.m`、`compute_objective_terms.m`、`extract_subproblem_solution.m`：`'twosided'` 下设 $c(s_{a1})=c(s_{a2})=P$、$c(u)=0$、$c_{\mathrm{fix}}=0$，分项归入 `'unit_norm_penalty'`（`inequality_penalty`）。
- **罚函数、对偶分解与输出**：
  - `trust_region/evaluate_penalty_function.m`：`'twosided'` 下计入 $\Theta_{\mathrm{unit}} = P\big(\max_i(\|u_i\|_2-1)_+ + \max_i(1-\|u_i\|_2^2)_+\big)$，无附加项（$\Gamma=0$）。
  - `subproblem/compute_control_dual_split.m`、`evaluate_control_report.m`、`create_empty_control_report.m`、`summarize_control_report.m`、`create_empty_control_summary.m`、`evaluate_p3_multipliers.m`：接入 `unit_norm_inner` 对偶分解，补充 `s_inner`、`lambda_inner`、`cone_dual_leading`、`unit_norm_slack`、`slack_capped` 及汇总量 `max_inward_gap`、`max_outward_gap`、`num_slack_capped`，并修复 `'twosided'` 下 `gamma_node` 不加 `norm_gap` 偏置的问题。
  - `output/describe_penalty_term.m`、`print_scp_iteration.m`、`build_control_export.m`、`print_control_report.m`、`build_iteration_plot_data.m`、`SCP.m`：补充 `'twosided'` 显示、导出与容错（`'regularized'` 下输出格式保持逐字节不变）。

## 验证结果（2026-11-24）

- **单元测试**：`tests/test_unit_norm_twosided.m`（6 项）、`tests/test_twosided_toy_problem.m`（2 项）、`tests/test_control_tightness_mechanisms.m`（7 项）、`tests/test_control_reg_integration_weights.m`（3 项），共 18 项用例全部通过（`Passed = true`）。
- **R1 默认 `'regularized'` 10 轮回归**：`results/scp_run_brief.txt`（SHA256 `81C6B9B5E09412900A1B6255FF3FECE4ED544D83C5D792794354FEC41410B4DE`）与 `results/scp_run_detail.txt`（SHA256 `1F3DCE300C0AFB6BB64F67797FE10FC7C5B022BAA99A716E7DC8E5DA2AAFAFAC`）均与 `Version1-3-standard-3/results/` 逐字节一致；`scp_run_control.txt` 仅第 2 行版本名不同。
- **`'twosided'` 模式 10 轮主链验证**（存档于 `Version1-3-ccd-twosided/results/twosided_10iter/`，$P=100, s_{\max}=2$）：10 轮均以 `OPTIMAL` 求解并接受，无触上界。第 1～10 轮核心指标：第 1 轮总脉冲 124.0102 m/s、$s_{a1}=6.557\times 10^{-4}$、$\max|1-\|u\||=6.562\times 10^{-4}$、圆约束预测误差 $4.894\times 10^{-5}$；第 2 轮总脉冲 140.8750 m/s、$s_{a1}=1.785\times 10^{-5}$、$\max|1-\|u\||=1.785\times 10^{-5}$；第 3～10 轮 $s_{a1}$ 保持在 $7.201\times 10^{-7}\sim 7.328\times 10^{-7}$，$s_{a2}\approx 0$（$-1.08\times 10^{-14}\sim -3.13\times 10^{-15}$），圆内缩进始终为 0，圆外溢出 $\max|1-\|u\||\le 9.596\times 10^{-7}$，第 10 轮总脉冲 137.5374 m/s、驻点残差 $4.134\times 10^{-9}$。

阶段 1 对比实验（`Version1-3-ccd-twosided/twosided_compare/`，fixed $r=1$、50 轮口径）共运行 12 个 `twosided` 工况并与 5 个只读 `standard-5` 基线比较：$P = 10^{-3}, 10^{-2}$ 低于外推和门槛而圆外不紧（末轮 `42.42`、`86.00 m/s`），$P = 3\times 10^{-2}, 10^{-1}, 1$ 末轮 `89.61~118.90 m/s` 且全部 E/D 节点共用向外偏离（$s_{a1} = 7.57\times 10^{-4}\sim 2.11\times 10^{-5}$），$P = 100$ 转角冻结至 $0.069^\circ$（`127.74 m/s`）；活跃轮对偶比满足 $\sum\hat\kappa/P = 1.0000$、$\sum(-y_i)/P \approx 0.33\text{--}0.50$；零初值第 1 轮均以 `s_a2 = 1.000` 退化为球松弛。数据见 [阶段1报告](../Version1-3-ccd-twosided/docs/算法改进_阶段1_双侧共用松弛对比实验.md)。
