function TrustData = collect_trust_series(HistorySeries)
% COLLECT_TRUST_SERIES 把各轮 PlotData.trust_region 拼成 1 x K 结构体数组，供预测下降与预测误差、半径与判据、半径平面三扇全程窗共用。
%
% 失败轮的预测下降、预测误差、K 估计和驻点度量的上界都是 NaN，不补零，也不拿其他轮的值填。

    all_plot_data = [HistorySeries.plot_data{:}];
    % 结构体数组的字段访问是逗号列表，先收集进元胞再拼接成 1 x K
    trust_cells = arrayfun(@(d) d.trust_region, all_plot_data, ...
        'UniformOutput', false);
    TrustData = [trust_cells{:}];
end
