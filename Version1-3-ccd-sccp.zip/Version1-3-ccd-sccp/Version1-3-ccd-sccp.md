# Version1-3-ccd-sccp SCCP 单位范数模式

自 `Version1-3-standard-3` 复制，在保留默认 `'regularized'` 行为不变的基础上，实现文献 [10]（Deng, Liu & Wang 2024）SCCP 方式的单位范数约束处理：`config.unit_norm.mode = 'sccp'`。

与 `Version1-3-standard-3` 的唯一算法区别在于对 $\|u_i\|_2 = 1$ 的处理方式：`'sccp'` 下不加控制正则项（`u1`、`u2` 目标系数与常数偏置均为 `0`，$\Gamma = 0$），保留控制圆盘锥 $\|u_i\|_2 \le 1$（`u1, u2 ∈ [-1, 1]`，`tightness_role = 'none'`），并在参考控制 $\bar u_i$ 处线性化反凸不等式 $1 - \|u_i\|_2^2 \le 0$，引入共用标量松弛 $\eta \in [0, \eta_{\max}]$（索引 `17*N + 26`，每节点分配 $\eta / N$）：
$$
-2\bar u_{1,i}\,u_{1,i} - 2\bar u_{2,i}\,u_{2,i} - \frac{1}{N}\eta \le -\big(1 + \bar u_{1,i}^2 + \bar u_{2,i}^2\big), \qquad i = 1, \dots, N
$$
（块名 `unit_norm_inner`，不对近零 $\bar u_i$ 做替换）。P3 目标中罚 $C_\eta \eta$（`sccp_penalty_weight`，默认 `1`；`sccp_slack_max`，默认 `1e4`），P2 罚函数 $J$ 对应不等式罚项 $\Theta_{\mathrm{unit}} = C_\eta N \max_i [1 - \|u_i\|_2^2]_+$（分项名 `unit_norm_penalty`，类别 `inequality_penalty`）。判停、信赖域、动力学和其余约束均不动。改动/新增文件清单见 `Version1-3-ccd-sccp/README.md`。

验证（2026-11-24）：

- **全部单元测试**：`tests/test_unit_norm_sccp.m`（6 用例）、`tests/test_sccp_toy_problem.m`（2 用例）、`tests/test_control_tightness_mechanisms.m`（7 用例）、`tests/test_control_reg_integration_weights.m`（3 用例）共 18 个用例全部 `Passed`（0 Failed / 0 Incomplete）。其中 `test_unit_norm_sccp` 的 3 轮与对偶残差严格 `<= 1e-6` 断言将 `co_tol_pfeas`、`co_tol_dfeas` 收紧至 `1e-10` 测得（默认 `1e-8` 乘以 $N = 661$ 与 $\max|\text{dual}| \approx 240$ 会产生 $O(10^{-5})$ 求解器容差余量）。
- **R1 回归**：默认 `SCP.m`（`'regularized'`、10 轮）输出的 `results/scp_run_brief.txt`（SHA256 `81C6B9B5E09412900A1B6255FF3FECE4ED544D83C5D792794354FEC41410B4DE`）和 `results/scp_run_detail.txt`（SHA256 `1F3DCE300C0AFB6BB64F67797FE10FC7C5B022BAA99A716E7DC8E5DA2AAFAFAC`）与 `Version1-3-standard-3/results/` 同名文件逐字节一致；`scp_run_control.txt` 共 712 行，仅第 2 行版本名不同。
- **`'sccp'` 10 轮跑通**（$C_\eta = 1$、$\eta_{\max} = 10^4$、固定半径 $r = 1$，存 `results/sccp_10iter/`）：10 轮 P3 全部 `OPTIMAL` 并被接受，第 1 轮至第 10 轮总脉冲为 `124.3036`、`144.2089`、`141.5063`、`141.1145`、`140.7283`、`140.3428`、`139.9573`、`139.5761`、`139.1950`、`138.8141` m/s；$\eta$ 由首轮 `4.9582e-03` 降至第 2–10 轮的 `5.09e-06`–`7.24e-06`；全部 10 轮 `num_untight = 0`（末轮 $\max|1-\|u\|| = 1.3070\times 10^{-8}$），圆约束组预测误差 $D_{\mathrm{unit}}$ 在 `-4.5653e-03` 至 `1.2128e-05`，驻点残差 `1.2051e-06`–`2.8134e-05`；至第 10 轮上限未收敛（`feasible = 0`、`max_ratio = 11.29`）。

阶段 1 对比实验（`Version1-3-ccd-sccp/sccp_compare/`，fixed $r=1$、50 轮口径）共运行 13 个 `sccp` 工况（$C_\eta = 10^{-8}\dots 1$、2 个无速率约束对照、3 个 10 轮初值专项）并与 5 个只读 `standard-5` 基线比较：$C_\eta \le 10^{-5}$ 时末轮总脉冲达 `88.86~88.97 m/s` 但伴随 51～70 个 D 节点（$\eta = 0.359\sim 10^4$）及迭代过程 E 节点不紧，$C_\eta \ge 10^{-3}$ 时转角上限 $\alpha$ 缩至 $0.27^\circ\text{--}0.005^\circ$ 导致冻结（`119.35~129.88 m/s`）；E 节点单步转角全程未超理论帽半角 $\alpha$；$u = 0$ 首步退化为球松弛（$\eta = N = 661$）。数据见 [阶段1报告](../Version1-3-ccd-sccp/docs/算法改进_阶段1_SCCP模式对比实验.md)。
