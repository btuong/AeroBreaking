function TrustResult = update_trust_region( ...
        CurrentSolution, SubproblemDiag, CurrentReference, ...
        TrustRegionState, ConstData, config, iter)
% UPDATE_TRUST_REGION 决定本轮候选解是否接受，并给出下一轮的信赖域。
%
% 方法由 config.trust_region.method 选择：
%   'ratio' - 按 ρ = 真实下降 ΔJ / 预测下降 ΔL 判断：ρ < ρ0 拒绝；
%             ρ < ρ1 缩小半径，ρ1 ≤ ρ < ρ2 保持，ρ ≥ ρ2 扩大。ΔL 过小时
%             不算 ρ：本轮已满足步长检查就接受（作为收敛），否则拒绝并缩小。
%   'fixed' - 半径固定、P3 成功即接受；ρ 照样算出，只报告不使用。
% 半径形式为 倍数 r × 基准半径（代码里叫 scale），只缩放 r。
% 本函数是唯一决定接受与半径的地方，advance_scp_iteration 只读
% TrustResult（含被接受解 accepted_solution 及其步长检查与 P2 可行性
% 检查报告 accepted_convergence_report、accepted_p2_feasibility），
% 不另写接受判断；拒绝或求解失败时这些字段保持空报告。
%
% 本函数依次完成：
%   1. 检查输入是否自洽。
%   2. P3 求解失败：不接受，半径保持。
%   3. 算候选解的真实下降、预测下降、ρ、逐项账和驻点度量的上界。
%   4. 决定是否接受，以及半径缩小、保持还是扩大。
%   5. 给出下一轮信赖域。
%   6. 汇总并检查信赖域结果。
%
% TrustResult.success=true 表示形成了有效结果，不表示 P3 成功。
% 本函数不修改 RunState、参考与 config，不积分，不设置停止。

    %% 1. 检查输入是否自洽
    check_trust_update_inputs(CurrentSolution, SubproblemDiag, iter);

    %% 2. P3 求解失败：不接受，半径保持
    if ~SubproblemDiag.success
        % 没有候选解可评价，后面的步骤不做
        TrustResult = build_subproblem_failure_trust_result( ...
            SubproblemDiag, TrustRegionState, iter);
        return;
    end

    %% 3. 算候选解的真实下降、预测下降、ρ、逐项账和驻点度量的上界
    Evaluation = evaluate_reduction_ratio( ...
        CurrentSolution, SubproblemDiag, CurrentReference, ...
        TrustRegionState, ConstData, config);

    %% 4. 决定是否接受，以及半径缩小、保持还是扩大
    if strcmp(config.trust_region.method, 'fixed')
        % 固定半径：P3 成功即接受，ρ 只报告
        Decision = build_unconditional_acceptance();
    else
        Decision = compute_ratio_decision( ...
            Evaluation, SubproblemDiag.convergence_report, config);
    end

    %% 5. 给出下一轮信赖域
    % 缩放半径 r，并把下一轮参考的罚函数值一并带上，下轮不再重算；
    % 候选解被拒绝时记下这次求解，供同一参考点上的下一次求解对比
    [NextTrustRegionState, TrustRegionUpdate] = update_trust_region_scale( ...
        TrustRegionState, Decision, Evaluation, ...
        SubproblemDiag.p2_feasibility, config, iter);

    %% 6. 汇总并检查信赖域结果
    TrustResult = build_trust_region_result( ...
        'candidate_evaluated', Decision, Evaluation, ...
        TrustRegionUpdate, NextTrustRegionState, iter, ...
        CurrentSolution, SubproblemDiag);
    check_trust_region_result(TrustResult, SubproblemDiag);
end


function check_trust_update_inputs(CurrentSolution, SubproblemDiag, iter)
% CHECK_TRUST_UPDATE_INPUTS 检查诊断轮次一致，求解成功时候选解不为空。

    if SubproblemDiag.iter ~= iter
        error('SCP:IterationIndexMismatch', ...
            '子问题诊断轮次与信赖域更新轮次不一致。');
    end
    if SubproblemDiag.success && isempty(CurrentSolution)
        error('SCP:MissingCandidateSolution', ...
            'P3 求解成功时候选解不能为空。');
    end
end


function TrustResult = build_subproblem_failure_trust_result( ...
        SubproblemDiag, TrustRegionState, iter)
% BUILD_SUBPROBLEM_FAILURE_TRUST_RESULT 求解失败时的信赖域结果：不接受，半径保持。

    Evaluation = create_empty_ratio_evaluation('subproblem_failed');
    Decision = build_decision(false, false, 'hold', 'subproblem_failed');
    TrustRegionUpdate = build_scale_update( ...
        'hold', TrustRegionState.scale, TrustRegionState.scale);
    TrustResult = build_trust_region_result( ...
        'subproblem_failure_handled', Decision, Evaluation, ...
        TrustRegionUpdate, TrustRegionState, iter, [], SubproblemDiag);
    check_trust_region_result(TrustResult, SubproblemDiag);
end


function Decision = build_unconditional_acceptance()
% BUILD_UNCONDITIONAL_ACCEPTANCE 固定半径方法的决定：有候选解、接受、半径保持。

    Decision = build_decision(true, true, 'hold', 'unconditional_acceptance');
end


function Decision = compute_ratio_decision( ...
        Evaluation, ConvergenceReport, config)
% COMPUTE_RATIO_DECISION 按 ρ 决定是否接受候选解，以及半径缩小、保持还是扩大。
%
% 规则（ρ0 = accept_ratio，ρ1 = shrink_ratio，ρ2 = expand_ratio）:
%   ρ 可用:   ρ < ρ0 拒绝，否则接受；ρ < ρ1 缩小，ρ < ρ2 保持，否则扩大。
%   ΔL 过小:  本轮相邻解差已小于收敛阈值时接受并保持（候选解与参考几乎相同，
%             停止判定按收敛处理）；否则拒绝并缩小。
%   值非有限: 拒绝并缩小。
% reason 依次为 'ratio_accepted'、'ratio_rejected'、
% 'small_predicted_reduction_converged'、'small_predicted_reduction'、
% 'nonfinite_penalty_function'。

    TrustConfig = config.trust_region;
    if Evaluation.ratio_available
        rho = Evaluation.ratio;
        accept = rho >= TrustConfig.accept_ratio;
        if rho < TrustConfig.shrink_ratio
            intent = 'shrink';
        elseif rho < TrustConfig.expand_ratio
            intent = 'hold';
        else
            intent = 'expand';
        end
        if accept
            reason = 'ratio_accepted';
        else
            reason = 'ratio_rejected';
        end
    elseif strcmp(Evaluation.reason, 'small_predicted_reduction') ...
            && ConvergenceReport.converged
        accept = true;
        intent = 'hold';
        reason = 'small_predicted_reduction_converged';
    else
        % ΔL 过小但候选解还在变，或罚函数值非有限：不接受，缩小半径重试
        accept = false;
        intent = 'shrink';
        reason = Evaluation.reason;
    end
    Decision = build_decision(true, accept, intent, reason);
end


function Decision = build_decision( ...
        candidate_available, accept_candidate, update_intent, reason)
% BUILD_DECISION 创建接受决定：有无候选解、是否接受、半径意图和原因。

    Decision.candidate_available = candidate_available;
    Decision.accept_candidate = accept_candidate;
    Decision.update_intent = update_intent;
    Decision.reason = reason;
end


function [NextTrustRegionState, TrustRegionUpdate] = ...
        update_trust_region_scale(TrustRegionState, Decision, Evaluation, ...
        CandidateCheck, config, iter)
% UPDATE_TRUST_REGION_SCALE 按决定缩放半径 r，并带上下一轮参考的罚函数值、P2 可行性检查和被拒绝的这次求解。
%
% 缩小 r/α、扩大 α·r，再钳到 [min_scale, max_scale]。下一轮参考：
% 接受时是候选解，拒绝时仍是本轮参考，对应的 J 和 P2 可行性检查分别取候选解
% （Evaluation.candidate 与 CandidateCheck）和参考（Evaluation.reference 与
% Evaluation.reference_check）的评价结果，下一轮不再重算。
% 候选解被拒绝时，参考点不变、半径变小，相邻两次求解是 ΔL(r)、D(r) 曲线上的两个点，
% 所以把本轮的 iter、r、ΔL、D、松弛罚项和动力学余项四部分记进 previous_attempt；
% 被接受时参考点换了，置空。

    TrustConfig = config.trust_region;
    scale_before = TrustRegionState.scale;
    switch Decision.update_intent
        case 'shrink'
            scale_after = max(TrustConfig.min_scale, ...
                scale_before / TrustConfig.scale_factor);
        case 'expand'
            scale_after = min(TrustConfig.max_scale, ...
                scale_before * TrustConfig.scale_factor);
        otherwise
            scale_after = scale_before;
    end

    NextTrustRegionState = TrustRegionState;
    NextTrustRegionState.scale = scale_after;
    if Decision.accept_candidate
        NextTrustRegionState.reference_penalty_function = Evaluation.candidate;
        NextTrustRegionState.reference_check = CandidateCheck;
        NextTrustRegionState.previous_attempt = [];
    else
        NextTrustRegionState.reference_penalty_function = Evaluation.reference;
        NextTrustRegionState.reference_check = Evaluation.reference_check;
        NextTrustRegionState.previous_attempt = struct( ...
            'iter', iter, ...
            'radius_scale', scale_before, ...
            'predicted_reduction', Evaluation.predicted_reduction, ...
            'prediction_error', Evaluation.prediction_error, ...
            'slack_penalty', Evaluation.slack_penalty, ...
            'remainder_weighted', Evaluation.remainder_split.weighted);
    end
    TrustRegionUpdate = build_scale_update( ...
        Decision.update_intent, scale_before, scale_after);
end


function TrustRegionUpdate = build_scale_update( ...
        requested_action, scale_before, scale_after)
% BUILD_SCALE_UPDATE 记录半径动作：请求的动作、实际执行的动作和前后半径 r。
%
% 半径已在上下限时请求的缩小/扩大不会改变 r，applied_action 记为 'hold'。

    changed = scale_after ~= scale_before;
    if changed
        applied_action = requested_action;
    else
        applied_action = 'hold';
    end
    TrustRegionUpdate = struct( ...
        'requested_action', requested_action, ...
        'applied_action', applied_action, ...
        'changed', changed, ...
        'scale_before', scale_before, ...
        'scale_after', scale_after);
end


function TrustResult = build_trust_region_result( ...
        status, Decision, Evaluation, TrustRegionUpdate, ...
        NextTrustRegionState, iter, CurrentSolution, SubproblemDiag)
% BUILD_TRUST_REGION_RESULT 填入接受决定及被接受解对应的检查报告。

    TrustResult = create_empty_trust_result();
    TrustResult.success = true;
    TrustResult.status = status;
    TrustResult.iter = iter;
    TrustResult.candidate_available = Decision.candidate_available;
    TrustResult.accept_candidate = Decision.accept_candidate;
    TrustResult.reason = Decision.reason;
    TrustResult.evaluation = Evaluation;
    TrustResult.trust_region_update = TrustRegionUpdate;
    TrustResult.next_state = NextTrustRegionState;
    if TrustResult.accept_candidate
        % 本方法只接受普通候选解，直接复制候选解的解与检查报告；
        % 拒绝或失败时保持 create_empty_trust_result 的空报告
        TrustResult.decision_point = 'candidate';
        TrustResult.accepted_solution = CurrentSolution;
        TrustResult.accepted_convergence_report = ...
            SubproblemDiag.convergence_report;
        TrustResult.accepted_p2_feasibility = SubproblemDiag.p2_feasibility;
    end
end


function check_trust_region_result(TrustResult, SubproblemDiag)
% CHECK_TRUST_REGION_RESULT 检查接受结果与候选解可用性、下一信赖域状态一致。

    if ~TrustResult.candidate_available && TrustResult.accept_candidate
        error('SCP:AcceptedUnavailableCandidate', ...
            '没有候选解时不能接受。');
    end
    if TrustResult.candidate_available ~= SubproblemDiag.success
        error('SCP:InconsistentCandidateAvailability', ...
            '候选解可用性必须与子问题求解成败一致。');
    end
    if isempty(TrustResult.next_state)
        error('SCP:MissingNextTrustRegionState', ...
            '信赖域结果必须包含下一轮信赖域状态。');
    end
end
