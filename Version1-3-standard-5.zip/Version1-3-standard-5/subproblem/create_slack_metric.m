function Metric = create_slack_metric(name, value, tolerance, unit)
% CREATE_SLACK_METRIC 创建一条检查指标（松弛、残差、余项共用）。

    if ~isscalar(tolerance) || ~isreal(tolerance) ...
            || ~isfinite(tolerance) || tolerance < 0
        error('SCP:InvalidMetricTolerance', ...
            '指标容差必须为有限非负实标量。');
    end
    Metric.name = name;
    Metric.value = value;
    Metric.tolerance = tolerance;
    Metric.unit = unit;
    Metric.active = true;
    Metric.evaluated = true;
    Metric.reason = '';

    if tolerance > 0
        Metric.ratio = value / tolerance;
    elseif value == 0
        Metric.ratio = 0;
    else
        Metric.ratio = Inf;
    end
    Metric.satisfied = isfinite(value) && value <= tolerance;
end
