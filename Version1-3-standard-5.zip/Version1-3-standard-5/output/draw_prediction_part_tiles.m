function draw_prediction_part_tiles(fig, HistorySeries, config)
% DRAW_PREDICTION_PART_TILES 画预测下降与预测误差的三部分: 性能指标、附加项、罚项各一块，再加罚项一块。
%
% 输入:
%   fig            - 目标图窗
%   HistorySeries  - plot_scp_result 整理好的迭代序列，各轮 plot_data 含 trust_region
%   config         - 读取 config.plot.font_size
%
% 四个分块（横轴为迭代序号，对数纵轴，负值按绝对值画并用向下三角标出）:
%   1. 性能指标部分: 这一部分的 ΔL、D、ΔJ。
%   2. 附加项部分: 这一部分的 ΔL、D、ΔJ。附加项（控制正则 −w_reg·Σω‖u‖）的 D 不大于 0，
%      只在控制方向变化时不为零；没有非零有限值时不画这条线，在标题下面写一句。
%   3. 罚项部分: 这一部分的 ΔL、D、ΔJ。
%   4. 罚项: 参考处的罚项、候选解处的罚项、松弛罚项（罚项部分的 ΔL = 参考处 − 松弛罚项，
%      ΔJ = 参考处 − 候选解处）。
% 每块只放一个部分，块里的曲线名就是 ΔL、D、ΔJ，与总量窗同名同色同标记，哪一部分看
% 纵轴标签。整扇窗只在底部放一个共用图例；不在图上加文字标注。

    iters = HistorySeries.iter;
    status = HistorySeries.status;
    TrustData = collect_trust_series(HistorySeries);
    pick = @(field) [TrustData.(field)];
    Palette = build_analysis_palette();
    series = @(name, field, key) build_log_series(name, pick(field), ...
        Palette.(key), false, Palette.marker.(key), Palette.width.normal);

    layout = create_tile_layout(fig, 4);
    tile_axes = gobjects(1, 4);
    for j = 1:4
        tile_axes(j) = nexttile(layout);
    end
    notes = {describe_status_marks(status)};

    notes = [notes, draw_log_history_tile(tile_axes(1), iters, status, ...
        [series('ΔL', 'cost_predicted', 'predicted_reduction'), ...
        series('D', 'cost_error', 'prediction_error'), ...
        series('ΔJ', 'cost_actual', 'actual_reduction')], ...
        '性能指标部分', config)];

    % 附加项的 D 只在控制方向变化时不为零，没有非零有限值时不画这条线
    extra_list = series('ΔL', 'extra_predicted', 'predicted_reduction');
    extra_error = pick('extra_error');
    if any(isfinite(extra_error) & extra_error ~= 0)
        extra_list = [extra_list, series('D', 'extra_error', 'prediction_error')];
    else
        notes{end + 1} = '附加项部分的 D 为 0，未画';
    end
    extra_list = [extra_list, series('ΔJ', 'extra_actual', 'actual_reduction')];
    notes = [notes, draw_log_history_tile(tile_axes(2), iters, status, ...
        extra_list, '附加项部分', config)];

    notes = [notes, draw_log_history_tile(tile_axes(3), iters, status, ...
        [series('ΔL', 'penalty_predicted', 'predicted_reduction'), ...
        series('D', 'penalty_error', 'prediction_error'), ...
        series('ΔJ', 'penalty_actual', 'actual_reduction')], ...
        '罚项部分', config)];

    notes = [notes, draw_log_history_tile(tile_axes(4), iters, status, ...
        [series('参考处的罚项', 'reference_penalty', 'reference_penalty'), ...
        series('候选解处的罚项', 'candidate_penalty', 'candidate_penalty'), ...
        series('松弛罚项', 'slack_penalty', 'slack_penalty')], ...
        '罚项', config)];

    finish_tile_window(layout, tile_axes, '预测下降与预测误差: 分三部分', ...
        notes, config);
end
