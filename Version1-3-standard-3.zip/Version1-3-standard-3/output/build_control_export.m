function ControlExport = build_control_export(FinalizedRun, ConstData, config)
% BUILD_CONTROL_EXPORT 把每次尝试的控制量报告整理成 ControlExport（只读历史，不重新求值）。
%
% 输出 ControlExport:
%   version_root       - 版本根目录名
%   w_reg              - 控制正则项系数 config.objective.weight_control_reg
%   reg_type           - 控制正则方式 config.objective.control_reg_type（sum、u1、u2、norm、none）
%   use_integration_weights - 控制正则项是否逐节点乘积分权 ω_i
%   weight_method      - 梯形积分权的计算方式说明（由权的数值判断：有负权为全局 τ）
%   t_f_unit           - 各圈 t_f 的单位说明
%   final_iter         - 最后被接受的轮号，没有接受解时为 NaN
%   attempts           - K x 1 结构体数组，每次尝试一个，字段:
%       iter                轮号
%       candidate_available P3 是否给出候选解
%       accepted            候选解是否被接受
%       radius_scale        本轮求解所用的半径 r（基准半径的倍数）
%       t_f                 候选解各圈 t_f（归一化时间 TU，无候选解时为空）
%       t_f_s               候选解各圈 t_f（s）
%       control_report      该次尝试的 SubproblemDiag.control_report

    History = FinalizedRun.history;
    attempt_list = cell(numel(History), 1);
    for k = 1:numel(History)
        Record = History(k);
        candidate_available = logical(Record.trust.candidate_available);
        if candidate_available && ~isempty(Record.solution)
            t_f = Record.solution.t_f(:);
        else
            t_f = [];
        end
        attempt_list{k} = struct( ...
            'iter', Record.iter, ...
            'candidate_available', candidate_available, ...
            'accepted', candidate_available && logical(Record.trust.accept_candidate), ...
            'radius_scale', Record.trust.trust_region_update.scale_before, ...
            't_f', t_f, ...
            't_f_s', t_f * ConstData.TU, ...
            'control_report', Record.subproblem.control_report);
    end
    if isempty(attempt_list)
        Attempts = struct('iter', {}, 'candidate_available', {}, ...
            'accepted', {}, 'radius_scale', {}, 't_f', {}, 't_f_s', {}, ...
            'control_report', {});
    else
        Attempts = vertcat(attempt_list{:});
    end

    version_root = fileparts(fileparts(mfilename('fullpath')));
    [~, version_name] = fileparts(version_root);
    ControlExport.version_root = version_name;
    ControlExport.w_reg = config.objective.weight_control_reg;
    ControlExport.reg_type = describe_control_regularizer(config).type;
    ControlExport.use_integration_weights = ...
        describe_control_regularizer(config).use_integration_weights;
    ControlExport.weight_method = describe_weight_method(Attempts);
    ControlExport.t_f_unit = '归一化时间 TU 与秒 (s)，各圈一个分量';
    accepted_index = find([Attempts.accepted], 1, 'last');
    if isempty(accepted_index)
        ControlExport.final_iter = NaN;
    else
        ControlExport.final_iter = Attempts(accepted_index).iter;
    end
    ControlExport.attempts = Attempts;
end


function text = describe_weight_method(Attempts)
% DESCRIBE_WEIGHT_METHOD 由权的数值判断梯形积分权的计算方式：存在负权说明圈间拼接节点按全局 τ 计算。

    evaluated = arrayfun(@(Attempt) Attempt.control_report.evaluated, Attempts);
    if ~any(evaluated)
        text = '未知（没有成功求解的尝试）';
        return;
    end
    omega = Attempts(find(evaluated, 1, 'last')).control_report.omega;
    if any(omega < 0)
        text = sprintf('全局 τ（圈间拼接节点为负权，共 %d 个，最小 %.3f）', ...
            sum(omega < 0), min(omega));
    else
        text = '按圈（各权非负）';
    end
end
