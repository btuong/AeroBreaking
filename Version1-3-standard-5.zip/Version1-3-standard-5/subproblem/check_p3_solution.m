function P3Check = check_p3_solution( ...
        SolverResult, LinearConstraints, VariableBounds, ...
        ConicConstraints, CurrentSolution, CurrentReference, config)
% CHECK_P3_SOLUTION 做 P3 解检查：P3 的解自身对不对，看原始矩阵残差、松弛、锥紧性和乘子。
%
% 本函数依次完成：
%   1. 把返回解代回原始矩阵，检查约束残差与解的量级。
%   2. 检查各类松弛是否降到容差以内。
%   3. 检查二阶锥可行性、上图紧性和无损凸化紧性。
%   4. 读 P3 的对偶解，报告各类约束乘子和信赖域乘子（不入成功判定）。
%   5. 汇总 P3 解检查报告。
%
% 各项只报告，不作接受门槛，不参与停止。本函数只用 P3 自己的量（返回解、装配矩阵、
% 锥和对偶解），不调用原非线性函数，也不做积分；凡是要用原函数或积分对照的量
% （违反量、终端映射的余项）都在 P2 可行性检查里，见 validation/check_p2_feasibility。
% 入轨等式是 P3 的一行线性等式，它的残差已含在第 1 步的原始矩阵残差里（insertion 块）。

    %% 1. 把返回解代回原始矩阵，检查约束残差与解的量级
    SolverFeasibilityReport = evaluate_solver_feasibility( ...
        SolverResult, LinearConstraints, VariableBounds, config);

    %% 2. 检查各类松弛是否降到容差以内
    SlackReport = evaluate_slack_feasibility( ...
        CurrentSolution, CurrentReference, config);

    %% 3. 检查二阶锥可行性、上图紧性和无损凸化紧性
    ReformulationReport = evaluate_conic_reformulation_consistency( ...
        SolverResult, ConicConstraints, config);

    %% 4. 读 P3 的对偶解，报告各类约束乘子和信赖域乘子（不入成功判定）
    MultiplierReport = evaluate_p3_multipliers( ...
        SolverResult, LinearConstraints, VariableBounds, ...
        CurrentReference, config);

    %% 5. 汇总 P3 解检查报告
    P3Check.solver_feasibility_report = SolverFeasibilityReport;
    P3Check.slack_report = SlackReport;
    P3Check.reformulation_report = ReformulationReport;
    P3Check.multiplier_report = MultiplierReport;
    P3Check.success = SolverFeasibilityReport.success ...
        && SlackReport.success && ReformulationReport.success;
end
