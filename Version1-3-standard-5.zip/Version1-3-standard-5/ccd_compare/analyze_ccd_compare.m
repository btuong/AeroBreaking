function [Summary, Groups, Check] = analyze_ccd_compare( ...
        results_root, pictures_root, delta, window)
% ANALYZE_CCD_COMPARE 汇总 CCD 对比实验：读各工况结果，算指标，写汇总文件，画图。
%
% 只读各工况目录里的 case_metrics.mat 和 scp_run_control.mat，以及阶段3-1 的两份存档
% （none、norm_w1e-4）做回归核对，不重跑 SCP，可单独运行。缺失或失败的工况在表里记为 '-'，
% 不影响其余工况。
%
% 汇总文本分九节（见 ccd_compare/README.md 任务 9 步骤 2）:
%   1 运行清单；2 回归核对；3 自检；4 末轮表；5 圆约束组的逐项账；6 下降比；
%   7 乘子；8 σ 偏差；9 逐轮序列。
% 差值 d_c,k = C_c,k − C_none,k（C 为各轮总脉冲，m/s）；稳定 ⇔ 最后 window 轮的极差 ≤ delta，
% 稳定轮 = 最早的 k，使所有 j ≥ k 有 |d_j − d_末轮| ≤ delta（与阶段3-1 同一定义）。
% 节点量取末轮（各工况最后被接受的一轮）。节点分组以 none 工况末轮的 q_i = ‖s_main,i‖/ω_i
% 为准：q_i < 1e-6 为退化节点 D，其余为 E，所有工况共用。
%
% 输入（均可省略）:
%   results_root  - 各工况结果所在目录，默认 <本文件夹>/results
%   pictures_root - 图的输出目录，默认 <本文件夹>/pictures
%   delta         - 差值稳定的阈值 δ (m/s)，默认 0.1
%   window        - 差值稳定看最后几轮，默认 5
%
% 输出:
%   Summary - 1 x n 结构体数组，每工况一项，字段是汇总表里的全部数值
%   Groups  - 节点分组（D/E）
%   Check   - 回归核对与自检的数值
%   同时写 results/对比汇总.txt、results/对比汇总.mat 和 pictures/ 下的 PNG。
%
% 本函数依次完成：
%   1. 补路径并确定目录和参数。
%   2. 读取各工况的结果和阶段3-1 的两份存档。
%   3. 按 none 工况确定节点分组。
%   4. 逐工况算指标。
%   5. 算相对 none 与相对 normgap_w1e-4 的差值及稳定性。
%   6. 回归核对、自检，并按判据定默认 p 的档位。
%   7. 写汇总文本和 MAT。
%   8. 画图。

    %% 1. 补路径并确定目录和参数
    compare_root = fileparts(mfilename('fullpath'));
    version_root = fileparts(compare_root);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));
    addpath(fullfile(version_root, 'subproblem'), fullfile(version_root, 'output'), ...
        compare_root);
    if nargin < 1 || isempty(results_root)
        results_root = fullfile(compare_root, 'results');
    end
    if nargin < 2 || isempty(pictures_root)
        pictures_root = fullfile(compare_root, 'pictures');
    end
    if nargin < 3 || isempty(delta)
        delta = 0.1;
    end
    if nargin < 4 || isempty(window)
        window = 5;
    end
    Options = struct('delta', delta, 'window', window, ...
        'reference_ccd', 'normgap_w1e-4', ...
        'stage3_root', fullfile(fileparts(version_root), ...
        'Version1-3-standard-3', 'regularizer_converge', 'results'), ...
        'default_ccd', '');

    %% 2. 读取各工况的结果
    CaseData = load_case_data(list_compare_cases(), results_root);

    %% 3. 按 none 工况确定节点分组
    Groups = determine_node_groups(CaseData);

    %% 4. 逐工况算指标
    Summary = compute_all_indicators(CaseData, Groups, Options);

    %% 5. 算相对 none 与相对 normgap_w1e-4 的差值及稳定性
    Summary = add_difference_indicators(Summary, Groups, Options);

    %% 6. 回归核对、自检，并按判据定默认 p 的档位
    Check = check_run(Summary, CaseData, Options);
    Options.default_ccd = Check.default_ccd;

    %% 7. 写汇总文本和 MAT
    write_compare_text(fullfile(results_root, '对比汇总.txt'), Summary, Groups, ...
        Check, Options);
    save(fullfile(results_root, '对比汇总.mat'), 'Summary', 'Groups', 'Check', 'Options');

    %% 8. 画图
    plot_compare_figures(Summary, Groups, Options, pictures_root);
end


%% ===== 读取结果 =====

function CaseData = load_case_data(Cases, results_root)
% LOAD_CASE_DATA 读各工况的 case_metrics.mat 与 scp_run_control.mat，核对版本和模式。
%
% 每个工况一项，字段: name、type、w、p、keep（工况属性）、state（'ok'、'no_solution'、
% 'failed'、'missing'）、Metrics、attempts（P3 求解成功的各次尝试，含 control_report）、
% error_message。

    data_list = cell(1, numel(Cases));
    for c = 1:numel(Cases)
        Case = Cases(c);
        Data = struct('name', Case.name, 'type', Case.type, 'w', Case.w, ...
            'p', Case.p, 'keep', logical(Case.keep_control_bounds), ...
            'state', 'missing', 'Metrics', [], 'attempts', [], 'error_message', '');
        case_directory = fullfile(results_root, Case.name);
        metrics_path = fullfile(case_directory, 'case_metrics.mat');
        control_path = fullfile(case_directory, 'scp_run_control.mat');
        error_path = fullfile(case_directory, 'case_error.txt');
        if isfile(metrics_path) && isfile(control_path)
            Loaded = load(metrics_path);
            Control = load(control_path);
            % 核对存档：版本目录和单位范数模式必须与工况一致，避免跨版本误读
            if ~strcmp(Control.ControlExport.version_root, 'Version1-3-standard-5')
                error('CCDCompare:ArchiveMismatch', ...
                    '工况 %s 的存档版本与预期不符（%s）。', Case.name, ...
                    Control.ControlExport.version_root);
            end
            expected_mode = 'regularized';
            if strcmp(Case.type, 'ccd')
                expected_mode = 'ccd';
            end
            if ~strcmp(Control.ControlExport.unit_norm_mode, expected_mode)
                error('CCDCompare:ArchiveMismatch', ...
                    '工况 %s 的存档单位范数模式与预期不符（%s）。', Case.name, ...
                    Control.ControlExport.unit_norm_mode);
            end
            Data.Metrics = Loaded.Metrics;
            attempts = Control.ControlExport.attempts;
            if isempty(attempts)
                solved = false(0, 1);
            else
                solved = arrayfun(@(a) logical(a.control_report.evaluated), attempts);
            end
            Data.attempts = attempts(solved);
            if Loaded.Metrics.num_accepted > 0
                Data.state = 'ok';
            else
                Data.state = 'no_solution';
            end
        elseif isfile(error_path)
            Data.state = 'failed';
            Data.error_message = strtrim(fileread(error_path));
        end
        data_list{c} = Data;
    end
    CaseData = [data_list{:}];
end


function Groups = determine_node_groups(CaseData)
% DETERMINE_NODE_GROUPS 以 none 工况末轮的 q_i = ‖s_main,i‖/ω_i 划分退化节点 D 与其余节点 E。

    Groups = struct('available', false, 'N', NaN, 'tau', [], 'cir', [], 'q', [], ...
        'D', [], 'E', [], 'num_D', NaN, 'num_E', NaN, 'threshold', 1e-6);
    none_index = find(strcmp({CaseData.name}, 'none') ...
        & strcmp({CaseData.state}, 'ok'), 1);
    if isempty(none_index)
        return;
    end
    Report = pick_final_report(CaseData(none_index));
    Groups.N = Report.num_nodes;
    Groups.tau = Report.tau;
    Groups.cir = Report.cir;
    if ~Report.dual_available
        Groups.D = false(Groups.N, 1);
        Groups.E = true(Groups.N, 1);
        Groups.num_D = 0;
        Groups.num_E = Groups.N;
        return;
    end
    Groups.available = true;
    Groups.q = Report.s_main_norm ./ Report.omega;
    Groups.D = Groups.q < Groups.threshold;
    Groups.E = ~Groups.D;
    Groups.num_D = sum(Groups.D);
    Groups.num_E = sum(Groups.E);
end


function Report = pick_final_report(Data)
% PICK_FINAL_REPORT 取一个工况最后被接受那次尝试的控制量报告。

    accepted = [Data.attempts.accepted];
    Report = Data.attempts(find(accepted, 1, 'last')).control_report;
end


%% ===== 逐工况指标 =====

function Summary = compute_all_indicators(CaseData, Groups, Options)
% COMPUTE_ALL_INDICATORS 逐工况算末轮表、逐项账、下降比和乘子的指标。
%
% 末轮 = 最后被接受的一轮。末 5 轮 / 末 10 轮按轮号区间取（与阶段3-1 相同，含区间内的
% 被拒绝轮，数值为 NaN 时用 omitnan 跳过）。逐轮序列按尝试轮号放进 max_rounds x 1 的列。

    max_rounds = max(arrayfun(@count_attempted, CaseData));
    if isempty(max_rounds) || max_rounds < 1
        max_rounds = 1;
    end
    none_index = find(strcmp({CaseData.name}, 'none') ...
        & strcmp({CaseData.state}, 'ok'), 1);
    none_sigma = [];
    if ~isempty(none_index)
        none_sigma = pick_final_report(CaseData(none_index)).sigma_deg;
    end
    summary_list = cell(1, numel(CaseData));
    for c = 1:numel(CaseData)
        summary_list{c} = compute_case_indicators(CaseData(c), Groups, ...
            none_sigma, max_rounds, Options);
    end
    Summary = [summary_list{:}];
end


function count = count_attempted(Data)
% COUNT_ATTEMPTED 一个工况的尝试轮数；没有结果文件时为 0。

    if isempty(Data.Metrics) || ~isfield(Data.Metrics, 'num_attempted')
        count = 0;
    else
        count = Data.Metrics.num_attempted;
    end
end


function Indicator = compute_case_indicators(Data, Groups, none_sigma, ...
        max_rounds, Options)
% COMPUTE_CASE_INDICATORS 算一个工况的末轮量、逐项账、下降比、乘子与 σ 偏差。

    Indicator = create_empty_indicator(Data, max_rounds);
    if ~strcmp(Data.state, 'ok')
        return;
    end
    Attempts = Data.attempts;
    Metrics = Data.Metrics;
    iters = [Attempts.iter];
    final_position = find([Attempts.accepted], 1, 'last');
    Report = Attempts(final_position).control_report;
    E = Groups.E;
    D = Groups.D;
    final_iter = Attempts(final_position).iter;
    window = Options.window;

    %% 运行清单与逐轮序列
    Indicator.num_attempted = Metrics.num_attempted;
    Indicator.num_accepted = Metrics.num_accepted;
    Indicator.final_iter = final_iter;
    Indicator.stop_reason = Metrics.stop_reason;
    Indicator.plateau_start = Metrics.plateau_start_iter;
    Indicator.elapsed_seconds = Metrics.elapsed_seconds;
    Indicator.mean_round_seconds = mean(Metrics.iter_seconds, 'omitnan');
    Indicator.impulse_series = place_series(Metrics.total_impulse_m_s, ...
        (1:numel(Metrics.accepted))', max_rounds);
    Indicator.gap_series = place_series(Metrics.max_tight_gap, ...
        (1:numel(Metrics.accepted))', max_rounds);
    Indicator.eps_series = place_series(Metrics.max_eps, ...
        (1:numel(Metrics.accepted))', max_rounds);
    Indicator.rho_series = place_series(Metrics.rho, ...
        (1:numel(Metrics.accepted))', max_rounds);

    %% 末轮表：总脉冲段
    series = Indicator.impulse_series;
    range_index = max(1, final_iter - window + 1):final_iter;
    Indicator.impulse_final = series(final_iter);
    Indicator.impulse_mean_last = mean(series(range_index), 'omitnan');
    Indicator.impulse_range_last = max(series(range_index), [], 'omitnan') ...
        - min(series(range_index), [], 'omitnan');
    if final_iter > 10
        Indicator.impulse_decrease_last10 = ...
            (series(final_iter - 10) - series(final_iter)) / 10;
    end

    %% 末轮表：单位范数紧性与触界
    Indicator.gap_final = Metrics.max_tight_gap(final_iter);
    Indicator.gap_max_all = max(Metrics.max_tight_gap, [], 'omitnan');
    Indicator.inward_final = Metrics.max_inward_gap(final_iter);
    Indicator.outward_final = Metrics.max_outward_gap(final_iter);
    Indicator.num_untight_final = Metrics.num_untight(final_iter);
    Indicator.num_capped_max = max(Metrics.num_slack_capped, [], 'omitnan');
    if isnan(Indicator.num_capped_max)
        Indicator.num_capped_max = 0;
    end
    % 边界乘子生效的节点数按 ‖s_bound,i‖ > 1e-6 算：内点法在不生效的边界上留有 1e-11 量级的残值，
    % 阈值取 1e-12 时会把全部节点都算进去；对偶不可用时为 NaN
    Indicator.num_bound_active_final = NaN;
    if Report.dual_available
        Indicator.num_bound_active_final = sum(vecnorm(Report.s_bound, 2, 2) > 1e-6);
    end
    % 触箱形边界的节点数（原始量）：|u1| 或 |u2| 到达该模式的箱形边界（容差 1e-6）
    if strcmp(Data.type, 'ccd') && ~Data.keep
        u_bound = 2;   % ±(1 + ε_max)，ε_max = 1
    else
        u_bound = 1;
    end
    at_bound = max(abs(Report.u1), abs(Report.u2)) >= u_bound - 1e-6;
    Indicator.num_box_touch_final = sum(at_bound);

    %% 圆约束组的逐项账（ΔL、ΔJ、D 的末轮值；全程 max|D|）
    Indicator.circle_predicted_final = Metrics.circle_predicted(final_iter);
    Indicator.circle_actual_final = Metrics.circle_actual(final_iter);
    Indicator.circle_error_final = Metrics.circle_error(final_iter);
    Indicator.circle_error_absmax = max(abs(Metrics.circle_error), [], 'omitnan');

    %% 下降比：末 5 轮 ρ、ΔL、ΔJ 的均值（ΔJ = ρ·ΔL）
    delta_L_series = Metrics.delta_L;
    rho_series = Metrics.rho;
    delta_J_series = rho_series .* delta_L_series;
    Indicator.rho_mean_last = mean(rho_series(range_index), 'omitnan');
    Indicator.delta_L_mean_last = mean(delta_L_series(range_index), 'omitnan');
    Indicator.delta_J_mean_last = mean(delta_J_series(range_index), 'omitnan');

    %% 乘子（末轮，E 上）：κ̂/ω 与 ‖s_main‖/ω 的统计；ccd 另给 λ_inner/ω 与 κ̂/(p·ω)
    omega = Report.omega;
    kappa_over_omega = Report.cone_dual_leading ./ omega;
    smain_over_omega = Report.s_main_norm ./ omega;
    Indicator.kappa_stats = describe_values(kappa_over_omega(E));
    Indicator.smain_stats = describe_values(smain_over_omega(E));
    % 图用的原始分布（E 上）
    Indicator.kappa_E = kappa_over_omega(E);
    Indicator.smain_E = smain_over_omega(E);
    if strcmp(Data.type, 'ccd')
        Indicator.lambda_inner_stats = describe_values( ...
            Report.lambda_inner(E) ./ omega(E));
        Indicator.kappa_over_pw_stats = describe_values( ...
            kappa_over_omega(E) / Data.p);
        Indicator.min_kappa_over_pw = min(kappa_over_omega(E) / Data.p);
    end

    %% σ 偏差（末轮）
    Indicator.final_sigma = Report.sigma_deg;
    if ~isempty(none_sigma)
        deviation = abs(wrap_angle_deg(Indicator.final_sigma - none_sigma));
        Indicator.sigma_dev_E_median = median(deviation(E));
        Indicator.sigma_dev_D_median = median(deviation(D));
    end

    %% 自检用的逐轮原始量（存最近的一份逐尝试记录）
    Indicator.min_u_norm_all = min(arrayfun( ...
        @(a) min(a.control_report.u_norm), Attempts));
    Indicator.stationarity_max = max(arrayfun( ...
        @(a) max(abs(a.control_report.stationarity_residual), [], 'all'), ...
        Attempts));
    Indicator.final_report_ok = Report.evaluated;
end


function Stats = describe_values(values)
% DESCRIBE_VALUES 一组数的中位数、5%、95% 分位、最小值、最大值（线性插值分位数）。

    values = values(~isnan(values(:)));
    Stats = struct('median', NaN, 'p5', NaN, 'p95', NaN, ...
        'min', NaN, 'max', NaN);
    if isempty(values)
        return;
    end
    Stats.median = median(values);
    quantiles = compute_percentile_set(values, [5, 95]);
    Stats.p5 = quantiles(1);
    Stats.p95 = quantiles(2);
    Stats.min = min(values);
    Stats.max = max(values);
end


function Indicator = create_empty_indicator(Data, max_rounds)
% CREATE_EMPTY_INDICATOR 创建字段齐全的空指标（工况不可用时数值为 NaN）。

    Indicator = struct();
    Indicator.name = Data.name;
    Indicator.type = Data.type;
    Indicator.mode = 'regularized';
    if strcmp(Data.type, 'ccd')
        Indicator.mode = 'ccd';
    end
    Indicator.w = Data.w;
    Indicator.p = Data.p;
    Indicator.keep = Data.keep;
    Indicator.state = Data.state;
    Indicator.error_message = Data.error_message;
    Indicator.num_attempted = NaN;
    Indicator.num_accepted = NaN;
    Indicator.final_iter = NaN;
    Indicator.stop_reason = char_or_dash('');
    Indicator.plateau_start = NaN;
    Indicator.elapsed_seconds = NaN;
    Indicator.mean_round_seconds = NaN;
    Indicator.impulse_series = nan(max_rounds, 1);
    Indicator.gap_series = nan(max_rounds, 1);
    Indicator.eps_series = nan(max_rounds, 1);
    Indicator.rho_series = nan(max_rounds, 1);
    Indicator.impulse_final = NaN;
    Indicator.impulse_mean_last = NaN;
    Indicator.impulse_range_last = NaN;
    Indicator.impulse_decrease_last10 = NaN;
    Indicator.gap_final = NaN;
    Indicator.gap_max_all = NaN;
    Indicator.inward_final = NaN;
    Indicator.outward_final = NaN;
    Indicator.num_untight_final = NaN;
    Indicator.num_capped_max = NaN;
    Indicator.num_bound_active_final = NaN;
    Indicator.num_box_touch_final = NaN;
    Indicator.circle_predicted_final = NaN;
    Indicator.circle_actual_final = NaN;
    Indicator.circle_error_final = NaN;
    Indicator.circle_error_absmax = NaN;
    Indicator.rho_mean_last = NaN;
    Indicator.delta_L_mean_last = NaN;
    Indicator.delta_J_mean_last = NaN;
    Indicator.kappa_stats = struct('median', NaN, 'p5', NaN, 'p95', NaN, ...
        'min', NaN, 'max', NaN);
    Indicator.smain_stats = Indicator.kappa_stats;
    Indicator.lambda_inner_stats = Indicator.kappa_stats;
    Indicator.kappa_over_pw_stats = Indicator.kappa_stats;
    Indicator.min_kappa_over_pw = NaN;
    Indicator.final_sigma = [];
    Indicator.sigma_dev_E_median = NaN;
    Indicator.sigma_dev_D_median = NaN;
    Indicator.sigma_ref_E_median = NaN;
    Indicator.impulse_diff_ref = NaN;
    Indicator.d_ref_final = NaN;
    Indicator.d_series = nan(max_rounds, 1);
    Indicator.d_final = NaN;
    Indicator.d_mean_last = NaN;
    Indicator.d_range_last = NaN;
    Indicator.d_stable = NaN;
    Indicator.d_stable_round = NaN;
    Indicator.min_u_norm_all = NaN;
    Indicator.stationarity_max = NaN;
    Indicator.final_report_ok = false;
end


function series = place_series(values, iters, max_rounds)
% PLACE_SERIES 把按尝试序号排列的逐轮值放进 max_rounds x 1 的列，缺的轮为 NaN。

    series = nan(max_rounds, 1);
    series(iters) = values(:);
end


function values_out = compute_percentile_set(values, percents)
% COMPUTE_PERCENTILE_SET 对一组分位点（0～100）取线性插值分位数；空输入返回 NaN。

    values = sort(values(~isnan(values(:))));
    count = numel(values);
    values_out = nan(size(percents));
    if count == 0
        return;
    end
    for k = 1:numel(percents)
        position = 1 + (count - 1) * percents(k) / 100;
        lower_index = floor(position);
        upper_index = ceil(position);
        values_out(k) = values(lower_index) ...
            + (position - lower_index) * (values(upper_index) - values(lower_index));
    end
end


%% ===== 差值与稳定性 =====

function Summary = add_difference_indicators(Summary, Groups, Options)
% ADD_DIFFERENCE_INDICATORS 补相对 none 的差值 d、相对 normgap_w1e-4 的差值及稳定性。

    % 逐项改字段时先放进元胞，全部改完再拼回结构体数组（结构体数组要求各项字段相同）
    ItemList = arrayfun(@(S) S, Summary, 'UniformOutput', false);
    names = {Summary.name};
    none_index = find(strcmp(names, 'none') & strcmp({Summary.state}, 'ok'), 1);
    reference_index = find(strcmp(names, Options.reference_ccd) ...
        & strcmp({Summary.state}, 'ok'), 1);
    for c = 1:numel(ItemList)
        if ~strcmp(Summary(c).state, 'ok')
            continue;
        end
        S = Summary(c);
        series = S.impulse_series;
        if ~isempty(none_index)
            S = fill_difference(S, series - Summary(none_index).impulse_series, ...
                '', Options);
        end
        % ccd 各档相对 normgap_w1e-4 的差值（只记末轮值，供 σ 偏差一节配对）
        if strcmp(S.type, 'ccd') && ~isempty(reference_index)
            difference = series - Summary(reference_index).impulse_series;
            S.d_ref_final = difference(S.final_iter);
        end
        ItemList{c} = S;
    end
    Summary = [ItemList{:}];

    % σ 偏差：ccd 各档相对 normgap_w1e-4 的 |Δσ| 中位数（E 上）
    if ~isempty(reference_index) && Groups.available
        reference_sigma = Summary(reference_index).final_sigma;
        for c = 1:numel(Summary)
            if ~strcmp(Summary(c).type, 'ccd') ...
                    || ~strcmp(Summary(c).state, 'ok')
                continue;
            end
            deviation = abs(wrap_angle_deg( ...
                Summary(c).final_sigma - reference_sigma));
            Summary(c).sigma_ref_E_median = median(deviation(Groups.E));
        end
    end
end


function S = fill_difference(S, difference, tag, Options)
% FILL_DIFFERENCE 由差值序列写入末轮值、最后几轮均值与极差、是否稳定和稳定轮。

    final_iter = S.final_iter;
    range_index = max(1, final_iter - Options.window + 1):final_iter;
    last_values = difference(range_index);
    S.(['d' tag '_series']) = difference;
    S.(['d' tag '_final']) = difference(final_iter);
    S.(['d' tag '_mean_last']) = mean(last_values, 'omitnan');
    S.(['d' tag '_range_last']) = max(last_values, [], 'omitnan') ...
        - min(last_values, [], 'omitnan');
    S.(['d' tag '_stable']) = double(S.(['d' tag '_range_last']) <= Options.delta);
    within = abs(difference(1:final_iter) - difference(final_iter)) ...
        <= Options.delta;
    last_outside = find(~within & ~isnan(difference(1:final_iter)), 1, 'last');
    if isempty(last_outside)
        S.(['d' tag '_stable_round']) = 1;
    else
        S.(['d' tag '_stable_round']) = last_outside + 1;
    end
end


%% ===== 回归核对与自检 =====

function Check = check_run(Summary, CaseData, Options)
% CHECK_RUN 回归核对（none、norm_w1e-4 相对阶段3-1 存档）和 ccd 自检，返回数值。

    Check = struct();
    %% 回归核对
    % 每行: 工况名、写进 Check 的字段后缀
    regression_cases = {'none', 'none'; 'norm_w1e-4', 'norm'};
    for k = 1:size(regression_cases, 1)
        name = regression_cases{k, 1};
        field = ['regression_' strrep(regression_cases{k, 2}, '-', '_')];
        archive_path = fullfile(Options.stage3_root, name, 'case_metrics.mat');
        index = find(strcmp({Summary.name}, name), 1);
        Check.(field) = struct('max_diff', NaN, 'num_this', NaN, ...
            'num_archive', NaN, 'final_archive', NaN, 'archive_found', false);
        if ~isfile(archive_path) || isempty(index) ...
                || ~strcmp(Summary(index).state, 'ok')
            continue;
        end
        Archive = load(archive_path);
        this_series = Summary(index).impulse_series;
        archive_series = Archive.Metrics.total_impulse_m_s(:);
        count = min(numel(this_series), numel(archive_series));
        Check.(field) = struct('max_diff', ...
            max(abs(this_series(1:count) - archive_series(1:count))), ...
            'num_this', numel(this_series), 'num_archive', numel(archive_series), ...
            'final_archive', archive_series(end), 'archive_found', true);
    end

    %% 自检：全部 ccd 轮的 |circle_error| 最大值、驻点残差最大值、min(u_norm) 的最小值
    is_ccd = strcmp({Summary.type}, 'ccd') & strcmp({Summary.state}, 'ok');
    Ccd = Summary(is_ccd);
    Check.ccd_circle_error_max = max([Ccd.circle_error_absmax]);
    Check.ccd_stationarity_max = max([Ccd.stationarity_max]);
    Check.ccd_min_u_norm = min([Ccd.min_u_norm_all]);
    Check.ccd_num_cases = numel(Ccd);

    %% 默认 p 的判据数据：各 ccd 工况（含保留箱形边界的对照）的触上界最大值与末轮 gap
    Check.ccd_names = {Ccd.name};
    Check.ccd_levels = [Ccd.p];
    Check.ccd_keep = [Ccd.keep];
    Check.ccd_capped_max = [Ccd.num_capped_max];
    Check.ccd_gap_final = [Ccd.gap_final];

    %% 默认 p：不保留箱形边界的各档里 p 最小、且满足判据的一档
    Check.default_ccd = select_default_ccd(Summary);
    Check.default_p = NaN;
    index = find(strcmp({Summary.name}, Check.default_ccd), 1);
    if ~isempty(index)
        Check.default_p = Summary(index).p;
    end
end


function default_ccd = select_default_ccd(Summary)
% SELECT_DEFAULT_CCD 按判据定默认 p 的工况名。
%
% 在不保留箱形边界的 ccd 各档里取 p 最小的一档，要求全程没有节点触上界、末轮 max|1−‖u‖| ≤ 1e-3；
% 没有满足的档时取 p = 1 的一档（即配置里原来的默认值），连它也没有时为空字符串。

    default_ccd = '';
    candidates = find(strcmp({Summary.type}, 'ccd') & ~[Summary.keep] ...
        & strcmp({Summary.state}, 'ok'));
    if isempty(candidates)
        return;
    end
    [~, order] = sort([Summary(candidates).p]);
    candidates = candidates(order);
    for k = 1:numel(candidates)
        S = Summary(candidates(k));
        if S.num_capped_max == 0 && S.gap_final <= 1e-3
            default_ccd = S.name;
            return;
        end
    end
    index = find(abs([Summary(candidates).p] - 1) < 1e-12, 1);
    if ~isempty(index)
        default_ccd = Summary(candidates(index)).name;
    end
end


%% ===== 汇总文本 =====

function write_compare_text(text_path, Summary, Groups, Check, Options)
% WRITE_COMPARE_TEXT 写九节汇总文本。

    file_id = fopen(text_path, 'w', 'n', 'UTF-8');
    cleanup = onCleanup(@() fclose(file_id));
    write_run_list(file_id, Summary);
    write_regression_check(file_id, Check);
    write_self_check(file_id, Check);
    write_final_tables(file_id, Summary);
    write_circle_ledger(file_id, Summary);
    write_ratio_table(file_id, Summary);
    write_multiplier_tables(file_id, Summary);
    write_sigma_deviation_tables(file_id, Summary, Groups);
    write_round_series(file_id, Summary);
    fprintf(file_id, '\n（δ = %g m/s，window = %d；节点分组: none 末轮 |D| = %g，|E| = %g）\n', ...
        Options.delta, Options.window, Groups.num_D, Groups.num_E);
end


function write_run_list(file_id, Summary)
% WRITE_RUN_LIST 第 1 节：运行清单。

    fprintf(file_id, '=== 1 运行清单 ===\n');
    headers = {'工况', '模式', 'w 或 p', '轮数', '接受', '停止原因', '用时 (s)', '末轮总脉冲 (m/s)'};
    rows = cell(numel(Summary), 8);
    for c = 1:numel(Summary)
        S = Summary(c);
        if strcmp(S.type, 'ccd')
            coefficient = sprintf('p=%.0e', S.p);
        elseif isnan(S.w)
            coefficient = '-';
        else
            coefficient = sprintf('w=%.0e', S.w);
        end
        rows(c, :) = {S.name, S.mode, coefficient, ...
            format_value(S.num_attempted, '%d'), format_value(S.num_accepted, '%d'), ...
            char_or_dash(S.stop_reason), format_value(S.elapsed_seconds, '%.1f'), ...
            format_value(S.impulse_final, '%.4f')};
    end
    write_table(file_id, headers, rows);
end


function write_regression_check(file_id, Check)
% WRITE_REGRESSION_CHECK 第 2 节：none、norm_w1e-4 相对阶段3-1 存档的逐轮最大差。

    fprintf(file_id, '\n=== 2 回归核对（相对阶段3-1 存档的逐轮总脉冲差） ===\n');
    items = {{'none', Check.regression_none}, {'norm_w1e-4', Check.regression_norm}};
    headers = {'工况', '本轮数', '存档轮数', '最大差 (m/s)', '存档末轮总脉冲 (m/s)'};
    rows = cell(2, 5);
    for k = 1:2
        Item = items{k}{2};
        if Item.archive_found
            verdict = '';
        else
            verdict = '（存档或本轮缺失）';
        end
        rows(k, :) = {items{k}{1}, format_value(Item.num_this, '%d'), ...
            format_value(Item.num_archive, '%d'), ...
            [format_value(Item.max_diff, '%.3e') verdict], ...
            format_value(Item.final_archive, '%.4f')};
    end
    write_table(file_id, headers, rows);
end


function write_self_check(file_id, Check)
% WRITE_SELF_CHECK 第 3 节：全部 ccd 轮的自检。

    fprintf(file_id, '\n=== 3 自检（全部 ccd 工况、全部轮） ===\n');
    fprintf(file_id, '圆约束组预测误差 max|D| = %.3e\n', Check.ccd_circle_error_max);
    fprintf(file_id, '驻点残差 max = %.3e\n', Check.ccd_stationarity_max);
    fprintf(file_id, 'min(u_norm) 的最小值 = %.12f（1 - 该值 = %.3e）\n', ...
        Check.ccd_min_u_norm, 1 - Check.ccd_min_u_norm);
    fprintf(file_id, 'ccd 工况数 = %d\n', Check.ccd_num_cases);
    fprintf(file_id, '\n默认 p 判据（触上界节点数的全程最大值 / 末轮 max|1-‖u‖|）:\n');
    headers = {'工况', 'p', '保留边界', '全程触上界最大值', '末轮 max|1-‖u‖|'};
    rows = cell(numel(Check.ccd_levels), 5);
    for k = 1:numel(Check.ccd_levels)
        rows(k, :) = {Check.ccd_names{k}, sprintf('%.0e', Check.ccd_levels(k)), ...
            yes_no_text(Check.ccd_keep(k)), ...
            format_value(Check.ccd_capped_max(k), '%d'), ...
            format_value(Check.ccd_gap_final(k), '%.3e')};
    end
    write_table(file_id, headers, rows);
    fprintf(file_id, ['默认 p 的判据：不保留箱形边界的各档里 p 最小、全程不触上界、' ...
        '末轮单位范数紧性差 ≤ 1e-3 的一档；没有满足的档时取 p = 1。\n']);
    if isnan(Check.default_p)
        fprintf(file_id, '默认 p: 没有满足判据的档，也没有 p = 1 的档\n');
    else
        satisfies = Check.ccd_capped_max(strcmp(Check.ccd_names, Check.default_ccd)) == 0 ...
            && Check.ccd_gap_final(strcmp(Check.ccd_names, Check.default_ccd)) <= 1e-3;
        fprintf(file_id, '默认 p: %s（p = %.0e），%s\n', Check.default_ccd, ...
            Check.default_p, yes_no_text(satisfies));
    end
end


function text = yes_no_text(value)
% YES_NO_TEXT 逻辑量写成“是”“否”。

    if value
        text = '是';
    else
        text = '否';
    end
end


function write_final_tables(file_id, Summary)
% WRITE_FINAL_TABLES 第 4 节：末轮表（总脉冲与差值、单位范数紧性与触界两张）。

    fprintf(file_id, '\n=== 4 末轮表 ===\n');
    fprintf(file_id, '(4a) 总脉冲与相对 none 的差值:\n');
    headers = {'工况', '末轮总脉冲', '末5轮均值', '末10轮每轮降幅', '末5轮极差', ...
        'd 末轮', 'd 末5轮极差', '差值稳定轮', '稳定'};
    rows = cell(numel(Summary), 9);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.impulse_final, '%.4f'), ...
            format_value(S.impulse_mean_last, '%.4f'), ...
            format_value(S.impulse_decrease_last10, '%.4f'), ...
            format_value(S.impulse_range_last, '%.4f'), ...
            format_value_plus(S.d_final), format_value_plus(S.d_range_last), ...
            format_value(S.d_stable_round, '%d'), stable_text(S.d_stable)};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(4b) 单位范数紧性与触界:\n');
    headers = {'工况', '末轮 max|1-‖u‖|', '全程 max|1-‖u‖|', '末轮向内', '末轮向外', ...
        '末轮不紧节点', '全程触上界最大值', '末轮触箱形边界', '末轮边界乘子>1e-6'};
    rows = cell(numel(Summary), 9);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.gap_final, '%.3e'), ...
            format_value(S.gap_max_all, '%.3e'), ...
            format_value(S.inward_final, '%.3e'), format_value(S.outward_final, '%.3e'), ...
            format_value(S.num_untight_final, '%d'), ...
            format_value(S.num_capped_max, '%d'), ...
            format_value(S.num_box_touch_final, '%d'), ...
            format_value(S.num_bound_active_final, '%d')};
    end
    write_table(file_id, headers, rows);
end


function write_circle_ledger(file_id, Summary)
% WRITE_CIRCLE_LEDGER 第 5 节：圆约束组的逐项账（末轮值与全程 max|D|）。

    fprintf(file_id, '\n=== 5 圆约束组的逐项账（ΔL、ΔJ、D） ===\n');
    headers = {'工况', 'ΔL 末轮', 'ΔJ 末轮', 'D 末轮', '全程 max|D|'};
    rows = cell(numel(Summary), 5);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value_plus(S.circle_predicted_final), ...
            format_value_plus(S.circle_actual_final), ...
            format_value_plus(S.circle_error_final), ...
            format_value(S.circle_error_absmax, '%.3e')};
    end
    write_table(file_id, headers, rows);
end


function write_ratio_table(file_id, Summary)
% WRITE_RATIO_TABLE 第 6 节：末 5 轮 ρ、ΔL、ΔJ 的均值。

    fprintf(file_id, '\n=== 6 下降比（末 5 轮均值） ===\n');
    headers = {'工况', 'ρ 均值', 'ΔL 均值', 'ΔJ 均值'};
    rows = cell(numel(Summary), 4);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.rho_mean_last, '%.4f'), ...
            format_value_plus(S.delta_L_mean_last), format_value_plus(S.delta_J_mean_last)};
    end
    write_table(file_id, headers, rows);
end


function write_multiplier_tables(file_id, Summary)
% WRITE_MULTIPLIER_TABLES 第 7 节：末轮 E 上的乘子统计。

    fprintf(file_id, '\n=== 7 乘子（末轮，E 上） ===\n');
    fprintf(file_id, '(7a) κ̂/ω 与 ‖s_main‖/ω:\n');
    headers = {'工况', 'κ̂/ω 中位', 'κ̂/ω 5%', 'κ̂/ω 95%', 'κ̂/ω 最小', 'κ̂/ω 最大', ...
        '‖s‖/ω 中位', '‖s‖/ω 5%', '‖s‖/ω 95%', '‖s‖/ω 最小', '‖s‖/ω 最大'};
    rows = cell(numel(Summary), 11);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = [{S.name}, ...
            format_stat(S.kappa_stats), format_stat(S.smain_stats)];
    end
    write_table(file_id, headers, rows);

    is_ccd = strcmp({Summary.type}, 'ccd');
    Ccd = Summary(is_ccd);
    if isempty(Ccd)
        return;
    end
    fprintf(file_id, '\n(7b) ccd 的 λ_inner/ω 与 κ̂/(p·ω):\n');
    headers = {'工况', 'λ/ω 中位', 'λ/ω 5%', 'λ/ω 95%', 'λ/ω 最小', 'λ/ω 最大', ...
        'κ̂/pω 中位', 'κ̂/pω 5%', 'κ̂/pω 95%', 'κ̂/pω 最小', 'κ̂/pω 最大'};
    rows = cell(numel(Ccd), 11);
    for c = 1:numel(Ccd)
        rows(c, :) = [{Ccd(c).name}, ...
            format_stat(Ccd(c).lambda_inner_stats), format_stat(Ccd(c).kappa_over_pw_stats)];
    end
    write_table(file_id, headers, rows);
end


function write_sigma_deviation_tables(file_id, Summary, Groups)
% WRITE_SIGMA_DEVIATION_TABLES 第 8 节：末轮 σ 偏差。

    fprintf(file_id, '\n=== 8 σ 偏差（末轮） ===\n');
    fprintf(file_id, '(8a) 相对 none 的 |Δσ| 中位数 (deg):\n');
    headers = {'工况', 'E 上中位', 'D 上中位'};
    rows = cell(numel(Summary), 3);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.sigma_dev_E_median, '%.3f'), ...
            format_value(S.sigma_dev_D_median, '%.3f')};
    end
    write_table(file_id, headers, rows);

    is_ccd = strcmp({Summary.type}, 'ccd');
    Ccd = Summary(is_ccd);
    if isempty(Ccd)
        return;
    end
    fprintf(file_id, '\n(8b) ccd 各档相对 normgap_w1e-4:\n');
    if Groups.available
        note = '（节点分组可用）';
    else
        note = '（节点分组不可用，σ 偏差按全部节点）';
    end
    headers = {'工况', '|Δσ| E 上中位 (deg)', '末轮总脉冲差 (m/s)'};
    rows = cell(numel(Ccd), 3);
    for c = 1:numel(Ccd)
        rows(c, :) = {Ccd(c).name, ...
            format_value(Ccd(c).sigma_ref_E_median, '%.3f'), ...
            format_value_plus(Ccd(c).d_ref_final)};
    end
    write_table(file_id, headers, rows);
    fprintf(file_id, '%s\n', note);
end


function write_round_series(file_id, Summary)
% WRITE_ROUND_SERIES 第 9 节：逐轮序列（总脉冲、max|1-‖u‖|、max ε），每工况一行。

    fprintf(file_id, '\n=== 9 逐轮序列 ===\n');
    series_specs = { ...
        'impulse_series', '各轮总脉冲 (m/s)', '%.3f'; ...
        'gap_series', '各轮 max|1-‖u‖|', '%.1e'; ...
        'eps_series', '各轮 max ε（ccd）', '%.1e'};
    num_rounds = numel(Summary(1).impulse_series);
    headers = [{'工况'}, arrayfun(@(k) sprintf('轮%d', k), 1:num_rounds, ...
        'UniformOutput', false)];
    for s = 1:size(series_specs, 1)
        fprintf(file_id, '\n%s:\n', series_specs{s, 2});
        rows = cell(numel(Summary), num_rounds + 1);
        for c = 1:numel(Summary)
            values = Summary(c).(series_specs{s, 1});
            rows{c, 1} = Summary(c).name;
            for k = 1:num_rounds
                rows{c, k + 1} = format_value(values(k), series_specs{s, 3});
            end
        end
        write_table(file_id, headers, rows);
    end
end


function text = stable_text(flag)
% STABLE_TEXT 把稳定标志写成文字；NaN 写成 '-'。

    if isnan(flag)
        text = '-';
    elseif flag > 0
        text = '是';
    else
        text = '否';
    end
end


function cells = format_stat(Stats)
% FORMAT_STAT 一组统计量写成五个格子的元胞（%.3e）。

    cells = {format_value(Stats.median, '%.3e'), format_value(Stats.p5, '%.3e'), ...
        format_value(Stats.p95, '%.3e'), format_value(Stats.min, '%.3e'), ...
        format_value(Stats.max, '%.3e')};
end


function text = format_value(value, spec)
% FORMAT_VALUE 按格式写一个数；NaN 写成 '-'，Inf 写成 'Inf'。

    if isnan(value)
        text = '-';
    elseif isinf(value)
        text = 'Inf';
    else
        text = sprintf(spec, value);
    end
end


function text = format_value_plus(value)
% FORMAT_VALUE_PLUS 带符号的科学计数（%.3e），NaN 写成 '-'。

    text = format_value(value, '%+.3e');
end


function text = char_or_dash(value)
% CHAR_OR_DASH 空字符串写成 '-'。

    if isempty(value)
        text = '-';
    else
        text = value;
    end
end


function write_table(file_id, headers, rows)
% WRITE_TABLE 按显示宽度对齐写表：首列左对齐，其余列右对齐，列间两个空格。

    all_rows = [headers; rows];
    num_columns = size(all_rows, 2);
    widths = zeros(1, num_columns);
    for c = 1:num_columns
        widths(c) = max(cellfun(@display_width, all_rows(:, c)));
    end
    for r = 1:size(all_rows, 1)
        parts = cell(1, num_columns);
        for c = 1:num_columns
            padding = blanks(widths(c) - display_width(all_rows{r, c}));
            if c == 1
                parts{c} = [all_rows{r, c}, padding];
            else
                parts{c} = [padding, all_rows{r, c}];
            end
        end
        fprintf(file_id, '%s\n', strjoin(parts, '  '));
    end
end


function width = display_width(text)
% DISPLAY_WIDTH 文字的显示宽度：中文等全角字符占两格，其余占一格。

    width = sum(1 + (double(text) >= 11904));
end


%% ===== 画图 =====

function plot_compare_figures(Summary, Groups, Options, pictures_root)
% PLOT_COMPARE_FIGURES 画六张对比图并导出 PNG。
%
% 每个工况的颜色、标记和线型由 case_style 给出，全部图共用。各轮总脉冲图、差值图和紧性图按三组
% 分块: regularized 各工况、ccd 小 p（≤ 0.1）、ccd 大 p（≥ 1），每块不超过四条线；none 只在
% regularized 分块里画灰色虚线，三个分块共用纵轴范围。norm_w1e-4 与 normgap_w1e-4 的逐轮总脉冲
% 相同，图上只画后者。
%
% 本函数依次完成：
%   1. 各轮总脉冲图、相对 none 的差值随轮次图。
%   2. 末轮差值随 p 和 w 的图、紧性图。
%   3. 末轮乘子分布图、末轮 σ 叠画图。

    if ~isfolder(pictures_root)
        mkdir(pictures_root);
    end
    plot_round_impulse_figure(Summary, pictures_root);
    plot_difference_rounds_figure(Summary, Options, pictures_root);
    plot_final_difference_figure(Summary, Options, pictures_root);
    plot_tightness_figure(Summary, pictures_root);
    plot_multiplier_figure(Summary, pictures_root);
    plot_final_sigma_figure(Summary, Groups, Options, pictures_root);
end


function plot_round_impulse_figure(Summary, pictures_root)
% PLOT_ROUND_IMPULSE_FIGURE 对比-各轮总脉冲：三个分块，各工况总脉冲随轮次，三个分块共用纵轴范围。

    font_size = 16;
    fig = new_figure('对比-各轮总脉冲', [100, 100, 1500, 520]);
    layout = tiledlayout(fig, 1, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
    limits = padded_limits(cellfun(@(S) S.impulse_series, num2cell(Summary), ...
        'UniformOutput', false));
    handles = gobjects(1, 0);
    for g = 1:3
        [group_name, label] = tile_group(g);
        ax = nexttile(layout);
        hold(ax, 'on');
        handles = [handles, draw_cases(ax, Summary, 'impulse_series', ...
            group_members(Summary, group_name, g > 1), g > 1)];
        ylim(ax, limits);
        style_axes(ax, ['总脉冲 (m/s)，' label], '', font_size);
    end
    xlabel(ax, '迭代轮次', 'FontSize', font_size);
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-各轮总脉冲.png'));
end


function plot_difference_rounds_figure(Summary, Options, pictures_root)
% PLOT_DIFFERENCE_ROUNDS_FIGURE 对比-相对none差值：四个分块，各工况相对 none 的同轮总脉冲差 d 随轮次，
% 画 0 线和 ±δ 两条虚线。
%
% 前两块都是 regularized 各工况：第一块纵轴放大，看得清 ±δ 带；第二块与后两块（ccd 小 p、ccd 大 p）
% 共用纵轴范围。

    font_size = 16;
    fig = new_figure('对比-相对none差值', [100, 100, 1900, 520]);
    layout = tiledlayout(fig, 1, 4, 'TileSpacing', 'compact', 'Padding', 'compact');
    regularized = group_members(Summary, 'regularized', true);
    zoom_values = cellfun(@(S) get_field_or_empty(S, 'd_series'), ...
        num2cell(Summary(regularized)), 'UniformOutput', false);
    zoom_limits = padded_limits([vertcat(zoom_values{:}); Options.delta; -Options.delta]);
    all_values = cellfun(@(S) get_field_or_empty(S, 'd_series'), num2cell(Summary), ...
        'UniformOutput', false);
    limits = padded_limits([vertcat(all_values{:}); Options.delta; -Options.delta]);
    groups = {'regularized', 'regularized', 'ccd_small', 'ccd_large'};
    labels = {'regularized，纵轴放大', 'regularized，与 ccd 同尺度', 'ccd，p ≤ 0.1', 'ccd，p ≥ 1'};
    tile_limits = {zoom_limits, limits, limits, limits};
    handles = gobjects(1, 0);
    for t = 1:4
        ax = nexttile(layout);
        hold(ax, 'on');
        yline(ax, 0, 'k-', 'LineWidth', 1.0, 'HandleVisibility', 'off');
        yline(ax, Options.delta, '--', 'Color', [0.6 0.6 0.6], 'LineWidth', 1.2, ...
            'HandleVisibility', 'off');
        yline(ax, -Options.delta, '--', 'Color', [0.6 0.6 0.6], 'LineWidth', 1.2, ...
            'HandleVisibility', 'off');
        % 第 2 块与第 1 块是同一组工况，它的线不重复进图例
        tile_handles = draw_cases(ax, Summary, 'd_series', ...
            group_members(Summary, groups{t}, true), true);
        if t ~= 2
            handles = [handles, tile_handles];
        end
        ylim(ax, tile_limits{t});
        style_axes(ax, ['d (m/s)，' labels{t}], '', font_size);
    end
    xlabel(ax, '迭代轮次', 'FontSize', font_size);
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-相对none差值.png'));
end


function plot_final_difference_figure(Summary, Options, pictures_root)
% PLOT_FINAL_DIFFERENCE_FIGURE 对比-末轮差值随p和w：左为 ccd 各档末轮 |d| 随 p，右为 normgap 各档
% 末轮 |d| 随 w，双对数，画 δ 线；保留箱形边界的对照工况画成空心标记。
%
% d 为末轮相对 none 的同轮总脉冲差；对照工况的末轮不是第 50 轮时，是它末轮那一轮的差。
% d 恰为 0 的工况在对数轴上画不出来，不画。

    font_size = 16;
    fig = new_figure('对比-末轮差值随p和w', [100, 100, 1100, 520]);
    layout = tiledlayout(fig, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    handles = gobjects(1, 0);
    types = {'ccd', 'norm_gap'};
    x_labels = {'p', 'w_{reg}'};
    x_fields = {'p', 'w'};
    for t = 1:2
        ax = nexttile(layout);
        hold(ax, 'on');
        for c = find(strcmp({Summary.type}, types{t}) & strcmp({Summary.state}, 'ok'))
            S = Summary(c);
            if isnan(S.d_final) || S.d_final == 0
                continue;
            end
            Style = case_style(S);
            handles(end + 1) = plot(ax, S.(x_fields{t}), abs(S.d_final), Style.line, ...
                'Color', Style.color, 'Marker', Style.marker, 'MarkerSize', 9, ...
                'MarkerFaceColor', marker_face(Style), 'LineWidth', 1.5, ...
                'DisplayName', Style.label); %#ok<AGROW>
        end
        if t == 1
            handles(end + 1) = yline(ax, Options.delta, '--', 'Color', [0.2 0.2 0.2], ...
                'LineWidth', 1.2, 'DisplayName', sprintf('δ = %g m/s', Options.delta)); %#ok<AGROW>
        else
            yline(ax, Options.delta, '--', 'Color', [0.2 0.2 0.2], 'LineWidth', 1.2, ...
                'HandleVisibility', 'off');
        end
        set(ax, 'XScale', 'log', 'YScale', 'log');
        style_axes(ax, '末轮 |d| (m/s)', '', font_size);
        xlabel(ax, x_labels{t}, 'FontSize', font_size);
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-末轮差值随p和w.png'));
end


function plot_tightness_figure(Summary, pictures_root)
% PLOT_TIGHTNESS_FIGURE 对比-紧性：上排为各轮 max|1-‖u‖|，下排为 ccd 各轮 max ε（regularized 没有 ε），
% 纵轴对数，恰为 0 的值画在下限 1e-12 处；三个分块组同各轮总脉冲图。

    font_size = 16;
    fig = new_figure('对比-紧性', [100, 100, 1500, 900]);
    layout = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
    floor_value = 1e-12;   % 对数纵轴的下限
    handles = gobjects(1, 0);
    for g = 1:3
        [group_name, label] = tile_group(g);
        members = group_members(Summary, group_name, g > 1);

        % 上排第 g 列画 max|1-‖u‖|，下排第 g 列画 max ε
        ax = nexttile(layout, g);
        hold(ax, 'on');
        handles = [handles, draw_cases(ax, Summary, 'gap_series', members, true, floor_value)];
        set(ax, 'YScale', 'log');
        style_axes(ax, ['max|1-‖u‖|，' label], '', font_size);

        ax = nexttile(layout, 3 + g);
        hold(ax, 'on');
        ccd_members = members & strcmp({Summary.type}, 'ccd');
        if any(ccd_members)
            draw_cases(ax, Summary, 'eps_series', ccd_members, true, floor_value);
            set(ax, 'YScale', 'log');
            style_axes(ax, ['max ε，' label], '', font_size);
        else
            text(ax, 0.5, 0.5, 'regularized 下没有 ε', 'Units', 'normalized', ...
                'HorizontalAlignment', 'center', 'FontSize', font_size);
            set(ax, 'XLim', [0, 1], 'YLim', [0, 1], 'XTick', [], 'YTick', [], ...
                'Box', 'on', 'FontSize', font_size);
        end
        xlabel(ax, '迭代轮次', 'FontSize', font_size);
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-紧性.png'));
end


function plot_multiplier_figure(Summary, pictures_root)
% PLOT_MULTIPLIER_FIGURE 对比-乘子分布：末轮 ccd 六档 κ̂/ω 的经验分布（E 节点），每档一个分块；
% 分块里另有 normgap_w1e-4 的 κ̂/ω 和各档自己的 ‖s_main‖/ω 作对照，并在 p 处画竖线。
% 横轴对数，不大于 0 的值画在下限 1e-12 处。

    font_size = 16;
    fig = new_figure('对比-乘子分布', [100, 100, 1500, 900]);
    layout = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
    reference_index = find(strcmp({Summary.name}, 'normgap_w1e-4') ...
        & strcmp({Summary.state}, 'ok'), 1);
    handles = gobjects(1, 0);
    ax = gobjects(1);
    for exponent = -3:2
        ax = nexttile(layout);
        hold(ax, 'on');
        index = find(strcmp({Summary.name}, sprintf('ccd_p1e%d', exponent)), 1);
        if isempty(index) || ~strcmp(Summary(index).state, 'ok')
            text(ax, 0.5, 0.5, '缺', 'Units', 'normalized', ...
                'HorizontalAlignment', 'center', 'FontSize', font_size);
        else
            S = Summary(index);
            Style = case_style(S);
            handle_kappa = plot_ecdf(ax, S.kappa_E, Style.color, 'κ̂/ω（该档）');
            handle_smain = plot_ecdf(ax, S.smain_E, [0.35 0.35 0.35], '‖s_{main}‖/ω');
            xline(ax, S.p, '--', 'Color', [0.1 0.1 0.1], 'LineWidth', 1.2, ...
                'HandleVisibility', 'off');
            handle_reference = gobjects(1);
            if ~isempty(reference_index)
                handle_reference = plot_ecdf(ax, Summary(reference_index).kappa_E, ...
                    case_style(Summary(reference_index)).color, 'κ̂/ω（normgap_w1e-4）');
            end
            set(ax, 'XScale', 'log');
            if exponent == -3
                handles = [handle_kappa, handle_reference, handle_smain];
            end
        end
        style_axes(ax, sprintf('分布函数，p=1e%d', exponent), '', font_size);
        if exponent >= 0
            xlabel(ax, 'κ̂/ω、‖s_{main}‖/ω', 'FontSize', font_size);
        end
    end
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-乘子分布.png'));
end


function plot_final_sigma_figure(Summary, Groups, Options, pictures_root)
% PLOT_FINAL_SIGMA_FIGURE 对比-末轮σ：每圈一个分块，末轮 σ 随圈内 τ，叠画 none、normgap_w1e-4 和默认 p 的
% ccd 工况（默认 p 没有定出来时取 ccd_p1e-1）；退化节点 D 处加浅色底纹。
%
% 节点分组不可用时不画。

    if ~Groups.available
        return;
    end
    font_size = 16;
    default_ccd = Options.default_ccd;
    if isempty(default_ccd)
        default_ccd = 'ccd_p1e-1';
    end
    names = {'none', 'normgap_w1e-4', default_ccd};
    y_limits = [-190, 190];
    fig = new_figure('对比-末轮σ', [100, 100, 1500, 520]);
    layout = tiledlayout(fig, 1, max(Groups.cir), 'TileSpacing', 'compact', 'Padding', 'compact');
    handles = gobjects(1, 0);
    for cir = 1:max(Groups.cir)
        ax = nexttile(layout);
        hold(ax, 'on');
        in_cir = Groups.cir == cir;
        ylim(ax, y_limits);
        handle_shade = gobjects(1);
        if any(Groups.D & in_cir)
            intervals = build_group_intervals(Groups.tau(in_cir), Groups.D(in_cir));
            for k = 1:size(intervals, 1)
                handle_shade = patch(ax, ...
                    [intervals(k, 1); intervals(k, 2); intervals(k, 2); intervals(k, 1)], ...
                    [y_limits(1); y_limits(1); y_limits(2); y_limits(2)], ...
                    [0.85 0.85 0.85], 'EdgeColor', 'none', 'FaceAlpha', 0.5, ...
                    'HandleVisibility', 'off');
            end
            handle_shade.DisplayName = 'D 节点';
        end
        for k = 1:numel(names)
            index = find(strcmp({Summary.name}, names{k}) & strcmp({Summary.state}, 'ok'), 1);
            if isempty(index)
                continue;
            end
            Style = case_style(Summary(index));
            handle = plot(ax, Groups.tau(in_cir), Summary(index).final_sigma(in_cir), ...
                Style.line, 'Color', Style.color, 'LineWidth', 1.5, 'DisplayName', Style.label);
            if cir == 1
                handles(end + 1) = handle; %#ok<AGROW>
            end
        end
        if cir == 1 && any(Groups.D & in_cir)
            handles = [handle_shade, handles];
        end
        style_axes(ax, sprintf('σ (deg)，第 %d 圈', cir), '', font_size);
    end
    xlabel(ax, '圈内 τ', 'FontSize', font_size);
    place_shared_legend(ax, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-末轮σ.png'));
end


function handles = draw_cases(ax, Summary, field, members, skip_none, floor_value)
% DRAW_CASES 在一个分块里为 members 选中的各工况画 field 逐轮序列，横轴为迭代轮次，返回线句柄。
%
% 线的颜色和线型取自 case_style；因平台停止的工况在平台起始轮画同色的点线（不进图例）。
% 没有这个字段或全是 NaN 的工况不画。skip_none 为真时 none 照画但不返回它的句柄
% （几个分块共用一个图例，none 只列一次）。floor_value 可省略，给出时把小于它的值画成它
% （对数纵轴用）。

    if nargin < 6
        floor_value = [];
    end
    handles = gobjects(1, 0);
    for c = find(members)
        S = Summary(c);
        if ~isfield(S, field)
            continue;
        end
        values = S.(field);
        if all(isnan(values))
            continue;
        end
        if ~isempty(floor_value)
            % 只对有值的轮取下限：MATLAB 的 max 把 NaN 当缺失值，直接取会把它变成下限，
            % 提前停止的工况后面就会画成掉到下限
            has_value = ~isnan(values);
            values(has_value) = max(values(has_value), floor_value);
        end
        Style = case_style(S);
        handle = plot(ax, 1:numel(values), values, Style.line, ...
            'Color', Style.color, 'LineWidth', 1.5, 'DisplayName', Style.label);
        if isfield(S, 'plateau_start') && ~isnan(S.plateau_start)
            xline(ax, S.plateau_start, ':', 'Color', Style.color, 'HandleVisibility', 'off');
        end
        if ~(skip_none && strcmp(S.type, 'none'))
            handles(end + 1) = handle; %#ok<AGROW>
        end
    end
end


function handle = plot_ecdf(ax, values, color, label)
% PLOT_ECDF 画一组数的经验分布函数，不大于 0 的值画在下限 1e-12 处；没有数时返回空的图形占位。

    values = sort(values(~isnan(values(:))));
    handle = gobjects(1);
    if isempty(values)
        return;
    end
    values = max(values, 1e-12);
    handle = plot(ax, values, (1:numel(values))' / numel(values), '-', ...
        'Color', color, 'LineWidth', 1.5, 'DisplayName', label);
end


function members = group_members(Summary, group_name, without_none)
% GROUP_MEMBERS 三个分块组里各画哪些工况（与 Summary 等长的逻辑行向量）。
%
%   'regularized'  none 加 normgap 三档（norm_w1e-4 与 normgap_w1e-4 相同，不画）
%   'ccd_small'    none 加 p ≤ 0.1 的 ccd 各档和保留箱形边界的对照工况
%   'ccd_large'    none 加 p ≥ 1 的 ccd 各档
% without_none 为真时去掉 none。只用状态为 ok 的工况。

    types = {Summary.type};
    p = [Summary.p];
    is_ok = strcmp({Summary.state}, 'ok');
    switch group_name
        case 'regularized'
            members = is_ok & (strcmp(types, 'none') | strcmp(types, 'norm_gap'));
        case 'ccd_small'
            members = is_ok & (strcmp(types, 'none') ...
                | (strcmp(types, 'ccd') & p <= 0.1));
        case 'ccd_large'
            members = is_ok & (strcmp(types, 'none') ...
                | (strcmp(types, 'ccd') & p >= 1));
        otherwise
            error('CCDCompare:UnknownGroup', '未知的分块组 %s。', group_name);
    end
    if without_none
        members = members & ~strcmp(types, 'none');
    end
end


function [group_name, label] = tile_group(g)
% TILE_GROUP 第 g 个分块组的名和写进纵轴标签的说明（g = 1、2、3）。

    groups = {'regularized', 'ccd_small', 'ccd_large'};
    labels = {'regularized', 'ccd，p ≤ 0.1', 'ccd，p ≥ 1'};
    group_name = groups{g};
    label = labels{g};
end


function Style = case_style(S)
% CASE_STYLE 一个工况固定的颜色、标记、线型和图上名称（全部图共用）。
%
% none 为灰色虚线；normgap 三档同用一种颜色、以标记区分；ccd 六档按 p 由小到大从深蓝到深红；
% 保留箱形边界的对照工况用同一档的颜色、点线和空心标记。

    if strcmp(S.type, 'none')
        Style = struct('color', [0.35 0.35 0.35], 'marker', 'none', ...
            'line', '--', 'filled', false, 'label', 'none');
    elseif strcmp(S.type, 'norm_gap')
        markers = {'d', 'o', 's'};   % w = 1e-3、1e-4、1e-5
        index = find([1e-3, 1e-4, 1e-5] == S.w, 1);
        Style = struct('color', [0.80 0.47 0.65], 'marker', markers{index}, ...
            'line', '-', 'filled', true, 'label', sprintf('w=1e%d', round(log10(S.w))));
    else
        exponents = -3:2;
        colors = [0.13 0.30 0.55; 0.13 0.55 0.63; 0.30 0.70 0.35; ...
            0.90 0.75 0.20; 0.95 0.50 0.10; 0.75 0.15 0.15];
        markers = {'o', 's', '^', 'd', 'v', 'p'};
        index = find(exponents == round(log10(S.p)), 1);
        Style = struct('color', colors(index, :), 'marker', markers{index}, ...
            'line', '-', 'filled', true, 'label', sprintf('p=1e%d', round(log10(S.p))));
        if S.keep
            Style.line = ':';
            Style.filled = false;
            Style.label = [Style.label '，保留边界'];
        end
    end
end


function face = marker_face(Style)
% MARKER_FACE 标记的填充色：实心用线的颜色，空心为 none。

    if Style.filled
        face = Style.color;
    else
        face = 'none';
    end
end


function limits = padded_limits(values)
% PADDED_LIMITS 一组数的范围，上下各留 5% 的边；只计有限值，没有有限值时为 [0, 1]。
%
% values 为数值数组，或每项一个数值数组的元胞。

    if iscell(values)
        values = vertcat(values{:});
    end
    values = values(isfinite(values));
    if isempty(values)
        limits = [0, 1];
        return;
    end
    span = max(values) - min(values);
    if span == 0
        span = max(1, abs(values(1)));
    end
    limits = [min(values) - 0.05 * span, max(values) + 0.05 * span];
end


function values = get_field_or_empty(S, field)
% GET_FIELD_OR_EMPTY 结构体的一个数值字段，没有这个字段时为空列。

    if isfield(S, field)
        values = S.(field)(:);
    else
        values = zeros(0, 1);
    end
end


function intervals = build_group_intervals(tau, mask)
% BUILD_GROUP_INTERVALS 把一圈内连续的 mask 节点合成 τ 区间 [起点, 终点]（相邻节点取中点为界）。
%
% tau 为该圈节点的圈内 τ（升序），mask 为同长度的逻辑列。返回 n x 2，每行一个区间。

    intervals = zeros(0, 2);
    if isempty(tau) || ~any(mask)
        return;
    end
    tau = tau(:);
    mask = logical(mask(:));
    midpoint = (tau(1:end - 1) + tau(2:end)) / 2;
    lower_edge = [tau(1) - (midpoint(1) - tau(1)); midpoint(:)];
    upper_edge = [midpoint(:); tau(end) + (tau(end) - midpoint(end))];
    change = diff([false; mask; false]);
    start_index = find(change == 1);
    stop_index = find(change == -1) - 1;
    intervals = [lower_edge(start_index), upper_edge(stop_index)];
end


function fig = new_figure(name, position)
% NEW_FIGURE 新建不显示的图窗（name 即窗口名）。

    fig = figure('Name', name, 'NumberTitle', 'off', 'Visible', 'off', ...
        'Position', position);
end


function style_axes(ax, y_label, x_label, font_size)
% STYLE_AXES 统一字号、网格和坐标轴标签；x_label 为空时不写横轴标签。

    set(ax, 'FontSize', font_size, 'Box', 'on');
    grid(ax, 'on');
    ylabel(ax, y_label, 'FontSize', font_size);
    if ~isempty(x_label)
        xlabel(ax, x_label, 'FontSize', font_size);
    end
end


function place_shared_legend(ax, handles, font_size)
% PLACE_SHARED_LEGEND 在多分块图窗底部放一个共用图例（没有条目时不放）。

    if isempty(handles)
        return;
    end
    legend_object = legend(ax, handles, 'Orientation', 'horizontal', ...
        'NumColumns', min(numel(handles), 6), 'FontSize', font_size);
    legend_object.Layout.Tile = 'south';
end


function finish_figure(fig, png_path)
% FINISH_FIGURE 导出 PNG 并关闭图窗。

    save_plot_figure(fig, png_path);
    close(fig);
end
