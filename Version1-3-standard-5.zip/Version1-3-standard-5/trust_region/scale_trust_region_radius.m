function radius = scale_trust_region_radius(TrustRegionState)
% SCALE_TRUST_REGION_RADIUS 算出本轮各通道的实际信赖域半径。
% radius 字段与 TrustRegionState.base 相同（r, V, gamma, phi, psi, P），
% 每个通道 = 倍数 r × 基准半径；单位同基准半径（P 为 m/s，其余归一化）。

    radius = structfun(@(value) TrustRegionState.scale * value, ...
        TrustRegionState.base, 'UniformOutput', false);
end
