function TrustRegionState = initialize_trust_region_state(config)
% INITIALIZE_TRUST_REGION_STATE 由配置生成初始信赖域状态。
%
% 实际半径 = 倍数 scale（即半径 r）× 基准半径 base；base 取自配置、运行中不变，
% scale 由 update_trust_region 按 ρ 缩放（method = 'fixed' 时保持）。
% P 半径保持 m/s 配置口径，装配变量边界时再除以 VU。
% reference_penalty_function 存当前参考的罚函数 J，reference_check 存算 J 用的那份
% P2 可行性检查（逐轮“违反量与松弛”图要用参考处的逐区间违反量），首轮都为空，
% 由 update_trust_region 第一次评价时算出，此后随参考一起更新。
% previous_attempt 存同一参考点上一次被拒绝的求解（r、ΔL、D、松弛罚项、动力学余项四部分），
% 参考点换了或首次求解时为空。

    Base.r = config.trust_region.r;
    Base.V = config.trust_region.V;
    Base.gamma = config.trust_region.gamma;
    Base.phi = config.trust_region.phi;
    Base.psi = config.trust_region.psi;
    Base.P = config.trust_region.P;

    radii = cell2mat(struct2cell(Base));
    if any(~isfinite(radii) | radii <= 0)
        error('SCP:InvalidTrustRegionRadius', ...
            '信赖域基准半径必须为有限正数。');
    end
    scale = config.trust_region.initial_scale;
    if ~(scale >= config.trust_region.min_scale ...
            && scale <= config.trust_region.max_scale)
        error('SCP:InvalidTrustRegionScale', ...
            '信赖域初始倍数必须位于 [min_scale, max_scale] 内。');
    end

    TrustRegionState.base = Base;
    TrustRegionState.scale = scale;
    TrustRegionState.reference_penalty_function = [];
    TrustRegionState.reference_check = [];
    TrustRegionState.previous_attempt = [];
end
