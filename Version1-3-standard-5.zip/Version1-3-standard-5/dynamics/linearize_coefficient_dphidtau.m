function [c, c_r, c_V, c_gamma, c_psi, c_t_f] = linearize_coefficient_dphidtau( ...
        r_k, V_k, gamma_k, psi_k, t_f_k)
% LINEARIZE_COEFFICIENT_DPHIDTAU 计算 dphi/dtau = V*cos(gamma)*cos(psi)*t_f/r 的仿射系数。
%
% 数学形式:
%   F_φ = t_f·V·cos γ·cos ψ / r。在参考点 (r̄, V̄, γ̄, ψ̄, t̄_f) 的一阶展开
%       F_φ ≈ c + c_r·(r − r̄) + c_V·(V − V̄) + c_γ·(γ − γ̄) + c_ψ·(ψ − ψ̄)
%               + c_tf·(t_f − t̄_f)
%   c = F_φ(参考点)，其余为对应偏导 ∂F_φ/∂(·)。单位: r: LU，V: VU，角度: rad，t_f: TU。
%   F_φ 不依赖 φ、u。
%
% 代码形式:
%   输出顺序 [c, c_r, c_V, c_gamma, c_psi, c_t_f]；系数乘变量偏移，
%   不含参考值回移；linearize_atmospheric_dynamics 中 φ、u1、u2 的系数补 0。

    r = r_k;
    V = V_k;
    gammaa = gamma_k;
    psi = psi_k;
    t_f = t_f_k;

    c = (V * t_f * cos(gammaa) * cos(psi)) / r;
    c_r = -(V * t_f * cos(gammaa) * cos(psi)) / r^2;
    c_V = (t_f * cos(gammaa) * cos(psi)) / r;
    c_gamma = -(V * t_f * cos(psi) * sin(gammaa)) / r;
    c_psi = -(V * t_f * cos(gammaa) * sin(psi)) / r;
    c_t_f = (V * cos(gammaa) * cos(psi)) / r;
end
