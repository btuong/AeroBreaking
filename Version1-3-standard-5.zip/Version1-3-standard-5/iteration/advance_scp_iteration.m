function [RunState, IterationRecord] = advance_scp_iteration( ...
        RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
        ~, config, iter)
% ADVANCE_SCP_ITERATION 按信赖域给出的接受结果更新参考和信赖域，判断是否停止，并记录本轮。
%
% 本函数是主循环中唯一修改 RunState 的函数，只照 TrustResult 办事：
% 不求解、不计算罚函数或 ρ、不做接受判断、不积分、不打印、不绘图。
%
% 本函数依次完成：
%   1. 检查输入是否自洽。
%   2. 登记本轮尝试（成功、被拒绝、求解失败都算一次）。
%   3. 候选解被接受时，把它设为下一轮参考。
%   4. 换成下一轮信赖域（接受与否都换）。
%   5. 判断是否停止。
%   6. 记录本轮并存入历史。

    %% 1. 检查输入是否自洽
    check_advance_inputs(RunState, SubproblemDiag, TrustResult, iter);

    %% 2. 登记本轮尝试（成功、被拒绝、求解失败都算一次）
    RunState.num_attempted = RunState.num_attempted + 1;
    RunState.last_attempt_success = logical(SubproblemDiag.success);

    %% 3. 候选解被接受时，把它设为下一轮参考
    % 换参考前先留一份旧参考（本轮 P3 就是在它上面线性化的），写进本轮记录
    ReferenceBefore = RunState.current_reference;
    if TrustResult.accept_candidate
        RunState = use_candidate_as_next_reference( ...
            RunState, TrustResult.accepted_solution);
    end

    %% 4. 换成下一轮信赖域（接受与否都换）
    RunState.trust_region = TrustResult.next_state;

    %% 5. 判断是否停止
    StopDecision = evaluate_scp_stop_conditions( ...
        SubproblemDiag, TrustResult, config, iter);
    RunState.stop = StopDecision.stop;
    RunState.stop_reason = StopDecision.reason;
    RunState.stop_detail = StopDecision.detail;

    %% 6. 记录本轮并存入历史
    IterationRecord = build_iteration_record( ...
        ReferenceBefore, RunState, CurrentSolution, ...
        SubproblemDiag, TrustResult, StopDecision, iter);
    check_iteration_record(IterationRecord, RunState, iter);
    RunState.history(iter) = IterationRecord;
end


function check_advance_inputs( ...
        RunState, SubproblemDiag, TrustResult, iter)
% CHECK_ADVANCE_INPUTS 检查输入是否自洽：未停止、轮次一致、求解失败时没有被接受。

    if RunState.stop
        error('SCP:IterationAfterStop', ...
            '运行已停止，不得再推进迭代。');
    end
    if SubproblemDiag.iter ~= iter || TrustResult.iter ~= iter
        error('SCP:IterationIndexMismatch', ...
            '子问题诊断、信赖域结果与推进轮次不一致。');
    end
    if ~SubproblemDiag.success && TrustResult.accept_candidate
        error('SCP:AcceptedUnavailableCandidate', ...
            'P3 求解失败时不能接受候选解。');
    end
    if isempty(TrustResult.next_state)
        error('SCP:MissingNextTrustRegionState', ...
            '信赖域结果必须包含下一轮信赖域状态。');
    end
end


function RunState = use_candidate_as_next_reference(RunState, CurrentSolution)
% USE_CANDIDATE_AS_NEXT_REFERENCE 候选解被接受后，把它设为下一轮参考，并记为最后接受解。
%
% 本函数依次完成：
%   1. 由候选解构造下一轮参考。
%   2. 换上新参考，记下最后接受解。
%   3. 接受次数加一。

    %% 1. 由候选解构造下一轮参考
    NextReference = build_next_reference( ...
        CurrentSolution, RunState.current_reference);

    %% 2. 换上新参考，记下最后接受解
    RunState.current_reference = NextReference;
    RunState.last_accepted_solution = CurrentSolution;

    %% 3. 接受次数加一
    RunState.num_accepted = RunState.num_accepted + 1;
    RunState.has_accepted_solution = true;
end


function NextReference = build_next_reference(CurrentSolution, CurrentReference)
% BUILD_NEXT_REFERENCE 由候选解构造下一轮参考。
%
% 网格（N, tau, PointsBounds）与当前参考相同；状态、控制和各圈大气段时间
% 取自候选解。

    NextReference = struct();
    NextReference.N = CurrentReference.N;
    NextReference.tau = CurrentReference.tau;
    NextReference.PointsBounds = CurrentReference.PointsBounds;
    NextReference.state = CurrentSolution.state;
    NextReference.control = CurrentSolution.control;
    NextReference.t_f = CurrentSolution.t_f;
end


function StopDecision = evaluate_scp_stop_conditions( ...
        SubproblemDiag, TrustResult, config, iter)
% EVALUATE_SCP_STOP_CONDITIONS 按优先级判断本轮之后是否停止，并写明停止说明。
%
% 收敛依据是步长检查：接受且被接受解的 accepted_convergence_report.converged
% （接受普通候选解时它就是候选解报告的复制）。接受来自 ρ 判断，或 ΔL 过小且
% 相邻解差已达标（update_trust_region 中按收敛接受）；两种情况停止原因都是
% scp_converged，区别写在 detail 中，候选解贴信赖域边界时也注明。
% P3 解检查和 P2 可行性检查只报告，不进入停止：本版本的停止
% 条件原本不含可行性，P2 可行性检查的物理通道判定（accepted_p2_feasibility.
% feasible）照常记录在案，但不改变停止。
% 优先级：P3 失败策略 > 接受且收敛 > 拒绝且半径已在下限 > 最大迭代数 > 继续。
% 任务完成条件不在停止条件中（终端验收口径未决，知识库 D1）。
% 另外只报告收敛的三项：驻点（驻点度量的上界 ≤ ε）、对 P2 可行（候选解的 P2 可行性检查通过）、
% 步长（相邻解差，即现有的步长检查）。本项目的停止依据只有步长，写在 stop_basis 里；
% 驻点度量衡量的是本轮参考点（候选解相对它的预测下降），不是候选解本身。
%
% 本函数依次完成：
%   1. 逐条算出各停止条件是否成立。
%   2. 按优先级选出停止原因。
%   3. 写出停止说明。
%   4. 报告收敛的三项和停止依据。

    %% 1. 逐条算出各停止条件是否成立
    subproblem_failure_requires_stop = ...
        ~SubproblemDiag.success ...
        && strcmp(config.iter.subproblem_failure_policy, 'stop');

    convergence_reached = TrustResult.accept_candidate ...
        && TrustResult.accepted_convergence_report.converged;

    % 拒绝后想缩小半径，但倍数已在下限、没缩成
    Update = TrustResult.trust_region_update;
    trust_region_stalled = TrustResult.candidate_available ...
        && ~TrustResult.accept_candidate ...
        && strcmp(Update.requested_action, 'shrink') && ~Update.changed;

    maximum_iterations_reached = iter >= config.iter.max_scp_iter;

    %% 2. 按优先级选出停止原因
    if subproblem_failure_requires_stop
        stop = true;
        reason = 'subproblem_failure';
    elseif convergence_reached
        stop = true;
        reason = 'scp_converged';
    elseif trust_region_stalled
        stop = true;
        reason = 'trust_region_stalled';
    elseif maximum_iterations_reached
        stop = true;
        reason = 'max_iterations';
    else
        stop = false;
        reason = 'continue';
    end

    %% 3. 写出停止说明
    StopDecision.stop = stop;
    StopDecision.reason = reason;
    StopDecision.detail = build_stop_detail( ...
        reason, SubproblemDiag, TrustResult, config);
    StopDecision.facts = struct( ...
        'subproblem_failure_requires_stop', subproblem_failure_requires_stop, ...
        'convergence_reached', convergence_reached, ...
        'trust_region_stalled', trust_region_stalled, ...
        'maximum_iterations_reached', maximum_iterations_reached);

    %% 4. 报告收敛的三项和停止依据
    % 驻点度量的上界 (r_max/r)ΔL 不可用时不算驻点
    Evaluation = TrustResult.evaluation;
    StopDecision.stationary = isfinite(Evaluation.stationarity_bound) ...
        && Evaluation.stationarity_bound <= config.iter.stationarity_tolerance;
    StopDecision.feasible = SubproblemDiag.success ...
        && SubproblemDiag.p2_feasibility.feasible;
    StopDecision.step_converged = SubproblemDiag.success ...
        && SubproblemDiag.convergence_report.converged;
    StopDecision.stop_basis = {'step'};
end


function detail = build_stop_detail(reason, SubproblemDiag, TrustResult, config)
% BUILD_STOP_DETAIL 用一句话写明停止的具体依据（继续时为空）。

    Evaluation = TrustResult.evaluation;
    Update = TrustResult.trust_region_update;
    switch reason
        case 'subproblem_failure'
            detail = sprintf('P3 求解失败（%s）', SubproblemDiag.solver.status);
        case 'scp_converged'
            Convergence = TrustResult.accepted_convergence_report;
            step_text = sprintf('相邻解差 %.2e < %.0e', ...
                Convergence.max_value, Convergence.tolerance);
            if strcmp(TrustResult.reason, 'small_predicted_reduction_converged')
                detail = sprintf(['预测下降 ΔL=%.2e 不超过 %.0e 且%s，' ...
                    '候选解与参考几乎相同，接受为收敛'], ...
                    Evaluation.predicted_reduction, ...
                    config.trust_region.min_predicted_reduction, step_text);
            else
                % 固定半径方法下 ρ 可能没算出，此时写接受原因
                if Evaluation.ratio_available
                    accept_text = sprintf('ρ=%.3f', Evaluation.ratio);
                else
                    accept_text = TrustResult.reason;
                end
                detail = sprintf('候选解被接受（%s）且%s', accept_text, step_text);
            end
            if Evaluation.on_boundary
                % 步长被半径压住时，解差小不一定是收敛
                detail = sprintf(['%s；候选解贴在信赖域边界上' ...
                    '（%s 通道步长/半径 %.2f，r=%.4g）'], detail, ...
                    Evaluation.step_ratio_channel, Evaluation.step_ratio, ...
                    Update.scale_before);
            end
        case 'trust_region_stalled'
            detail = sprintf('候选解被拒绝（%s），信赖域半径已在下限 r=%.4g', ...
                TrustResult.reason, Update.scale_after);
        case 'max_iterations'
            detail = sprintf('达到最大尝试次数 %d', config.iter.max_scp_iter);
        otherwise
            detail = '';
    end
end


function IterationRecord = build_iteration_record( ...
        ReferenceBefore, RunState, CurrentSolution, ...
        SubproblemDiag, TrustResult, StopDecision, iter)
% BUILD_ITERATION_RECORD 把本轮的参考、解、检查结果、接受结果和停止结果填进一条记录。

    IterationRecord = create_empty_iteration_record();
    IterationRecord.iter = iter;
    IterationRecord.reference_before = ReferenceBefore;
    IterationRecord.reference_after = RunState.current_reference;
    IterationRecord.solution = CurrentSolution;
    IterationRecord.subproblem = SubproblemDiag;
    IterationRecord.trust = TrustResult;
    IterationRecord.num_accepted_after = RunState.num_accepted;
    IterationRecord.stop = StopDecision;
    IterationRecord.complete = true;
end


function check_iteration_record(IterationRecord, RunState, iter)
% CHECK_ITERATION_RECORD 检查本轮记录与运行状态一致，只检查、不改记录。

    if IterationRecord.iter ~= iter ...
            || IterationRecord.num_accepted_after ~= RunState.num_accepted
        error('SCP:IncompleteIterationRecord', ...
            '迭代记录轮次或接受计数与运行状态不一致。');
    end
    if ~IterationRecord.trust.accept_candidate ...
            && ~isequal(IterationRecord.reference_before, ...
            IterationRecord.reference_after)
        error('SCP:RejectedReferenceAdvanced', ...
            '被拒绝轮次的前后参考必须一致。');
    end
end
