function [TrapezoidSolution, TrapezoidCheck] = check_trapezoid_solution( ...
        AcceptedSolution, ConstData, config)
% CHECK_TRAPEZOID_SOLUTION 做梯形递推检查：从初始状态按 P2 的同一离散格式递推整条轨迹，在递推轨迹上算终端违反量、路径约束和性能指标。
%
% 本函数依次完成：
%   1. 从初始状态逐区间梯形递推，段间用原映射。
%   2. 检查递推是否正常完成。
%   3. 按原关系重算终端状态与末次脉冲。
%   4. 用原终端函数检查终端约束。
%   5. 在递推轨迹的每个节点检查路径约束。
%   6. 算性能指标（总脉冲）。
%   7. 汇总检查及递推值与优化节点值之差。

    %% 1. 从初始状态逐区间梯形递推，段间用原映射
    TrapezoidSolution = propagate_trapezoid_solution(AcceptedSolution, ConstData, config);

    %% 2. 检查递推是否正常完成
    RecursionReport = check_trapezoid_recursion(TrapezoidSolution, config);
    if ~RecursionReport.success
        TrapezoidCheck = build_failed_trapezoid_check(RecursionReport);
        return;
    end

    %% 3. 按原关系重算终端状态与末次脉冲
    TrapezoidSolution = compute_dependent_quantities( ...
        TrapezoidSolution, ConstData, config);
    RolloutSolution = TrapezoidSolution;

    %% 4. 用原终端函数检查终端约束
    TerminalReport = evaluate_terminal_constraints(RolloutSolution, ConstData, config);

    %% 5. 在递推轨迹的每个节点检查路径约束
    PathReport = evaluate_path_constraints(RolloutSolution, ConstData, config);

    %% 6. 算性能指标（总脉冲）
    PerformanceReport = evaluate_performance_index(RolloutSolution, ConstData, config);

    %% 7. 汇总检查及递推值与优化节点值之差
    TrapezoidCheck = build_trapezoid_check(RecursionReport, TerminalReport, ...
        PathReport, PerformanceReport, TrapezoidSolution.node_deviation, ConstData);
end


function TrapezoidCheck = build_trapezoid_check( ...
        RecursionReport, TerminalReport, PathReport, PerformanceReport, deviation, ConstData)
% BUILD_TRAPEZOID_CHECK 汇总递推结果，以及递推值与优化节点值之差（物理单位）。

    channel_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    scales = [ConstData.LU / 1e3, ConstData.VU, 180 / pi, 180 / pi, 180 / pi];
    units = {'km', 'm/s', 'deg', 'deg', 'deg'};
    metric_list = cell(1, numel(channel_names));
    for s = 1:numel(channel_names)
        [value, node] = max(abs(deviation(:, s)) * scales(s));
        metric_list{s} = struct('name', channel_names{s}, 'value', value, ...
            'max_value', value, 'unit', units{s}, 'max_node', node);
    end
    TrapezoidCheck = create_empty_trapezoid_check();
    TrapezoidCheck.evaluated = true;
    TrapezoidCheck.success = true;
    TrapezoidCheck.feasible = TerminalReport.success && PathReport.success;
    TrapezoidCheck.failure_reason = '';
    TrapezoidCheck.recursion_report = RecursionReport;
    TrapezoidCheck.deviation_report = [metric_list{:}];
    TrapezoidCheck.terminal_report = TerminalReport;
    TrapezoidCheck.path_report = PathReport;
    TrapezoidCheck.performance_report = PerformanceReport;
end
