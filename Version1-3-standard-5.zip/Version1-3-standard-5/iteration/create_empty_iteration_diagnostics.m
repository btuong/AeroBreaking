function IterationDiagnostics = create_empty_iteration_diagnostics()
% CREATE_EMPTY_ITERATION_DIAGNOSTICS 创建统一的空迭代后处理诊断。
%
% IterationDiagnostics 是 梯形递推检查的产物，由
% postprocess_scp_iteration 生成，与同轮 IterationRecord 按 iter 配对。

    IterationDiagnostics.iter = [];
    IterationDiagnostics.trapezoid_solution = [];
    IterationDiagnostics.trapezoid_check = create_empty_trapezoid_check();
    IterationDiagnostics.complete = false;
end
