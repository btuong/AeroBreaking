function TrustResult = create_empty_trust_result()
% CREATE_EMPTY_TRUST_RESULT 创建统一的空信赖域结果。
%
% 字段与 update_trust_region 的输出完全一致。accepted_* 为被接受解
% 对应的报告：拒绝或求解失败时保持空，不冒充结果。

    TrustResult.success = false;
    TrustResult.status = 'not_evaluated';
    TrustResult.iter = [];
    TrustResult.candidate_available = false;
    TrustResult.accept_candidate = false;
    TrustResult.reason = 'not_evaluated';
    TrustResult.decision_point = 'none';
    TrustResult.accepted_solution = [];
    TrustResult.accepted_convergence_report = struct( ...
        'converged', false, 'metrics', struct([]), 'max_value', NaN, ...
        'max_name', '', 'tolerance', NaN);
    TrustResult.accepted_p2_feasibility = ...
        create_empty_subproblem_diag().p2_feasibility;
    TrustResult.evaluation = create_empty_ratio_evaluation('not_evaluated');
    TrustResult.trust_region_update = struct( ...
        'requested_action', 'hold', 'applied_action', 'hold', ...
        'changed', false, 'scale_before', NaN, 'scale_after', NaN);
    TrustResult.next_state = [];
end
