function TerminalReport = evaluate_terminal_constraints(Solution, ConstData, config)
% EVALUATE_TERMINAL_CONSTRAINTS 用重算的终端状态算终端违反量（远地点半径、轨道倾角）。
%
% 数学形式:
%   e_ra = r_ff - R_aaim，e_i = i_ff - i_aim。
%   xff、i 已经由末圈出口的原真空映射重算，不取 P3 的线性化终端变量。
%
% 代码形式:
%   actual_value/target_value 分别以 km、deg 保存，供绘图和对照表读取；
%   normalized_violation 保留 LU、rad，乘罚权即得罚函数 J 的终端罚项。

    apoapsis = Solution.xff(1);
    inclination = Solution.i;
    violations = [apoapsis - ConstData.R_aaim, inclination - ConstData.i_aim];
    scales = [ConstData.LU / 1e3, 180 / pi];
    actual_values = [apoapsis, inclination] .* scales;
    target_values = [ConstData.R_aaim, ConstData.i_aim] .* scales;
    tolerances = [config.validation.terminal_tolerance.apoapsis, ...
        config.validation.terminal_tolerance.inclination];
    names = {'terminal_apoapsis_violation', 'terminal_inclination_violation'};
    units = {'km', 'deg'};
    metric_list = cell(1, 2);
    for k = 1:2
        violation = abs(violations(k)) * scales(k);
        metric_list{k} = struct('name', names{k}, 'value', violation, ...
            'max_value', violation, 'tolerance', tolerances(k), 'unit', units{k}, ...
            'ratio', violation / tolerances(k), ...
            'satisfied', isfinite(violation) && violation <= tolerances(k), ...
            'active', true, 'evaluated', true, ...
            'actual_value', actual_values(k), 'target_value', target_values(k), ...
            'signed_value', violations(k) * scales(k), ...
            'normalized_violation', violations(k), 'purpose', 'constraint', ...
            'max_cir', NaN, 'max_node', NaN, 'max_point', NaN, ...
            'components', violations(k) * scales(k));
    end
    Metrics = [metric_list{:}];
    TerminalReport.metrics = Metrics;
    TerminalReport.success = all([Metrics.satisfied]);
    TerminalReport.evaluated = true;
    TerminalReport.failed_names = {Metrics(~[Metrics.satisfied]).name};
    [TerminalReport.max_ratio, max_index] = max([TerminalReport.metrics.ratio]);
    TerminalReport.max_name = TerminalReport.metrics(max_index).name;
end
