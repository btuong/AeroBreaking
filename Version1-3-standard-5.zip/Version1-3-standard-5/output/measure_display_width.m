function width = measure_display_width(text)
% MEASURE_DISPLAY_WIDTH 文字的显示宽度：中文等全角字符占两格，其余占一格。
%
% 绘图里估算图例列数、标题说明行宽度时用；终端输出有自己的 display_width。

    width = sum(1 + (double(text) >= 11904));
end
