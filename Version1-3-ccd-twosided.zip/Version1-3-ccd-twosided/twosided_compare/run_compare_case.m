function [Result, FinalizedRun, SaveReport, RunInfo] = run_compare_case( ...
        config, plateau, Case)
% RUN_COMPARE_CASE 按给定配置与工况选项完整跑一次 SCP，并按总脉冲平台判据停止。
%
% 流程与主入口 SCP.m 相同，支持 Case 覆盖速率约束开关并在生成初始参考后、
% 初始化 SCP 运行前按 init_control_mode 调整初始控制；主循环加入在线总脉冲平台判据
% （最近 plateau.window 个被接受轮的总脉冲极差 <= plateau.tolerance 且均对 P2 可行）。
% 路径管理与工作区隔离由调用方负责，本函数不修改外部全局状态或主链源码。
%
% 输入:
%   config  - 完整配置（scp_config_default 的返回值加覆盖项）
%   plateau - 平台判据结构体：window（轮数）、tolerance（总脉冲极差上限，m/s）
%   Case    - （可选）工况结构体，可含 enable_control_continuity 与 init_control_mode
%
% 输出:
%   Result       - 对外稳定结果（build_scp_result）
%   FinalizedRun - 冻结的运行对象
%   SaveReport   - 保存报告（save_scp_result）
%   RunInfo      - 本次运行的平台停止与轮次用时信息
%
% 本函数依次完成：
%   1. 应用工况覆盖并初始化问题数据。
%   2. 生成初始参考轨迹并按工况调整初始控制。
%   3. 准备迭代数据结构。
%   4. SCP 主迭代循环（含总脉冲平台判断）。
%   5. 整理最终结果并保存。

    if nargin < 3
        Case = struct();
    end

    %% 1. 应用工况覆盖并初始化问题数据
    if isfield(Case, 'enable_control_continuity') ...
            && ~isempty(Case.enable_control_continuity)
        config.constraints.enable_control_continuity = ...
            logical(Case.enable_control_continuity);
    end
    [ConstData, InitialState] = initialize_problem(config);

    %% 2. 生成初始参考轨迹并按工况调整初始控制
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, config);
    InitialReference = apply_init_control_mode(InitialReference, Case);

    %% 3. 准备迭代数据结构
    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);
    if config.output.print_pre_iteration
        print_initial_summary(ConstData, InitialReference, InitialPropagation);
    end
    if config.plot.enable_initial
        plot_initial_reference(ConstData, InitialPropagation, config);
    end

    %% 4. SCP 主迭代循环（含总脉冲平台判断）
    accepted_iter = zeros(0, 1);
    accepted_impulse = zeros(0, 1);
    accepted_feasible = false(0, 1);
    iter_seconds = nan(config.iter.max_scp_iter, 1);
    Plateau = create_plateau_result();
    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        iter_timer = tic;

        % 构建、求解本轮 P3，并做步长、P3 解与 P2 可行性检查
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);

        % 决定候选解是否接受与下一轮信赖域半径
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);

        % 更新参考和信赖域，判断是否停止并记录本轮
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);

        % 被接受轮记下总脉冲与 P2 可行性，判断是否进入总脉冲平台
        if TrustResult.accept_candidate
            accepted_iter(end + 1, 1) = iter; %#ok<AGROW>
            accepted_impulse(end + 1, 1) = ...
                IterationRecord.subproblem.p2_feasibility.performance_report.value; %#ok<AGROW>
            accepted_feasible(end + 1, 1) = ...
                logical(TrustResult.accepted_p2_feasibility.feasible); %#ok<AGROW>
            Plateau = detect_performance_plateau( ...
                accepted_iter, accepted_impulse, accepted_feasible, plateau);
        end
        % 主链已因 P3 失败等原因停止时不改停止原因；达到上限同时平台成立时以平台为准
        if Plateau.reached && (~RunState.stop ...
                || strcmp(RunState.stop_reason, 'max_iterations'))
            RunState = mark_plateau_stop(RunState, Plateau, plateau);
        end

        % 只读后处理：梯形递推、逐轮打印与绘图
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);
        iter_seconds(iter) = toc(iter_timer);

        if RunState.stop
            break;
        end
    end

    %% 5. 整理最终结果并保存
    FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory);
    Result = build_scp_result(FinalizedRun);
    SaveReport = save_scp_result(FinalizedRun, ConstData, config);
    RunInfo = build_run_info(Plateau, strcmp(RunState.stop_reason, ...
        'performance_plateau'), iter_seconds(1:FinalizedRun.num_attempted));
end


function InitialReference = apply_init_control_mode(InitialReference, Case)
% APPLY_INIT_CONTROL_MODE 按 init_control_mode 调整初始参考控制（default/scale_0p3/zero）。

    init_mode = 'default';
    if isfield(Case, 'init_control_mode') && ~isempty(Case.init_control_mode)
        init_mode = char(string(Case.init_control_mode));
    end
    switch init_mode
        case 'default'
            % 保持打靶生成的单位圆初始控制不变
        case 'scale_0p3'
            InitialReference.control.u1 = 0.3 * InitialReference.control.u1;
            InitialReference.control.u2 = 0.3 * InitialReference.control.u2;
        case 'zero'
            InitialReference.control.u1 = zeros(size(InitialReference.control.u1));
            InitialReference.control.u2 = zeros(size(InitialReference.control.u2));
        otherwise
            error('TwosidedCompare:UnknownInitControlMode', ...
                '未知初始控制模式 %s，允许 default/scale_0p3/zero。', init_mode);
    end
end


function Plateau = create_plateau_result()
% CREATE_PLATEAU_RESULT 创建“平台尚未成立”的判断结果。

    Plateau = struct('reached', false, 'start_iter', NaN, ...
        'mean_impulse', NaN, 'range', NaN);
end


function Plateau = detect_performance_plateau( ...
        accepted_iter, accepted_impulse, accepted_feasible, plateau)
% DETECT_PERFORMANCE_PLATEAU 判断最近 window 个被接受轮的总脉冲是否进入平台。

    Plateau = create_plateau_result();
    window = plateau.window;
    if numel(accepted_iter) < window
        return;
    end
    recent = numel(accepted_iter) - window + 1:numel(accepted_iter);
    window_impulse = accepted_impulse(recent);
    window_range = max(window_impulse) - min(window_impulse);
    if window_range <= plateau.tolerance && all(accepted_feasible(recent))
        Plateau.reached = true;
        Plateau.start_iter = accepted_iter(recent(1));
        Plateau.mean_impulse = mean(window_impulse);
        Plateau.range = window_range;
    end
end


function RunState = mark_plateau_stop(RunState, Plateau, plateau)
% MARK_PLATEAU_STOP 在 RunState 上写入平台停止标记，不动参考和信赖域。

    RunState.stop = true;
    RunState.stop_reason = 'performance_plateau';
    RunState.stop_detail = sprintf( ...
        '最近 %d 个被接受轮（自第 %d 轮起）总脉冲极差 %.2e <= %g m/s 且对 P2 可行', ...
        plateau.window, Plateau.start_iter, Plateau.range, plateau.tolerance);
end


function RunInfo = build_run_info(Plateau, stopped_by_plateau, iter_seconds)
% BUILD_RUN_INFO 整理平台停止统计与逐轮用时。

    RunInfo.plateau_reached = stopped_by_plateau;
    if stopped_by_plateau
        RunInfo.plateau_start_iter = Plateau.start_iter;
        RunInfo.plateau_mean_impulse = Plateau.mean_impulse;
        RunInfo.plateau_range = Plateau.range;
    else
        RunInfo.plateau_start_iter = NaN;
        RunInfo.plateau_mean_impulse = NaN;
        RunInfo.plateau_range = NaN;
    end
    RunInfo.iter_seconds = iter_seconds(:);
end
