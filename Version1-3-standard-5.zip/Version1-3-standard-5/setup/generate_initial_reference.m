function [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, config)
% GENERATE_INITIAL_REFERENCE 用打靶法生成 M 圈大气跳跃的首次 SCP 参考及传播历史。
%
% 轨迹契约：
%   state   - N x 5，ECF 球坐标状态 [r, V, gamma, phi, psi]，归一化单位。
%   control - 结构体：u1 (N x 1)，u2 (N x 1) 为倾侧角分量 cos(sigma)/sin(sigma)，
%             P (6 x 1) 为脉冲 P0~P5，归一化单位。
%   tau     - N x 1，各圈拼接的归一化时间（每圈内部 0~1），跨圈不连续。
%   t_f     - 5 x 1，各圈大气段飞行时间（TU）。
%   PointsBounds - 5 元素结构体数组，字段 begin/end 为各圈在拼接节点中的行号。
%   网格为 ODE 原生节点拼接（每圈出口事件终止的 ode45 输出），N 由构造结果确定。
%   附加诊断字段 ra_list/i/xff 来自打靶，不进入 P3。
%
% InitialPropagation 保存逐圈三段（真空-大气-真空）传播历史，仅供绘图，
% P3 不读它。
%
% 本函数依次完成：
%   1. 由近地点速度梯度构造各圈目标远地点列表 RefAim。
%   2. 逐圈二分搜索初始脉冲 P_j 并三段积分，拼接参考轨迹。
%   3. 核对网格布局与参考有效域。
%   4. 组装 InitialReference 与 InitialPropagation。

    total_cir = config.scenario.total_cir;
    R_atm = ConstData.R_atm;
    mu = ConstData.mu;

    %% 1. 由近地点速度梯度构造各圈目标远地点列表 RefAim
    % 参考轨道的末端目标：近地点为大气边界，远地点为目标轨道半径
    RefAim.ra_end_aim = ConstData.R_aaim;
    RefAim.rp_end_aim = R_atm;
    RefAim.a_end_aim = (RefAim.ra_end_aim + RefAim.rp_end_aim) / 2;
    RefAim.e_end_aim = (RefAim.ra_end_aim - RefAim.rp_end_aim) ...
        / (2 * RefAim.a_end_aim);
    RefAim.vp_end_aim = sqrt(2 * mu / RefAim.a_end_aim ...
        * (1 / (1 - RefAim.e_end_aim) - 0.5));

    % 各圈近地点速度从 vp24 线性过渡到末端目标；由能量关系得离心率与远地点
    RefAim.vp_list_aim = linspace( ...
        InitialState.vp24, RefAim.vp_end_aim, total_cir + 1);
    RefAim.e_list_aim = (RefAim.vp_list_aim(2:end) * R_atm).^2 ...
        / mu / R_atm - 1;
    if RefAim.e_list_aim(1) > 1
        RefAim.e_list_aim(1) = 0.5 * RefAim.e_list_aim(2) + 0.5 * 1;
    end
    RefAim.ra_list_aim = (1 + RefAim.e_list_aim) ...
        ./ (1 - RefAim.e_list_aim) .* R_atm;
    if RefAim.ra_list_aim(1) < ConstData.R_aaim
        error('SCP:InvalidReferenceApoapsis', ...
            '第一圈目标远地点低于目标轨道远地点。');
    end

    % 大气段固定倾侧角分量 u1=u2=sqrt(2)/2（对应 sigma=45 度）
    RefAim.u1 = sqrt(2) / 2;
    RefAim.u2 = sqrt(2) / 2;

    %% 2. 逐圈二分搜索初始脉冲 P_j 并三段积分，拼接参考轨迹
    for cir = 1:total_cir
        if cir == 1
            % 第一圈：从初始点减速被捕获，近地点进入大气层
            [ra, va, x_out_atm, P, tf_atm, data] = shoot_first_pass( ...
                InitialState.ele24, RefAim.u1, RefAim.u2, ...
                RefAim.ra_list_aim(cir), 0, ConstData);
            PointsBounds(1).begin = 1;
            PointsBounds(1).end = length(data.t_atm);
        else
            % 后续各圈：上一圈大气出口 -> 远地点脉冲 -> 下一圈大气出口
            [ra, va, x_out_atm, P, tf_atm, data] = shoot_follow_pass( ...
                Passes(cir - 1).x_out_atm, RefAim.u1, RefAim.u2, ...
                RefAim.ra_list_aim(cir), Passes(cir - 1).tf_atm, ...
                ConstData);
            PointsBounds(cir).begin = PointsBounds(cir - 1).end + 1;
            PointsBounds(cir).end = PointsBounds(cir - 1).end ...
                + length(data.t_atm);
        end

        Passes(cir).x_atm = data.x_atm;      % M x 6 大气段状态
        Passes(cir).tf_atm = tf_atm;         % 飞出大气层的绝对时刻
        Passes(cir).t_f = data.t_atm(end) - data.t_atm(1);
        Passes(cir).tau = (data.t_atm - data.t_atm(1)) / Passes(cir).t_f;
        Passes(cir).x_out_atm = x_out_atm;
        Passes(cir).ra = ra;
        Passes(cir).va = va;
        Passes(cir).P = P;
        Passes(cir).data = data;
    end

    % 第 5 圈出口远地点处的入轨脉冲 P5
    Passes(total_cir).P5 = sqrt(2 * ConstData.mu / ConstData.R_aaim ...
        - 2 * ConstData.mu / (ConstData.R_aaim + ConstData.R_paim)) ...
        - Passes(total_cir).va;

    % 末端轨道根数与终端状态诊断
    ele_f = transform_rv2elements( ...
        Passes(total_cir).data.rv_trans_out(end, 1:3)', ...
        Passes(total_cir).data.rv_trans_out(end, 4:6)', mu);
    rv_ff = Passes(total_cir).data.rv_trans_out(end, :);
    [r_ff, v_ff] = transform_eci2ecf( ...
        0, ConstData.we, rv_ff(1:3)', rv_ff(4:6)');
    xff = transform_rv2state(r_ff, v_ff);
    xff = xff(1:5);

    %% 3. 核对网格布局与参考有效域
    N = sum(arrayfun(@(pass) length(pass.tau), Passes));
    reference_state = vertcat(Passes.x_atm);
    reference_state = reference_state(:, 1:5);
    tau = vertcat(Passes.tau);

    if N < 2 || any(~isfinite(tau))
        error('SCP:InvalidInitialReferenceGrid', ...
            '初始参考节点必须有限且至少有两个。');
    end
    % 各圈内部 tau 从 0 到 1 严格递增；圈间拼接处允许不连续（回跳到 0）
    for cir = 1:total_cir
        pass_tau = Passes(cir).tau;
        if any(diff(pass_tau) <= 0) ...
                || abs(pass_tau(1)) > 1e-12 ...
                || abs(pass_tau(end) - 1) > 1e-12
            error('SCP:InvalidPassNormalization', ...
                '第 %d 圈 tau 必须在圈内严格递增且归一化到 [0,1]。', cir);
        end
    end

    %% 4. 组装 InitialReference 与 InitialPropagation
    InitialReference.N = N;
    InitialReference.tau = tau;
    InitialReference.t_f = [Passes.t_f]';
    InitialReference.PointsBounds = PointsBounds;
    InitialReference.state = reference_state;
    InitialReference.control.u1 = RefAim.u1 * ones(N, 1);
    InitialReference.control.u2 = RefAim.u2 * ones(N, 1);
    InitialReference.control.P = [Passes.P, Passes(total_cir).P5]';
    InitialReference.ra_list = [Passes.ra]';
    InitialReference.i = ele_f(3);
    InitialReference.xff = xff;

    InitialPropagation.success = true;
    InitialPropagation.ref_aim = RefAim;
    InitialPropagation.passes = Passes;
    InitialPropagation.i = ele_f(3);

    check_initial_reference_contract(InitialReference, InitialPropagation);
end


function check_initial_reference_contract( ...
        InitialReference, InitialPropagation)
% CHECK_INITIAL_REFERENCE_CONTRACT 检查首次参考与传播历史的尺寸和数值。

    if size(InitialReference.state, 1) ~= InitialReference.N
        error('SCP:InvalidInitialReferenceStateSize', ...
            '参考状态节点数必须等于 N。');
    end
    if any(~isfinite(InitialReference.state), 'all') ...
            || any(~isfinite(InitialReference.control.u1)) ...
            || any(~isfinite(InitialReference.control.u2)) ...
            || any(~isfinite(InitialReference.control.P)) ...
            || any(~isfinite(InitialReference.t_f))
        error('SCP:NonfiniteInitialReference', ...
            '参考状态、控制和终端时间必须全部有限。');
    end
    if numel(InitialReference.PointsBounds) ~= 5 ...
            || InitialReference.PointsBounds(end).end ~= InitialReference.N
        error('SCP:InvalidPassBounds', ...
            '各圈节点边界必须连续覆盖全部 N 个节点。');
    end
    if ~InitialPropagation.success ...
            || numel(InitialPropagation.passes) ~= 5
        error('SCP:InvalidInitialPropagation', ...
            '初始传播历史无效。');
    end
end


function [ra, va, x_out_atm, P, tf_atm, data] = shoot_first_pass( ...
        ele0, u1, u2, ra_aim, t0, ConstData)
% SHOOT_FIRST_PASS 二分搜索第一圈初始脉冲使命中目标远地点。
%
% 输入 ele0 为初始轨道根数（对应 24 h 反向积分前的状态点）。

    RM = ConstData.RM;
    R_atm = ConstData.R_atm;
    mu = ConstData.mu;
    hatm = ConstData.hatm;

    [r24, v24] = transform_elements2rv(ele0, mu);

    % 脉冲搜索边界：近地点降到大气边界 / 降到地面以内
    Pupp = search_perigee_pulse(r24, v24, R_atm, ConstData);
    Plow = search_perigee_pulse(r24, v24, RM - hatm, ConstData);

    for i = 1:50
        P_tmp = (Pupp + Plow) / 2;
        v1 = v24 + P_tmp .* (v24 ./ norm(v24));
        [raf, vaf, tf_atm, x_out_atm, data, flag] = ...
            integrate_space_atm_space([r24, v1], u1, u2, t0, ConstData);
        if raf < ra_aim || flag == 0
            Plow = P_tmp;
        else
            Pupp = P_tmp;
        end
        if norm(raf - ra_aim) < hatm / 2
            break;
        end
    end

    P = P_tmp;
    ra = raf;
    va = vaf;
    if i == 50
        error('SCP:InitialShootDiverged', ...
            '第一圈初始脉冲打靶未收敛。');
    end
end


function [ra, va, x_out_atm, P, tf_atm, data] = shoot_follow_pass( ...
        x0, u1, u2, ra_aim, t0, ConstData)
% SHOOT_FOLLOW_PASS 二分搜索远地点脉冲使下一圈命中目标远地点。
%
% 输入 x0 为上一圈大气出口状态（1x6 ECF 球坐标）。

    R_atm = ConstData.R_atm;
    mu = ConstData.mu;
    we = ConstData.we;
    J2 = ConstData.J2;
    RM = ConstData.RM;
    TU = ConstData.TU;
    hatm = ConstData.hatm;

    [r0, v0] = transform_state2rv(x0);
    [r0, v0] = transform_ecf2eci(t0 * we, we, r0, v0);

    % 从大气出口积分到远地点
    opts_ra = odeset('Events', @event_apoapsis, 'RelTol', 1e-11, ...
        'AbsTol', 1e-11);
    [t_trans_out, rv_trans_out] = ode45( ...
        @(t, x) evaluate_vacuum_dynamics(mu, J2, RM, x), ...
        [t0, t0 + 3e6 / TU], [r0; v0], opts_ra);
    r1 = rv_trans_out(end, 1:3).';
    if norm(r1) < ra_aim
        error('SCP:InvalidFollowShootBound', ...
            '当前远地点低于目标远地点，无法继续减速。');
    end
    v1 = rv_trans_out(end, 4:6).';

    % 脉冲搜索边界：近地点降到大气边界 / 降到地面以内（二体能量式）
    Pupp = sqrt(2 * mu) * sqrt(1 / norm(r1) - 1 / (norm(r1) + R_atm)) ...
        - norm(rv_trans_out(end, 4:6).');
    Plow = sqrt(2 * mu) * sqrt(1 / norm(r1) - 1 / (norm(r1) + RM - hatm)) ...
        - norm(rv_trans_out(end, 4:6).');

    for i = 1:50
        P_tmp = (Pupp + Plow) / 2;
        v2 = v1 + P_tmp .* (v1 ./ norm(v1));
        [raf, vaf, tf_atm, x_out_atm, data, flag] = ...
            integrate_space_atm_space([r1; v2], u1, u2, ...
                t_trans_out(end), ConstData);
        if raf < ra_aim || flag == 0
            Plow = P_tmp;
        else
            Pupp = P_tmp;
        end
        if (raf - ra_aim) < hatm / 10 && 0 < (raf - ra_aim)
            break;
        end
    end

    ra = raf;
    P = P_tmp;
    va = vaf;
    if i == 50
        error('SCP:InitialShootDiverged', ...
            '后续圈脉冲打靶未收敛。');
    end
end


function P = search_perigee_pulse(r0, v0, rp_aim, ConstData)
% SEARCH_PERIGEE_PULSE 二分搜索切向脉冲使新轨道近地点半径等于 rp_aim。

    Pup = 150 / ConstData.VU;
    Plow = -150 / ConstData.VU;

    for i = 1:50
        P_tmp = (Pup + Plow) / 2;
        v1 = v0 + P_tmp .* (v0 ./ norm(v0));
        ele1 = transform_rv2elements(r0, v1, ConstData.mu);
        rpf = ele1(1) .* (1 - ele1(2));
        if rpf < rp_aim
            Plow = P_tmp;
        else
            Pup = P_tmp;
        end
        if abs(rpf - rp_aim) < ConstData.hatm / 100
            break;
        end
    end

    P = P_tmp;
    if i == 50
        error('SCP:PerigeePulseSearchDiverged', ...
            '近地点脉冲搜索未收敛。');
    end
end


function [raf, va, tf_atm, x_out_atm, data, flag] = ...
        integrate_space_atm_space(rv_0, u1, u2, t0, ConstData)
% INTEGRATE_SPACE_ATM_SPACE 三段积分：真空下降-大气飞行-真空到远地点。
%
% 输出 raf/va 为大气出口后新轨道的远地点半径与速度，tf_atm 为飞出大气层的
% 绝对时刻，flag 为 1 成功 / 0 坠入大气 / -1 未被捕获。

    R_atm = ConstData.R_atm;
    mu = ConstData.mu;
    we = ConstData.we;
    RM = ConstData.RM;
    TU = ConstData.TU;
    LU = ConstData.LU;
    J2 = ConstData.J2;

    % 真空段：从远地点/初始点积分到大气层入口
    opts_in = odeset('Events', @(t, y) event_atmosphere_entry_rv( ...
        t, y, R_atm), 'RelTol', 1e-12, 'AbsTol', 1e-12);
    [t_trans_in, rv_trans_in] = ode45( ...
        @(t, x) evaluate_vacuum_dynamics(mu, J2, RM, x), ...
        [t0, t0 + 3000000 / TU], rv_0, opts_in);
    [r_in_atm, v_in_atm] = transform_eci2ecf( ...
        t_trans_in(end) * we, we, rv_trans_in(end, 1:3)', ...
        rv_trans_in(end, 4:6)');
    x_in_atm = transform_rv2state(r_in_atm, v_in_atm);

    % 大气段：固定倾侧角飞行，直到飞出大气或坠入
    r_min_guard = RM + R_atm / 10;
    t_max = 3000 / TU;
    opts_atm = odeset('Events', @(t, y) event_atmosphere_exit_state( ...
        t, y, R_atm, r_min_guard), 'RelTol', 1e-7, 'AbsTol', 1e-9);
    [t_atm, x_atm] = ode45( ...
        @(t, x) evaluate_atmospheric_dynamics(t, x, u1, u2, ConstData), ...
        [t_trans_in(end), t_trans_in(end) + t_max], x_in_atm, opts_atm);
    tf_atm = t_atm(end);

    [r_out_atm, v_out_atm] = transform_state2rv(x_atm(end, :));
    [r_out_atm, v_out_atm] = transform_ecf2eci( ...
        t_atm(end) * we, we, r_out_atm, v_out_atm);
    ele_out = transform_rv2elements(r_out_atm, v_out_atm, mu);
    x_out_atm = x_atm(end, :).';

    flag = 1;
    if abs(t_atm(end) - (t_trans_in(end) + t_max)) < 10 / TU ...
            || abs(x_atm(end, 1) - r_min_guard) < 100 / LU
        flag = 0;   % 坠入大气
        raf = NaN; va = NaN; tf_atm = NaN;
        x_out_atm = NaN; data = NaN;
        return;
    elseif ele_out(2) >= 1
        flag = -1;  % 捕获失败
        raf = NaN; va = NaN; tf_atm = NaN;
        x_out_atm = NaN; data = NaN;
        return;
    end

    % 真空段：从大气出口积分到远地点
    opts_ra = odeset('Events', @event_apoapsis, ...
        'RelTol', 1e-11, 'AbsTol', 1e-11);
    [t_trans_out, rv_trans_out] = ode45( ...
        @(t, x) evaluate_vacuum_dynamics(mu, J2, RM, x), ...
        [t_atm(end), t_atm(end) + 3e6 / TU], ...
        [r_out_atm; v_out_atm], opts_ra);
    raf = norm(rv_trans_out(end, 1:3));
    va = norm(rv_trans_out(end, 4:6));

    data.t_trans_in = t_trans_in;
    data.rv_trans_in = rv_trans_in;
    data.t_atm = t_atm;
    data.x_atm = x_atm;
    data.t_trans_out = t_trans_out;
    data.rv_trans_out = rv_trans_out;
end
