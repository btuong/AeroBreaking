function print_save_report(SaveReport)
% PRINT_SAVE_REPORT 打印本次运行保存了哪些文件；打开了开关却没写成的给出警告和原因。
%
% 输入 SaveReport 为 save_scp_result 的输出。没有打开任何保存开关时什么也不打印。

    for k = 1:numel(SaveReport.files)
        File = SaveReport.files(k);
        if File.completed
            fprintf('%s: %s\n', File.label, File.path);
        elseif File.requested
            fprintf('警告: %s没有保存成功 (%s)\n', File.label, File.error_message);
        end
    end
end
