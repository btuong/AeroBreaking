function [position, isterminal, direction] = event_atmosphere_exit_state( ...
        ~, y, r_atm, r_min)
% EVENT_ATMOSPHERE_EXIT_STATE ode45 事件：ECF 球坐标状态飞出大气边界或坠至下界。

    position = [y(1) - r_atm; y(1) - r_min];
    isterminal = [1; 1];
    direction = [1; 0];
end
