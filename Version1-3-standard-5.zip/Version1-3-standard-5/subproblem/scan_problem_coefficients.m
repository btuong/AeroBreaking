function CoefficientReport = scan_problem_coefficients( ...
        objective, LinearConstraints, VariableBounds, ConicConstraints, config)
% SCAN_PROBLEM_COEFFICIENTS 求解前统计送入 MOSEK 的系数量级，标出过大、过小或行内跨度过大的块。
%
% 按块统计（线性约束按 row_groups 分块，锥映射按锥名合并成块，目标系数 c
% 与变量边界各一块），每块给出：
%   max_abs / min_abs   非零系数绝对值的最大值 / 最小值
%   max_row_span        各行“最大系数 / 最小非零系数”的最大值及其块内行号
%   num_tiny            小于所在行最大系数 × tiny_relative_coefficient 的元素数
%   max_abs_bound       有限上下界（锥块为偏移 g）绝对值的最大值
%   num_nonfinite       系数中的 NaN/Inf 个数与边界中的 NaN 个数
% 系数最大值超过 max_abs_coefficient、行内跨度超过 max_row_span 或含非法值
% 的块标为异常。全部量为装配坐标（归一化单位）。
%
% 另存线性约束矩阵 A 的逐行跨度 CoefficientReport.linear_rows（span、block、
% block_names），供逐轮数值健康图使用。
%
% 本检查在调用 MOSEK 之前执行，只报告，不修改问题，不作接受门槛。

    numerics_config = config.solver.numerics;
    Blocks = {};

    % 线性约束：每个约束块一行组
    group_names = fieldnames(LinearConstraints.row_groups);
    for g = 1:numel(group_names)
        rows = LinearConstraints.row_groups.(group_names{g});
        Blocks{end + 1} = summarize_coefficient_block( ...
            ['A.' group_names{g}], LinearConstraints.matrix(rows, :), ...
            [LinearConstraints.lower(rows); LinearConstraints.upper(rows)], ...
            numerics_config); %#ok<AGROW>
    end

    % 锥映射：同名锥（如逐区间的动力学松弛上图锥）合并为一块
    cone_names = unique({ConicConstraints.cones.name}, 'stable');
    for k = 1:numel(cone_names)
        in_block = strcmp({ConicConstraints.cones.name}, cone_names{k});
        rows = vertcat(ConicConstraints.cones(in_block).rows);
        Blocks{end + 1} = summarize_coefficient_block( ...
            ['F.' cone_names{k}], ConicConstraints.mapping(rows, :), ...
            ConicConstraints.offset(rows), numerics_config); %#ok<AGROW>
    end

    % 目标系数视为一行；变量边界只有界值、没有系数
    Blocks{end + 1} = summarize_coefficient_block( ...
        'c', objective(:).', [], numerics_config);
    Blocks{end + 1} = summarize_coefficient_block( ...
        'x_bounds', sparse(0, numel(objective)), ...
        [VariableBounds.lower(:); VariableBounds.upper(:)], numerics_config);
    Blocks = [Blocks{:}];

    CoefficientReport = build_coefficient_report(Blocks, numerics_config);
    CoefficientReport.linear_rows = build_linear_row_spans(LinearConstraints);
end


function LinearRows = build_linear_row_spans(LinearConstraints)
% BUILD_LINEAR_ROW_SPANS 计算 A 每一行的行内跨度（最大系数 / 最小非零系数）及所属块。
% 空行跨度记为 1。

    matrix = LinearConstraints.matrix;
    num_rows = size(matrix, 1);
    [row, ~, value] = find(matrix);
    abs_value = abs(value(:));
    finite = isfinite(abs_value) & abs_value > 0;
    row_max = accumarray(row(finite), abs_value(finite), [num_rows, 1], @max, 0);
    row_min = accumarray(row(finite), abs_value(finite), [num_rows, 1], @min, Inf);
    span = row_max ./ row_min;
    span(row_max == 0) = 1;

    LinearRows.span = span;
    [LinearRows.block, LinearRows.block_names] = build_row_block_index( ...
        LinearConstraints.row_groups, num_rows);
end


function Block = summarize_coefficient_block( ...
        name, matrix, bound_values, numerics_config)
% SUMMARIZE_COEFFICIENT_BLOCK 统计一块系数矩阵及其界值的量级。

    num_rows = size(matrix, 1);
    [row, ~, value] = find(matrix);
    row = row(:);
    abs_value = abs(value(:));
    finite = isfinite(abs_value);
    row = row(finite);
    abs_value = abs_value(finite);

    Block = struct();
    Block.name = name;
    Block.num_rows = num_rows;
    Block.num_nonzeros = numel(abs_value);
    Block.num_nonfinite = sum(~finite) + sum(isnan(bound_values(:)));

    if isempty(abs_value)
        Block.max_abs = NaN;
        Block.min_abs = NaN;
        Block.max_row_span = NaN;
        Block.worst_row = NaN;
        Block.num_tiny = 0;
    else
        Block.max_abs = max(abs_value);
        Block.min_abs = min(abs_value);

        % 行内跨度：同一行最大系数与最小非零系数之比，空行记为 1
        row_max = accumarray(row, abs_value, [num_rows, 1], @max, 0);
        row_min = accumarray(row, abs_value, [num_rows, 1], @min, Inf);
        row_span = row_max ./ row_min;
        row_span(row_max == 0) = 1;
        [Block.max_row_span, Block.worst_row] = max(row_span);

        % 相对所在行主导系数过小、可能被求解器当作零的元素
        Block.num_tiny = sum(abs_value ...
            < numerics_config.tiny_relative_coefficient * row_max(row));
    end

    finite_bounds = abs(bound_values(isfinite(bound_values)));
    Block.max_abs_bound = max([finite_bounds(:); 0]);

    Block.flagged = Block.num_nonfinite > 0 ...
        || Block.max_abs > numerics_config.max_abs_coefficient ...
        || Block.max_row_span > numerics_config.max_row_span ...
        || Block.max_abs_bound > numerics_config.max_abs_bound;
end


function CoefficientReport = build_coefficient_report(Blocks, numerics_config)
% BUILD_COEFFICIENT_REPORT 汇总各块统计，给出全局最大/最小系数与异常块。

    % 全局量只看约束矩阵 A 与锥映射 F，与 MOSEK 日志中的 |A|、|F| 口径一致
    is_matrix_block = startsWith({Blocks.name}, {'A.', 'F.'});
    matrix_blocks = Blocks(is_matrix_block);
    max_values = [matrix_blocks.max_abs];
    min_values = [matrix_blocks.min_abs];

    CoefficientReport = struct();
    CoefficientReport.evaluated = true;
    CoefficientReport.blocks = Blocks;
    CoefficientReport.max_abs = max(max_values, [], 'omitnan');
    CoefficientReport.min_abs = min(min_values, [], 'omitnan');
    CoefficientReport.global_ratio = ...
        CoefficientReport.max_abs / CoefficientReport.min_abs;
    CoefficientReport.num_tiny = sum([Blocks.num_tiny]);
    CoefficientReport.num_nonfinite = sum([Blocks.num_nonfinite]);
    CoefficientReport.flagged_names = {Blocks([Blocks.flagged]).name};
    CoefficientReport.success = isempty(CoefficientReport.flagged_names);
    CoefficientReport.thresholds = numerics_config;
end
