# regularizer_converge：正则方式长迭代对比（阶段3-1）

本文件夹放 Version1-3-standard-3 阶段3-1 的实验：与 Version1-3-standard-2 阶段2（`../Version1-3-standard-2/regularizer_compare/`，10 轮）用同一组工况，把每个工况一直迭代到性能指标（总脉冲）基本不变，再比较各种正则方式。目的是检验 `../正则型无损凸化的无偏性_文章提纲_261116.md` 第 6 节的预言：‖u‖ 正则无偏，平台总脉冲与 w 无关；线性正则（u1+u2、u1、u2）有偏，偏差随 w 增大。

**不追求严格收敛到驻点。** “收敛”只按下面的性能指标平台判据认定。

下文先写实验方案，供实施者照做。实施完成后，在末尾“运行方法与产物”一节补上实际文件清单和运行方法。

## 1 工况与配置

- 工况与阶段2 相同，共 21 个：type ∈ {sum, u1, u2, norm} × w ∈ {1e-2, 1e-3, 1e-4, 1e-5, 1e-6}，加上 none。工况名如 `sum_w1e-3`、`norm_w1e-5`、`none`。w 用字面量 `1e-k`（`10^(-5)` 与 `1e-5` 末位不同，会改变结果）。
- 配置一律取 `scp_config_default()`，只覆盖以下各项：
  - `config.objective.control_reg_type`、`config.objective.weight_control_reg` 按工况设置。
  - `config.iter.max_scp_iter = 50`（上限）。
  - 关闭步长停止：`config.iter.tolerance` 的停止作用要关掉，停止只看本节的平台判据与上限。先读 iteration 模块，确认怎样关；若设为 0 就能关，就用 0。
  - 信赖域保持默认 `'fixed'`、r = 1，与阶段2 相同，以便前 10 轮逐轮回归。
  - 关闭绘图和逐轮打印；保存 `brief_text`、`detail_text`、`control_text`、`control_mat`，关闭 `scan_mat`、`full_mat`；保存目录为 `regularizer_converge/results/<工况名>`。

**性能指标平台判据（本实验的“收敛”）：** 每轮被接受后，取最近 W = 5 个被接受轮。若它们的总脉冲极差不超过 δ = 0.1 m/s，且这 5 轮都 P2 可行（用项目自己的可行判定，如 `max_ratio ≤ 1`，先核对口径），就停止，停止原因记为 `performance_plateau`；平台起始轮记为这 5 轮的第 1 轮。到上限仍未满足，记为 `max_iter`。P3 失败按现有策略停止。W、δ 作为入口脚本中的变量，便于按试点结果再调。

判据的依据：
- 半径固定（`'fixed'`、r = 1），没有信赖域更新，后期迭代改进有限，不追求更细的平台。
- δ = 0.1 m/s 约为总脉冲的 1×10⁻³，能分辨本实验最关心的差别：线性正则在 w = 1e-2、1e-3 时与 none 差 0.6～6 m/s，‖u‖ 在 w = 1e-2 时差 3.18 m/s（阶段2 第 10 轮）。
- 分辨不了 w ≤ 1e-4 时 0.1 m/s 以下的差别，这一档的结论只说“在 δ 以内”。
- `'fixed'` 下每轮都被接受；若改用 `'ratio'`，只计被接受轮，并报告平台时的半径，半径到下限时另行标注。

**判据调整：主判据改为相对 none 的差值稳定（本实验的“基本不变”），上面的绝对总脉冲平台只作在线停止与记录。** 原因（试点数据）：norm_w1e-2、norm_w1e-5、sum_w1e-3 在 50 轮内总脉冲都未出平台，第 20 轮后各工况以相近速率（约 0.07～0.09 m/s/轮）共同下降，ρ 在 0 附近，速度通道步长被半径压住；W=5 窗口总脉冲极差最小为 0.22～0.37 m/s，δ = 0.1、0.2 m/s 都不触发。因此比较各方式时看同轮差值：
- d_c,k = C_c,k − C_none,k（C 为第 k 轮总脉冲，m/s）。最后 W = 5 轮 d 的极差 ≤ δ = 0.1 m/s 判为“差值已稳定”。
- **差值稳定轮** = 最早的 k，使所有 j ≥ k 有 |d_c,j − d_c,末轮| ≤ δ。
- 另以 norm_w1e-5 为参照算 d′_c,k = C_c,k − C_{norm_w1e-5,k}，稳定判定与稳定轮同上；norm 各档间的比较用它。
- M3～M8 的节点量一律取末轮（各工况最后被接受的一轮）。

**实现说明：** 平台停止直接在 `run_converge_case.m` 里向 RunState 写停止三项（`stop`、`stop_reason`、`stop_detail`），仅此实验的运行脚本这样做，主代码不改、默认行为不变；步长停止用 `config.iter.tolerance = 0` 关掉（步长判据 `max_value < tolerance` 恒不成立）。P2 可行取 P2 可行性检查的 `feasible`（动力学、衔接、终端、路径各通道违反量在各自容差内），比 `max_ratio ≤ 1` 略松（路径约束容差为 1+1e-3）。

## 2 代码（全部放在本文件夹，主代码尽量不改）

- `SCP_regularizer_converge.m`：入口脚本，结构照搬 `../Version1-3-standard-2/regularizer_compare/SCP_regularizer_compare.m`：
  - 加本版本各模块路径和本文件夹路径。
  - 开关 `rerun_existing`、`case_filter`。
  - 每个工况用 try/catch 包住。
  - 打印 `[CASE] <名> start/done/failed/skipped <秒> <停止原因> <末轮>`，全部结束打印 `ALL_DONE`。
  - 最后调用分析函数。
- `run_converge_case.m`：照搬阶段2 的 `run_scp_case.m`（流程同 `SCP.m`），加平台停止判据。总脉冲、可行性从本轮记录中读，字段路径参照阶段2 `extract_case_metrics.m` 的写法。停止原因要进入最终结果或单独返回，供指标提取使用。
- `list_converge_cases.m`：21 个工况的工况表。
- `extract_converge_metrics.m`：在阶段2 `extract_case_metrics.m` 的基础上，存每轮的这些量：总脉冲、J、C、Γ、Θ、可行违反比、步长（相邻解差）、ΔL、ρ、max|1−‖u‖|、不紧节点数（>1e-6）、各节点转角中位数。另存停止原因、平台起始轮、末轮、运行秒数。存为工况目录下的 `case_metrics.mat`。
- `analyze_regularizer_converge.m`：只读各工况的 `case_metrics.mat` 与 `scp_run_control.mat`，按第 3 节算指标，写 `results/长迭代汇总.txt`（UTF-8，定宽列）与 `results/长迭代汇总.mat`，按第 4 节画图导出到 `pictures/`。可单独运行，不重跑 SCP。
- 若平台停止确实需要改主代码（如 RunState 的停止字段），默认值必须保持 `SCP.m` 的行为不变。改完用默认配置跑 `SCP.m`，与 `../Version1-3-standard-2/results/scp_run_brief.txt` 对照，末轮总脉冲差应小于 1e-6 m/s。

## 3 指标

记号：
- 末轮 K_c 为各工况停止时的轮。
- 节点量取自 `ControlExport.attempts(k).control_report`：`sigma_deg`、`u_norm`、`tight_gap`、`reg_ratio`、`sigma_shift_deg`、`s_main`、`s_reg`、`s_total`、`s_cone`、`omega`、`tau`、`cir`。
- $e_i = u_i/\|u_i\|$，$P_i^\perp = I - e_ie_i^\top$。角度差一律用 `wrap_angle_deg` 规约。
- **节点分组**：以本阶段 none 工况末轮为准，q_i = ‖s_main,i‖/ω_i。D = {q < 1e-6}，E 为其余节点，所有工况共用。报告 |D|、|E|，并与阶段2 的 96/565 对照。

**M1 平台表。** 工况、type、w、停止原因、平台起始轮（多为 NaN，照实列出）、末轮 K_c、末轮总脉冲、最后 5 轮均值、最后 10 轮平均每轮降幅、最后 5 轮极差、末轮可行违反比、远地点与倾角的实际值、起可行轮；另列 d 与 d′ 的末轮值、最后 5 轮均值与极差、是否稳定、差值稳定轮。

**M2 性能指标偏差。**
- 末轮 d（以及最后 5 轮 d 的均值）作为与 none 之差。
- 线性三种：|d| > 3δ 的各档上，log|d| 对 log w 的斜率。
- norm：各档 w 的末轮总脉冲两两之间的最大差。

**M3 方向偏差。** 末轮取 E 中“紧（gap ≤ 1e-6）且主问题占主导（reg_ratio < 1）”的节点，统计：
- |sigma_shift_deg| 的均值、中位数、95% 分位；
- $t_i = \|P_i^\perp s_{\mathrm{reg},i}\|/\|s_{\mathrm{main},i}\|$ 的中位数、95% 分位；
- 线性三种另报预测角 $\arcsin(\min(1, w\omega_i\|c\|/\|s_{\mathrm{main},i}\|))$ 的中位数，c 取 (1,1)、(1,0)、(0,1)。

**M4 σ 偏差（末轮）。**
- |σ_c − σ_none| 在 E 上的中位数、均值，在 D 上的中位数。
- norm 各档另报 |σ_c − σ_{norm_w1e-5}| 在 E 上的中位数、均值。

**M5 径向乘子（末轮）。** $\nu_i/\omega_i = -e_i^\top s_{\mathrm{main},i}/\omega_i$ 在 E 上的统计：<0 的节点数、< −w 的节点数、最小值、5% 分位、中位数。

**M6 紧性余量。**
- norm 各档：末轮紧节点上 $\|s_{\mathrm{cone},i}\|/(\nu_i + w\omega_i)$ 的中位数与 5%、95% 分位（预期约为 1）。
- 线性三种：末轮 E 上 $\min\|s_{\mathrm{total},i}\|/\omega_i$，以及 $\|s_{\mathrm{total},i}\|/\omega_i < 0.1w$ 的节点数。
- 数值紧性律，全部轮次：$\log_{10}[(1 - \|u\|^2)\|s_{\mathrm{cone}}\|/\|u\|]$ 的中位数与四分位距（只取 gap > 0 的节点），以及 log gap 对 log‖s_total‖ 的斜率与 R²。写法参照 `C:\Users\19364\AppData\Local\Temp\ana_ipm_gap.m`。

**M7 紧性（全部轮次）。** 各轮 max gap 的最大值、gap > 1e-6 的轮数、单轮 gap > 1e-6 的节点数的最大值、gap > 1e-3 的轮数。

**M8 惯性。**
- 各轮全部节点转角 |σ^k − σ^{k−1}| 的中位数序列；
- 全程始终在 45°±15° 内的节点数，分 E、D；
- 差值稳定轮随 w 的变化。

**步长 > 1 的轮。** 各工况相邻解差 > 1 的轮（第 1 轮不列）：该轮 max gap、不紧节点数、控制通道最大差 max(|Δu1|,|Δu2|)（等于步长则步长由控制通道决定）、相邻轮 σ 最大变化与变化 > 90° 的节点数。

**M9 逐轮序列。** 每个工况每轮的总脉冲、max gap、转角中位数，写入 TXT 与 MAT。

## 4 图（中文标签，字号 16，横轴 w 用对数坐标，每种方式一条线并固定颜色，与阶段2 一致；none 画水平虚线；用 `output/save_plot_figure` 导出）

1. `长迭代-各轮总脉冲.png`：5 个子图（每档 w 一个），各方式总脉冲随轮次的曲线与 none，标出平台起始轮（有则标）。
2. `长迭代-与none差值随轮次.png`（关键图）：5 个子图（每档 w 一个），各方式 d_c,k 随轮次，画 0 线和 ±δ 带。
3. `长迭代-norm各档差值随轮次.png`（关键图）：norm 各档 d′ 随轮次，纵轴取 |d′| 的对数坐标，画 δ 线。
4. `长迭代-末轮差值.png`：上为末轮总脉冲随 w；下为 |末轮 d| 随 w（双对数），画 δ 参考线。
5. `长迭代-方向偏差.png`：M3 中位数随 w（双对数）。
6. `长迭代-相对无正则的σ偏差.png`：M4 的 E 中位数随 w。
7. `长迭代-差值稳定轮.png`：差值稳定轮随 w。
8. `长迭代-径向乘子.png`：norm 各档（每档一个子图）E 上 ν/ω 的经验分布函数，在 −w 处画竖线。
9. `长迭代-紧性余量.png`：左为 norm 各档 ‖s_cone‖/ω 对 ν/ω + w 的散点（双对数，画等值线）；右为各工况末轮 gap 对 ‖s_total‖ 的散点，画 μ/(2‖s‖) 参考线。
10. `长迭代-末轮σ_w1e-3.png`：5 个子图（每圈一个），横轴为圈内 τ，五种方式末轮 σ 叠画，D 节点处加浅色底纹。参照阶段2 的同名图。

## 5 核对（写进 `长迭代汇总.txt` 末节）

1. **前 10 轮回归。** 每个工况前 10 轮的总脉冲应与 `../Version1-3-standard-2/regularizer_compare/results/<工况>/case_metrics.mat` 逐轮一致（差 < 1e-6 m/s）。配置只多了上限和停止规则，前 10 轮必须相同；不一致时先查原因，不要改阈值掩盖。
2. **预测误差。** 线性三种的 Γ 预测误差各轮 ≤ 1e-12；norm 各轮 ≤ 1e-12（应为非正）。
3. **节点分组。** none 的 D/E 规模与阶段2 对照。

## 6 实施顺序

1. **实现与快速回归。** 读 `matlab-scp-standards`、`matlab-code-standards`、`trajectory-optimization-code-paradigm` 三个 skill 后再动代码。先用 `norm_w1e-5`、上限 10 轮跑一次，核对第 5 节第 1 条。
2. **试点。** 跑 `norm_w1e-2`、`norm_w1e-5`、`sum_w1e-3`，上限 50，平台停止开启；另报每个工况若取 δ = 0.05、0.1、0.2 m/s 各在第几轮判为平台（由逐轮总脉冲事后计算）。报告以下内容后**停下，等确认再跑其余工况**：
   - 各工况的停止原因、平台起始轮、平台总脉冲；
   - 每轮用时；
   - 每 5 轮的总脉冲；
   - 异常：持续振荡、不可行、P3 失败。

   若 `'fixed'` 下到上限极差仍持续大于 δ（振荡而非下降），在同一工况上再试 `'ratio'`，一并报告。
3. **正式运行。** 其余 18 个工况放后台运行，按 `[CASE]` 行监控。然后运行分析与作图。
4. **文档。**
   - 阶段报告 `../docs/算法改进_阶段3-1_正则方式长迭代对比.md`：只写数据，紧凑，不写推导、结论和推荐。
   - 版本 `../README.md`：标题与来历改为 Version1-3-standard-3（自 Version1-3-standard-2 复制），保留原说明，加“阶段3-1”一节。
   - 根目录：新建 `docs/Version1-3-standard-3.md`（版本报告），在 `README_bbb2.m` 加本版本一条。
   - 本 README 末尾补“运行方法与产物”。
   - 主代码没改就不动知识库。

## 运行方法与产物

**运行**（MATLAB 工作目录任意；入口按自身位置补路径，运行结束恢复）：

```matlab
cd('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-standard-3');
run('regularizer_converge/SCP_regularizer_converge.m')   % 全部 21 个工况，已有 case_metrics.mat 的跳过
```

入口可先设的变量：`case_filter`（如 `{'norm_w1e-5'}`）、`rerun_existing`、`max_iter`（默认 50）、`plateau_window`（默认 5）、`plateau_tolerance`（默认 0.1）、`results_folder`（默认 `results`，回归试跑可用别的文件夹）、`run_analysis`（默认 true）。单独重做分析与作图：`addpath('regularizer_converge'); analyze_regularizer_converge()`，不重跑 SCP。每工况约 2 分钟（50 轮，每轮 2～3 s；机器上同时开着桌面 MATLAB 时约 7 分钟）。后台运行时输出建议重定向到 `results/logs/`，按 `[CASE]` 行和 `ALL_DONE` 监控。

**文件：**
- `SCP_regularizer_converge.m`、`run_converge_case.m`、`list_converge_cases.m`、`extract_converge_metrics.m`、`analyze_regularizer_converge.m`：第 2 节所列。`run_converge_case.m` 返回 `RunInfo`（平台起始轮、窗口均值与极差、各轮用时）。
- `results/<工况>/`：`scp_run_brief.txt`、`scp_run_detail.txt`、`scp_run_control.txt`、`scp_run_control.mat`（`ControlExport`）、`case_metrics.mat`（`Metrics`，逐轮字段 K×1：总脉冲、远地点、倾角、可行违反比、可行标志、J、C、Γ、Θ、ΔL、ρ、Γ 的预测下降/真实下降/预测误差、步长、max|1−‖u‖|、不紧节点数、节点转角中位数、每轮用时；另有停止原因 `stop_reason`（`max_iterations` 记为 `max_iter`）、`stop_reason_raw`、`plateau_start_iter` 等）。
- `results/长迭代汇总.txt`（12 节，含逐轮序列和核对）、`results/长迭代汇总.mat`（`Summary`、`Groups`、`Check`、`Options`）、`results/logs/`（试点与正式运行日志）。
- `pictures/`：第 4 节的 10 张图。

**运行结果（2026-11-16）：** 21 个工况全部完成；20 个到上限 50 轮，sum_w1e-2 在第 36 轮因在线平台停止。核对：前 10 轮回归与阶段2 逐轮差为 0；Γ 预测误差满足要求；none 的 |D|/|E| = 89/572（阶段2 为 96/565）。数据见 `../docs/算法改进_阶段3-1_正则方式长迭代对比.md`。

## 控制正则积分权开关对照（2026-11-24）

`SCP_control_reg_weight_switch.m` 保持正则方式和 w 不变，分别令 `config.objective.control_reg_use_integration_weights` 为 true 和 false。前者为原式 `w_reg*Σω_i*(·)_i`，后者为 `w_reg*Σ(·)_i`，只影响控制正则附加项。默认工况为 sum、u1、u2、norm × w=1e-4，各 10 轮，fixed、r=1；可先设 `max_iter` 和 `results_folder`。结果写入 `results_weight_switch/<type>_omega_<0或1>/`，汇总是 `results_weight_switch/对照汇总.txt`、`.mat`，包括逐轮总脉冲、P2 可行性、终端量、Γ、紧性差和参考处 |J−L|。此目录独立于原 21 工况结果。
