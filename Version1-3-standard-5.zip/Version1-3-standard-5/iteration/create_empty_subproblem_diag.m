function SubproblemDiag = create_empty_subproblem_diag()
% CREATE_EMPTY_SUBPROBLEM_DIAG 创建统一的空 P3 求解诊断。
%
% 字段与 solve_scp_subproblem 成功路径的 SubproblemDiag 完全一致；
% 求解失败与未尝试路径从本函数取得 schema，再改写状态字段。

    SubproblemDiag.success = false;
    SubproblemDiag.status = 'not_attempted';
    SubproblemDiag.iter = [];
    SubproblemDiag.num_variables = 0;
    SubproblemDiag.num_nodes = NaN;
    SubproblemDiag.solver = create_empty_solver_result();

    % 求解前的系数量级扫描（求解失败时也保留）
    SubproblemDiag.coefficient_report = struct( ...
        'evaluated', false, 'success', false, 'blocks', struct([]), ...
        'max_abs', NaN, 'min_abs', NaN, 'global_ratio', NaN, ...
        'num_tiny', 0, 'num_nonfinite', 0, 'flagged_names', {{}}, ...
        'thresholds', struct(), ...
        'linear_rows', struct('span', [], 'block', [], 'block_names', {{}}));

    % P3 的目标 L 按项拆开的值（求解失败时为空）
    SubproblemDiag.objective_terms = struct('total', NaN, ...
        'terms', struct('name', {}, 'label', {}, 'kind', {}, 'value', {}));

    % 步长检查
    SubproblemDiag.convergence_report = struct( ...
        'converged', false, 'metrics', struct([]), ...
        'state_channels', struct([]), 't_f_channel', struct([]), ...
        'max_value', NaN, 'max_name', '', ...
        'tolerance', NaN);

    % P3 解检查与 P2 可行性检查；
    % multiplier_report 是 P3 乘子，只报告，不进 success；
    % terminal_remainder_report 是终端映射的余项，只报告，不进 feasible
    SubproblemDiag.p3_check = struct( ...
        'solver_feasibility_report', create_empty_check_report(), ...
        'slack_report', create_empty_check_report(), ...
        'reformulation_report', create_empty_check_report(), ...
        'multiplier_report', create_empty_multiplier_report(), ...
        'success', false);
    SubproblemDiag.p2_feasibility = struct( ...
        'dynamics_report', create_empty_check_report(), ...
        'junction_report', create_empty_check_report(), ...
        'terminal_report', create_empty_check_report(), ...
        'path_report', create_empty_check_report(), ...
        'performance_report', struct('value', NaN, 'unit', 'm/s', ...
        'components', [], 'normalized_value', NaN, 'evaluated', false), ...
        'terminal_remainder_report', create_empty_check_report(), ...
        'feasible', false, 'failed_names', {{}}, 'max_ratio', NaN, ...
        'max_name', '', 'evaluated', false);

    % 控制量报告：u 的紧性、σ 的偏向和 u 列驻点条件的对偶分解（只报告）
    SubproblemDiag.control_report = create_empty_control_report('not_attempted');
end


function Report = create_empty_check_report()
% CREATE_EMPTY_CHECK_REPORT 创建一份未评价的检查报告。

    Report.success = false;
    Report.evaluated = false;
    Report.metrics = struct([]);
    Report.failed_names = {};
end


function SolverResult = create_empty_solver_result()
% CREATE_EMPTY_SOLVER_RESULT 创建统一的空求解结果。

    SolverResult.solver_name = 'mosek';
    SolverResult.success = false;
    SolverResult.status = 'not_solved';
    SolverResult.problem_status = 'unknown';
    SolverResult.primal = [];
    % 内点解的对偶变量（求解成功时填入；字段缺失时为空）：
    % y 线性约束乘子，slx/sux 变量下界/上界乘子，snx、doty 锥乘子
    SolverResult.dual = struct('y', [], 'slx', [], 'sux', [], ...
        'snx', [], 'doty', []);
    SolverResult.objective = NaN;
    SolverResult.response_code = NaN;
    SolverResult.message = '';
    SolverResult.parameters = struct();
    SolverResult.mosek_report = create_empty_mosek_report();
end


function MosekReport = create_empty_mosek_report()
% CREATE_EMPTY_MOSEK_REPORT 创建未求解时的 MOSEK 数值信息（缺失记为 NaN，不记为 0）。

    MosekReport.response_name = '';
    MosekReport.log_captured = false;
    MosekReport.warning_codes = [];
    MosekReport.warning_lines = {};
    MosekReport.num_iterations = NaN;
    MosekReport.primal_violation_con = NaN;
    MosekReport.primal_violation_var = NaN;
    MosekReport.primal_violation_acc = NaN;
    MosekReport.dual_violation_con = NaN;
    MosekReport.dual_norm_inf = NaN;
end
