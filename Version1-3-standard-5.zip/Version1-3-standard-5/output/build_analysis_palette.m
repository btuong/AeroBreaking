function Palette = build_analysis_palette()
% BUILD_ANALYSIS_PALETTE 迭代分析各图共用的颜色、标记形状和线宽：同一个量在每扇窗里都用同一种画法。
%
% 为什么要有这个函数：每扇窗只在底部放一个共用图例，同名的曲线只列一次，所以同一个
% 名字在各分块里的画法必须相同，不同名字的画法必须不同。预测下降与预测误差、半径与
% 判据、半径平面和半径扫描各扇窗都从这里取。
%
% 区分曲线的四个手段，各管一件事:
%   颜色  - 是哪个量（ΔL、D、ΔJ、各罚项……），同名同色。
%   标记  - 也跟着量走（Palette.marker，与颜色字段同名）。同一个分块里的实际量标记两两
%           不同，颜色相近或两条线重合时靠标记也分得开。可用的形状只有 o ◇ △ ☆ ▷ 五种：
%           □ 留给初始参考，▼ 留给负值（按绝对值画），红 × 留给 P3 失败，都不拿来区分量。
%           实心表示接受，空心表示拒绝（半径扫描里一律实心）。
%   线型  - 实际量画实线；门槛、阈值、容差、界画虚线（-- -. : 区分几条界）。
%   粗细  - 同一个分块里既有总量又有分项时，总量粗（Palette.width.total）、分项细
%           （Palette.width.part）；同级的几条线一样粗（Palette.width.normal）。粗线
%           先画、细线后画，细线压在粗线上面，两条线重合时也看得出是两条。
% 分块里唯一的一条曲线不进图例（纵轴标签就是它的名字），统一用深灰色和圆点，免得和
% 图例里的颜色混淆。

    %% 颜色
    Palette.predicted_reduction = [0, 0.447, 0.741];     % 预测下降 ΔL，门槛也用它
    Palette.prediction_error = [0.85, 0.325, 0.098];     % 预测误差 D
    Palette.actual_reduction = [0, 0.6, 0.5];            % 真实下降 ΔJ
    Palette.cost_part = [0.466, 0.674, 0.188];           % 性能指标部分（只含总脉冲）
    Palette.extra_part = [1, 0.4, 0.6];                  % 附加项部分（控制正则项）
    Palette.penalty_part = [0.494, 0.184, 0.556];        % 罚项部分
    Palette.reference_penalty = [0.301, 0.745, 0.933];   % 参考处的罚项
    Palette.candidate_penalty = [0.635, 0.078, 0.184];   % 候选解处的罚项
    Palette.slack_penalty = [0.929, 0.694, 0.125];       % 松弛罚项
    Palette.stationarity_bound = [0.494, 0.184, 0.556];  % 驻点度量的上界 (r_max/r)ΔL
    Palette.tolerance = [0.85, 0.325, 0.098];            % ε（虚线）
    Palette.single = [0.25, 0.25, 0.25];                 % 分块里唯一的曲线

    % 半径扫描专用: 修复检查得到的量，和三个特殊半径（画竖线，汇总图里画成曲线）
    % G(r)、E(r) 按性能指标和附加项各画一块，两块同名同色，由纵轴标签区分
    Palette.gain = [0.466, 0.674, 0.188];                % G(r)
    Palette.effective_drop = [0, 0.45, 0.25];            % 有效下降 E(r)
    Palette.repair_slack_penalty = [0.75, 0, 0.75];      % 修复后的松弛罚项
    Palette.actual_radius = [0.9, 0, 0];                 % 本轮实际半径 r^k
    Palette.radius_mark = [0.5, 0.5, 0.5];               % 松弛为零所需的半径、能维持的最大半径
    Palette.stage_metric = [0.3, 0.3, 0.75];             % 阶段度量 ΔL 的该部分(r_top)

    % 动力学余项的四部分；按阶合并画时，二次用状态×状态的颜色，一次用状态×控制的
    % 颜色，与半径无关用控制×时长的颜色
    Palette.state_state = [0.15, 0.15, 0.55];
    Palette.state_control = [0.55, 0.55, 0];
    Palette.state_time = [0.55, 0.34, 0.29];
    Palette.control_time = [0.89, 0.47, 0.76];

    %% 标记形状（字段与上面的颜色同名；会同框出现的量标记两两不同）
    % ΔL、D、ΔJ 常在同一块里
    Palette.marker.predicted_reduction = 'o';
    Palette.marker.prediction_error = '^';
    Palette.marker.actual_reduction = 'd';
    % 三部分只在“分三部分”以外的窗里偶尔同框，形状与 ΔL 等错开
    Palette.marker.cost_part = 'o';
    Palette.marker.extra_part = 'd';
    Palette.marker.penalty_part = '^';
    % 罚项块: 参考处、候选解处、松弛、修复后的松弛
    Palette.marker.reference_penalty = 'o';
    Palette.marker.candidate_penalty = 'd';
    Palette.marker.slack_penalty = '^';
    Palette.marker.repair_slack_penalty = 'p';
    % 驻点度量块: ΔL（用 ΔL 的形状）和上界
    Palette.marker.stationarity_bound = 'd';
    Palette.marker.single = 'o';
    % 半径扫描: 收益块里 G、E，汇总图里再加阶段度量
    Palette.marker.gain = 'o';
    Palette.marker.effective_drop = 'd';
    Palette.marker.stage_metric = '^';
    Palette.marker.actual_radius = 'o';
    % 动力学余项四部分；按阶合并时二次、一次、与半径无关沿用对应部分的形状
    Palette.marker.state_state = 'o';
    Palette.marker.state_control = 'd';
    Palette.marker.state_time = '^';
    Palette.marker.control_time = 'p';

    %% 线宽
    Palette.width.total = 2.5;    % 同块里的总量
    Palette.width.normal = 1.5;   % 同级的几条线
    Palette.width.part = 1.2;     % 同块里的分项
    Palette.width.bound = 1.5;    % 门槛、阈值、界（虚线）

    % 通用分块（draw_history_tiles）里按曲线顺序轮流取的标记，用于各通道（r、V、γ、φ、ψ）
    % 这类没有固定画法的同级曲线
    Palette.marker_cycle = {'o', 'd', '^', 'p', '>'};
end
