function Cases = list_compare_cases(p_exponents)
% LIST_COMPARE_CASES 列出 CCD 对比实验的工况（固定 + ccd 罚权扫描）。
%
% 工况分两组:
%   固定: none；norm_w1e-4（type 'norm'，回归用）；normgap_w1e-3、normgap_w1e-4、normgap_w1e-5（type 'norm_gap'）
%   ccd:  p = 10^e，e 取 p_exponents；默认 [] 时用本文件写死的最终档位（由任务 8 步骤 5 的
%         试点确定: q_ref 取各轮 s_main_norm./omega 的最大值，e0 = floor(log10(q_ref))，
%         档位 (e0-1):(e0+4)），名字 sprintf('ccd_p1e%d', e)；
%         两档保留箱形边界的对照工况 ccdkeep_p1e<档>（keep_control_bounds = true）：默认档和试点时预期的档
% 入口脚本与分析函数共用这张表，保证工况名和顺序一致。
%
% 输出 Cases（1 x n 结构体数组）:
%   name              - 工况名，如 'ccd_p1e-1'、'ccdkeep_p1e2'、'normgap_w1e-4'
%   type              - 'none'、'norm'、'norm_gap'、'ccd'
%   w                 - 控制正则系数 w_reg；ccd 工况为 NaN
%   p                 - ccd 罚权；regularized 工况为 NaN
%   keep_control_bounds - 是否保留 u1、u2 的 ±1 箱形边界（仅 ccdkeep 工况为 true）

    if nargin < 1
        p_exponents = [];
    end
    if isempty(p_exponents)
        % 试点（任务 8 步骤 5）确定的最终档位；改这里就改了默认扫描
        p_exponents = default_p_exponents();
    end

    case_list = {};
    % 固定工况: none、norm_w1e-4（回归）、normgap 三档
    case_list{end + 1} = struct('name', 'none', 'type', 'none', ...
        'w', NaN, 'p', NaN, 'keep_control_bounds', false); %#ok<AGROW>
    case_list{end + 1} = struct('name', 'norm_w1e-4', 'type', 'norm', ...
        'w', str2double('1e-4'), 'p', NaN, 'keep_control_bounds', false); %#ok<AGROW>
    for exponent = [3, 4, 5]
        case_list{end + 1} = struct( ... %#ok<AGROW>
            'name', sprintf('normgap_w1e-%d', exponent), 'type', 'norm_gap', ...
            'w', str2double(sprintf('1e-%d', exponent)), ...
            'p', NaN, 'keep_control_bounds', false);
    end

    % ccd 扫描工况；p 用字符串转换得到与字面量逐位相同的值（10^e 与 1e e 末位可能不同，
    % SCP 对系数的末位扰动敏感，与 list_converge_cases 同一做法）
    for e = p_exponents
        case_list{end + 1} = struct( ... %#ok<AGROW>
            'name', sprintf('ccd_p1e%d', e), 'type', 'ccd', ...
            'w', NaN, 'p', str2double(sprintf('1e%d', e)), ...
            'keep_control_bounds', false);
    end
    % 保留箱形边界的对照工况：一档取按判据定出的默认 p（任务 9 步骤 3，扫描后为 p = 1），
    % 一档取试点时预期的默认档 p = 0.1（它最先按“ccdkeep_p1e<默认档>”跑过，结果保留）
    for e = keep_p_exponents()
        case_list{end + 1} = struct( ... %#ok<AGROW>
            'name', sprintf('ccdkeep_p1e%d', e), 'type', 'ccd', ...
            'w', NaN, 'p', str2double(sprintf('1e%d', e)), ...
            'keep_control_bounds', true);
    end

    Cases = [case_list{:}];
end


function p_exponents = default_p_exponents()
% DEFAULT_P_EXPONENTS ccd 罚权扫描的默认档位（e，p = 10^e）。
%
% 由任务 8 步骤 5 的试点确定: q_ref 取 normgap_w1e-4 各轮控制量报告 s_main_norm./omega
% 在全部节点上的最大值（10 轮试点得 q_ref = 5.796846e-02），e0 = floor(log10(q_ref)) = -2，
% 档位取 (e0-1):(e0+4)。

    p_exponents = -3:2;
end


function keep_exponents = keep_p_exponents()
% KEEP_P_EXPONENTS 保留箱形边界的对照工况的档位（e，p = 10^e），依次为默认档和试点时预期的档。
%
% 默认 p 由任务 9 步骤 3 的判据定（不保留边界的各档里 p 最小、全程不触上界、末轮 max|1-‖u‖| ≤ 1e-3）:
% 扫描结果 p = 0.1 时末轮 max|1-‖u‖| = 1.262e-3，不满足；p = 1 时为 2.195e-4，满足，默认档为 e = 0。

    keep_exponents = [0, -1];
end
