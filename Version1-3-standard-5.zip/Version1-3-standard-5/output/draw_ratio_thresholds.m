function draw_ratio_thresholds(ax, config)
% DRAW_RATIO_THRESHOLDS 在 ρ 的分块里画 ρ0、ρ1、ρ2 三条阈值线（黑色，三种虚线线型）。
%
% ρ0 = accept_ratio（低于它拒绝），ρ1 = shrink_ratio（低于它缩小半径），
% ρ2 = expand_ratio（不低于它扩大半径）。三条线都起了名字，进共用图例。

    TrustConfig = config.trust_region;
    yline(ax, TrustConfig.accept_ratio, '--k', 'LineWidth', 1.2, ...
        'DisplayName', 'ρ0');
    yline(ax, TrustConfig.shrink_ratio, '-.k', 'LineWidth', 1.2, ...
        'DisplayName', 'ρ1');
    yline(ax, TrustConfig.expand_ratio, ':k', 'LineWidth', 1.5, ...
        'DisplayName', 'ρ2');
end
