function scan_norm_w_and_omega()
% SCAN_NORM_W_AND_OMEGA 对 norm 控制正则扫描各级 w_reg 及 ω_i 开关（各 10 轮）。
%
% 在固定配置（fixed、r=1、tolerance=0、10 轮，不写 results/）下，对
%   w_reg ∈ {1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8}
% 分别运行 ω=1（带按圈梯形权）和 ω=0（去掉 ω_i，节点权全 1），并运行 none（无正则）作基准。
% 运行结束后统一打印三张汇总表（避开 MOSEK 版权横幅）：
%   1) 按名义 w_reg 汇总（含 none 基准）；
%   2) 按相近总权重对齐对照（ω=1 的 w 与 ω=0 的 w/100）；
%   3) 全程出现 maxGap > 1e-3 的最差节点明细。

    %% 1. 准备路径与公共初始参考
    tests_dir = fileparts(mfilename('fullpath'));
    version_root = fileparts(tests_dir);
    [~, version_name] = fileparts(version_root);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));

    modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
        'trust_region', 'validation', 'iteration', 'output', 'tests'};
    for k = 1:numel(modules)
        addpath(fullfile(version_root, modules{k}));
    end
    rehash;

    base_config = build_base_config();
    [ConstData, InitialState] = initialize_problem(base_config);
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, base_config);

    %% 2. 依次运行 none 与 norm 各级 w_reg × ω 开关
    weights = [1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8];
    num_w = numel(weights);

    none_res = run_one_case('none', 0, true, ...
        ConstData, InitialReference, InitialPropagation);

    res_o1 = cell(num_w, 1);
    res_o0 = cell(num_w, 1);
    for iw = 1:num_w
        w_reg = weights(iw);
        res_o1{iw} = run_one_case('norm', w_reg, true, ...
            ConstData, InitialReference, InitialPropagation);
        res_o0{iw} = run_one_case('norm', w_reg, false, ...
            ConstData, InitialReference, InitialPropagation);
    end
    res_o1 = [res_o1{:}];
    res_o0 = [res_o0{:}];

    %% 3. 统一打印汇总表
    fprintf('\n========================================================================================================================\n');
    fprintf('=== %s: norm 控制正则各级 w_reg × ω_i 开关扫描 (10 轮, fixed r=1, tol=0) ===\n', version_name);
    fprintf('========================================================================================================================\n\n');

    dv_none = none_res.dv_last;

    % 表 1：按名义 w_reg 汇总
    fprintf('[表 1] 按名义 w_reg 汇总（基准 none 第 10 轮总脉冲 = %.4f m/s）\n', dv_none);
    print_table_header();
    print_summary_row('none', none_res, dv_none);
    fprintf('\n');
    for iw = 1:num_w
        w_tag = sprintf('%.0e', weights(iw));
        print_summary_row(['norm_o1_' w_tag], res_o1(iw), dv_none);
        print_summary_row(['norm_o0_' w_tag], res_o0(iw), dv_none);
        fprintf('\n');
    end

    % 表 2：按总权量级对齐（ω=1 的 w 与 ω=0 的 w/100，总权比 661/500 = 1.322）
    fprintf('[表 2] 按总权重 |Γ| 量级对齐对照（ω=1 取 w，ω=0 取 w/100，总权比 1.322）\n');
    print_table_header();
    for iw = 1:(num_w - 2)
        tag_o1 = sprintf('norm_o1_%.0e', weights(iw));
        tag_o0 = sprintf('norm_o0_%.0e', weights(iw + 2));
        print_summary_row(tag_o1, res_o1(iw), dv_none);
        print_summary_row(tag_o0, res_o0(iw + 2), dv_none);
        fprintf('\n');
    end

    % 表 3：全程出现大不紧 (maxGap > 1e-3) 的最差节点诊断明细
    fprintf('[表 3] 全程出现 maxGap > 1e-3 的最差节点诊断\n');
    fprintf('%-16s | %4s | %4s | %3s | %9s | %9s | %9s | %8s | %5s | %8s\n', ...
        'case', 'iter', 'node', 'cir', 'gap', 'margin_m', 'ratio', 'cos_canc', 'chAct', 'step_max');
    fprintf('%s\n', repmat('-', 1, 98));
    all_cases = [none_res, res_o1, res_o0];
    all_names = [{'none'}, ...
        arrayfun(@(w) sprintf('norm_o1_%.0e', w), weights, 'UniformOutput', false), ...
        arrayfun(@(w) sprintf('norm_o0_%.0e', w), weights, 'UniformOutput', false)];
    has_large = false;
    for k = 1:numel(all_cases)
        S = all_cases(k);
        if isfinite(S.max_gap_all) && S.max_gap_all > 1e-3
            has_large = true;
            W = S.worst_gap_info;
            fprintf('%-16s | %4d | %4d | %3d | %9.2e | %9.2e | %9.2e | %8.4f | %5d | %8.3f\n', ...
                all_names{k}, W.iter, W.node, W.cir, W.gap, W.margin_m, ...
                W.reg_ratio, W.cancel_cos, double(W.chord_active), W.step_max);
        end
    end
    if ~has_large
        fprintf('（无全程 maxGap > 1e-3 的工况）\n');
    end
    fprintf('\nSCAN_DONE\n');
end


function config = build_base_config()
% BUILD_BASE_CONFIG 返回 10 轮固定信赖域扫描的基础配置（不绘图、不写文件）。

    config = scp_config_default();
    config.iter.max_scp_iter = 10;
    config.iter.tolerance = 0;
    config.plot.enable_initial = false;
    config.plot.enable_iteration = false;
    config.plot.enable_final = false;
    config.output.print_pre_iteration = false;
    config.output.print_iteration = false;
    config.output.print_summary = false;
    config.output.save.brief_text = false;
    config.output.save.detail_text = false;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    config.output.save.control_text = false;
    config.output.save.control_mat = false;
    config.validation.enable_trapezoid_check = false;
end


function Summary = run_one_case(reg_type, w_reg, use_weights, ...
        ConstData, InitialReference, InitialPropagation)
% RUN_ONE_CASE 复用公共初始参考，运行单个 10 轮 SCP 工况并提取指标。

    config = build_base_config();
    config.objective.control_reg_type = reg_type;
    config.objective.weight_control_reg = w_reg;
    config.objective.control_reg_use_integration_weights = use_weights;

    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);

    ok_iters = 0;
    max_gap_all = -Inf;
    untight_rounds = 0;
    max_untight_nodes = 0;
    worst_info = struct('iter', NaN, 'node', NaN, 'cir', NaN, 'gap', NaN, ...
        'margin_m', NaN, 'reg_ratio', NaN, 'cancel_cos', NaN, ...
        'chord_active', false, 'step_max', NaN);

    dv_last = NaN;
    gamma_last = NaN;
    max_gap_last = NaN;
    feasible_last = false;
    ratio_med = NaN;
    ratio_gt1 = NaN;
    near45_last = NaN;
    turn_med_last = NaN;
    prev_control = InitialReference.control;

    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);

        if TrustResult.candidate_available && TrustResult.accept_candidate
            ok_iters = ok_iters + 1;
            CR = SubproblemDiag.control_report;
            gaps = abs(CR.tight_gap);
            [iter_max_gap, worst_idx] = max(gaps);
            n_untight = sum(gaps > 1e-6);
            if n_untight > 0
                untight_rounds = untight_rounds + 1;
                max_untight_nodes = max(max_untight_nodes, n_untight);
            end
            if iter_max_gap > max_gap_all
                max_gap_all = iter_max_gap;
                worst_info.iter = iter;
                worst_info.node = CR.node(worst_idx);
                worst_info.cir = CR.cir(worst_idx);
                worst_info.gap = iter_max_gap;
                worst_info.margin_m = CR.tightness_margin(worst_idx);
                worst_info.reg_ratio = CR.reg_ratio(worst_idx);
                worst_info.cancel_cos = CR.cancellation_cosine(worst_idx);
                worst_info.chord_active = logical(CR.chord_active(worst_idx));
                worst_info.step_max = SubproblemDiag.convergence_report.max_value;
            end

            % 更新末轮量
            P2F = SubproblemDiag.p2_feasibility;
            dv_last = P2F.performance_report.value;
            feasible_last = logical(P2F.feasible);
            gamma_last = TrustResult.evaluation.group.extra.candidate;
            max_gap_last = iter_max_gap;
            ratio_med = median(CR.reg_ratio, 'omitnan');
            ratio_gt1 = sum(CR.reg_ratio > 1);
            sigma_deg = CR.sigma_deg(:);
            near45_last = mean(abs(wrap_angle_deg(sigma_deg - 45)) <= 15);
            turn_deg = abs(wrap_angle_deg( ...
                sigma_deg - atan2d(prev_control.u2(:), prev_control.u1(:))));
            turn_med_last = median(turn_deg);
            prev_control = CurrentSolution.control;
        end
    end

    if ~isfinite(max_gap_all)
        max_gap_all = NaN;
    end

    Summary = struct( ...
        'reg_type', reg_type, ...
        'w_reg', w_reg, ...
        'use_weights', use_weights, ...
        'ok_iters', ok_iters, ...
        'num_attempted', RunState.num_attempted, ...
        'dv_last', dv_last, ...
        'gamma_last', gamma_last, ...
        'max_gap_all', max_gap_all, ...
        'untight_rounds', untight_rounds, ...
        'max_untight_nodes', max_untight_nodes, ...
        'max_gap_last', max_gap_last, ...
        'feasible_last', feasible_last, ...
        'ratio_med', ratio_med, ...
        'ratio_gt1', ratio_gt1, ...
        'near45_last', near45_last, ...
        'turn_med_last', turn_med_last, ...
        'worst_gap_info', worst_info);
end


function print_table_header()
% PRINT_TABLE_HEADER 打印扫描汇总表头。

    header = sprintf('%-16s | %5s | %9s | %8s | %9s | %9s | %7s | %9s | %4s | %8s | %7s | %6s | %6s', ...
        'case', 'ok', 'DV@10', 'dDV_none', '|Gamma|', 'maxGapAll', 'ut(r/N)', ...
        'maxGap@10', 'feas', 'rat_med', 'rat>1', 'near45', 'turn10');
    fprintf('%s\n%s\n', header, repmat('-', 1, strlength(header)));
end


function print_summary_row(label, S, dv_none)
% PRINT_SUMMARY_ROW 打印单个工况的汇总行。

    ut_str = sprintf('%2d/%3d', S.untight_rounds, S.max_untight_nodes);
    fprintf('%-16s | %2d/%2d | %9.4f | %+8.4f | %9.2e | %9.2e | %7s | %9.2e | %4d | %8.3f | %3d/661 | %5.1f%% | %6.2f\n', ...
        label, S.ok_iters, S.num_attempted, S.dv_last, S.dv_last - dv_none, ...
        abs(S.gamma_last), S.max_gap_all, ut_str, S.max_gap_last, ...
        double(S.feasible_last), S.ratio_med, round(S.ratio_gt1), ...
        100 * S.near45_last, S.turn_med_last);
end
