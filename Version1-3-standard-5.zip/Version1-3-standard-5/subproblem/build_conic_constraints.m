function ConicConstraints = build_conic_constraints( ...
        VariableIndex, CurrentReference, ConstData, config)
% BUILD_CONIC_CONSTRAINTS 构建 M 圈大气跳跃 P3 的二阶锥约束。
%
% 锥类型（按装配顺序）:
%   control_disk            - Q3：[1; u1(i); u2(i)]，即 ||u(i)||_2 <= 1
%                             （P1 单位模等式 u1²+u2²=1 的无损凸化，
%                             tightness_role = 'lossless'）；config.unit_norm.mode = 'ccd'
%                             时为 [1 + ε(i); u1(i); u2(i)]，即 ||u(i)||_2 <= 1 + ε(i)，
%                             ε(i) 为单位范数松弛，tightness_role = 'epigraph'
%   point_slack_epigraph    - Q2：(t_poi, poi_slack)，|衔接松弛| <= t_poi
%   dynamics_slack_epigraph - Q2：(t_dyn, dyn_slack)，|动力学松弛| <= t_dyn
%   impulse_epigraph        - Q2：(t_P, P)，|P_k| <= t_P
%   apoapsis_slack_epigraph    - Q2：(t_raf, xff(1)-R_aaim)，|终端远地点松弛| <= t_raf
%   inclination_slack_epigraph - Q2：(t_if, xff_i-i_aim)，|终端倾角松弛| <= t_if
%   后五类的 t 在目标里系数为正，tightness_role = 'epigraph'（上图紧性检查）。
%
% 数学形式:
%   每个锥块要求仿射映射 z = A·x + b 落在二阶锥 Q^d 内：
%       z_1 ≥ ‖z_(2:d)‖_2,    z ∈ R^d
%   各类锥块的 z（d 为维数）:
%       control_disk            z = [1; u1_i; u2_i]，d = 3，i = 1..N：‖(u1_i, u2_i)‖ ≤ 1；
%                               ccd 模式下 z = [1 + ε_i; u1_i; u2_i]：‖(u1_i, u2_i)‖ ≤ 1 + ε_i
%       point_slack_epigraph    z = [t_poi,s,k; ν_poi,s,k]，d = 2：t_poi,s,k ≥ |ν_poi,s,k|，
%                               k = 1..5（初始 + 4 内点），s ∈ {r, V, γ, φ, ψ}
%       dynamics_slack_epigraph z = [t_dyn,s,k; ν_dyn,s,k]，d = 2：t_dyn,s,k ≥ |ν_dyn,s,k|，
%                               k = 1..N−M，s ∈ {r, V, γ, φ, ψ}
%       impulse_epigraph        z = [t_P,k; P_k]，d = 2：t_P,k ≥ |P_k|，k = 1..6
%       apoapsis_slack_epigraph    z = [t_raf; r_ff − R_aaim]，d = 2：t_raf ≥ |r_ff − R_aaim|
%       inclination_slack_epigraph z = [t_if; i_ff − i_aim]，d = 2：t_if ≥ |i_ff − i_aim|
%   r_ff 为终态半径（LU），i_ff 为终端倾角（rad），R_aaim、i_aim 为目标值。
%   control_disk 由 P1 的 u1² + u2² = 1 无损凸化得到，取等号（‖u‖=1）是 P3 解检查
%   的必检项（tightness_role = 'lossless'）；其余五类的 t 在目标中系数
%   为正，应取紧（tightness_role = 'epigraph'）。tightness_role 取值：
%   none 只查可行性，epigraph 查上图紧性，lossless 查无损凸化紧性。
%   ccd 模式下 control_disk 的首分量是 1 + ε_i，ε_i 在目标里系数 p·ω_i > 0，
%   最优解处取紧（ε_i = ‖u_i‖ − 1），所以角色为 'epigraph'；此时没有无损凸化锥。
%
% 代码形式:
%   所有锥块按上述顺序堆叠为 Z = mapping·x + offset，cones(j).rows 为第 j 个锥
%   在 Z 中的行范围，dimension 为 d，index 为它在同名锥中的序号（从 1 起）。
%   control_disk 按节点 i = 1..N 依次生成，所以它的 index 就是节点号。各块局部装配:
%       control_disk            regularized：行 2、3 ← VariableIndex.u1(i)、u2(i)，系数 1；
%                               offset = [1; 0; 0]
%                               ccd：行 1、2、3 ← VariableIndex.unit_norm_slack(i)、u1(i)、u2(i)，
%                               系数 1；offset = [1; 0; 0]
%       *_slack_epigraph        行 1 ← VariableIndex.t_{poi,dyn}_slack_<s>(k)，
%                               行 2 ← VariableIndex.{poi,dyn}_slack_<s>(k)，系数 1；offset = [0; 0]
%       impulse_epigraph        行 1 ← VariableIndex.t_P(i)，行 2 ← VariableIndex.P(i)；offset = [0; 0]
%       apoapsis_slack_epigraph    行 1 ← VariableIndex.t_raf，行 2 ← VariableIndex.xff(1)；
%                               offset = [0; −R_aaim]
%       inclination_slack_epigraph 行 1 ← VariableIndex.t_if，行 2 ← VariableIndex.xff_i；
%                               offset = [0; −i_aim]
%   松弛上图锥的循环为外层 k、内层 s，即同一点 / 区间的 5 个状态通道相邻。
%
% 本函数依次完成：
%   1. 控制圆盘锥。
%   2. 衔接松弛上图锥。
%   3. 动力学松弛上图锥。
%   4. 脉冲绝对值上图锥。
%   5. 终端远地点松弛上图锥。
%   6. 终端倾角松弛上图锥。
%   7. 聚合。

    N = CurrentReference.N;
    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    UnitNorm = describe_unit_norm(config);

    %% 1. 控制圆盘锥
    % regularized：[1; u1_i; u2_i] ∈ Q³（无损凸化）；
    % ccd：[1 + ε_i; u1_i; u2_i] ∈ Q³（凸的一半带松弛，ε_i 在目标里取紧）
    for i = 1:N
        ConeBlock.name = 'control_disk';
        ConeBlock.type = 'quadratic';
        ConeBlock.dimension = 3;
        if UnitNorm.is_ccd
            ConeBlock.row_index = [1; 2; 3];
            ConeBlock.column_index = [VariableIndex.unit_norm_slack(i); ...
                VariableIndex.u1(i); VariableIndex.u2(i)];
            ConeBlock.value = [1; 1; 1];
            ConeBlock.tightness_role = 'epigraph';
        else
            ConeBlock.row_index = [2; 3];
            ConeBlock.column_index = [VariableIndex.u1(i); VariableIndex.u2(i)];
            ConeBlock.value = [1; 1];
            ConeBlock.tightness_role = 'lossless';
        end
        ConeBlock.offset = [1; 0; 0];
        ControlDiskCones(i) = ConeBlock;
    end

    %% 2. 衔接松弛上图锥
    block_count = 0;
    for k = 1:5
        for s = 1:numel(state_names)
            block_count = block_count + 1;
            err_index = VariableIndex.(['poi_slack_' state_names{s}])(k);
            t_index = VariableIndex.(['t_poi_slack_' state_names{s}])(k);
            ConeBlock.name = 'point_slack_epigraph';
            ConeBlock.type = 'quadratic';
            ConeBlock.dimension = 2;
            ConeBlock.row_index = [1; 2];
            ConeBlock.column_index = [t_index; err_index];
            ConeBlock.value = [1; 1];
            ConeBlock.offset = [0; 0];
            ConeBlock.tightness_role = 'epigraph';
            PointSlackCones(block_count) = ConeBlock;
        end
    end

    %% 3. 动力学松弛上图锥
    num_dyn_err = length(VariableIndex.dyn_slack_r);
    block_count = 0;
    for k = 1:num_dyn_err
        for s = 1:numel(state_names)
            block_count = block_count + 1;
            err_index = VariableIndex.(['dyn_slack_' state_names{s}])(k);
            t_index = VariableIndex.(['t_dyn_slack_' state_names{s}])(k);
            ConeBlock.name = 'dynamics_slack_epigraph';
            ConeBlock.type = 'quadratic';
            ConeBlock.dimension = 2;
            ConeBlock.row_index = [1; 2];
            ConeBlock.column_index = [t_index; err_index];
            ConeBlock.value = [1; 1];
            ConeBlock.offset = [0; 0];
            ConeBlock.tightness_role = 'epigraph';
            DynSlackCones(block_count) = ConeBlock;
        end
    end

    %% 4. 脉冲绝对值上图锥
    for i = 1:6
        ConeBlock.name = 'impulse_epigraph';
        ConeBlock.type = 'quadratic';
        ConeBlock.dimension = 2;
        ConeBlock.row_index = [1; 2];
        ConeBlock.column_index = [VariableIndex.t_P(i); VariableIndex.P(i)];
        ConeBlock.value = [1; 1];
        ConeBlock.offset = [0; 0];
        ConeBlock.tightness_role = 'epigraph';
        ImpulseCones(i) = ConeBlock;
    end

    %% 5. 终端远地点松弛上图锥
    ConeBlock.name = 'apoapsis_slack_epigraph';
    ConeBlock.type = 'quadratic';
    ConeBlock.dimension = 2;
    ConeBlock.row_index = [1; 2];
    ConeBlock.column_index = [VariableIndex.t_raf; VariableIndex.xff(1)];
    ConeBlock.value = [1; 1];
    ConeBlock.offset = [0; -ConstData.R_aaim];
    ConeBlock.tightness_role = 'epigraph';
    ApoapsisCone = ConeBlock;

    %% 6. 终端倾角松弛上图锥
    ConeBlock.name = 'inclination_slack_epigraph';
    ConeBlock.type = 'quadratic';
    ConeBlock.dimension = 2;
    ConeBlock.row_index = [1; 2];
    ConeBlock.column_index = [VariableIndex.t_if; VariableIndex.xff_i];
    ConeBlock.value = [1; 1];
    ConeBlock.offset = [0; -ConstData.i_aim];
    ConeBlock.tightness_role = 'epigraph';
    InclinationCone = ConeBlock;

    %% 7. 聚合
    Blocks = [ControlDiskCones(:); PointSlackCones(:); ...
        DynSlackCones(:); ImpulseCones(:); ApoapsisCone; InclinationCone];
    num_variables = max(collect_index_values(VariableIndex));
    ConicConstraints = assemble_conic_constraint_blocks( ...
        Blocks, num_variables);
    validate_conic_constraints(ConicConstraints, num_variables);
end


function ConicConstraints = assemble_conic_constraint_blocks( ...
        Blocks, num_variables)
% ASSEMBLE_CONIC_CONSTRAINT_BLOCKS 聚合锥块并组装仿射锥映射。

    total_rows = sum([Blocks.dimension]);
    total_nonzeros = sum(arrayfun( ...
        @(Block) numel(Block.value), Blocks));

    row_index = zeros(total_nonzeros, 1);
    column_index = zeros(total_nonzeros, 1);
    coefficient = zeros(total_nonzeros, 1);
    offset = zeros(total_rows, 1);
    cones = repmat(struct( ...
        'name', '', 'type', '', 'dimension', 0, ...
        'rows', [], 'tightness_role', 'none', 'index', 0), numel(Blocks), 1);
    name_counts = struct();   % 每种锥名已出现的个数，用来给同名锥编序号

    row_offset = 0;
    nonzero_offset = 0;
    for block_index = 1:numel(Blocks)
        ConeBlock = Blocks(block_index);
        validate_cone_block(ConeBlock, num_variables);

        row_range = row_offset + (1:ConeBlock.dimension);
        nonzero_range = nonzero_offset + (1:numel(ConeBlock.value));

        row_index(nonzero_range) = ConeBlock.row_index + row_offset;
        column_index(nonzero_range) = ConeBlock.column_index;
        coefficient(nonzero_range) = ConeBlock.value;
        offset(row_range) = ConeBlock.offset;

        cones(block_index).name = ConeBlock.name;
        cones(block_index).type = ConeBlock.type;
        cones(block_index).dimension = ConeBlock.dimension;
        cones(block_index).rows = row_range(:);
        cones(block_index).tightness_role = ConeBlock.tightness_role;
        if ~isfield(name_counts, ConeBlock.name)
            name_counts.(ConeBlock.name) = 0;
        end
        name_counts.(ConeBlock.name) = name_counts.(ConeBlock.name) + 1;
        cones(block_index).index = name_counts.(ConeBlock.name);

        row_offset = row_offset + ConeBlock.dimension;
        nonzero_offset = nonzero_offset + numel(ConeBlock.value);
    end

    ConicConstraints.mapping = sparse( ...
        row_index, column_index, coefficient, total_rows, num_variables);
    ConicConstraints.offset = offset;
    ConicConstraints.cones = cones;
end


function validate_cone_block(ConeBlock, num_variables)
% VALIDATE_CONE_BLOCK 检查单个锥块的维数、索引和数值。

    if ConeBlock.dimension <= 0 || floor(ConeBlock.dimension) ...
            ~= ConeBlock.dimension
        error('SCP:InvalidConeDimension', ...
            '锥块 %s 维数必须为正整数。', ConeBlock.name);
    end
    if ~strcmp(ConeBlock.type, 'quadratic')
        error('SCP:UnsupportedConeType', ...
            '锥块 %s 类型 %s 不受支持。', ConeBlock.name, ConeBlock.type);
    end
    if ~ismember(ConeBlock.tightness_role, {'none', 'epigraph', 'lossless'})
        error('SCP:InvalidTightnessRole', ...
            '锥块 %s 的 tightness_role 必须为 none/epigraph/lossless。', ...
            ConeBlock.name);
    end
    if numel(ConeBlock.row_index) ~= numel(ConeBlock.column_index) ...
            || numel(ConeBlock.row_index) ~= numel(ConeBlock.value)
        error('SCP:InvalidConeTriplets', ...
            '锥块 %s 三元组长度不一致。', ConeBlock.name);
    end
    if max(ConeBlock.row_index) > ConeBlock.dimension ...
            || min(ConeBlock.row_index) < 1
        error('SCP:InvalidConeRows', ...
            '锥块 %s 局部行号越界。', ConeBlock.name);
    end
    if max(ConeBlock.column_index) > num_variables ...
            || min(ConeBlock.column_index) < 1
        error('SCP:InvalidConeColumns', ...
            '锥块 %s 变量列号越界。', ConeBlock.name);
    end
    if any(~isfinite(ConeBlock.value)) ...
            || any(~isfinite(ConeBlock.offset))
        error('SCP:InvalidConeValues', ...
            '锥块 %s 映射或偏移含 NaN/Inf。', ConeBlock.name);
    end
end


function validate_conic_constraints(ConicConstraints, num_variables)
% VALIDATE_CONIC_CONSTRAINTS 检查聚合锥映射的尺寸和行覆盖。

    if size(ConicConstraints.mapping, 2) ~= num_variables
        error('SCP:InvalidConicMappingWidth', ...
            '锥映射列数必须等于决策变量总数。');
    end
    total_dimension = sum([ConicConstraints.cones.dimension]);
    if size(ConicConstraints.mapping, 1) ...
            ~= numel(ConicConstraints.offset) ...
            || size(ConicConstraints.mapping, 1) ~= total_dimension
        error('SCP:InvalidConicMappingHeight', ...
            '锥映射行数、偏移长度与锥维数之和不一致。');
    end
end
