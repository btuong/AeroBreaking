function Summary = create_empty_control_summary()
% CREATE_EMPTY_CONTROL_SUMMARY 创建字段齐全的空控制量汇总（数值为 NaN）。
%
% 字段含义见 summarize_control_report。

    Summary.num_nodes = 0;
    Summary.sum_omega = NaN;                  % Σω
    Summary.gamma_sum = NaN;                  % Γ 小计 Σ gamma_node
    Summary.max_abs_tight_gap = NaN;          % max|1-‖u‖|
    Summary.max_inward_gap = NaN;             % max(1-‖u‖, 0)，向内的差
    Summary.max_outward_gap = NaN;            % max(‖u‖-1, 0)，向外的差
    Summary.num_slack_capped = NaN;           % ε 触上界的节点数
    Summary.num_untight = NaN;                % |1-‖u‖| 超容差的节点数
    Summary.sigma_mean = NaN;                 % σ 的均值、最小、最大 (deg)
    Summary.sigma_min = NaN;
    Summary.sigma_max = NaN;
    Summary.fraction_neg135 = NaN;            % σ 落在 -135° ± 15° 的节点比例
    Summary.fraction_pos45 = NaN;             % σ 落在 +45° ± 15° 的节点比例
    Summary.reg_ratio_median = NaN;
    Summary.reg_ratio_max = NaN;
    Summary.num_reg_ratio_gt1 = NaN;          % reg_ratio > 1 的节点数
    Summary.shift_abs_median = NaN;           % |σ_shift| 的中位数、最大值 (deg)
    Summary.shift_abs_max = NaN;
    Summary.residual_max_abs = NaN;           % max|stationarity_residual|
end
