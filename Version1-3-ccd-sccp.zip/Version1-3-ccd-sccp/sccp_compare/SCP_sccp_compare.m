% SCCP 模式对比实验入口：在同一 SCP 框架下运行全部 13 个 SCCP 工况
% （8 档 C_eta 主扫描、2 个无速率约束对照、3 个初值与 D 节点专项工况），
% 每个工况运行到总脉冲进入平台或达到各自轮数上限，再调用 analyze_sccp_compare 汇总作图。
%
% 可选的工作区变量（运行前设置，未设就取默认）:
%   rerun_existing    - 默认 false；工况目录已有 case_metrics.mat 时跳过
%   case_filter       - 工况名元胞数组，如 {'sccp_c1e-4'}；空则全跑
%   max_iter_override - 覆盖工况默认轮数上限的正整数（如试点设 5）；空则按工况表
%   plateau_window    - 平台判据窗口长度 W（被接受轮数），默认 5
%   plateau_tolerance - 平台判据总脉冲极差上限 δ (m/s)，默认 0.1
%   results_folder    - 结果文件夹名（在 sccp_compare 下），默认 'results'
%   run_analysis      - 结束后是否调用分析函数，默认 true
%
% 输出: sccp_compare/<results_folder>/<工况名>/ 下 brief/detail/control 文本、
%       scp_run_control.mat 与 case_metrics.mat（不存 full_mat 与 scan_mat）；
%       全跑完后由 analyze_sccp_compare 写 results/对比汇总.txt、.mat 与 pictures/。
% 日志行: [CASE] <工况名> start/done/failed/skipped，全部结束打印 ALL_DONE。

%% ===== 环境准备 =====
tic;
compare_root = fileparts(mfilename('fullpath'));
version_root = fileparts(compare_root);
previous_path = path;
restore_compare_path = onCleanup(@() path(previous_path));
modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
    'trust_region', 'validation', 'iteration', 'output'};
for k = 1:numel(modules)
    addpath(fullfile(version_root, modules{k}));
end
addpath(compare_root);
rehash;

if ~exist('rerun_existing', 'var')
    rerun_existing = false;
end
if ~exist('case_filter', 'var')
    case_filter = {};
end
if ~exist('max_iter_override', 'var')
    max_iter_override = [];
end
if ~exist('plateau_window', 'var')
    plateau_window = 5;
end
if ~exist('plateau_tolerance', 'var')
    plateau_tolerance = 0.1;
end
if ~exist('results_folder', 'var')
    results_folder = 'results';
end
if ~exist('run_analysis', 'var')
    run_analysis = true;
end

%% ===== 平台判据与工况表 =====
plateau.window = plateau_window;
plateau.tolerance = plateau_tolerance;

Cases = list_compare_cases();
if ~isempty(case_filter)
    Cases = Cases(ismember({Cases.name}, case_filter));
end
results_root = fullfile(compare_root, results_folder);
fprintf(['版本目录: %s\n工况数: %d，平台判据: 最近 %d 个被接受轮极差 ≤ %g m/s，' ...
    '结果目录: %s\n'], version_root, numel(Cases), plateau.window, ...
    plateau.tolerance, results_root);

%% ===== 逐个运行工况 =====
for c = 1:numel(Cases)
    Case = Cases(c);
    case_directory = fullfile(results_root, Case.name);
    metrics_path = fullfile(case_directory, 'case_metrics.mat');
    if isfile(metrics_path) && ~rerun_existing
        fprintf('[CASE] %s skipped (已有 case_metrics.mat)\n', Case.name);
        continue;
    end

    fprintf('[CASE] %s start\n', Case.name);
    case_timer = tic;
    try
        case_max_iter = Case.max_iter;
        if ~isempty(max_iter_override)
            case_max_iter = max_iter_override;
        end

        % 公共配置：关闭步长停止，fixed 半径 r = 1，关闭绘图与逐轮终端打印
        config = scp_config_default();
        config.iter.max_scp_iter = case_max_iter;
        config.iter.tolerance = 0;
        config.trust_region.method = 'fixed';
        config.plot.enable_initial = false;
        config.plot.enable_iteration = false;
        config.plot.enable_final = false;
        config.output.print_pre_iteration = false;
        config.output.print_iteration = false;
        config.output.print_summary = false;

        % 只保存简略/详细/控制文本与 control_mat，严禁生成 scan_mat 与 full_mat
        config.output.save.brief_text = true;
        config.output.save.detail_text = true;
        config.output.save.control_text = true;
        config.output.save.control_mat = true;
        config.output.save.scan_mat = false;
        config.output.save.full_mat = false;
        config.output.save.directory = ['sccp_compare/' results_folder '/' Case.name];

        % 工况特化配置：SCCP 模式、罚权 C_eta、上界与速率约束开关
        config.unit_norm.mode = 'sccp';
        config.unit_norm.sccp_penalty_weight = Case.c_eta;
        config.unit_norm.sccp_slack_max = Case.sccp_slack_max;
        config.constraints.enable_control_continuity = ...
            logical(Case.enable_control_continuity);

        [Result, ~, SaveReport, RunInfo] = run_compare_case( ...
            config, plateau, Case);
        elapsed_seconds = toc(case_timer);

        if ~SaveReport.success
            error('SCCPCompare:SaveFailed', ...
                '工况 %s 的结果文件没有全部写成。', Case.name);
        end
        Metrics = extract_compare_metrics(Result, RunInfo, Case.name, ...
            Case, elapsed_seconds);
        save(metrics_path, 'Metrics');

        error_path = fullfile(case_directory, 'case_error.txt');
        if isfile(error_path)
            delete(error_path);
        end
        final_impulse = NaN;
        if ~isnan(Metrics.final_index)
            final_impulse = Metrics.total_impulse_m_s(Metrics.final_index);
        end
        eta_final = NaN;
        if ~isnan(Metrics.final_index)
            eta_final = Metrics.eta(Metrics.final_index);
        end
        fprintf(['[CASE] %s done %.1f s, first=%s, stop=%s, 末轮=%d, ' ...
            '总脉冲=%.6f m/s, eta=%.3e\n'], Case.name, elapsed_seconds, ...
            Metrics.first_status, Metrics.stop_reason, Metrics.final_index, ...
            final_impulse, eta_final);
    catch exception
        elapsed_seconds = toc(case_timer);
        if ~isfolder(case_directory)
            mkdir(case_directory);
        end
        error_id = fopen(fullfile(case_directory, 'case_error.txt'), ...
            'w', 'n', 'UTF-8');
        fprintf(error_id, 'identifier: %s\nmessage: %s\n', ...
            exception.identifier, exception.message);
        for s = 1:numel(exception.stack)
            fprintf(error_id, 'at %s (line %d)\n', ...
                exception.stack(s).name, exception.stack(s).line);
        end
        fclose(error_id);
        fprintf('[CASE] %s failed %.1f s\n', Case.name, elapsed_seconds);
        fprintf('[CASE] %s ERROR: %s (%s)\n', Case.name, exception.message, ...
            exception.identifier);
    end
end
fprintf('ALL_DONE (%.1f s)\n', toc);

%% ===== 汇总分析 =====
if run_analysis && exist('analyze_sccp_compare', 'file') == 2
    analyze_sccp_compare(results_root);
end
