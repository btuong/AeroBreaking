function ConstraintBlock = build_control_continuity_block( ...
        VariableIndex, CurrentReference, config)
% BUILD_CONTROL_CONTINUITY_BLOCK 构建相邻节点 u1 差值有界的线性约束（每圈内部，双边）。
%
% 数学形式:
%   −δ_u ≤ u1_(i+1) − u1_i ≤ δ_u，每圈内相邻节点 i,i+1。
%   δ_u = config.trust_region.consecutive_u，圈间不约束。
%   config.constraints.enable_control_continuity = false 时不发该块，供固定参考对照。
%
% 代码形式（每个相邻节点对 1 行）:
%   变量列与系数: VariableIndex.u1(i+1) +1，VariableIndex.u1(i) −1；
%   lower = −δ_u，upper = δ_u。该线性约束无需线性化，不加松弛。

    PointsBounds = CurrentReference.PointsBounds;
    consecutive_u = config.trust_region.consecutive_u;

    ConstraintBlock.name = 'control_continuity';
    ConstraintBlock.row_index = [];
    ConstraintBlock.column_index = [];
    ConstraintBlock.value = [];
    lower = [];
    upper = [];
    if ~config.constraints.enable_control_continuity
        ConstraintBlock.lower = lower;
        ConstraintBlock.upper = upper;
        return;
    end

    row = 0;
    for cir = 1:config.scenario.total_cir
        current_begin = PointsBounds(cir).begin;
        current_end = PointsBounds(cir).end;
        for i = current_begin:(current_end - 1)
            row = row + 1;
            ConstraintBlock.row_index = [ ...
                ConstraintBlock.row_index; row; row];
            ConstraintBlock.column_index = [ ...
                ConstraintBlock.column_index; ...
                VariableIndex.u1(i + 1); VariableIndex.u1(i)];
            ConstraintBlock.value = [ConstraintBlock.value; 1; -1];
            lower = [lower; -consecutive_u];
            upper = [upper; consecutive_u];
        end
    end

    ConstraintBlock.lower = lower;
    ConstraintBlock.upper = upper;
end
