function ReformulationReport = ...
        evaluate_conic_reformulation_consistency( ...
            SolverResult, ConicConstraints, config)
% EVALUATE_CONIC_REFORMULATION_CONSISTENCY 检查本轮 P3 的解在各二阶锥上的可行性和紧性。
%
% 对每个锥检查 feasibility_residual = max(||y||-t, 0)；
% 并按 Cone.tightness_role 检查紧性 tightness_gap = |t - ||y|||：
%   none     只查可行性。
%   epigraph 目标里系数为正的上图锥，t 应取紧（容差 conic_tightness_tolerance）。
%   lossless P1 非凸等式的无损凸化锥（control_disk：‖u‖<=1 恢复 ‖u‖=1），
%            容差 lossless_tightness_tolerance；紧性是必检项。
%
% 每个锥的指标另存 index（同名锥中的序号；control_disk 即节点号）和
% leading_value、vector_norm，打印详细输出时用来定位节点。
%
% 本检查只报告，不作接受门槛，不修改解。

    if ~SolverResult.success
        error('SCP:UnavailableConicSolution', ...
            '求解失败时不能检查二阶锥重构关系。');
    end
    cone_values = ConicConstraints.mapping * SolverResult.primal(:) ...
        + ConicConstraints.offset;
    if any(~isfinite(cone_values))
        error('SCP:NonfiniteConicValue', ...
            '二阶锥仿射映射包含 NaN 或 Inf。');
    end

    num_cones = numel(ConicConstraints.cones);
    for cone_index = 1:num_cones
        Cone = ConicConstraints.cones(cone_index);
        metrics(cone_index) = evaluate_quadratic_cone_metric( ...
            Cone, cone_values(Cone.rows), config.validation);
    end

    failed = ~[metrics.feasibility_satisfied] ...
        | ([metrics.tightness_checked] & ~[metrics.tightness_satisfied]);
    ReformulationReport.success = ~any(failed);
    ReformulationReport.evaluated = true;
    ReformulationReport.metrics = metrics;
    ReformulationReport.failed_names = {metrics(failed).name};

    [ReformulationReport.max_feasibility_residual, fi] = ...
        max([metrics.feasibility_residual]);
    ReformulationReport.max_feasibility_name = metrics(fi).name;

    epigraph = metrics(strcmp({metrics.tightness_role}, 'epigraph'));
    [ReformulationReport.max_epigraph_gap, ...
        ReformulationReport.max_epigraph_name] = ...
        summarize_tightness(epigraph);
    lossless = metrics(strcmp({metrics.tightness_role}, 'lossless'));
    [ReformulationReport.max_lossless_gap, ...
        ReformulationReport.max_lossless_name] = ...
        summarize_tightness(lossless);
end


function [max_gap, max_name] = summarize_tightness(Metrics)
% SUMMARIZE_TIGHTNESS 汇总同一紧性角色锥的最大紧性差值。

    if isempty(Metrics)
        max_gap = 0;
        max_name = '';
    else
        [max_gap, max_index] = max([Metrics.tightness_gap]);
        max_name = Metrics(max_index).name;
    end
end


function Metric = evaluate_quadratic_cone_metric( ...
        Cone, cone_value, validation_config)
% EVALUATE_QUADRATIC_CONE_METRIC 计算单个二阶锥的可行性残差与紧性差值。

    leading_value = cone_value(1);
    vector_norm = norm(cone_value(2:end), 2);
    feasibility_residual = max(vector_norm - leading_value, 0);

    Metric = struct();
    Metric.name = Cone.name;
    Metric.index = Cone.index;
    Metric.type = Cone.type;
    Metric.dimension = Cone.dimension;
    Metric.tightness_role = Cone.tightness_role;
    Metric.tightness_checked = ~strcmp(Cone.tightness_role, 'none');
    Metric.leading_value = leading_value;
    Metric.vector_norm = vector_norm;
    Metric.feasibility_residual = feasibility_residual;
    Metric.feasibility_tolerance = ...
        validation_config.conic_feasibility_tolerance;
    Metric.feasibility_satisfied = feasibility_residual ...
        <= validation_config.conic_feasibility_tolerance;

    switch Cone.tightness_role
        case 'none'
            tightness_tolerance = NaN;
        case 'epigraph'
            tightness_tolerance = validation_config.conic_tightness_tolerance;
        case 'lossless'
            tightness_tolerance = validation_config.lossless_tightness_tolerance;
        otherwise
            error('SCP:InvalidTightnessRole', ...
                '锥 %s 的 tightness_role 无效。', Cone.name);
    end

    if Metric.tightness_checked
        tightness_gap = abs(leading_value - vector_norm);
        Metric.tightness_gap = tightness_gap;
        Metric.tightness_tolerance = tightness_tolerance;
        Metric.tightness_satisfied = tightness_gap ...
            <= tightness_tolerance;
    else
        Metric.tightness_gap = NaN;
        Metric.tightness_tolerance = NaN;
        Metric.tightness_satisfied = true;
    end
end
