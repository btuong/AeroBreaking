function draw_radius_tiles(fig, HistorySeries, config)
% DRAW_RADIUS_TILES 画半径与步长: 半径 r、最大步长/半径、K 估计。
%
% 输入:
%   fig            - 目标图窗
%   HistorySeries  - plot_scp_result 整理好的迭代序列，各轮 plot_data 含 trust_region
%   config         - 读取 config.plot.font_size 与 config.trust_region
%
% 三个分块（横轴为迭代序号）:
%   1. 半径 r: 每轮画 r 前→后的台阶，点画在本轮所用的 r 上；下限、r_max 画虚线。
%   2. 最大步长/半径: r、V、γ、φ、ψ、P 六个通道里最大的一个；1（半径边界）画虚线。
%      各通道的值见终端“迭代分析”块的展开表。
%   3. K 估计 D/‖d‖²，对数纵轴。
% 动力学余项按阶和驻点度量在另一扇窗（draw_stationarity_tiles）。
% 标记约定与其他全程图一致: 接受实心点、拒绝空心点、P3 失败红叉，含义写在标题
% 下面一行；三块各只有一条曲线，不进图例，纵轴标签就是它的名字，图例里只有几条界；
% 不在图上加文字标注。没算出的轮留空，不补零。

    iters = HistorySeries.iter;
    status = HistorySeries.status;
    TrustData = collect_trust_series(HistorySeries);
    pick = @(field) [TrustData.(field)];
    Palette = build_analysis_palette();

    layout = create_tile_layout(fig, 3);
    tile_axes = gobjects(1, 3);
    for j = 1:3
        tile_axes(j) = nexttile(layout);
    end
    notes = {describe_status_marks(status)};

    draw_radius_tile(tile_axes(1), iters, status, TrustData, Palette.single, ...
        config);
    draw_step_ratio_tile(tile_axes(2), iters, status, TrustData, ...
        Palette.single, config);
    notes = [notes, draw_log_history_tile(tile_axes(3), iters, status, ...
        build_log_series('K 估计', pick('curvature_estimate'), ...
            Palette.single, false), ...
        'K 估计 D/‖d‖²', config)];

    finish_tile_window(layout, tile_axes, '半径与步长', notes, config);
end


function draw_radius_tile(ax, iters, status, TrustData, color, config)
% DRAW_RADIUS_TILE 画半径 r 的台阶，点画在本轮所用的 r 上；下限、r_max 画虚线。

    hold(ax, 'on');
    scale_before = [TrustData.scale_before];
    scale_after = [TrustData.scale_after];
    % 每轮画 [r_前, r_后] 的竖直段；下一轮 r_前 与本轮 r_后 相同，
    % 竖直段之间自然连成台阶
    step_x = reshape([iters(:)'; iters(:)'], 1, []);
    step_y = reshape([scale_before; scale_after], 1, []);
    plot(ax, step_x, step_y, '-', 'Color', color, 'LineWidth', 1.5, ...
        'DisplayName', 'r', 'Tag', 'series');
    mark_history_status(ax, iters, status, scale_before, color);
    yline(ax, config.trust_region.min_scale, '--k', 'LineWidth', 1.2, ...
        'DisplayName', '下限');
    yline(ax, config.trust_region.max_scale, '-.k', 'LineWidth', 1.2, ...
        'DisplayName', 'r_max');

    set(ax, 'YScale', 'log');
    ylim(ax, [config.trust_region.min_scale / 1.5, ...
        config.trust_region.max_scale * 1.5]);
    mark_failed_rounds(ax, iters, status);
    finish_history_axes(ax, iters, '半径 r', config);
end


function draw_step_ratio_tile(ax, iters, status, TrustData, color, config)
% DRAW_STEP_RATIO_TILE 画各通道里最大的步长/半径，1（半径边界）画虚线。

    hold(ax, 'on');
    step_ratio = [TrustData.step_ratio];
    plot(ax, iters, step_ratio, '-', 'Color', color, 'LineWidth', 1.5, ...
        'DisplayName', '最大步长/半径', 'Tag', 'series');
    mark_history_status(ax, iters, status, step_ratio, color);
    yline(ax, 1, ':k', 'LineWidth', 1.5, 'DisplayName', '半径边界');
    fit_axis_limits(ax, 1);
    mark_failed_rounds(ax, iters, status);
    finish_history_axes(ax, iters, '最大步长/半径', config);
end
