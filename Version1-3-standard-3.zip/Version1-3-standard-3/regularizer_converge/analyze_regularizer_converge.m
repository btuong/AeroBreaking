function [Summary, Check] = analyze_regularizer_converge(results_root, pictures_root, delta, window)
% ANALYZE_REGULARIZER_CONVERGE 汇总控制正则长迭代对比实验：读各工况结果，算指标，写汇总文件，画图。
%
% 只读各工况目录里的 case_metrics.mat 和 scp_run_control.mat，不重跑 SCP，可单独运行。
% 缺失或失败的工况在表里记为 '-'，不影响其余工况。
%
% 本实验的“基本不变”看相对 none 的同轮差值 d_c,k = C_c,k − C_none,k（C 为各轮总脉冲，m/s）：
% 最后 window 轮 d 的极差 ≤ delta 记为“差值已稳定”；差值稳定轮 = 最早的 k，使所有 j ≥ k
% 有 |d_c,j − d_c,末轮| ≤ delta。norm 各档间的比较另用参照 norm_w1e-5 的差值 d′。
% 节点量（M3～M8）一律取末轮（各工况最后被接受的一轮）。
%
% 输入（均可省略）:
%   results_root  - 各工况结果所在目录，默认 <本文件夹>/results
%   pictures_root - 图的输出目录，默认 <本文件夹>/pictures
%   delta         - 差值稳定的阈值 δ (m/s)，默认 0.1
%   window        - 差值稳定看最后几轮，默认 5
%
% 输出:
%   Summary - 1 x 21 结构体数组，每工况一项，字段是汇总表里的全部数值
%   Check   - 第 5 节核对的数值
%   同时写 results/长迭代汇总.txt、results/长迭代汇总.mat 和 pictures/ 下的 PNG。
%
% 节点分组以 none 工况末轮的 q_i = ‖s_main,i‖/ω_i 为准：q_i < 1e-6 的节点为退化节点 D，
% 其余为升力有效节点 E，所有工况共用。指标定义见本文件夹 README.md 第 3 节。
%
% 本函数依次完成：
%   1. 补路径并确定目录和参数。
%   2. 读取各工况的结果。
%   3. 按 none 工况确定节点分组。
%   4. 逐工况算指标。
%   5. 算相对 none 与相对 norm_w1e-5 的差值及稳定性。
%   6. 核对（前 10 轮回归、Γ 预测误差、节点分组）。
%   7. 写汇总文本和 MAT。
%   8. 画图。

    %% 1. 补路径并确定目录和参数
    converge_root = fileparts(mfilename('fullpath'));
    version_root = fileparts(converge_root);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));
    addpath(fullfile(version_root, 'subproblem'), fullfile(version_root, 'output'), ...
        converge_root);
    if nargin < 1 || isempty(results_root)
        results_root = fullfile(converge_root, 'results');
    end
    if nargin < 2 || isempty(pictures_root)
        pictures_root = fullfile(converge_root, 'pictures');
    end
    if nargin < 3 || isempty(delta)
        delta = 0.1;
    end
    if nargin < 4 || isempty(window)
        window = 5;
    end
    Options = struct('delta', delta, 'window', window, 'reference_norm', 'norm_w1e-5');

    %% 2. 读取各工况的结果
    CaseData = load_case_data(list_converge_cases(), results_root);

    %% 3. 按 none 工况确定节点分组
    Groups = determine_node_groups(CaseData);

    %% 4. 逐工况算指标
    Summary = compute_all_indicators(CaseData, Groups, Options);

    %% 5. 算相对 none 与相对 norm_w1e-5 的差值及稳定性
    Summary = add_difference_indicators(Summary, Options);

    %% 6. 核对（前 10 轮回归、Γ 预测误差、节点分组）
    Check = check_run(Summary, Groups, version_root);

    %% 7. 写汇总文本和 MAT
    write_converge_text(fullfile(results_root, '长迭代汇总.txt'), Summary, Groups, ...
        Check, Options);
    save(fullfile(results_root, '长迭代汇总.mat'), 'Summary', 'Groups', 'Check', 'Options');

    %% 8. 画图
    plot_converge_figures(Summary, Groups, Options, pictures_root);
end


%% ===== 读取结果 =====

function CaseData = load_case_data(Cases, results_root)
% LOAD_CASE_DATA 读各工况的 case_metrics.mat 与 scp_run_control.mat，核对版本和正则方式。
%
% 每个工况一项，字段: name、type、w、state（'ok'、'no_solution'、'failed'、'missing'）、
% Metrics、attempts（P3 求解成功的各次尝试，含 control_report）、error_message。

    data_list = cell(1, numel(Cases));
    for c = 1:numel(Cases)
        Case = Cases(c);
        Data = struct('name', Case.name, 'type', Case.type, 'w', Case.w, ...
            'state', 'missing', 'Metrics', [], 'attempts', [], 'error_message', '');
        case_directory = fullfile(results_root, Case.name);
        metrics_path = fullfile(case_directory, 'case_metrics.mat');
        control_path = fullfile(case_directory, 'scp_run_control.mat');
        error_path = fullfile(case_directory, 'case_error.txt');
        if isfile(metrics_path) && isfile(control_path)
            Loaded = load(metrics_path);
            Control = load(control_path);
            % 核对存档：版本目录和正则方式必须与工况一致，避免跨版本误读
            if ~strcmp(Control.ControlExport.version_root, 'Version1-3-standard-3') ...
                    || ~strcmp(Control.ControlExport.reg_type, Case.type)
                error('Converge:ArchiveMismatch', ...
                    '工况 %s 的存档版本或正则方式与预期不符（%s，%s）。', Case.name, ...
                    Control.ControlExport.version_root, Control.ControlExport.reg_type);
            end
            Data.Metrics = Loaded.Metrics;
            attempts = Control.ControlExport.attempts;
            if isempty(attempts)
                solved = false(0, 1);
            else
                solved = arrayfun(@(a) logical(a.control_report.evaluated), attempts);
            end
            Data.attempts = attempts(solved);
            if Loaded.Metrics.num_accepted > 0
                Data.state = 'ok';
            else
                Data.state = 'no_solution';
            end
        elseif isfile(error_path)
            Data.state = 'failed';
            Data.error_message = strtrim(fileread(error_path));
        end
        data_list{c} = Data;
    end
    CaseData = [data_list{:}];
end


function Groups = determine_node_groups(CaseData)
% DETERMINE_NODE_GROUPS 以 none 工况末轮的 q_i = ‖s_main,i‖/ω_i 划分退化节点 D 与升力有效节点 E。
%
% 数学形式:
%   D = {i : q_i < 1e-6}，E = 其余节点。q_i 是主问题对 u_i 的需求按积分权归一化后的大小。
%
% 代码形式:
%   Groups 的字段: available（none 工况可用）、N、tau、cir（节点的圈内 τ 与圈号）、
%   q（none 末轮的 q_i）、D、E（N x 1 逻辑量）、num_D、num_E。
%   none 不可用时 D 全为假、E 全为真，available 为假。

    Groups = struct('available', false, 'N', NaN, 'tau', [], 'cir', [], 'q', [], ...
        'D', [], 'E', [], 'num_D', NaN, 'num_E', NaN, 'threshold', 1e-6);
    reference_index = find(strcmp({CaseData.state}, 'ok'), 1);
    none_index = find(strcmp({CaseData.type}, 'none') ...
        & strcmp({CaseData.state}, 'ok'), 1);
    if isempty(reference_index)
        return;
    end
    if isempty(none_index)
        Report = pick_final_report(CaseData(reference_index));
    else
        Report = pick_final_report(CaseData(none_index));
    end
    Groups.N = Report.num_nodes;
    Groups.tau = Report.tau;
    Groups.cir = Report.cir;
    if isempty(none_index) || ~Report.dual_available
        Groups.D = false(Groups.N, 1);
        Groups.E = true(Groups.N, 1);
        Groups.num_D = 0;
        Groups.num_E = Groups.N;
        return;
    end
    Groups.available = true;
    Groups.q = Report.s_main_norm ./ Report.omega;
    Groups.D = Groups.q < Groups.threshold;
    Groups.E = ~Groups.D;
    Groups.num_D = sum(Groups.D);
    Groups.num_E = sum(Groups.E);
end


function Report = pick_final_report(Data)
% PICK_FINAL_REPORT 取一个工况最后被接受那次尝试的控制量报告。

    accepted = [Data.attempts.accepted];
    Report = Data.attempts(find(accepted, 1, 'last')).control_report;
end


%% ===== 逐工况指标 =====

function Summary = compute_all_indicators(CaseData, Groups, Options)
% COMPUTE_ALL_INDICATORS 逐工况算 README 第 3 节的指标（不含跨工况的差值）。

    none_index = find(strcmp({CaseData.type}, 'none') ...
        & strcmp({CaseData.state}, 'ok'), 1);
    reference_index = find(strcmp({CaseData.name}, Options.reference_norm) ...
        & strcmp({CaseData.state}, 'ok'), 1);
    none_sigma = [];
    reference_sigma = [];
    if ~isempty(none_index)
        none_sigma = pick_final_report(CaseData(none_index)).sigma_deg;
    end
    if ~isempty(reference_index)
        reference_sigma = pick_final_report(CaseData(reference_index)).sigma_deg;
    end
    max_rounds = 1;
    for c = 1:numel(CaseData)
        if ~isempty(CaseData(c).Metrics)
            max_rounds = max(max_rounds, numel(CaseData(c).Metrics.accepted));
        end
    end
    indicator_list = cell(1, numel(CaseData));
    for c = 1:numel(CaseData)
        indicator_list{c} = compute_case_indicators(CaseData(c), Groups, ...
            none_sigma, reference_sigma, max_rounds);
    end
    Summary = [indicator_list{:}];
end


function Indicator = compute_case_indicators(Data, Groups, none_sigma, reference_sigma, ...
        max_rounds)
% COMPUTE_CASE_INDICATORS 算一个工况的 M1、M3～M8 指标（取自末轮或全部轮次）。
%
% 数学形式:
%   e_i = u_i/‖u_i‖，P_i^⊥ = I − e_i e_i^T，ν_i = −e_i^T s_main,i，
%   t_i = ‖P_i^⊥ s_reg,i‖/‖s_main,i‖，q_i = ‖s_main,i‖/ω_i。
%   末轮 = 最后被接受的一轮；E、D 为共用节点分组；紧节点指 |1−‖u_i‖| ≤ 1e-6。
%   M3 取 E 中紧且 reg_ratio < 1 的节点；线性正则的预测角 arcsin(min(1, w ω_i ‖c‖/‖s_main,i‖))，
%   c 为该方式的系数向量（sum: (1,1)，u1: (1,0)，u2: (0,1)）。
%
% 代码形式:
%   工况不是 'ok' 时数值字段全为 NaN，只保留名称和状态。

    Indicator = create_empty_indicator(Data, max_rounds);
    if ~strcmp(Data.state, 'ok')
        return;
    end

    Attempts = Data.attempts;
    Metrics = Data.Metrics;
    num_attempts = numel(Attempts);
    iters = [Attempts.iter];
    final_position = find([Attempts.accepted], 1, 'last');
    Report = Attempts(final_position).control_report;
    num_nodes = Report.num_nodes;
    E = Groups.E;
    D = Groups.D;
    w = Data.w;
    if isnan(w)
        w = 0;
    end

    sigma = zeros(num_nodes, num_attempts);
    gap = zeros(num_nodes, num_attempts);
    for k = 1:num_attempts
        sigma(:, k) = Attempts(k).control_report.sigma_deg;
        gap(:, k) = abs(Attempts(k).control_report.tight_gap);
    end
    final_sigma = sigma(:, final_position);
    final_gap = gap(:, final_position);
    final_iter = Attempts(final_position).iter;

    %% M1 平台与末轮总脉冲
    series = place_series(Metrics.total_impulse_m_s, (1:numel(Metrics.accepted))', max_rounds);
    Indicator.final_iter = final_iter;
    Indicator.num_attempted = Metrics.num_attempted;
    Indicator.elapsed_seconds = Metrics.elapsed_seconds;
    Indicator.mean_round_seconds = mean(Metrics.iter_seconds, 'omitnan');
    Indicator.plateau_start = Metrics.plateau_start_iter;
    Indicator.impulse_series = series;
    Indicator.impulse_final = series(final_iter);
    Indicator.max_ratio = Metrics.max_ratio(final_iter);
    Indicator.apoapsis_km = Metrics.apoapsis_km(final_iter);
    Indicator.inclination_deg = Metrics.inclination_deg(final_iter);
    Indicator.final_feasible = double(Metrics.feasible(final_iter));
    last_infeasible = find(~Metrics.feasible, 1, 'last');
    if isempty(last_infeasible)
        Indicator.feasible_from = 1;
    else
        Indicator.feasible_from = last_infeasible + 1;
    end
    Indicator.C_final = Metrics.C(final_iter);
    Indicator.Gamma_final = Metrics.Gamma(final_iter);
    Indicator.Theta_final = Metrics.Theta(final_iter);
    Indicator.final_sigma = final_sigma;
    Indicator.final_report_ok = true;

    %% M3 方向偏差（末轮，E 中紧且主问题占主导的节点）
    e = [Report.u1, Report.u2] ./ Report.u_norm;
    s_main = Report.s_main;
    s_reg = Report.s_reg;
    s_main_norm = Report.s_main_norm;
    perpendicular = s_reg - e .* sum(e .* s_reg, 2);
    t_ratio = vecnorm(perpendicular, 2, 2) ./ s_main_norm;
    selected = E & final_gap <= 1e-6 & Report.reg_ratio < 1;
    shift = abs(Report.sigma_shift_deg(selected));
    Indicator.m3_count = sum(selected);
    Indicator.m3_shift_mean = mean(shift);
    Indicator.m3_shift_median = median(shift);
    Indicator.m3_shift_p95 = compute_percentile(shift, 95);
    Indicator.m3_t_median = median(t_ratio(selected));
    Indicator.m3_t_p95 = compute_percentile(t_ratio(selected), 95);
    coefficient = [];
    switch Data.type
        case 'sum'
            coefficient = [1, 1];
        case 'u1'
            coefficient = [1, 0];
        case 'u2'
            coefficient = [0, 1];
    end
    if ~isempty(coefficient)
        predicted = asind(min(1, w * Report.omega * norm(coefficient) ./ s_main_norm));
        Indicator.m3_predicted_median = median(predicted(selected));
    end

    %% M4 σ 偏差（末轮）
    if ~isempty(none_sigma)
        deviation = abs(wrap_angle_deg(final_sigma - none_sigma));
        Indicator.m4_E_median = median(deviation(E));
        Indicator.m4_E_mean = mean(deviation(E));
        Indicator.m4_D_median = median(deviation(D));
    end
    if strcmp(Data.type, 'norm') && ~isempty(reference_sigma)
        deviation = abs(wrap_angle_deg(final_sigma - reference_sigma));
        Indicator.m4_ref_E_median = median(deviation(E));
        Indicator.m4_ref_E_mean = mean(deviation(E));
    end

    %% M5 径向乘子（末轮，E 上的 ν/ω）
    radial = -sum(e .* s_main, 2);
    nu_over_omega = radial ./ Report.omega;
    nu_E = nu_over_omega(E);
    Indicator.m5_negative = sum(nu_E < 0);
    Indicator.m5_below_w = sum(nu_E < -w);
    Indicator.m5_min = min(nu_E);
    Indicator.m5_p5 = compute_percentile(nu_E, 5);
    Indicator.m5_median = median(nu_E);
    Indicator.nu_E = nu_E;

    %% M6 紧性余量
    tight = final_gap <= 1e-6;
    cone_norm = vecnorm(Report.s_cone, 2, 2);
    s_total_norm = vecnorm(Report.s_total, 2, 2);
    if strcmp(Data.type, 'norm')
        denominator = radial + w * Report.omega;
        valid = tight & denominator > 0;
        margin = cone_norm(valid) ./ denominator(valid);
        Indicator.m6_cone_median = median(margin);
        Indicator.m6_cone_p5 = compute_percentile(margin, 5);
        Indicator.m6_cone_p95 = compute_percentile(margin, 95);
        Indicator.cone_x = (radial(tight) + w * Report.omega(tight)) ./ Report.omega(tight);
        Indicator.cone_y = cone_norm(tight) ./ Report.omega(tight);
    end
    if ismember(Data.type, {'sum', 'u1', 'u2'})
        relative_total = s_total_norm ./ Report.omega;
        Indicator.m6_total_min = min(relative_total(E));
        Indicator.m6_total_small = sum(relative_total(E) < 0.1 * w);
    end
    Indicator = add_numerical_law(Indicator, Attempts);
    Indicator.final_gap_values = final_gap;
    Indicator.final_s_total = s_total_norm;

    %% M7 紧性（全部轮次）
    nodes_over = sum(gap > 1e-6, 1);
    Indicator.gap_max_series = place_series(max(gap, [], 1)', iters, max_rounds);
    Indicator.m7_gap_max = max(gap(:));
    Indicator.m7_rounds_gt_1e6 = sum(nodes_over > 0);
    Indicator.m7_max_nodes_gt_1e6 = max(nodes_over);
    Indicator.m7_rounds_gt_1e3 = sum(any(gap > 1e-3, 1));

    %% M8 惯性
    Indicator.turn_series = place_series(Metrics.turn_median_deg, ...
        (1:numel(Metrics.accepted))', max_rounds);
    kept = all(abs(wrap_angle_deg(sigma - 45)) <= 15, 2);
    Indicator.m8_kept_E = sum(kept & E);
    Indicator.m8_kept_D = sum(kept & D);

    %% 步长 > 1 的轮
    Indicator = add_large_step_rounds(Indicator, Metrics, Attempts, sigma, gap);

    %% 控制预测误差与 Γ
    Indicator.error_gamma_series = place_series(Metrics.error_gamma, ...
        (1:numel(Metrics.accepted))', max_rounds);
    Indicator.max_error_gamma = max(Metrics.error_gamma, [], 'omitnan');
    Indicator.max_abs_error_gamma = max(abs(Metrics.error_gamma), [], 'omitnan');
    Indicator.convex_error_flag = any(Metrics.convex_error_flag);
end


function Indicator = add_numerical_law(Indicator, Attempts)
% ADD_NUMERICAL_LAW 全部轮次的数值紧性律：(1−‖u‖²)‖s_cone‖/‖u‖ 的 log10 分布，及 log gap 对 log‖s_total‖ 的回归。
%
% 数学形式:
%   中心路径上 (1−‖u‖²)‖s_cone‖/‖u‖ = μ。只取 gap = 1−‖u‖ > 0 且 s_cone、s_total 非零的节点。
%   回归 log10 gap = a + b·log10‖s_total‖，报告斜率 b 与 R²。

    log_law = [];
    gap_all = [];
    s_all = [];
    for k = 1:numel(Attempts)
        R = Attempts(k).control_report;
        un = R.u_norm(:);
        sc = vecnorm(R.s_cone, 2, 2);
        st = vecnorm(R.s_total, 2, 2);
        gap = 1 - un;
        positive = gap > 0 & sc > 0 & st > 0;
        log_law = [log_law; log10((1 - un(positive).^2) .* sc(positive) ./ un(positive))]; %#ok<AGROW>
        gap_all = [gap_all; gap(positive)]; %#ok<AGROW>
        s_all = [s_all; st(positive)]; %#ok<AGROW>
    end
    Indicator.law_count = numel(log_law);
    if numel(log_law) < 3
        return;
    end
    quartiles = compute_percentile_set(log_law, [25 50 75]);
    Indicator.law_median = quartiles(2);
    Indicator.law_iqr = quartiles(3) - quartiles(1);
    X = [ones(numel(gap_all), 1), log10(s_all)];
    coefficient = X \ log10(gap_all);
    residual = log10(gap_all) - X * coefficient;
    Indicator.law_slope = coefficient(2);
    Indicator.law_R2 = 1 - sum(residual.^2) ...
        / sum((log10(gap_all) - mean(log10(gap_all))).^2);
end


function Indicator = add_large_step_rounds(Indicator, Metrics, Attempts, sigma, gap)
% ADD_LARGE_STEP_ROUNDS 列出步长（相邻解差）> 1 的轮及这些轮的紧性和控制通道情况。
%
% 代码形式:
%   第 1 轮没有上一轮解，不列。控制通道最大差 max(|Δu1|, |Δu2|) 与步长相等（比值 ≥ 0.999）
%   时，记该轮步长由控制通道决定。σ 翻转用相邻两轮的 |Δσ|（规约后）最大值和 > 90° 的节点数描述。

    steps = Metrics.step_max;
    rounds = find(steps > 1);
    rounds = rounds(rounds >= 2 & rounds <= numel(Attempts));
    count = numel(rounds);
    result = struct('round', rounds(:), 'step', steps(rounds), ...
        'max_gap', zeros(count, 1), 'untight', zeros(count, 1), ...
        'control_step', zeros(count, 1), 'max_dsigma', zeros(count, 1), ...
        'flip_nodes', zeros(count, 1));
    for n = 1:count
        k = rounds(n);
        R = Attempts(k).control_report;
        P = Attempts(k - 1).control_report;
        control_step = max(max(abs(R.u1 - P.u1)), max(abs(R.u2 - P.u2)));
        delta_sigma = abs(wrap_angle_deg(sigma(:, k) - sigma(:, k - 1)));
        result.max_gap(n) = max(gap(:, k));
        result.untight(n) = sum(gap(:, k) > 1e-6);
        result.control_step(n) = control_step;
        result.max_dsigma(n) = max(delta_sigma);
        result.flip_nodes(n) = sum(delta_sigma > 90);
    end
    Indicator.large_step = result;
end


function Indicator = create_empty_indicator(Data, max_rounds)
% CREATE_EMPTY_INDICATOR 创建字段齐全、数值全为 NaN 的指标结构体。

    scalar_names = {'final_iter', 'num_attempted', 'elapsed_seconds', ...
        'mean_round_seconds', 'plateau_start', 'impulse_final', 'max_ratio', ...
        'apoapsis_km', 'inclination_deg', 'final_feasible', 'feasible_from', ...
        'C_final', 'Gamma_final', 'Theta_final', 'm3_count', 'm3_shift_mean', ...
        'm3_shift_median', 'm3_shift_p95', 'm3_t_median', 'm3_t_p95', ...
        'm3_predicted_median', 'm4_E_median', 'm4_E_mean', 'm4_D_median', ...
        'm4_ref_E_median', 'm4_ref_E_mean', 'm5_negative', 'm5_below_w', 'm5_min', ...
        'm5_p5', 'm5_median', 'm6_cone_median', 'm6_cone_p5', 'm6_cone_p95', ...
        'm6_total_min', 'm6_total_small', 'law_count', 'law_median', 'law_iqr', ...
        'law_slope', 'law_R2', 'm7_gap_max', 'm7_rounds_gt_1e6', ...
        'm7_max_nodes_gt_1e6', 'm7_rounds_gt_1e3', 'm8_kept_E', 'm8_kept_D', ...
        'max_error_gamma', 'max_abs_error_gamma', ...
        'd_final', 'd_mean_last', 'd_range_last', 'd_stable', 'd_stable_round', ...
        'dp_final', 'dp_mean_last', 'dp_range_last', 'dp_stable', 'dp_stable_round', ...
        'impulse_mean_last', 'impulse_range_last', 'impulse_decrease_last10'};
    series_names = {'impulse_series', 'gap_max_series', 'turn_series', ...
        'error_gamma_series', 'd_series', 'dp_series'};
    Indicator = struct('name', Data.name, 'type', Data.type, 'w', Data.w, ...
        'state', Data.state, 'stop_reason', '', 'error_message', Data.error_message, ...
        'convex_error_flag', false, 'final_sigma', [], 'final_report_ok', false, ...
        'nu_E', [], 'cone_x', [], 'cone_y', [], 'final_gap_values', [], ...
        'final_s_total', [], 'large_step', struct('round', [], 'step', [], ...
        'max_gap', [], 'untight', [], 'control_step', [], 'max_dsigma', [], ...
        'flip_nodes', []));
    for k = 1:numel(scalar_names)
        Indicator.(scalar_names{k}) = NaN;
    end
    for k = 1:numel(series_names)
        Indicator.(series_names{k}) = nan(max_rounds, 1);
    end
    if ~isempty(Data.Metrics)
        Indicator.stop_reason = Data.Metrics.stop_reason;
        Indicator.num_attempted = Data.Metrics.num_attempted;
        Indicator.elapsed_seconds = Data.Metrics.elapsed_seconds;
    end
end


function series = place_series(values, iters, max_rounds)
% PLACE_SERIES 把按尝试序号排列的逐轮值放进 max_rounds x 1 的列，缺的轮为 NaN。

    series = nan(max_rounds, 1);
    series(iters) = values(:);
end


function value = compute_percentile(values, percent)
% COMPUTE_PERCENTILE 线性插值分位数，percent 取 0～100；空输入返回 NaN。

    value = compute_percentile_set(values, percent);
end


function values_out = compute_percentile_set(values, percents)
% COMPUTE_PERCENTILE_SET 对一组分位点（0～100）取线性插值分位数；空输入返回 NaN。

    values = sort(values(~isnan(values(:))));
    count = numel(values);
    values_out = nan(size(percents));
    if count == 0
        return;
    end
    for k = 1:numel(percents)
        position = 1 + (count - 1) * percents(k) / 100;
        lower_index = floor(position);
        upper_index = ceil(position);
        values_out(k) = values(lower_index) ...
            + (position - lower_index) * (values(upper_index) - values(lower_index));
    end
end


%% ===== 差值与稳定性 =====

function Summary = add_difference_indicators(Summary, Options)
% ADD_DIFFERENCE_INDICATORS 补相对 none 的差值 d 和相对 norm_w1e-5 的差值 d′ 及其稳定性，以及总脉冲末段统计。
%
% 数学形式:
%   d_c,k = C_c,k − C_none,k；d′_c,k = C_c,k − C_{norm_w1e-5},k（只对 norm 各档）。
%   稳定 ⇔ 最后 window 轮的极差 ≤ δ；稳定轮 = 最早的 k，使所有 j ≥ k 有 |d_j − d_末轮| ≤ δ。
%   末轮取各工况自己最后被接受的一轮；没有 none（或参照）数据时相应字段为 NaN。

    names = {Summary.name};
    none_index = find(strcmp(names, 'none') & strcmp({Summary.state}, 'ok'), 1);
    reference_index = find(strcmp(names, Options.reference_norm) ...
        & strcmp({Summary.state}, 'ok'), 1);
    for c = 1:numel(Summary)
        if ~strcmp(Summary(c).state, 'ok')
            continue;
        end
        S = Summary(c);
        series = S.impulse_series;
        final_iter = S.final_iter;
        window = Options.window;
        range_index = max(1, final_iter - window + 1):final_iter;
        S.impulse_mean_last = mean(series(range_index));
        S.impulse_range_last = max(series(range_index)) - min(series(range_index));
        if final_iter > 10
            S.impulse_decrease_last10 = (series(final_iter - 10) - series(final_iter)) / 10;
        end
        if ~isempty(none_index)
            S = fill_difference(S, series - Summary(none_index).impulse_series, '', Options);
        end
        if strcmp(S.type, 'norm') && ~isempty(reference_index)
            S = fill_difference(S, series - Summary(reference_index).impulse_series, ...
                'p', Options);
        end
        Summary(c) = S;
    end
end


function S = fill_difference(S, difference, tag, Options)
% FILL_DIFFERENCE 由差值序列写入末轮值、最后几轮均值与极差、是否稳定和稳定轮。tag 为 '' 或 'p'。

    final_iter = S.final_iter;
    range_index = max(1, final_iter - Options.window + 1):final_iter;
    last_values = difference(range_index);
    S.(['d' tag '_series']) = difference;
    S.(['d' tag '_final']) = difference(final_iter);
    S.(['d' tag '_mean_last']) = mean(last_values);
    S.(['d' tag '_range_last']) = max(last_values) - min(last_values);
    S.(['d' tag '_stable']) = double(S.(['d' tag '_range_last']) <= Options.delta);
    within = abs(difference(1:final_iter) - difference(final_iter)) <= Options.delta;
    last_outside = find(~within, 1, 'last');
    if isempty(last_outside)
        S.(['d' tag '_stable_round']) = 1;
    else
        S.(['d' tag '_stable_round']) = last_outside + 1;
    end
end


%% ===== 核对 =====

function Check = check_run(Summary, Groups, version_root)
% CHECK_RUN 做 README 第 5 节的三项核对，返回数值（判定留给文本写出处）。
%
% 代码形式:
%   item1: 每个工况前 10 轮总脉冲与阶段2 case_metrics.mat 逐轮之差的最大绝对值；
%   item2: 线性三种的 Γ 预测误差 max|D_Γ|，norm 的 max D_Γ（应不大于 0）；
%   item3: none 末轮 D/E 规模，与阶段2 的 96/565 对照。

    compare_root = fullfile(fileparts(version_root), 'Version1-3-standard-2', ...
        'regularizer_compare', 'results');
    item1 = struct('name', {}, 'max_diff', {}, 'num_rounds', {});
    for c = 1:numel(Summary)
        S = Summary(c);
        old_path = fullfile(compare_root, S.name, 'case_metrics.mat');
        if ~strcmp(S.state, 'ok') || ~isfile(old_path)
            item1(end + 1) = struct('name', S.name, 'max_diff', NaN, 'num_rounds', 0); %#ok<AGROW>
            continue;
        end
        Old = load(old_path).Metrics;
        count = min(numel(Old.total_impulse_m_s), numel(S.impulse_series));
        difference = abs(S.impulse_series(1:count) - Old.total_impulse_m_s(1:count));
        item1(end + 1) = struct('name', S.name, ... %#ok<AGROW>
            'max_diff', max(difference), 'num_rounds', count);
    end
    Check.item1 = item1;
    Check.item2 = struct('name', {{Summary.name}}, 'type', {{Summary.type}}, ...
        'max_abs_error_gamma', [Summary.max_abs_error_gamma], ...
        'max_error_gamma', [Summary.max_error_gamma], ...
        'convex_error_flag', [Summary.convex_error_flag]);
    Check.item3 = struct('num_D', Groups.num_D, 'num_E', Groups.num_E, ...
        'old_D', 96, 'old_E', 565);
end


%% ===== 汇总文本 =====

function write_converge_text(text_path, Summary, Groups, Check, Options)
% WRITE_CONVERGE_TEXT 写 results/长迭代汇总.txt（UTF-8），各节表格用定宽列。
%
% 本函数依次完成：
%   1. 运行清单与节点分组。
%   2. M1 平台与差值稳定表。
%   3. M2 与 none 之差。
%   4. M3～M5 方向偏差、σ 偏差、径向乘子。
%   5. M6、M7 紧性。
%   6. M8 惯性与步长大于 1 的轮。
%   7. M9 逐轮序列。
%   8. 核对。

    file_id = fopen(text_path, 'w', 'n', 'UTF-8');
    if file_id < 0
        error('Converge:OpenFailed', '无法打开汇总文件：%s。', text_path);
    end
    cleanup = onCleanup(@() fclose(file_id));
    fprintf(file_id, '控制正则方式长迭代对比汇总（Version1-3-standard-3，阶段3-1）\n');
    fprintf(file_id, ['角度单位 deg；总脉冲单位 m/s；"-" 表示不适用或没有数据。\n' ...
        '差值稳定判据: 最后 %d 轮 d 的极差 ≤ δ = %g m/s；差值稳定轮 = 最早的 k，使所有 j ≥ k ' ...
        '有 |d_j − d_末轮| ≤ δ。d = 与 none 的同轮总脉冲差，d′ = 与 norm_w1e-5 的同轮差。\n' ...
        'M3～M8 的节点量取各工况末轮。\n'], Options.window, Options.delta);

    write_run_list(file_id, Summary, Groups);
    write_m1_table(file_id, Summary);
    write_m2_table(file_id, Summary, Options);
    write_direction_tables(file_id, Summary);
    write_tightness_tables(file_id, Summary);
    write_inertia_tables(file_id, Summary);
    write_round_series(file_id, Summary);
    write_check(file_id, Check);
end


function write_run_list(file_id, Summary, Groups)
% WRITE_RUN_LIST 第 1 节：运行清单，加节点分组 |D|、|E| 与 D 的 τ 范围。

    fprintf(file_id, '\n=== 1 运行清单 ===\n');
    rows = cell(numel(Summary), 7);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, S.type, format_value(S.w, '%.0e'), S.state, ...
            format_value(S.num_attempted, '%d'), char_or_dash(S.stop_reason), ...
            format_value(S.elapsed_seconds, '%.1f')};
    end
    write_table(file_id, {'工况', 'type', 'w', '状态', '尝试轮数', '停止原因', '用时(s)'}, ...
        rows);
    failed = Summary(strcmp({Summary.state}, 'failed'));
    for c = 1:numel(failed)
        fprintf(file_id, '失败工况 %s: %s\n', failed(c).name, ...
            strrep(failed(c).error_message, newline, ' | '));
    end

    fprintf(file_id, '\n节点分组（以 none 工况末轮 q_i = ‖s_main,i‖/ω_i < %.0e 为退化节点 D）:\n', ...
        Groups.threshold);
    if ~Groups.available
        fprintf(file_id, '  none 工况不可用，分组无法确定（D 记为空）。\n');
        return;
    end
    fprintf(file_id, '  节点总数 N = %d，退化节点 |D| = %d，升力有效节点 |E| = %d\n', ...
        Groups.N, Groups.num_D, Groups.num_E);
    for cir = 1:max(Groups.cir)
        in_cir = Groups.cir == cir;
        in_D = in_cir & Groups.D;
        if any(in_D)
            fprintf(file_id, '  圈 %d: D 节点 %d 个，τ ∈ [%.4f, %.4f]（该圈 τ ∈ [%.4f, %.4f]）\n', ...
                cir, sum(in_D), min(Groups.tau(in_D)), max(Groups.tau(in_D)), ...
                min(Groups.tau(in_cir)), max(Groups.tau(in_cir)));
        else
            fprintf(file_id, '  圈 %d: 无 D 节点\n', cir);
        end
    end
    fprintf(file_id, '  E 节点 q_i 中位数 %.3e，D 节点 q_i 最大 %.3e\n', ...
        median(Groups.q(Groups.E)), max([Groups.q(Groups.D); 0]));
end


function write_m1_table(file_id, Summary)
% WRITE_M1_TABLE 第 2 节：M1 平台与差值稳定表（总脉冲末段统计、d、d′ 及稳定轮）。

    fprintf(file_id, '\n=== 2 M1 平台表 ===\n');
    rows = cell(numel(Summary), 12);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, char_or_dash(S.stop_reason), ...
            format_value(S.plateau_start, '%d'), format_value(S.final_iter, '%d'), ...
            format_value(S.impulse_final, '%.4f'), format_value(S.impulse_mean_last, '%.4f'), ...
            format_value(S.impulse_decrease_last10, '%.4f'), ...
            format_value(S.impulse_range_last, '%.4f'), format_value(S.max_ratio, '%.4f'), ...
            format_value(S.apoapsis_km, '%.3f'), format_value(S.inclination_deg, '%.4f'), ...
            format_value(S.feasible_from, '%d')};
    end
    write_table(file_id, {'工况', '停止原因', '平台起始轮', '末轮', '末轮总脉冲', ...
        '末5轮均值', '末10轮降幅/轮', '末5轮极差', '违反比', '远地点km', '倾角deg', ...
        '起可行轮'}, rows);

    fprintf(file_id, '\n与 none、与 norm_w1e-5 的差值（d、d′）:\n');
    rows = cell(numel(Summary), 11);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.d_final, '%+.4f'), ...
            format_value(S.d_mean_last, '%+.4f'), format_value(S.d_range_last, '%.4f'), ...
            stable_text(S.d_stable), format_value(S.d_stable_round, '%d'), ...
            format_value(S.dp_final, '%+.4f'), format_value(S.dp_mean_last, '%+.4f'), ...
            format_value(S.dp_range_last, '%.4f'), stable_text(S.dp_stable), ...
            format_value(S.dp_stable_round, '%d')};
    end
    write_table(file_id, {'工况', 'd末轮', 'd末5轮均值', 'd末5轮极差', 'd稳定', 'd稳定轮', ...
        'd′末轮', 'd′末5轮均值', 'd′末5轮极差', 'd′稳定', 'd′稳定轮'}, rows);
end


function write_m2_table(file_id, Summary, Options)
% WRITE_M2_TABLE 第 3 节：M2 与 none 之差；线性三种 log|d|-log w 斜率；norm 各档两两最大差。

    fprintf(file_id, '\n=== 3 M2 性能指标偏差 ===\n');
    fprintf(file_id, '线性三种 |d| > 3δ = %.2f 的档上 log10|d| 对 log10 w 的斜率:\n', 3 * Options.delta);
    rows = cell(0, 5);
    for type = {'sum', 'u1', 'u2'}
        mask = strcmp({Summary.type}, type{1}) & strcmp({Summary.state}, 'ok');
        w = [Summary(mask).w];
        values = [Summary(mask).d_final];
        mean_values = [Summary(mask).d_mean_last];
        for source = {values, mean_values}
            use = abs(source{1}) > 3 * Options.delta & ~isnan(source{1});
            slope = NaN;
            if sum(use) >= 2
                coefficient = polyfit(log10(w(use)), log10(abs(source{1}(use))), 1);
                slope = coefficient(1);
            end
            if isequal(source{1}, values)
                label = '末轮 d';
            else
                label = '末5轮均值 d';
            end
            rows(end + 1, :) = {type{1}, label, format_value(sum(use), '%d'), ... %#ok<AGROW>
                format_value(slope, '%.3f'), mat2str(w(use), 2)};
        end
    end
    write_table(file_id, {'type', '取值', '参与档数', '斜率', '参与的 w'}, rows);

    norm_mask = strcmp({Summary.type}, 'norm') & strcmp({Summary.state}, 'ok');
    fprintf(file_id, '\nnorm 各档两两最大差（max − min）:\n');
    if any(norm_mask)
        final_values = [Summary(norm_mask).impulse_final];
        mean_values = [Summary(norm_mask).impulse_mean_last];
        fprintf(file_id, '  末轮总脉冲 %.4f；末5轮均值 %.4f（档数 %d）\n', ...
            max(final_values) - min(final_values), max(mean_values) - min(mean_values), ...
            sum(norm_mask));
    end
end


function write_direction_tables(file_id, Summary)
% WRITE_DIRECTION_TABLES 第 4 节：M3 方向偏差、M4 σ 偏差、M5 径向乘子。

    fprintf(file_id, '\n=== 4 M3 方向偏差（末轮，E 中紧且 reg_ratio<1 的节点） ===\n');
    rows = cell(numel(Summary), 8);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.m3_count, '%d'), ...
            format_value(S.m3_shift_mean, '%.4f'), format_value(S.m3_shift_median, '%.4f'), ...
            format_value(S.m3_shift_p95, '%.4f'), format_value(S.m3_t_median, '%.3e'), ...
            format_value(S.m3_t_p95, '%.3e'), format_value(S.m3_predicted_median, '%.4f')};
    end
    write_table(file_id, {'工况', '节点数', '|σ_shift|均值', '|σ_shift|中位', ...
        '|σ_shift| p95', 't中位', 't p95', '预测角中位'}, rows);

    fprintf(file_id, '\n=== 5 M4 σ 偏差（末轮，|σ_c − σ_none| 与 |σ_c − σ_norm_w1e-5|） ===\n');
    rows = cell(numel(Summary), 6);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.m4_E_median, '%.4f'), ...
            format_value(S.m4_E_mean, '%.4f'), format_value(S.m4_D_median, '%.4f'), ...
            format_value(S.m4_ref_E_median, '%.4f'), format_value(S.m4_ref_E_mean, '%.4f')};
    end
    write_table(file_id, {'工况', 'E中位', 'E均值', 'D中位', '相对norm_w1e-5 E中位', ...
        '相对norm_w1e-5 E均值'}, rows);

    fprintf(file_id, '\n=== 6 M5 径向乘子 ν/ω（末轮，E 上） ===\n');
    rows = cell(numel(Summary), 6);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.m5_negative, '%d'), ...
            format_value(S.m5_below_w, '%d'), format_value(S.m5_min, '%.3e'), ...
            format_value(S.m5_p5, '%.3e'), format_value(S.m5_median, '%.3e')};
    end
    write_table(file_id, {'工况', '<0 节点数', '<−w 节点数', '最小值', '5%分位', '中位数'}, rows);
end


function write_tightness_tables(file_id, Summary)
% WRITE_TIGHTNESS_TABLES 第 5 节：M6 紧性余量与数值紧性律，M7 紧性。

    fprintf(file_id, '\n=== 7 M6 紧性余量 ===\n');
    fprintf(file_id, 'norm: 末轮紧节点上 ‖s_cone‖/(ν+wω)；线性三种: 末轮 E 上 min‖s_total‖/ω 与 <0.1w 的节点数。\n');
    rows = cell(numel(Summary), 6);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.m6_cone_median, '%.4f'), ...
            format_value(S.m6_cone_p5, '%.4f'), format_value(S.m6_cone_p95, '%.4f'), ...
            format_value(S.m6_total_min, '%.3e'), format_value(S.m6_total_small, '%d')};
    end
    write_table(file_id, {'工况', 'cone比中位', 'cone比5%', 'cone比95%', 'min‖s_total‖/ω', ...
        '<0.1w 节点数'}, rows);

    fprintf(file_id, '\n数值紧性律（全部轮次，gap > 0 的节点）: log10[(1−‖u‖²)‖s_cone‖/‖u‖] 与 log gap 对 log‖s_total‖ 回归\n');
    rows = cell(numel(Summary), 6);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.law_count, '%d'), ...
            format_value(S.law_median, '%.2f'), format_value(S.law_iqr, '%.2f'), ...
            format_value(S.law_slope, '%.3f'), format_value(S.law_R2, '%.3f')};
    end
    write_table(file_id, {'工况', '节点数', 'log10 p中位', 'IQR', '斜率', 'R²'}, rows);

    fprintf(file_id, '\n=== 8 M7 紧性（全部轮次） ===\n');
    rows = cell(numel(Summary), 5);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.m7_gap_max, '%.2e'), ...
            format_value(S.m7_rounds_gt_1e6, '%d'), ...
            format_value(S.m7_max_nodes_gt_1e6, '%d'), format_value(S.m7_rounds_gt_1e3, '%d')};
    end
    write_table(file_id, {'工况', '各轮max gap的最大值', 'gap>1e-6轮数', '单轮最多节点数', ...
        'gap>1e-3轮数'}, rows);
end


function write_inertia_tables(file_id, Summary)
% WRITE_INERTIA_TABLES 第 6 节：M8 惯性（始终在 45°±15° 内的节点数），及步长 > 1 的轮。

    fprintf(file_id, '\n=== 9 M8 惯性 ===\n');
    rows = cell(numel(Summary), 6);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.m8_kept_E, '%d'), format_value(S.m8_kept_D, '%d'), ...
            format_value(S.turn_series(min(5, end)), '%.3f'), ...
            format_value(S.turn_series(min(20, end)), '%.3f'), ...
            format_value(S.turn_series(max(1, S.final_iter)), '%.3f')};
    end
    write_table(file_id, {'工况', '全程45±15° E', '全程45±15° D', '转角中位 轮5', ...
        '转角中位 轮20', '转角中位 末轮'}, rows);
    fprintf(file_id, '（转角中位数的逐轮序列见第 11 节；平台起始轮全为 "-"，差值稳定轮见第 2 节。）\n');

    fprintf(file_id, '\n=== 10 步长 > 1 的轮（相邻解差 > 1，第 1 轮不列） ===\n');
    fprintf(file_id, ['列: 轮号、步长、控制通道最大差 max(|Δu1|,|Δu2|)、该轮 max gap、不紧节点数、' ...
        '相邻轮 σ 最大变化(deg)、变化 > 90° 的节点数。\n']);
    rows = cell(0, 8);
    for c = 1:numel(Summary)
        L = Summary(c).large_step;
        for n = 1:numel(L.round)
            if L.control_step(n) >= 0.999 * L.step(n)
                owner = '是';
            else
                owner = '否';
            end
            rows(end + 1, :) = {Summary(c).name, format_value(L.round(n), '%d'), ... %#ok<AGROW>
                format_value(L.step(n), '%.3f'), format_value(L.control_step(n), '%.3f'), ...
                format_value(L.max_gap(n), '%.2e'), format_value(L.untight(n), '%d'), ...
                format_value(L.max_dsigma(n), '%.1f'), [format_value(L.flip_nodes(n), '%d') ...
                ' (控制通道决定步长: ' owner ')']};
        end
    end
    if isempty(rows)
        fprintf(file_id, '无。\n');
    else
        write_table(file_id, {'工况', '轮', '步长', '控制通道差', 'max gap', '不紧节点数', ...
            'σ最大变化', '翻转节点数'}, rows);
    end
end


function write_round_series(file_id, Summary)
% WRITE_ROUND_SERIES 第 11 节：M9 逐轮序列（总脉冲、d、max gap、转角中位数），每工况一行。

    fprintf(file_id, '\n=== 11 M9 逐轮序列 ===\n');
    series_specs = { ...
        'impulse_series', '各轮总脉冲 (m/s)', '%.3f'; ...
        'd_series', '各轮 d = 总脉冲 − none (m/s)', '%+.3f'; ...
        'dp_series', '各轮 d′ = 总脉冲 − norm_w1e-5 (m/s)', '%+.3f'; ...
        'gap_max_series', '各轮 max|1-‖u‖|', '%.1e'; ...
        'turn_series', '各轮转角中位数 (deg，全部节点)', '%.2f'};
    num_rounds = numel(Summary(1).impulse_series);
    headers = [{'工况'}, arrayfun(@(k) sprintf('轮%d', k), 1:num_rounds, ...
        'UniformOutput', false)];
    for s = 1:size(series_specs, 1)
        fprintf(file_id, '\n%s:\n', series_specs{s, 2});
        rows = cell(numel(Summary), num_rounds + 1);
        for c = 1:numel(Summary)
            values = Summary(c).(series_specs{s, 1});
            rows{c, 1} = Summary(c).name;
            for k = 1:num_rounds
                rows{c, k + 1} = format_value(values(k), series_specs{s, 3});
            end
        end
        write_table(file_id, headers, rows);
    end
end


function write_check(file_id, Check)
% WRITE_CHECK 第 12 节：核对（前 10 轮回归、Γ 预测误差、节点分组）。

    fprintf(file_id, '\n=== 12 核对 ===\n');
    fprintf(file_id, '\n(1) 前 10 轮回归: 各工况前 10 轮总脉冲与阶段2 逐轮之差的最大绝对值（要求 < 1e-6 m/s）\n');
    rows = cell(numel(Check.item1), 4);
    for k = 1:numel(Check.item1)
        I = Check.item1(k);
        rows(k, :) = {I.name, format_value(I.num_rounds, '%d'), ...
            format_value(I.max_diff, '%.3e'), judge_text(I.max_diff < 1e-6)};
    end
    write_table(file_id, {'工况', '比较轮数', '最大差', '判定'}, rows);

    I2 = Check.item2;
    fprintf(file_id, '\n(2) Γ 预测误差: 线性三种与 none 各轮 max|D_Γ|（要求 ≤ 1e-12）；norm 各轮 max D_Γ（要求 ≤ 1e-12，应为非正）\n');
    rows = cell(0, 4);
    for k = 1:numel(I2.name)
        if isnan(I2.max_abs_error_gamma(k))
            continue;
        end
        if strcmp(I2.type{k}, 'norm')
            value = I2.max_error_gamma(k);
        else
            value = I2.max_abs_error_gamma(k);
        end
        rows(end + 1, :) = {I2.name{k}, format_value(value, '%.3e'), ... %#ok<AGROW>
            judge_text(value <= 1e-12), judge_text(~I2.convex_error_flag(k), '无报警', '报警')};
    end
    write_table(file_id, {'工况', 'max 误差', '判定', '凸项一致性'}, rows);

    I3 = Check.item3;
    fprintf(file_id, '\n(3) 节点分组: none 末轮 |D| = %g，|E| = %g；阶段2 为 %d/%d\n', ...
        I3.num_D, I3.num_E, I3.old_D, I3.old_E);
end


function text = judge_text(passed, pass_text, fail_text)
% JUDGE_TEXT 把判定结果写成文字，默认“一致 / 不一致”。

    if nargin < 2
        pass_text = '一致';
        fail_text = '不一致';
    end
    if passed
        text = pass_text;
    else
        text = fail_text;
    end
end


function text = stable_text(flag)
% STABLE_TEXT 把稳定标志写成文字；NaN 写成 '-'。

    if isnan(flag)
        text = '-';
    elseif flag > 0
        text = '是';
    else
        text = '否';
    end
end


function text = format_value(value, spec)
% FORMAT_VALUE 按格式写一个数；NaN 写成 '-'，Inf 写成 'Inf'。

    if isnan(value)
        text = '-';
    elseif isinf(value)
        text = 'Inf';
    else
        text = sprintf(spec, value);
    end
end


function text = char_or_dash(value)
% CHAR_OR_DASH 空字符串写成 '-'。

    if isempty(value)
        text = '-';
    else
        text = value;
    end
end


function write_table(file_id, headers, rows)
% WRITE_TABLE 按显示宽度对齐写表：首列左对齐，其余列右对齐，列间两个空格。
%
% 中文等全角字符占两格，所以不用 %-20s，而是自己补空格。

    all_rows = [headers; rows];
    num_columns = size(all_rows, 2);
    widths = zeros(1, num_columns);
    for c = 1:num_columns
        widths(c) = max(cellfun(@display_width, all_rows(:, c)));
    end
    for r = 1:size(all_rows, 1)
        parts = cell(1, num_columns);
        for c = 1:num_columns
            padding = blanks(widths(c) - display_width(all_rows{r, c}));
            if c == 1
                parts{c} = [all_rows{r, c}, padding];
            else
                parts{c} = [padding, all_rows{r, c}];
            end
        end
        fprintf(file_id, '%s\n', strjoin(parts, '  '));
    end
end


function width = display_width(text)
% DISPLAY_WIDTH 文字的显示宽度：中文等全角字符占两格，其余占一格。

    width = sum(1 + (double(text) >= 11904));
end


%% ===== 画图 =====

function plot_converge_figures(Summary, Groups, Options, pictures_root)
% PLOT_CONVERGE_FIGURES 画 README 第 4 节的图并导出 PNG。
%
% 横轴 w 用对数坐标，每种方式一条线并固定颜色；none 画水平虚线。
%
% 本函数依次完成：
%   1. 各轮总脉冲图与两张差值随轮次图（关键图）。
%   2. 末轮差值图与差值稳定轮图。
%   3. 方向偏差图与 σ 偏差图。
%   4. 径向乘子图与紧性余量图。
%   5. 末轮 σ 图。

    if ~isfolder(pictures_root)
        mkdir(pictures_root);
    end
    plot_round_impulse_figure(Summary, Options, pictures_root);
    plot_difference_rounds_figure(Summary, Options, pictures_root);
    plot_norm_difference_figure(Summary, Options, pictures_root);
    plot_final_difference_figure(Summary, Options, pictures_root);
    plot_stable_round_figure(Summary, pictures_root);
    plot_direction_figure(Summary, pictures_root);
    plot_deviation_figure(Summary, pictures_root);
    plot_radial_multiplier_figure(Summary, pictures_root);
    plot_tightness_margin_figure(Summary, pictures_root);
    plot_final_sigma_figure(Summary, Groups, 1e-3, pictures_root);
end


function plot_round_impulse_figure(Summary, ~, pictures_root)
% PLOT_ROUND_IMPULSE_FIGURE 长迭代-各轮总脉冲：5 个子图（每档 w 一个），各方式总脉冲随轮次。

    font_size = 16;
    fig = figure('Name', '长迭代-各轮总脉冲', 'NumberTitle', 'off', 'Visible', 'off', ...
        'Position', [100, 100, 1100, 1000]);
    layout = tiledlayout(fig, 3, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    title(layout, '各轮总脉冲', 'FontSize', font_size);
    handles = gobjects(1, 0);
    first_axes = [];
    for exponent = 2:6
        ax = nexttile(layout);
        hold(ax, 'on');
        w_text = sprintf('1e-%d', exponent);
        names = [arrayfun(@(t) sprintf('%s_w%s', t{1}, w_text), ...
            {'sum', 'u1', 'u2', 'norm'}, 'UniformOutput', false), {'none'}];
        for k = 1:numel(names)
            index = find(strcmp({Summary.name}, names{k}), 1);
            if isempty(index) || ~strcmp(Summary(index).state, 'ok')
                continue;
            end
            S = Summary(index);
            Style = get_type_style(S.type);
            h = plot(ax, 1:numel(S.impulse_series), S.impulse_series, line_style_of(S.type), ...
                'Color', Style.color, 'LineWidth', 1.5, 'DisplayName', Style.label);
            if ~isnan(S.plateau_start)
                xline(ax, S.plateau_start, ':', 'Color', Style.color, 'HandleVisibility', 'off');
            end
            if exponent == 2
                handles(end + 1) = h; %#ok<AGROW>
            end
        end
        ylim(ax, [85, 130]);
        style_axes(ax, sprintf('总脉冲 (m/s)，w=%s', w_text), '迭代轮次', font_size);
        if exponent == 2
            first_axes = ax;
        end
    end
    place_shared_legend(first_axes, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '长迭代-各轮总脉冲.png'));
end


function plot_difference_rounds_figure(Summary, Options, pictures_root)
% PLOT_DIFFERENCE_ROUNDS_FIGURE 长迭代-与none差值随轮次：每档 w 一个子图，各方式 d 随轮次，画 0 线和 ±δ 带。

    font_size = 16;
    fig = figure('Name', '长迭代-与none差值随轮次', 'NumberTitle', 'off', 'Visible', 'off', ...
        'Position', [100, 100, 1100, 1000]);
    layout = tiledlayout(fig, 3, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    title(layout, sprintf('与 none 的同轮总脉冲差 d（阴影为 ±δ = %g m/s）', Options.delta), ...
        'FontSize', font_size);
    handles = gobjects(1, 0);
    first_axes = [];
    for exponent = 2:6
        ax = nexttile(layout);
        hold(ax, 'on');
        w_text = sprintf('1e-%d', exponent);
        num_rounds = numel(Summary(1).impulse_series);
        patch(ax, 'XData', [1 num_rounds num_rounds 1], ...
            'YData', Options.delta * [-1 -1 1 1], 'FaceColor', [0.8 0.8 0.8], ...
            'FaceAlpha', 0.5, 'EdgeColor', 'none', 'HandleVisibility', 'off');
        yline(ax, 0, '--', 'Color', get_type_style('none').color, 'LineWidth', 1.2, ...
            'HandleVisibility', 'off');
        for type = {'sum', 'u1', 'u2', 'norm'}
            index = find(strcmp({Summary.name}, sprintf('%s_w%s', type{1}, w_text)), 1);
            if isempty(index) || ~strcmp(Summary(index).state, 'ok')
                continue;
            end
            Style = get_type_style(type{1});
            h = plot(ax, 1:num_rounds, Summary(index).d_series, '-', 'Color', Style.color, ...
                'LineWidth', 1.5, 'DisplayName', Style.label);
            if exponent == 2
                handles(end + 1) = h; %#ok<AGROW>
            end
        end
        xlim(ax, [1 num_rounds]);
        style_axes(ax, sprintf('d (m/s)，w=%s', w_text), '迭代轮次', font_size);
        if exponent == 2
            first_axes = ax;
        end
    end
    place_shared_legend(first_axes, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '长迭代-与none差值随轮次.png'));
end


function plot_norm_difference_figure(Summary, Options, pictures_root)
% PLOT_NORM_DIFFERENCE_FIGURE 长迭代-norm各档差值随轮次：norm 各档相对 norm_w1e-5 的 |d′| 随轮次，纵轴对数。

    font_size = 16;
    fig = figure('Name', '长迭代-norm各档差值随轮次', 'NumberTitle', 'off', 'Visible', 'off');
    ax = axes(fig);
    hold(ax, 'on');
    colors = [0.00 0.45 0.70; 0.84 0.37 0.00; 0.00 0.62 0.45; 0.50 0.50 0.50; 0.80 0.47 0.65];
    handles = gobjects(1, 0);
    for exponent = 2:6
        index = find(strcmp({Summary.name}, sprintf('norm_w1e-%d', exponent)), 1);
        if isempty(index) || ~strcmp(Summary(index).state, 'ok') || exponent == 5
            continue;
        end
        series = abs(Summary(index).dp_series);
        series(series == 0) = NaN;
        handles(end + 1) = plot(ax, 1:numel(series), series, '-', ... %#ok<AGROW>
            'Color', colors(exponent - 1, :), 'LineWidth', 1.5, ...
            'DisplayName', sprintf('w=1e-%d', exponent));
    end
    set(ax, 'YScale', 'log');
    yline(ax, Options.delta, ':', 'Color', [0.3 0.3 0.3], 'LineWidth', 1.5, ...
        'DisplayName', sprintf('δ=%g', Options.delta));
    style_axes(ax, '|d′| = |总脉冲 − norm_w1e-5 总脉冲| (m/s)', '迭代轮次', font_size);
    title(ax, 'norm 各档相对 norm_{w=1e-5} 的同轮总脉冲差', 'FontSize', font_size);
    legend(ax, 'Location', 'best', 'FontSize', font_size);
    finish_figure(fig, fullfile(pictures_root, '长迭代-norm各档差值随轮次.png'));
end


function plot_final_difference_figure(Summary, Options, pictures_root)
% PLOT_FINAL_DIFFERENCE_FIGURE 长迭代-末轮差值：上为末轮总脉冲随 w，下为 |末轮 d| 随 w（双对数，画 δ 线）。

    font_size = 16;
    fig = figure('Name', '长迭代-末轮差值', 'NumberTitle', 'off', 'Visible', 'off');
    layout = tiledlayout(fig, 2, 1, 'TileSpacing', 'compact', 'Padding', 'compact');
    title(layout, '末轮总脉冲与相对 none 的差', 'FontSize', font_size);

    top_axes = nexttile(layout);
    hold(top_axes, 'on');
    handles = draw_type_lines(top_axes, Summary, 'impulse_final');
    handles = [handles, draw_none_line(top_axes, Summary, 'impulse_final')];
    style_axes(top_axes, '末轮总脉冲 (m/s)', '', font_size);

    bottom_axes = nexttile(layout);
    hold(bottom_axes, 'on');
    absolute = Summary;
    for c = 1:numel(absolute)
        absolute(c).abs_d_final = abs(absolute(c).d_final);
    end
    draw_type_lines(bottom_axes, absolute, 'abs_d_final');
    set(bottom_axes, 'YScale', 'log');
    yline(bottom_axes, Options.delta, ':', 'Color', [0.3 0.3 0.3], 'LineWidth', 1.5, ...
        'HandleVisibility', 'off');
    style_axes(bottom_axes, '|末轮 d| (m/s)', 'w', font_size);

    place_shared_legend(top_axes, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '长迭代-末轮差值.png'));
end


function plot_stable_round_figure(Summary, pictures_root)
% PLOT_STABLE_ROUND_FIGURE 长迭代-差值稳定轮：差值稳定轮随 w（实线 d；norm 另画 d′ 虚线）。

    font_size = 16;
    fig = figure('Name', '长迭代-差值稳定轮', 'NumberTitle', 'off', 'Visible', 'off');
    ax = axes(fig);
    hold(ax, 'on');
    handles = draw_type_lines(ax, Summary, 'd_stable_round');
    Style = get_type_style('norm');
    mask = strcmp({Summary.type}, 'norm') & strcmp({Summary.state}, 'ok');
    [w_sorted, order] = sort([Summary(mask).w]);
    values = [Summary(mask).dp_stable_round];
    handles(end + 1) = plot(ax, w_sorted, values(order), '--', 'Color', Style.color, ...
        'Marker', Style.marker, 'LineWidth', 1.5, 'DisplayName', '‖u‖ (d′)');
    style_axes(ax, '差值稳定轮', 'w', font_size);
    title(ax, '差值稳定轮（最早的 k，使其后各轮 d 与末轮之差都不超过 δ）', 'FontSize', font_size);
    legend(ax, handles, 'Location', 'best', 'FontSize', font_size);
    finish_figure(fig, fullfile(pictures_root, '长迭代-差值稳定轮.png'));
end


function plot_direction_figure(Summary, pictures_root)
% PLOT_DIRECTION_FIGURE 长迭代-方向偏差：M3 的 |σ_shift| 中位数（左）和 t 中位数（右）随 w，双对数。

    font_size = 16;
    fig = figure('Name', '长迭代-方向偏差', 'NumberTitle', 'off', 'Visible', 'off');
    layout = tiledlayout(fig, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    title(layout, '末轮方向偏差（E 中紧且主问题占主导的节点）', 'FontSize', font_size);
    left_axes = nexttile(layout);
    hold(left_axes, 'on');
    handles = draw_type_lines(left_axes, Summary, 'm3_shift_median');
    set(left_axes, 'YScale', 'log');
    style_axes(left_axes, '|σ_{shift}| 中位数 (deg)', 'w', font_size);
    right_axes = nexttile(layout);
    hold(right_axes, 'on');
    draw_type_lines(right_axes, Summary, 'm3_t_median');
    set(right_axes, 'YScale', 'log');
    style_axes(right_axes, 't 中位数', 'w', font_size);
    place_shared_legend(left_axes, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, '长迭代-方向偏差.png'));
end


function plot_deviation_figure(Summary, pictures_root)
% PLOT_DEVIATION_FIGURE 长迭代-相对无正则的σ偏差：M4（E 节点中位数）随 w。

    font_size = 16;
    fig = figure('Name', '长迭代-相对无正则的σ偏差', 'NumberTitle', 'off', 'Visible', 'off');
    ax = axes(fig);
    hold(ax, 'on');
    handles = draw_type_lines(ax, Summary, 'm4_E_median');
    set(ax, 'YScale', 'log');
    style_axes(ax, '|σ − σ_{none}| 中位数 (deg)', 'w', font_size);
    title(ax, '末轮 σ 相对不加正则的偏差（E 节点）', 'FontSize', font_size);
    legend(ax, handles, 'Location', 'best', 'FontSize', font_size);
    finish_figure(fig, fullfile(pictures_root, '长迭代-相对无正则的σ偏差.png'));
end


function plot_radial_multiplier_figure(Summary, pictures_root)
% PLOT_RADIAL_MULTIPLIER_FIGURE 长迭代-径向乘子：norm 各档 E 上 ν/ω 的经验分布函数，在 −w 处画竖线。

    font_size = 16;
    fig = figure('Name', '长迭代-径向乘子', 'NumberTitle', 'off', 'Visible', 'off', ...
        'Position', [100, 100, 1200, 800]);
    layout = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
    title(layout, '末轮 norm 各档径向乘子 ν/ω 的经验分布（E 节点，竖线为 −w）', ...
        'FontSize', font_size);
    for exponent = 2:6
        ax = nexttile(layout);
        hold(ax, 'on');
        index = find(strcmp({Summary.name}, sprintf('norm_w1e-%d', exponent)), 1);
        if ~isempty(index) && strcmp(Summary(index).state, 'ok')
            S = Summary(index);
            values = sort(S.nu_E);
            plot(ax, values, (1:numel(values)) / max(1, numel(values)), '-', ...
                'LineWidth', 1.5, 'Color', get_type_style('norm').color);
            xline(ax, -S.w, '--', 'Color', [0.2 0.2 0.2], 'LineWidth', 1.2);
        end
        style_axes(ax, sprintf('分布函数，w=1e-%d', exponent), 'ν/ω', font_size);
    end
    finish_figure(fig, fullfile(pictures_root, '长迭代-径向乘子.png'));
end


function plot_tightness_margin_figure(Summary, pictures_root)
% PLOT_TIGHTNESS_MARGIN_FIGURE 长迭代-紧性余量：左为 norm 各档 ‖s_cone‖/ω 对 ν/ω + w，右为末轮 gap 对 ‖s_total‖。

    font_size = 16;
    fig = figure('Name', '长迭代-紧性余量', 'NumberTitle', 'off', 'Visible', 'off', ...
        'Position', [100, 100, 1200, 550]);
    layout = tiledlayout(fig, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    colors = [0.00 0.45 0.70; 0.84 0.37 0.00; 0.00 0.62 0.45; 0.50 0.50 0.50; 0.80 0.47 0.65];
    left_axes = nexttile(layout);
    hold(left_axes, 'on');
    for exponent = 2:6
        index = find(strcmp({Summary.name}, sprintf('norm_w1e-%d', exponent)), 1);
        if isempty(index) || ~strcmp(Summary(index).state, 'ok')
            continue;
        end
        S = Summary(index);
        valid = S.cone_x > 0 & S.cone_y > 0;
        scatter(left_axes, S.cone_x(valid), S.cone_y(valid), 14, colors(exponent - 1, :), ...
            'filled', 'DisplayName', sprintf('w=1e-%d', exponent));
    end
    set(left_axes, 'XScale', 'log', 'YScale', 'log');
    limits = [1e-9, 1e2];
    plot(left_axes, limits, limits, 'k--', 'LineWidth', 1.2, 'DisplayName', 'y = x');
    style_axes(left_axes, '‖s_{cone}‖/ω', 'ν/ω + w', font_size);
    legend(left_axes, 'Location', 'northwest', 'FontSize', 12);

    right_axes = nexttile(layout);
    hold(right_axes, 'on');
    all_log = [];
    for c = 1:numel(Summary)
        S = Summary(c);
        if ~strcmp(S.state, 'ok') || isempty(S.final_gap_values)
            continue;
        end
        valid = S.final_gap_values > 0 & S.final_s_total > 0;
        scatter(right_axes, S.final_s_total(valid), S.final_gap_values(valid), 8, ...
            get_type_style(S.type).color, 'filled', 'HandleVisibility', 'off');
        all_log(end + 1) = S.law_median; %#ok<AGROW>
    end
    set(right_axes, 'XScale', 'log', 'YScale', 'log');
    mu = 10^median(all_log, 'omitnan');
    s_axis = logspace(-8, 2, 50);
    plot(right_axes, s_axis, mu ./ (2 * s_axis), 'k--', 'LineWidth', 1.2, ...
        'DisplayName', sprintf('μ/(2‖s‖)，μ=%.1e', mu));
    style_axes(right_axes, '末轮 gap = 1−‖u‖', '‖s_{total}‖', font_size);
    legend(right_axes, 'Location', 'northeast', 'FontSize', 12);
    finish_figure(fig, fullfile(pictures_root, '长迭代-紧性余量.png'));
end


function plot_final_sigma_figure(Summary, Groups, w_value, pictures_root)
% PLOT_FINAL_SIGMA_FIGURE 长迭代-末轮σ：每圈一个子图，五种方式末轮 σ 叠画，D 节点处加浅色底纹。

    font_size = 16;
    w_text = sprintf('1e-%d', round(-log10(w_value)));
    figure_name = ['长迭代-末轮σ_w' w_text];
    if ~Groups.available
        return;
    end
    fig = figure('Name', figure_name, 'NumberTitle', 'off', 'Visible', 'off', ...
        'Position', [100, 100, 1000, 1000]);
    num_circuits = max(Groups.cir);
    layout = tiledlayout(fig, num_circuits, 1, 'TileSpacing', 'compact', 'Padding', 'compact');
    title(layout, sprintf('末轮 σ（w = %s，浅色底纹为 D 节点）', w_text), 'FontSize', font_size);
    case_names = [arrayfun(@(t) sprintf('%s_w%s', t{1}, w_text), ...
        {'sum', 'u1', 'u2', 'norm'}, 'UniformOutput', false), {'none'}];
    handles = gobjects(1, 0);
    first_axes = [];
    for cir = 1:num_circuits
        ax = nexttile(layout);
        hold(ax, 'on');
        in_cir = Groups.cir == cir;
        tau = Groups.tau(in_cir);
        intervals = build_group_intervals(tau, Groups.D(in_cir));
        for k = 1:size(intervals, 1)
            patch(ax, 'XData', intervals(k, [1 1 2 2]), 'YData', [-180 180 180 -180], ...
                'FaceColor', [0.88 0.88 0.88], 'EdgeColor', 'none', 'HandleVisibility', 'off');
        end
        for k = 1:numel(case_names)
            index = find(strcmp({Summary.name}, case_names{k}), 1);
            if isempty(index) || isempty(Summary(index).final_sigma)
                continue;
            end
            Style = get_type_style(Summary(index).type);
            h = plot(ax, tau, Summary(index).final_sigma(in_cir), '-', ...
                'Color', Style.color, 'LineWidth', 1.2, 'DisplayName', Style.label, ...
                'Marker', Style.marker, 'MarkerSize', 5, 'MarkerFaceColor', Style.color, ...
                'MarkerIndices', 1:max(1, round(numel(tau) / 12)):numel(tau));
            if cir == 1
                handles(end + 1) = h; %#ok<AGROW>
            end
        end
        ylim(ax, [-190 190]);
        xlim(ax, [-0.02 1.02]);
        yticks(ax, [-180 0 180]);
        style_axes(ax, sprintf('圈%d σ (deg)', cir), '', font_size);
        if cir == num_circuits
            xlabel(ax, '圈内 τ', 'FontSize', font_size);
        end
        if cir == 1
            first_axes = ax;
        end
    end
    place_shared_legend(first_axes, handles, font_size);
    finish_figure(fig, fullfile(pictures_root, [figure_name '.png']));
end


function Style = get_type_style(type)
% GET_TYPE_STYLE 每种控制正则方式固定的颜色、标记形状和图上名称（全部图共用，与阶段2 相同）。

    switch type
        case 'sum'
            Style = struct('color', [0.00 0.45 0.70], 'marker', 'o', 'label', 'u1+u2');
        case 'u1'
            Style = struct('color', [0.84 0.37 0.00], 'marker', 's', 'label', 'u1');
        case 'u2'
            Style = struct('color', [0.00 0.62 0.45], 'marker', '^', 'label', 'u2');
        case 'norm'
            Style = struct('color', [0.80 0.47 0.65], 'marker', 'd', 'label', '‖u‖');
        otherwise
            Style = struct('color', [0.35 0.35 0.35], 'marker', 'none', 'label', '不加');
    end
end


function style = line_style_of(type)
% LINE_STYLE_OF none 画虚线，其余画实线。

    if strcmp(type, 'none')
        style = '--';
    else
        style = '-';
    end
end


function handles = draw_type_lines(ax, Summary, field)
% DRAW_TYPE_LINES 为 sum、u1、u2、norm 四种方式各画一条“指标 - w”曲线，返回线句柄；横轴对数。
%
% 只取状态为 ok 且该指标不是 NaN 的工况；w 升序。

    handles = gobjects(1, 0);
    for type = {'sum', 'u1', 'u2', 'norm'}
        mask = strcmp({Summary.type}, type{1}) & strcmp({Summary.state}, 'ok');
        w = [Summary(mask).w];
        values = [Summary(mask).(field)];
        valid = ~isnan(values);
        if ~any(valid)
            continue;
        end
        [w_sorted, order] = sort(w(valid));
        values_valid = values(valid);
        Style = get_type_style(type{1});
        handles(end + 1) = plot(ax, w_sorted, values_valid(order), '-', ... %#ok<AGROW>
            'Color', Style.color, 'Marker', Style.marker, 'MarkerFaceColor', Style.color, ...
            'LineWidth', 1.5, 'DisplayName', Style.label);
    end
    set(ax, 'XScale', 'log');
end


function handle = draw_none_line(ax, Summary, field)
% DRAW_NONE_LINE 把 none 工况的指标画成水平虚线；没有数据时返回空句柄数组。

    handle = gobjects(1, 0);
    mask = strcmp({Summary.type}, 'none') & strcmp({Summary.state}, 'ok');
    if ~any(mask) || isnan(Summary(mask).(field))
        return;
    end
    Style = get_type_style('none');
    handle = yline(ax, Summary(mask).(field), '--', 'Color', Style.color, 'LineWidth', 1.5, ...
        'DisplayName', Style.label);
end


function style_axes(ax, y_label, x_label, font_size)
% STYLE_AXES 统一字号、网格、坐标轴标签；横轴标签为 'w' 时写成 w_{reg}。

    set(ax, 'FontSize', font_size, 'Box', 'on');
    grid(ax, 'on');
    ylabel(ax, y_label, 'FontSize', font_size);
    if strcmp(x_label, 'w')
        xlabel(ax, 'w_{reg}', 'FontSize', font_size);
    elseif ~isempty(x_label)
        xlabel(ax, x_label, 'FontSize', font_size);
    end
end


function place_shared_legend(ax, handles, font_size)
% PLACE_SHARED_LEGEND 在多分块图窗底部放一个共用图例。

    legend_object = legend(ax, handles, 'Orientation', 'horizontal', ...
        'NumColumns', min(numel(handles), 5), 'FontSize', font_size);
    legend_object.Layout.Tile = 'south';
end


function finish_figure(fig, png_path)
% FINISH_FIGURE 导出 PNG 并关闭图窗。

    save_plot_figure(fig, png_path);
    close(fig);
end


function intervals = build_group_intervals(tau, mask)
% BUILD_GROUP_INTERVALS 把一圈内连续的 mask 节点合成 τ 区间 [起点, 终点]（相邻节点取中点为界）。

    intervals = zeros(0, 2);
    if isempty(tau) || ~any(mask)
        return;
    end
    midpoint = (tau(1:end-1) + tau(2:end)) / 2;
    lower_edge = [tau(1) - (midpoint(1) - tau(1)); midpoint(:)];
    upper_edge = [midpoint(:); tau(end) + (tau(end) - midpoint(end))];
    change = diff([false; mask(:); false]);
    starts = find(change == 1);
    stops = find(change == -1) - 1;
    intervals = [lower_edge(starts), upper_edge(stops)];
end
