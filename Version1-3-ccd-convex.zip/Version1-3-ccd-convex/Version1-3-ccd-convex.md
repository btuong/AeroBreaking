# Version1-3-ccd-convex：Lu (2020) 原文凹凸分解模式

自 `Version1-3-standard-3` 复制（2026-11-24）。按文章 [20]（Ping Lu, *JGCD*, 2020）原文 Eqs. (40)、(71)–(74) 实现可切换的凹凸分解（CCD）单位范数约束处理方式 `config.unit_norm.mode = 'ccd_lu'`，与 `Version1-3-standard-5` 的 `'ccd'` 模式保持隔离并保留原文两处核心写法：

1. **凹半平方线性化且零点不替换**（Eq. (72)）：`build_linear_constraints.m` 新增 `unit_norm_inner` 块，装配 $-2\bar u_{1,i} u_{1,i} - 2\bar u_{2,i} u_{2,i} \le -(1 + \bar u_{1,i}^2 + \bar u_{2,i}^2)$（不归一化为 $\bar e_i$，零节点系数保持 $[0, 0]$、上界 $-1$）；`initialize_scp_run.m` 启用 `ccd_normalize_initial_control`（默认 `true`）时仅对非零参考控制归一化，零向量保持 $(0,0)$。
2. **目标与罚函数不乘积分权 $\omega_i$**（Eqs. (40)、(74)）：P3 目标在 `unit_norm_slack`（$N$ 个逐节点松弛 $\varepsilon_1,\dots,\varepsilon_N$，位置 `(17*N+26):(18*N+25)`）上设常系数 $p = \texttt{ccd\_penalty\_weight}$（默认 `1e-2`）；P2 罚函数 $J$ 计入 $\Theta_{\text{unit}} = p \sum_{i=1}^N \max(\|u_i\|_2 - 1, 0)$，类别 `'inequality_penalty'`，控制附加项 $\Gamma = 0$。同时修复了 `evaluate_control_report.m` 在 `'norm_gap'` 配置下向 `'ccd_lu'` 误加偏置的问题，确保 `gamma_node` 全为 0。

默认 `'regularized'` 模式不变（布局 `17*N+25`、目标、约束、报告逐项一致）。主代码及文档修改清单见 [README.md](../Version1-3-ccd-convex/README.md) 与 [气动辅助降轨算法知识库.md](../Version1-3-ccd-convex/docs/algorithm_knowledge_base/气动辅助降轨算法知识库.md)。

**验证（2026-11-24）**：
- 单元测试与玩具问题：`test_unit_norm_ccd_lu.m`、`test_ccd_lu_toy_problem.m`、`test_control_tightness_mechanisms.m`、`test_control_reg_integration_weights.m` 共 20 个用例全部 `Passed`（覆盖平方行、零节点保零、零初值玩具问题不可行、目标/罚函数不乘 $\omega_i$、对偶驻点分解与全输出流程）。
- R1 回归：默认 `SCP.m`（`'regularized'`，10 轮）输出的 `results/scp_run_brief.txt`（SHA256 `81C6B9B5...41410B4DE`）和 `results/scp_run_detail.txt`（SHA256 `1F3DCE30...2AAFAFAC`）与 `../Version1-3-standard-3/results/` 对应文件逐字节一致；`results/scp_run_control.txt` 仅第 2 行版本名不同。
- `'ccd_lu'` 10 轮主链跑通（`p = 1e-2`、$\varepsilon_{\max} = 1$，存至 `Version1-3-ccd-convex/results/ccd_lu_10iter/`）：10 轮均以 `OPTIMAL` 求解并被接受，无节点触及 $\varepsilon$ 上界，`max|1-‖u‖|` 从第 1 轮 `3.894e-02` 降至第 10 轮 `8.222e-05`，末轮总脉冲 `128.840813 m/s`、对 P2 可行（`max_ratio = 8.902e-01`），圆约束组预测误差量级 `1e-11`，对偶驻点残差 $\le 1.92\times 10^{-7}$。

阶段 1 对比实验（`Version1-3-ccd-convex/ccd_lu_compare/`，fixed $r=1$、50 轮口径）运行 12 个 `ccd_lu` 工况并联合 `Version1-3-standard-5` 12 个只读存档对比：$p = 10^{-5}, 10^{-4}$ 触上界且圆外不紧（末轮 `79.25`、`87.10 m/s`），$p = 10^{-3}\dots 1$ 末轮 `99.81~129.48 m/s` 且 D 节点全紧；等总权配对 `ccd_lu_peq_1e-1` / `1e0` 较加权 `ccd_p1e-1` / `1e0` 末轮脉冲分别高 `+1.19` 与 `+4.19 m/s`，前者第 50 轮残留不紧（$>10^{-4}$）偏粗半单元（`41/6`）；全零初值与保界 `0.3` 初值均在第 1 轮 `PRIMAL_INFEASIBLE_CER`。数据见 [阶段1报告](../Version1-3-ccd-convex/docs/算法改进_阶段1_原文凹凸分解对比实验.md)。
