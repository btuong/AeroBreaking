function save_plot_figure(fig, relative_path)
% SAVE_PLOT_FIGURE 按指定相对路径把图窗导出为 PNG。
%
% 输入:
%   fig           - 要导出的图窗句柄
%   relative_path - 相对当前工作目录的路径，不含扩展名时可省略 .png；
%                   父目录不存在时自动创建，同名文件覆盖
%
% 导出前 drawnow 强制完成挂起的渲染；图窗 Visible='off' 时导出前临时
% 切为 on、导出后恢复，否则部分图形管线（含 OpenGL 渲染的三维图）会
% 导出空白。可见图窗不受影响。本函数是否被调用由调用方按
% config.plot.save_figures 决定。

    drawnow;
    if ~endsWith(relative_path, '.png')
        relative_path = [relative_path '.png'];
    end
    folder = fileparts(relative_path);
    if ~isempty(folder) && ~isfolder(folder)
        mkdir(folder);
    end

    restore_visibility = strcmp(fig.Visible, 'off');
    if restore_visibility
        previous_visibility = fig.Visible;
        fig.Visible = 'on';
        cleanup = onCleanup(@() set(fig, 'Visible', previous_visibility));
        drawnow;
    end
    exportgraphics(fig, relative_path, 'Resolution', 300);
end
