function ScanRound = solve_radius_scan_round(ScanInput, scan, iter)
% SOLVE_RADIUS_SCAN_ROUND 扫描一轮的参考点: 在一组半径上解 P3 并评价，做修复检查，算评价量。
%
% 输入:
%   ScanInput - load_radius_scan_input 读入的 ScanInput（config、ConstData、attempts）
%   scan      - 补好默认值的扫描设置（radius_scales、retry_solver、repair_check、
%               repair_radius_scale）
%   iter      - 扫描哪一轮的参考点
%
% 输出 ScanRound:
%   iter                - 扫描的轮号
%   same_iters          - 线性化在同一参考点上的所有轮号（含本轮）
%   attempt             - 这一轮运行时的记录（ScanInput.attempts 的一项: 实际半径 r^k、
%                         是否接受、ρ 等）
%   reference_J         - 参考处的罚函数 J（首个解出的半径上现算）
%   reference_penalty   - 参考处的罚项
%   reference_cost      - 参考处的性能指标 C（只含总脉冲，= 罚函数里类别为
%                         cost_* 的项之和，与 Evaluation.group.cost.reference 相同）
%   reference_extra     - 参考处的附加项 Γ（控制正则项，类别为 extra_* 的项之和）
%   reference_impulse   - 参考处的总脉冲 (m/s)，= reference_cost·VU/w_P
%   impulse_factor      - VU/w_P，性能指标乘它就换成总脉冲 (m/s)
%   points              - 1 x K 扫描记录，按 r 从大到小
%   actual_index        - points 里 r^k 那一项的下标
%   repair_radius_scale - 修复检查用的半径；没做修复检查时为 NaN
%   metrics             - compute_radius_scan_metrics 的输出
%
% 只调用现有的求解和评价函数，不改它们，不碰 RunState。
% 修复检查回答“这个半径留下的罚项下一轮修得掉吗”: 把这个半径的候选解当参考，
% 半径取 repair_radius_scale（默认是扫描里最小的半径）再解一次 P3，松弛为零就是修得掉，
% 这时那次 P3 的性能指标和附加项就是“修复后的性能指标”“修复后的附加项”。
%
% 本函数依次完成：
%   1. 取出这一轮的参考点和运行时的记录，找出同一参考点上的其他轮。
%   2. 定下要扫的半径: scan.radius_scales 加上本轮实际半径 r^k。
%   3. 半径从大到小逐个解 P3 并评价。
%   4. 修复检查: 每个候选解当参考，按 repair_radius_scale 再解一次 P3。
%   5. 算拐点、能维持的最大半径、分区、G(r)、有效下降、ΔJ 比、阶段度量和复现自检
%      （G、有效下降、阶段度量按性能指标和附加项各一份）。

    config = ScanInput.config;
    ConstData = ScanInput.ConstData;

    %% 1. 取出这一轮的参考点和运行时的记录，找出同一参考点上的其他轮
    saved_iters = [ScanInput.attempts.iter];
    Attempt = ScanInput.attempts(find(saved_iters == iter, 1));
    Reference = Attempt.reference;
    same = false(size(saved_iters));
    for k = 1:numel(saved_iters)
        same(k) = isequal(ScanInput.attempts(k).reference, Reference);
    end
    ScanRound.iter = iter;
    ScanRound.same_iters = saved_iters(same);
    % 参考点本身不再存一份（太大），要用时按轮号从 ScanInput 取
    ScanRound.attempt = rmfield(Attempt, 'reference');
    ScanRound.reference_J = NaN;
    ScanRound.reference_penalty = NaN;
    ScanRound.reference_cost = NaN;
    ScanRound.reference_extra = NaN;
    ScanRound.reference_impulse = NaN;
    ScanRound.impulse_factor = ConstData.VU / config.objective.weight_impulse;

    %% 2. 定下要扫的半径: scan.radius_scales 加上本轮实际半径 r^k
    radius_scales = scan.radius_scales;
    actual_radius = Attempt.radius_scale;
    matched = abs(radius_scales - actual_radius) <= 1e-9 * actual_radius;
    if ~any(matched)
        radius_scales = sort([radius_scales, actual_radius], 'descend');
        matched = abs(radius_scales - actual_radius) <= 1e-9 * actual_radius;
    end
    ScanRound.actual_index = find(matched, 1);

    %% 3. 半径从大到小逐个解 P3 并评价
    % 参考处的 J 和 P2 可行性检查只在首个解出的半径上现算，之后各半径共用
    num_radii = numel(radius_scales);
    point_list = cell(1, num_radii);
    solution_list = cell(1, num_radii);
    ReferenceCache = [];
    for k = 1:num_radii
        [Point, ReferenceCache, solution_list{k}] = solve_radius_scan_point( ...
            Reference, ReferenceCache, radius_scales(k), iter, ...
            ConstData, config, scan.retry_solver);
        Point.is_actual_radius = (k == ScanRound.actual_index);
        point_list{k} = Point;
        if Point.success && ~isfinite(ScanRound.reference_J)
            ScanRound.reference_J = ReferenceCache.penalty_function.total;
            ScanRound.reference_penalty = Point.reference_penalty;
            ScanRound.reference_cost = sum_terms_by_kind( ...
                ReferenceCache.penalty_function, {'cost_convex', 'cost_nonconvex'});
            ScanRound.reference_extra = sum_terms_by_kind( ...
                ReferenceCache.penalty_function, {'extra_convex', 'extra_nonconvex'});
            ScanRound.reference_impulse = ...
                ReferenceCache.check.performance_report.value;
        end
    end

    %% 4. 修复检查: 每个候选解当参考，按 repair_radius_scale 再解一次 P3
    ScanRound.repair_radius_scale = NaN;
    if scan.repair_check
        ScanRound.repair_radius_scale = scan.repair_radius_scale;
        for k = 1:num_radii
            if ~point_list{k}.success
                continue;   % 本半径没有候选解，没东西可修
            end
            RepairReference = build_repair_reference(solution_list{k}, Reference);
            RepairPoint = solve_radius_scan_point(RepairReference, [], ...
                scan.repair_radius_scale, iter, ConstData, config, ...
                scan.retry_solver);
            point_list{k} = fill_repair_fields(point_list{k}, RepairPoint);
        end
    end
    ScanRound.points = [point_list{:}];

    %% 5. 算拐点、能维持的最大半径、分区、G(r)、有效下降、ΔJ 比、阶段度量和复现自检
    % （G、有效下降、阶段度量按性能指标和附加项各一份）
    ScanRound.metrics = compute_radius_scan_metrics(ScanRound.points, ...
        ScanRound.actual_index, ScanRound.attempt, scan.repair_check, config);
end


function RepairReference = build_repair_reference(CurrentSolution, Reference)
% BUILD_REPAIR_REFERENCE 由候选解构造修复检查用的参考，和主流程里接受后的下一轮参考同样构造。
%
% 网格（N, tau, PointsBounds）与原参考相同；状态、控制和各圈大气段时间取自候选解。

    RepairReference = struct();
    RepairReference.N = Reference.N;
    RepairReference.tau = Reference.tau;
    RepairReference.PointsBounds = Reference.PointsBounds;
    RepairReference.state = CurrentSolution.state;
    RepairReference.control = CurrentSolution.control;
    RepairReference.t_f = CurrentSolution.t_f;
end


function Point = fill_repair_fields(Point, RepairPoint)
% FILL_REPAIR_FIELDS 把修复用的那次求解的结果抄进扫描记录的 repair_* 字段。

    Point.repair_evaluated = true;
    Point.repair_success = RepairPoint.success;
    Point.repair_status = RepairPoint.solver_status;
    Point.repair_relaxed_tolerance = RepairPoint.relaxed_tolerance;
    Point.repair_slack_penalty = RepairPoint.slack_penalty;
    Point.repair_slack_zero = RepairPoint.success && RepairPoint.slack_zero;
    Point.repair_cost_p3 = RepairPoint.cost_p3;
    Point.repair_extra_p3 = RepairPoint.extra_p3;
end


function value = sum_terms_by_kind(PenaltyFunction, kinds)
% SUM_TERMS_BY_KIND 罚函数里类别属于 kinds 的各项之和（与 evaluate_reduction_ratio 的分组同一口径）。

    Terms = PenaltyFunction.terms;
    value = sum([Terms(ismember({Terms.kind}, kinds)).value]);
end
