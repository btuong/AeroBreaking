function Item = build_history_item(name, group, y_label, value, ...
        reference, reference_label, style)
% BUILD_HISTORY_ITEM 组装一项本轮标量指标，供最终图按迭代拼成序列。
%
% 输入:
%   name            - 指标名称，跨轮按名称对齐，也是图例名称
%   group           - 分块名称；同组指标画在同一分块（如各状态通道的动力学松弛）
%   y_label         - 纵轴标签，写成“名称 (单位)”
%   value           - 本轮数值，物理单位
%   reference       - 参考线数值（目标或容差），没有时给 NaN
%   reference_label - 参考线图例名称，如“目标”“容差”
%   style           - 曲线画法，省略时为 'line'；同一分块里的总量写 'bold'（画粗线，
%                     同块其余曲线画细线），见 build_plot_curve

    if nargin < 7
        style = 'line';
    end
    Item.name = name;
    Item.group = group;
    Item.y_label = y_label;
    Item.value = value;
    Item.reference = reference;
    Item.reference_label = reference_label;
    Item.style = style;
end
