function add_legend_entry(ax, name, color, line_style, line_width, marker, is_series)
% ADD_LEGEND_ENTRY 在分块里画一个不含数据的图例条目：线型、线宽、颜色和实心标记与曲线一致。
%
% 为什么要有这个函数：曲线本身和它的接受/拒绝标记是分开画的（实心、空心不同），直接拿
% 曲线进图例时图例里只有线没有标记。这里画一个数据为 NaN 的对象带上名字，图例里就同时
% 显示线和标记；曲线本身不起名字、不进图例。NaN 不画任何点，也不影响坐标范围。
%
% 输入:
%   ax         - 分块的坐标轴
%   name       - 图例名称
%   color      - 1 x 3 颜色
%   line_style - '-'（实际量）或 '--'、'-.'、':'（界）
%   line_width - 线宽
%   marker     - 标记形状；界传 'none'
%   is_series  - 是否是实际量曲线。是的话打上 Tag 'series'，共用图例据此跳过
%                “分块里只有一条曲线”时的这条曲线（纵轴标签就是它的名字）

    tag = '';
    if is_series
        tag = 'series';
    end
    plot(ax, NaN, NaN, 'LineStyle', line_style, 'Color', color, ...
        'LineWidth', line_width, 'Marker', marker, 'MarkerSize', 7, ...
        'MarkerFaceColor', color, 'DisplayName', name, 'Tag', tag);
end
