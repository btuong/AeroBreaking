function TrapezoidCheck = create_empty_trapezoid_check()
% CREATE_EMPTY_TRAPEZOID_CHECK 创建未评价的梯形递推检查报告。

    TrapezoidCheck.evaluated = false;
    TrapezoidCheck.success = false;
    TrapezoidCheck.feasible = false;
    TrapezoidCheck.failure_reason = 'not_evaluated';
    TrapezoidCheck.recursion_report = struct('success', false, ...
        'evaluated', false, 'failure_reason', 'not_evaluated', ...
        'last_completed_node', NaN, 'failing_interval', NaN, ...
        'failure_step_residual', NaN, 'failure_newton_iterations', NaN, ...
        'num_completed_intervals', 0, 'max_step_residual', NaN, ...
        'max_newton_iterations', NaN, 'tolerance', NaN);
    TrapezoidCheck.deviation_report = struct([]);
    TrapezoidCheck.terminal_report = struct([]);
    TrapezoidCheck.path_report = struct([]);
    TrapezoidCheck.performance_report = struct([]);
end
