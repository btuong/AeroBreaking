function draw_overlay_tiles(fig, HistorySeries, field_name, figure_title, config)
% DRAW_OVERLAY_TILES 把各轮的状态量或控制量按分块叠画（最终图用）。
%
% 输入:
%   fig           - 目标图窗
%   HistorySeries - plot_scp_result 整理的序列，读 iter、status、plot_data、final_index
%   field_name    - 'states' 或 'controls'
%   figure_title  - 整扇窗的总标题
%   config        - 读取 config.plot.font_size 与 config.plot.overlay_max_rounds
%
% 颜色表示迭代序号（parula，配 colorbar）；拒绝轮用虚线；最后接受解画粗线，其余轮
% 画细线。加粗和虚线的含义写在窗口标题下面一行，不放图例（每块一个图例会压曲线）。
% 失败轮没有解，不画。分块清单以第一个有解的轮次为准。
% 有解的轮数超过 config.plot.overlay_max_rounds 时只画其中几轮: 第一轮、最后接受解，
% 中间按序号均匀取，画了哪几轮写在标题下面；设为 Inf 时每轮都画。

    font_size = config.plot.font_size;
    plot_data = HistorySeries.plot_data;
    iters = HistorySeries.iter;
    template_index = find(~strcmp(HistorySeries.status, 'failed'), 1);
    num_tiles = numel(plot_data{template_index}.(field_name));

    % 迭代序号映射到颜色；只有一轮时给一个单位宽的范围
    color_map = parula(256);
    color_limits = [min(iters), max(iters)];
    if color_limits(1) == color_limits(2)
        color_limits = color_limits + [-0.5, 0.5];
    end

    % 要画的轮（失败轮不在其中）
    [draw_index, is_subset] = select_overlay_rounds(HistorySeries, ...
        config.plot.overlay_max_rounds);

    layout = create_tile_layout(fig, num_tiles);
    for j = 1:num_tiles
        TemplateTile = plot_data{template_index}.(field_name)(j);
        ax = nexttile(layout);
        hold(ax, 'on');

        % 最后接受解放到最后画，避免被后面的轮盖住
        draw_order = [setdiff(draw_index, HistorySeries.final_index, 'stable'), ...
            HistorySeries.final_index];
        for k = draw_order
            Tile = plot_data{k}.(field_name)(j);
            color = map_value_to_color(iters(k), color_limits, color_map);
            is_final = isequal(k, HistorySeries.final_index);
            draw_overlay_curves(ax, Tile.curves, color, is_final, ...
                strcmp(HistorySeries.status{k}, 'rejected'));
        end

        colormap(ax, color_map);
        set(ax, 'CLim', color_limits);
        fit_axis_limits(ax, NaN);
        style_plot_axes(ax, '时间 (s)', ...
            TemplateTile.y_label, config);
    end

    % 所有分块共用一条 colorbar，放在布局右侧
    color_bar = colorbar(ax);
    color_bar.Layout.Tile = 'east';
    color_bar.Label.String = '迭代序号';
    color_bar.FontSize = font_size;
    notes = {};
    if is_subset
        drawn_text = strjoin(arrayfun(@num2str, iters(draw_index), ...
            'UniformOutput', false), '、');
        notes{end + 1} = ['只画第 ' drawn_text ' 轮'];
    end
    if ~isempty(HistorySeries.final_index)
        notes{end + 1} = '粗线：最后接受解';
    end
    if any(strcmp(HistorySeries.status(draw_index), 'rejected'))
        notes{end + 1} = '虚线：被拒绝的轮';
    end
    if isempty(notes)
        title(layout, figure_title, 'FontSize', font_size);
    else
        title(layout, {figure_title, strjoin(notes, '   ')}, 'FontSize', font_size);
    end
end


function draw_overlay_curves(ax, curves, color, is_final, is_rejected)
% DRAW_OVERLAY_CURVES 画某一轮在一个分块里的全部曲线。
% 最后接受解加粗，拒绝轮用虚线；曲线都不进图例。

    line_width = 1.0;
    line_style = '-';
    if is_rejected
        line_style = '--';
    end
    if is_final
        line_width = 3.0;
    end

    for c = 1:numel(curves)
        Curve = curves(c);
        legend_args = {'HandleVisibility', 'off'};
        switch Curve.style
            case 'line'
                plot(ax, Curve.x, Curve.y, line_style, 'Color', color, ...
                    'LineWidth', line_width, legend_args{:});
            case 'marker'
                plot(ax, Curve.x, Curve.y, 'o', 'LineStyle', 'none', ...
                    'Color', color, 'LineWidth', line_width, ...
                    'MarkerSize', 6, legend_args{:});
        end
    end
end


function [draw_index, is_subset] = select_overlay_rounds(HistorySeries, max_rounds)
% SELECT_OVERLAY_ROUNDS 挑出要叠画的轮: 有解的轮不超过 max_rounds 时全画，否则取第一轮、
% 最后接受解，中间按序号均匀取，凑满 max_rounds 轮。
%
% 输出 draw_index 是这些轮在 HistorySeries 里的位置（从小到大），is_subset 表示是否
% 只画了一部分。

    solved = find(~strcmp(HistorySeries.status, 'failed'));
    is_subset = isfinite(max_rounds) && numel(solved) > max_rounds;
    if ~is_subset
        draw_index = solved;
        return;
    end
    max_rounds = max(2, round(max_rounds));
    picked = solved(round(linspace(1, numel(solved), max_rounds)));
    % 最后接受解不一定是最后一轮（之后的轮可能被拒绝），确保它在里面
    draw_index = unique([picked, HistorySeries.final_index]);
end


function color = map_value_to_color(value, color_limits, color_map)
% MAP_VALUE_TO_COLOR 把迭代序号线性映射到色图中的一行。

    ratio = (value - color_limits(1)) / (color_limits(2) - color_limits(1));
    row = 1 + round(ratio * (size(color_map, 1) - 1));
    color = color_map(min(max(row, 1), size(color_map, 1)), :);
end
