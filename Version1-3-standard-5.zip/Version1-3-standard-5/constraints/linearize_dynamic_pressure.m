function [c, c_r, c_V] = linearize_dynamic_pressure(ConstData, r_k, V_k)
% LINEARIZE_DYNAMIC_PRESSURE 计算动压 q = rho*(V*VU)^2/2 的仿射系数。
%
% 数学形式:
%       q(r, V) = ρ(r)·(V·VU)² / 2,    ρ(r) = ρ_0·exp((R_M − r)/h_s)
%   r 单位 LU，V 单位 VU（V·VU 为 m/s），q 单位 N/m²。P3 中取参考点 (r̄, V̄)
%   的一阶展开 q ≈ c + c_r·(r − r̄) + c_V·(V − V̄)，其中
%       c_r = ∂q/∂r = −q/h_s,    c_V = ∂q/∂V = ρ·VU·(V·VU)
%
% 代码形式:
%   输出 c = q(r_k, V_k)，c_r、c_V 为上述偏导；r_k、V_k 为输入参考点。
%   c_V 因 V 取归一化量而含因子 VU（链式法则）。

    Rho0 = ConstData.Rho0;
    RM = ConstData.RM;
    hs = ConstData.hs;
    VU = ConstData.VU;

    r = r_k;
    V = V_k;

    c = (Rho0 * (V * VU)^2 * exp((RM - r) / hs)) / 2;
    c_r = -(Rho0 * (V * VU)^2 * exp((RM - r) / hs)) / (2 * hs);
    c_V = Rho0 * (V * VU) * exp((RM - r) / hs);
end
