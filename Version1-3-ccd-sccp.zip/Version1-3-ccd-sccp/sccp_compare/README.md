# sccp_compare：文献 [10] SCCP 模式对比实验

在保持同一 SCP 外壳的条件下（`scp_config_default()` 基础上设 `iter.tolerance = 0`、固定信赖域 `r = 1`，带总脉冲平台停止：最近 5 个被接受轮极差 $\le 0.1\text{ m/s}$ 且对 P2 可行；关闭绘图与逐轮打印；不保存 `scp_run_full.mat` 与 `scp_run_scan.mat`），运行文献 [10]（Deng et al. 2024）SCCP 单位范数模式 `config.unit_norm.mode = 'sccp'` 的全部 13 个工况，并与只读复用的 5 个 `Version1-3-standard-5` 基线存档（`none`、`norm_w1e-4`、`normgap_w1e-3..5`）统一对比。数据整理见阶段报告 `../docs/算法改进_阶段1_SCCP模式对比实验.md`。

## 工况清单（13 个 `sccp` 工况，$\eta_{\max} = 10^4$）

| 组别 | 工况名 | $C_\eta$ | 上限轮数 | 速率约束 | 初始控制 | 检验目的 |
|---|---|---|---|---|---|---|
| 主扫描（8 档） | `sccp_c1e-8` .. `sccp_c1e-2`、`sccp_c1e0` | $10^{-8},10^{-7},10^{-6},10^{-5},10^{-4},10^{-3},10^{-2},1$ | 50 | 是 | 默认单位圆 | 欠罚扩散、临界区与高权冻结 |
| 无速率对照 | `sccp_nr_c1e-7`、`sccp_nr_c1e-5` | $10^{-7}, 10^{-5}$ | 50 | 否 | 默认单位圆 | 分离相邻节点 $u_1$ 差值约束效应 |
| 初值专项 | `sccp_init0p3_c1e-4` | $10^{-4}$ | 10 | 是 | 模长缩为 $0.3$ | 圆内初值恢复取紧与推进 |
|  | `sccp_init0_c1e-4` | $10^{-4}$ | 10 | 是 | 全零 $u=0$ | 零初值首步退化与 D 节点表现 |
|  | `sccp_init0_nr_c1e-4` | $10^{-4}$ | 10 | 否 | 全零 $u=0$ | 无速率约束下零初值表现 |

## 运行方法

MATLAB 工作目录任意；脚本按自身路径只添加 `Version1-3-ccd-sccp` 各模块与 `sccp_compare/`，结束后自动恢复原路径：

```matlab
run('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-ccd-sccp/sccp_compare/SCP_sccp_compare.m')
```

运行前可在工作区设置的可选变量：`rerun_existing`（默认 `false`）、`case_filter`（默认 `{}`）、`max_iter_override`（默认 `[]`）、`plateau_window`（默认 `5`）、`plateau_tolerance`（默认 `0.1`）、`results_folder`（默认 `'results'`）、`run_analysis`（默认 `true`）。

若全部 `case_metrics.mat` 已存在，单独重跑汇总表与作图：

```matlab
cd('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-ccd-sccp/sccp_compare');
[Summary, Groups, Check] = analyze_sccp_compare();
close all;
```

## 文件与产物清单

- `SCP_sccp_compare.m`：对比实验批处理入口。
- `list_compare_cases.m`：13 个 `sccp` 工况清单定义。
- `run_compare_case.m`：单工况运行与在线平台判据。
- `extract_compare_metrics.m`：提取 `case_metrics.mat`（含 $\eta$、$\eta/N$、命题 C1 帽半角 $\alpha$、单步转角分位、对偶和比及圆约束分项账）。
- `analyze_sccp_compare.m`：只读加载 13 个 `sccp` 工况及 5 个 `Version1-3-standard-5` 基线，校验 `version_root` 与 `unit_norm_mode`，写出汇总与 7 张图。
- `results/<工况>/`：`scp_run_brief.txt`、`scp_run_detail.txt`、`scp_run_control.txt`、`scp_run_control.mat`、`case_metrics.mat`（无 `full_mat` 与 `scan_mat`）。
- `results/对比汇总.txt` 与 `results/对比汇总.mat`（含 `Summary`、`Groups`、`Check`、`Options`）；`results/logs/` 存放批运行与分析日志。
- `pictures/`（7 张 PNG）：`对比-各轮总脉冲.png`、`对比-相对none差值.png`、`对比-ED不紧扩散.png`、`对比-命题C1转角与冻结.png`、`对比-初值影响.png`、`对比-末轮σ.png`、`对比-紧性与eta.png`。
