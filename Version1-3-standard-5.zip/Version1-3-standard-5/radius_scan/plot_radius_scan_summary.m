function fig = plot_radius_scan_summary(Summary, config)
% PLOT_RADIUS_SCAN_SUMMARY 画多轮扫描的汇总: 一扇窗「半径扫描-多轮汇总」，横轴为轮号。
%
% 输入:
%   Summary - build_radius_scan_summary 的输出
%   config  - 读取 config.plot 的 font_size、visibility
%
% 四个分块（点按运行时这一轮的结果: 接受实心、拒绝空心、P3 失败红叉，含义写在标题
% 下面一行；整扇窗只在底部放一个共用图例，颜色和标记形状与单轮扫描图一致）:
%   1. 半径: 本轮实际半径 r^k、松弛为零所需的半径（拐点）、能维持的最大半径，对数纵轴；
%      r^k 落在后两条线之间就是“合适”
%   2. ΔJ(r^k)/max ΔJ(r): 线性纵轴限在 [−1, 1.1]，超出的点画在边上用三角标出
%   3. 性能指标: G(r^k)、E(r^k)、阶段度量 ΔL:性能指标(r_top)，取 _cost，对数纵轴
%   4. 附加项: 同上三条，取 _extra；和第 3 块同名同色，由纵轴标签区分
% 没有的量（如松弛都不为零的轮没有拐点）留空。

    fig = figure('Name', '半径扫描-多轮汇总', 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    iters = Summary.iters;
    status = Summary.status;
    Palette = build_analysis_palette();
    layout = create_tile_layout(fig, 4);
    tile_axes = gobjects(1, 4);
    for j = 1:4
        tile_axes(j) = nexttile(layout);
    end
    notes = {describe_status_marks(status)};

    draw_summary_radius_tile(tile_axes(1), Summary, Palette, config);
    notes = [notes, draw_summary_share_tile(tile_axes(2), iters, status, ...
        Summary.actual_share, Palette.single, config)];
    % 性能指标和附加项各一块，三条曲线同名同色
    part_specs = { ...
        '性能指标', Summary.actual_gain_cost, Summary.actual_effective_drop_cost, ...
            Summary.stage_cost; ...
        '附加项', Summary.actual_gain_extra, Summary.actual_effective_drop_extra, ...
            Summary.stage_extra};
    for j = 1:2
        notes = [notes, draw_log_history_tile(tile_axes(j + 2), iters, status, ...
            [build_log_series('G(r^k)', part_specs{j, 2}, Palette.gain, false, ...
                Palette.marker.gain), ...
            build_log_series('E(r^k)', part_specs{j, 3}, ...
                Palette.effective_drop, false, Palette.marker.effective_drop), ...
            build_log_series('阶段度量', part_specs{j, 4}, ...
                Palette.stage_metric, false, Palette.marker.stage_metric)], ...
            part_specs{j, 1}, config)]; %#ok<AGROW>
    end

    finish_tile_window(layout, tile_axes, '半径扫描: 多轮汇总', notes, config);
end


function draw_summary_radius_tile(ax, Summary, Palette, config)
% DRAW_SUMMARY_RADIUS_TILE 画三种半径随轮号: r^k 实线、拐点点线、能维持的最大半径点划线，对数纵轴。
%
% 线型与单轮扫描图里的三条竖线相同；r^k 的点按接受/拒绝画实心/空心圆。

    hold(ax, 'on');
    iters = Summary.iters;
    add_legend_entry(ax, '本轮半径 r^k', Palette.actual_radius, '-', 1.5, ...
        Palette.marker.actual_radius, true);
    plot(ax, iters, Summary.actual_radius, '-', 'Color', Palette.actual_radius, ...
        'LineWidth', 1.5, 'HandleVisibility', 'off');
    mark_history_status(ax, iters, Summary.status, Summary.actual_radius, ...
        Palette.actual_radius, Palette.marker.actual_radius);
    plot(ax, iters, Summary.zero_radius, ':s', 'Color', Palette.radius_mark, ...
        'LineWidth', 2, 'MarkerSize', 7, 'DisplayName', '松弛为零所需的半径', ...
        'Tag', 'series');
    plot(ax, iters, Summary.hold_radius, '-.d', 'Color', Palette.radius_mark, ...
        'LineWidth', 1.5, 'MarkerSize', 7, 'DisplayName', '能维持的最大半径', ...
        'Tag', 'series');
    set(ax, 'YScale', 'log');
    values = [Summary.actual_radius, Summary.zero_radius, Summary.hold_radius];
    values = values(isfinite(values) & values > 0);
    if ~isempty(values)
        ylim(ax, [min(values) / 1.5, max(values) * 1.5]);
    end
    mark_failed_rounds(ax, iters, Summary.status);
    finish_history_axes(ax, iters, '半径 r', config);
end


function notes = draw_summary_share_tile(ax, iters, status, share, color, config)
% DRAW_SUMMARY_SHARE_TILE 画 ΔJ(r^k)/max ΔJ(r): 纵轴限在 [-1, 1.1]，超出的点画在边上。
%
% r^k 处 ΔJ 为负时比值可以是很大的负数，纵轴不限范围时 0 到 1 之间看不清。
% 返回要写在窗口标题下面的说明行。

    notes = {};
    hold(ax, 'on');
    lower_limit = -1;
    upper_limit = 1.1;
    % 超出范围的值夹到边上；不能用 max/min 夹取，它们会把 NaN 当缺失值丢掉
    clipped = share;
    clipped(share > upper_limit) = upper_limit;
    clipped(share < lower_limit) = lower_limit;
    plot(ax, iters, clipped, '-', 'Color', color, 'LineWidth', 1.5, ...
        'DisplayName', 'ΔJ比', 'Tag', 'series');
    in_range = share >= lower_limit & share <= upper_limit;
    marked = share;
    marked(~in_range) = NaN;
    mark_history_status(ax, iters, status, marked, color);
    below = share < lower_limit;
    plot(ax, iters(below), repmat(lower_limit, 1, nnz(below)), 'v', ...
        'Color', color, 'MarkerFaceColor', color, 'MarkerSize', 8, ...
        'HandleVisibility', 'off');
    if any(below)
        notes{end + 1} = '▼ ΔJ比 < -1（画在下沿）';
    end
    ylim(ax, [lower_limit - 0.05, upper_limit + 0.05]);
    mark_failed_rounds(ax, iters, status);
    finish_history_axes(ax, iters, 'ΔJ(r^k)/max ΔJ', config);
end
