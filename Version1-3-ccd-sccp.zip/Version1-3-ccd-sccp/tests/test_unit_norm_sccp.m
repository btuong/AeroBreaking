function tests = test_unit_norm_sccp
% TEST_UNIT_NORM_SCCP 核验 'sccp' 单位范数处理方式的装配、罚函数、对偶、控制报告与入口输出。

    tests = functiontests(localfunctions);
end


function setupOnce(testCase)
% SETUPONCE 初始化真实问题的 ConstData 与 InitialReference 供装配与短程运行测试复用。

    config = scp_config_default();
    [ConstData, InitialState] = initialize_problem(config);
    [InitialReference, ~] = generate_initial_reference( ...
        ConstData, InitialState, config);
    testCase.TestData.ConstData = ConstData;
    testCase.TestData.InitialReference = InitialReference;
end


function test_describe_unit_norm_modes(testCase)
% TEST_DESCRIBE_UNIT_NORM_MODES 检查默认、缺字段、'sccp'、非法模式与非法参数。

    default_config = scp_config_default();
    DefaultInfo = describe_unit_norm(default_config);
    verifyEqual(testCase, DefaultInfo.mode, 'regularized');
    verifyFalse(testCase, DefaultInfo.is_sccp);
    verifyEqual(testCase, DefaultInfo.penalty_weight, 0);
    verifyEqual(testCase, DefaultInfo.slack_max, 0);
    verifyEqual(testCase, DefaultInfo.term_name, 'control_reg');
    verifyEqual(testCase, DefaultInfo.term_label, '控制正则项');
    verifyEqual(testCase, DefaultInfo.term_kind, 'extra_nonconvex');

    missing_field_config = rmfield(default_config, 'unit_norm');
    missing_field_config.objective.control_reg_type = 'sum';
    MissingInfo = describe_unit_norm(missing_field_config);
    verifyEqual(testCase, MissingInfo.mode, 'regularized');
    verifyFalse(testCase, MissingInfo.is_sccp);
    verifyEqual(testCase, MissingInfo.term_kind, 'extra_convex');

    sccp_config = default_config;
    sccp_config.unit_norm.mode = 'sccp';
    sccp_config.unit_norm.sccp_penalty_weight = 2.5;
    sccp_config.unit_norm.sccp_slack_max = 500;
    SccpInfo = describe_unit_norm(sccp_config);
    verifyEqual(testCase, SccpInfo.mode, 'sccp');
    verifyTrue(testCase, SccpInfo.is_sccp);
    verifyEqual(testCase, SccpInfo.penalty_weight, 2.5);
    verifyEqual(testCase, SccpInfo.slack_max, 500);
    verifyEqual(testCase, SccpInfo.term_name, 'unit_norm_penalty');
    verifyEqual(testCase, SccpInfo.term_label, '单位范数罚项');
    verifyEqual(testCase, SccpInfo.term_kind, 'inequality_penalty');

    bad_mode_config = default_config;
    bad_mode_config.unit_norm.mode = 'invalid_mode';
    verifyError(testCase, @() describe_unit_norm(bad_mode_config), ...
        'SCP:UnknownUnitNormMode');

    bad_weight_cases = {0, -1, NaN, Inf, 1 + 1i};
    for k = 1:numel(bad_weight_cases)
        bad_config = sccp_config;
        bad_config.unit_norm.sccp_penalty_weight = bad_weight_cases{k};
        verifyError(testCase, @() describe_unit_norm(bad_config), ...
            'SCP:InvalidUnitNormConfig');
    end

    bad_max_cases = {0, -10, NaN, Inf};
    for k = 1:numel(bad_max_cases)
        bad_config = sccp_config;
        bad_config.unit_norm.sccp_slack_max = bad_max_cases{k};
        verifyError(testCase, @() describe_unit_norm(bad_config), ...
            'SCP:InvalidUnitNormConfig');
    end
end


function test_variable_layout_and_p3_assembly(testCase)
% TEST_VARIABLE_LAYOUT_AND_P3_ASSEMBLY 核验两种模式的变量索引、边界、锥、线性行与目标装配。

    ConstData = testCase.TestData.ConstData;
    Reference = testCase.TestData.InitialReference;
    N = Reference.N;

    % 'regularized' 保持原布局
    reg_config = scp_config_default();
    TrustState = initialize_trust_region_state(reg_config);
    [RegIndex, reg_num_vars] = build_variable_index(Reference, ConstData, reg_config);
    RegLinear = build_linear_constraints(RegIndex, Reference, ConstData, reg_config);
    RegCones = build_conic_constraints(RegIndex, Reference, ConstData, reg_config);
    verifyEqual(testCase, reg_num_vars, 17 * N + 25);
    verifyEmpty(testCase, RegIndex.unit_norm_slack);
    verifyFalse(testCase, isfield(RegLinear.row_groups, 'unit_norm_inner'));
    reg_disk = RegCones.cones(strcmp({RegCones.cones.name}, 'control_disk'));
    verifyTrue(testCase, all(strcmp({reg_disk.tightness_role}, 'lossless')));

    % 'sccp' 布局与装配
    sccp_config = scp_config_default();
    sccp_config.unit_norm.mode = 'sccp';
    sccp_config.unit_norm.sccp_penalty_weight = 1.75;
    sccp_config.unit_norm.sccp_slack_max = 1234;
    [SccpIndex, sccp_num_vars] = build_variable_index(Reference, ConstData, sccp_config);
    verifyEqual(testCase, sccp_num_vars, 17 * N + 26);
    verifyEqual(testCase, numel(SccpIndex.unit_norm_slack), 1);
    verifyEqual(testCase, SccpIndex.unit_norm_slack, 17 * N + 26);

    Bounds = build_variable_bounds(SccpIndex, Reference, TrustState, ConstData, sccp_config);
    verifyEqual(testCase, Bounds.lower(SccpIndex.u1), -ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, Bounds.upper(SccpIndex.u1), ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, Bounds.lower(SccpIndex.u2), -ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, Bounds.upper(SccpIndex.u2), ones(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, Bounds.lower(SccpIndex.unit_norm_slack), 0, 'AbsTol', 1e-14);
    verifyEqual(testCase, Bounds.upper(SccpIndex.unit_norm_slack), 1234, 'AbsTol', 1e-14);

    Cones = build_conic_constraints(SccpIndex, Reference, ConstData, sccp_config);
    disk_cones = Cones.cones(strcmp({Cones.cones.name}, 'control_disk'));
    verifyEqual(testCase, numel(disk_cones), N);
    verifyTrue(testCase, all(strcmp({disk_cones.tightness_role}, 'none')));
    verifyEqual(testCase, Cones.offset(disk_cones(1).rows), [1; 0; 0]);

    Linear = build_linear_constraints(SccpIndex, Reference, ConstData, sccp_config);
    group_names = fieldnames(Linear.row_groups);
    inner_pos = find(strcmp(group_names, 'unit_norm_inner'));
    cont_pos = find(strcmp(group_names, 'control_continuity'));
    imp_pos = find(strcmp(group_names, 'impulse_epigraph'));
    verifyEqual(testCase, inner_pos, cont_pos + 1);
    verifyEqual(testCase, imp_pos, inner_pos + 1);

    inner_rows = Linear.row_groups.unit_norm_inner;
    verifyEqual(testCase, numel(inner_rows), N);
    u1_ref = Reference.control.u1(:);
    u2_ref = Reference.control.u2(:);
    A_inner = Linear.matrix(inner_rows, :);
    verifyEqual(testCase, full(diag(A_inner(:, SccpIndex.u1))), -2 * u1_ref, ...
        'AbsTol', 1e-14);
    verifyEqual(testCase, full(diag(A_inner(:, SccpIndex.u2))), -2 * u2_ref, ...
        'AbsTol', 1e-14);
    verifyEqual(testCase, full(A_inner(:, SccpIndex.unit_norm_slack)), ...
        repmat(-1 / N, N, 1), 'AbsTol', 1e-14);
    verifyTrue(testCase, all(Linear.lower(inner_rows) == -Inf));
    verifyEqual(testCase, Linear.upper(inner_rows), ...
        -(1 + u1_ref.^2 + u2_ref.^2), 'AbsTol', 1e-14);

    [objective, objective_offset] = build_objective( ...
        SccpIndex, Reference, ConstData, sccp_config);
    verifyEqual(testCase, objective(SccpIndex.unit_norm_slack), 1.75, 'AbsTol', 1e-14);
    verifyEqual(testCase, objective(SccpIndex.u1), zeros(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, objective(SccpIndex.u2), zeros(N, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, objective_offset, 0, 'AbsTol', 1e-14);

    % 第 3 节点改为 (0, 0) 后禁止任何替换，第 3 行 u 系数必须严格为 [0, 0]、upper 为 -1
    ZeroNodeRef = Reference;
    ZeroNodeRef.control.u1(3) = 0;
    ZeroNodeRef.control.u2(3) = 0;
    ZeroLinear = build_linear_constraints(SccpIndex, ZeroNodeRef, ConstData, sccp_config);
    row3 = ZeroLinear.row_groups.unit_norm_inner(3);
    verifyEqual(testCase, full(ZeroLinear.matrix(row3, ...
        [SccpIndex.u1(3), SccpIndex.u2(3), SccpIndex.unit_norm_slack])), ...
        [0, 0, -1 / N], 'AbsTol', 1e-14);
    verifyEqual(testCase, ZeroLinear.upper(row3), -1, 'AbsTol', 1e-14);
end


function test_penalty_function_and_3_rounds(testCase)
% TEST_PENALTY_FUNCTION_AND_3_ROUNDS 核验罚函数分项与 'sccp' 3 轮主链关键不变量。

    ConstData = testCase.TestData.ConstData;
    Reference = testCase.TestData.InitialReference;
    N = Reference.N;

    % 'regularized' 分项列表不变
    reg_config = scp_config_default();
    RegCheck = check_p2_feasibility(Reference, ConstData, reg_config);
    RegPenalty = evaluate_penalty_function(Reference, RegCheck, ConstData, reg_config);
    verifyEqual(testCase, {RegPenalty.terms.name}, ...
        {'terminal_inclination', 'terminal_apoapsis', 'impulse', ...
        'point_slack', 'dyn_slack', 'control_reg'});

    % 'sccp' 跑 3 轮主链（即使 control_reg_type = 'norm_gap' 也不得污染 gamma_node）
    sccp_config = scp_config_default();
    sccp_config.unit_norm.mode = 'sccp';
    sccp_config.unit_norm.sccp_penalty_weight = 1;
    sccp_config.unit_norm.sccp_slack_max = 1e4;
    sccp_config.objective.control_reg_type = 'norm_gap';
    sccp_config.objective.weight_control_reg = 0.5;
    sccp_config.iter.max_scp_iter = 3;
    % 默认 co_tol_pfeas=1e-8 乘以 N=661 后会使 N*(1-‖u‖^2)-η 出现 ~5e-6 数值余量；
    % 本测试收紧到 1e-10 以严格核验不等式预测误差 D_unit <= 1e-6
    sccp_config.solver.co_tol_pfeas = 1e-10;
    sccp_config.solver.co_tol_dfeas = 1e-10;

    [RunState, ~] = initialize_scp_run(Reference, struct(), sccp_config);
    for iter = 1:3
        RefBefore = RunState.current_reference;
        [Solution, Diag] = solve_scp_subproblem( ...
            RefBefore, RunState.trust_region, ConstData, sccp_config, iter);
        verifyTrue(testCase, Diag.success);

        TrustResult = update_trust_region( ...
            Solution, Diag, RefBefore, RunState.trust_region, ...
            ConstData, sccp_config, iter);
        [RunState, Record] = advance_scp_iteration( ...
            RunState, Solution, Diag, TrustResult, ConstData, sccp_config, iter);

        Eval = Record.trust.evaluation;
        verifyEqual(testCase, Eval.group.extra.candidate, 0, 'AbsTol', 1e-14);

        u_norm_sq = Solution.control.u1(:).^2 + Solution.control.u2(:).^2;
        expected_unit_penalty = sccp_config.unit_norm.sccp_penalty_weight * N ...
            * max([1 - u_norm_sq; 0]);
        cand_term = Eval.candidate.terms(strcmp( ...
            {Eval.candidate.terms.name}, 'unit_norm_penalty'));
        verifyEqual(testCase, cand_term.value, expected_unit_penalty, 'AbsTol', 1e-12);

        unit_idx = strcmp(Eval.term_names, 'unit_norm_penalty');
        verifyLessThanOrEqual(testCase, Eval.term_prediction_error(unit_idx), 1e-6);

        % 零步长可行性：参考点 (u_ref, eta_ref) 满足 unit_norm_inner
        [Idx, ~] = build_variable_index(RefBefore, ConstData, sccp_config);
        Lin = build_linear_constraints(Idx, RefBefore, ConstData, sccp_config);
        u1_ref = RefBefore.control.u1(:);
        u2_ref = RefBefore.control.u2(:);
        eta_ref = N * max([1 - (u1_ref.^2 + u2_ref.^2); 0]);
        inner_rows = Lin.row_groups.unit_norm_inner;
        lhs_ref = -2 * (u1_ref.^2 + u2_ref.^2) - eta_ref / N;
        verifyLessThanOrEqual(testCase, max(lhs_ref - Lin.upper(inner_rows)), 1e-12);

        verifyEqual(testCase, Diag.control_report.gamma_node, zeros(N, 1), 'AbsTol', 1e-14);
    end
end


function test_dual_split_and_multiplier_bound(testCase)
% TEST_DUAL_SPLIT_AND_MULTIPLIER_BOUND 核验 'sccp' 下对偶驻点残差、s_inner 与乘子之和界。

    ConstData = testCase.TestData.ConstData;
    Reference = testCase.TestData.InitialReference;
    N = Reference.N;

    config = scp_config_default();
    config.unit_norm.mode = 'sccp';
    config.unit_norm.sccp_penalty_weight = 1;
    config.unit_norm.sccp_slack_max = 1e4;
    % 默认 co_tol_dfeas=1e-8 乘以 max|dual|≈240 会使绝对驻点残差达 ~3e-6；
    % 本测试收紧到 1e-10 以严格核验 max|stationarity_residual| <= 1e-6
    config.solver.co_tol_pfeas = 1e-10;
    config.solver.co_tol_dfeas = 1e-10;
    TrustState = initialize_trust_region_state(config);

    [VariableIndex, ~] = build_variable_index(Reference, ConstData, config);
    [objective, objective_offset] = build_objective( ...
        VariableIndex, Reference, ConstData, config);
    LinearConstraints = build_linear_constraints( ...
        VariableIndex, Reference, ConstData, config);
    VariableBounds = build_variable_bounds( ...
        VariableIndex, Reference, TrustState, ConstData, config);
    ConicConstraints = build_conic_constraints( ...
        VariableIndex, Reference, ConstData, config);
    SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ConicConstraints, ...
        config, objective_offset);
    verifyTrue(testCase, SolverResult.success);

    ControlReport = evaluate_control_report( ...
        SolverResult, VariableIndex, objective, LinearConstraints, ...
        ConicConstraints, Reference, config);
    verifyTrue(testCase, ControlReport.dual_available);
    verifyLessThanOrEqual(testCase, ...
        max(abs(ControlReport.stationarity_residual), [], 'all'), 1e-6);

    inner_rows = LinearConstraints.row_groups.unit_norm_inner(:);
    y_inner = SolverResult.dual.y(inner_rows);
    u_ref = [Reference.control.u1(:), Reference.control.u2(:)];
    expected_s_inner = 2 * u_ref .* y_inner;
    scale = max(1, max(abs(expected_s_inner), [], 'all'));
    verifyEqual(testCase, ControlReport.s_inner, expected_s_inner, ...
        'AbsTol', 1e-10 * scale);

    if ControlReport.unit_norm_slack < config.unit_norm.sccp_slack_max
        verifyLessThanOrEqual(testCase, sum(-y_inner), ...
            config.unit_norm.sccp_penalty_weight * N + 1e-6);
    end
end


function test_slack_cap_and_empty_report(testCase)
% TEST_SLACK_CAP_AND_EMPTY_REPORT 核验 η 触上界标记及空报告字段完整性。

    ConstData = testCase.TestData.ConstData;
    Reference = testCase.TestData.InitialReference;

    config = scp_config_default();
    config.unit_norm.mode = 'sccp';
    config.unit_norm.sccp_penalty_weight = 1e-6;
    config.unit_norm.sccp_slack_max = 1e-3;
    TrustState = initialize_trust_region_state(config);

    [VariableIndex, ~] = build_variable_index(Reference, ConstData, config);
    [objective, objective_offset] = build_objective( ...
        VariableIndex, Reference, ConstData, config);
    LinearConstraints = build_linear_constraints( ...
        VariableIndex, Reference, ConstData, config);
    VariableBounds = build_variable_bounds( ...
        VariableIndex, Reference, TrustState, ConstData, config);
    ConicConstraints = build_conic_constraints( ...
        VariableIndex, Reference, ConstData, config);
    SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ConicConstraints, ...
        config, objective_offset);
    verifyTrue(testCase, SolverResult.success);

    Report = evaluate_control_report( ...
        SolverResult, VariableIndex, objective, LinearConstraints, ...
        ConicConstraints, Reference, config);
    verifyTrue(testCase, Report.slack_capped);
    verifyEqual(testCase, Report.summary_total.num_slack_capped, 1);

    EmptyReport = create_empty_control_report('solver_failed');
    verifyEqual(testCase, sort(fieldnames(EmptyReport)), sort(fieldnames(Report)));
    verifyFalse(testCase, EmptyReport.slack_capped);
    verifyTrue(testCase, isnan(EmptyReport.unit_norm_slack));

    EmptySummary = create_empty_control_summary();
    verifyEqual(testCase, sort(fieldnames(EmptySummary)), ...
        sort(fieldnames(Report.summary_total)));
end


function test_sccp_entry_outputs_run(testCase)
% TEST_SCCP_ENTRY_OUTPUTS_RUN 核验 'sccp' 下 2 轮全输出（绘图 + 简略/详细/控制导出）无报错。

    ConstData = testCase.TestData.ConstData;
    Reference = testCase.TestData.InitialReference;

    version_root = fileparts(fileparts(mfilename('fullpath')));
    tmp_dir_rel = 'results/tmp_entry_check';
    tmp_dir_abs = fullfile(version_root, tmp_dir_rel);
    cleanup_dir = onCleanup(@() cleanup_temp_directory(tmp_dir_abs));
    cleanup_figs = onCleanup(@() close('all', 'force'));

    config = scp_config_default();
    config.unit_norm.mode = 'sccp';
    config.unit_norm.sccp_penalty_weight = 1;
    config.unit_norm.sccp_slack_max = 1e4;
    config.iter.max_scp_iter = 2;

    config.plot.visibility = 'off';
    config.plot.enable_initial = false;
    config.plot.enable_iteration = true;
    config.plot.enable_final = true;
    config.plot.save_figures = false;

    config.output.print_pre_iteration = false;
    config.output.print_iteration = false;
    config.output.print_summary = false;

    config.output.save.brief_text = true;
    config.output.save.detail_text = true;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    config.output.save.control_text = true;
    config.output.save.control_mat = true;
    config.output.save.directory = tmp_dir_rel;
    config.output.save.filename_prefix = 'sccp_entry_test';

    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        Reference, struct(), config);
    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        [Solution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            Solution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, Solution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);
    end

    FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory);
    PlotReport = plot_scp_result(FinalizedRun, ConstData, config);
    SaveReport = save_scp_result(FinalizedRun, ConstData, config);

    verifyTrue(testCase, PlotReport.success);
    verifyTrue(testCase, SaveReport.success);

    detail_text = fileread(fullfile(tmp_dir_abs, 'sccp_entry_test_detail.txt'));
    control_text = fileread(fullfile(tmp_dir_abs, 'sccp_entry_test_control.txt'));
    verifyTrue(testCase, contains(detail_text, '单位范数内逼近'));
    verifyTrue(testCase, contains(control_text, '单位范数处理: sccp'));
end


function cleanup_temp_directory(dir_path)
% CLEANUP_TEMP_DIRECTORY 删除测试产生的临时目录。

    if isfolder(dir_path)
        rmdir(dir_path, 's');
    end
end
