function JunctionReport = evaluate_junction_violation(Solution, ConstData, config)
% EVALUATE_JUNCTION_VIOLATION 用原真空映射计算初始点与四次圈间衔接违反量。
%
% 数学形式:
%   g_poi,0 = x_b1 - G_0(P_0)，
%   g_poi,c = x_b(c+1) - G_c([R_atm,V_out,γ_out,φ_out,ψ_out,0],P_c), c=1..4。
%   每个衔接都从前一段末节点重新求值，不传递误差。
%
% 代码形式:
%   values 为 5 x 5 带符号的衔接违反量，列为 r,V,γ,φ,ψ；终端映射等式和入轨
%   速度等式不在本报告里（它们不带松弛，不进衔接罚项）。sum_abs 保留求解坐标，供罚函数使用。
%
% 本函数依次完成：
%   1. 逐衔接点用原真空映射算衔接违反量。
%   2. 按通道换成物理单位，取最大值并与容差比较。
%   3. 汇总各通道结果与逐衔接点的违反量。

    %% 1. 逐衔接点用原真空映射算衔接违反量
    num_passes = numel(Solution.PointsBounds);
    values = zeros(num_passes, 5);
    entry_first = evaluate_coast_to_entry_first( ...
        ConstData.rv00, Solution.control.P(1), ConstData);
    values(1, :) = Solution.state(Solution.PointsBounds(1).begin, :) - entry_first;
    for cir = 1:(num_passes - 1)
        exit_this = [ConstData.R_atm, ...
            Solution.state(Solution.PointsBounds(cir).end, 2:5), 0];
        entry_next = evaluate_coast_pass_to_entry( ...
            exit_this, Solution.control.P(cir + 1), ConstData);
        values(cir + 1, :) = Solution.state( ...
            Solution.PointsBounds(cir + 1).begin, :) - entry_next;
    end

    %% 2. 按通道换成物理单位，取最大值并与容差比较
    channel_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    scales = [ConstData.LU / 1e3, ConstData.VU, 180 / pi, 180 / pi, 180 / pi];
    units = {'km', 'm/s', 'deg', 'deg', 'deg'};
    metric_list = cell(1, numel(channel_names));
    for s = 1:numel(channel_names)
        [max_value, max_row] = max(abs(values(:, s)) * scales(s));
        tolerance = config.validation.junction_tolerance.(channel_names{s});
        metric_list{s} = create_junction_metric( ...
            ['junction_' channel_names{s}], max_value, tolerance, units{s}, ...
            max_row, values(max_row, s) * scales(s));
        metric_list{s}.max_cir = NaN;
        metric_list{s}.max_node = NaN;
        metric_list{s}.max_point = max_row;
    end

    %% 3. 汇总各通道结果与逐衔接点的违反量
    JunctionReport = summarize_junction_metrics([metric_list{:}]);
    JunctionReport.values = values;
    JunctionReport.sum_abs = sum(abs(values), 'all');
    JunctionReport.scale = scales;
end


function Metric = create_junction_metric(name, value, tolerance, unit, index, component)
% CREATE_JUNCTION_METRIC 创建一个衔接通道的最大违反量指标（物理单位）。

    Metric = struct('name', name, 'value', value, 'max_value', value, ...
        'tolerance', tolerance, 'unit', unit, 'ratio', value / tolerance, ...
        'satisfied', isfinite(value) && value <= tolerance, ...
        'active', true, 'evaluated', true, 'max_index', index, ...
        'components', component);
end


function Report = summarize_junction_metrics(Metrics)
% SUMMARIZE_JUNCTION_METRICS 汇总各衔接通道的报告。

    Report.success = all([Metrics.satisfied]);
    Report.evaluated = true;
    Report.metrics = Metrics;
    Report.failed_names = {Metrics(~[Metrics.satisfied]).name};
    [Report.max_ratio, max_index] = max([Metrics.ratio]);
    Report.max_name = Metrics(max_index).name;
end
