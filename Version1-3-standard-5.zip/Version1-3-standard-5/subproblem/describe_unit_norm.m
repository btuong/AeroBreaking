function UnitNorm = describe_unit_norm(config)
% DESCRIBE_UNIT_NORM 按 config.unit_norm 返回单位范数约束 ‖u‖ = 1 的处理方式、类别和显示名。
%
% 数学形式:
%   控制 u_i = (u1_i, u2_i) = (cos σ_i, sin σ_i)，P1 要求 u1_i² + u2_i² = 1。P3 中两种处理:
%       'regularized'（默认）无损凸化：‖u_i‖ ≤ 1 作硬约束（锥角色 lossless），目标里加控制正则项
%                   Γ（按 config.objective.control_reg_type，见 describe_control_regularizer）把解推回圆周
%       'ccd'          凹凸分解（Lu 2020）：凸的一半 ‖u_i‖ ≤ 1 + ε_i 原样保留，松弛 ε_i 罚 p·ω_i·ε_i；
%                   反凸的一半 ‖u_i‖ ≥ 1 在参考控制 ū_i 处线性化为 ē_i^T·u_i ≥ 1（内逼近）。
%                   没有控制正则项（Γ = 0）；圆约束组在 J = C + Θ 里是罚项 Θ 的一项
%                   p·Σ ω_i·max(‖u_i‖ − 1, 0)，类别 inequality_penalty
%   ω_i 为按圈梯形权，p 为 ccd_penalty_weight，ε_max 为 ccd_slack_max。
%
% 代码形式:
%   UnitNorm 的字段:
%       mode               模式字符串，与 config.unit_norm.mode 一致
%       is_ccd             是否为 ccd 模式（逻辑量）
%       penalty_weight     p；非 ccd 时为 0
%       slack_max          ε_max；非 ccd 时为 0
%       keep_control_bounds 'ccd' 下是否保留 u1、u2 的 ±1 边界；非 ccd 时为 false
%       term_name          圆约束组在目标分项里的名字：regularized 为 'control_reg'，ccd 为 'unit_norm_penalty'
%       term_label         显示名：'控制正则项' 或 '单位范数罚项'
%       term_kind          分项类别：regularized 取 describe_control_regularizer(config).kind，
%                          ccd 为 'inequality_penalty'
%   config 中没有 unit_norm 字段时按 'regularized' 处理（旧运行存下的配置没有这个字段）；
%   未知模式报错；ccd 下 p ≤ 0 或 ε_max ≤ 0 报错。build_variable_index、build_variable_bounds、
%   build_conic_constraints、build_linear_constraints、build_objective、evaluate_penalty_function、
%   compute_objective_terms、evaluate_control_report 都从这里取模式，不各自写一遍。

    mode = 'regularized';
    if isfield(config, 'unit_norm') && isfield(config.unit_norm, 'mode')
        mode = config.unit_norm.mode;
    end

    switch mode
        case 'regularized'
            is_ccd = false;
            penalty_weight = 0;
            slack_max = 0;
            keep_control_bounds = false;
            term_name = 'control_reg';
            term_label = '控制正则项';
            term_kind = describe_control_regularizer(config).kind;
        case 'ccd'
            is_ccd = true;
            penalty_weight = config.unit_norm.ccd_penalty_weight;
            slack_max = config.unit_norm.ccd_slack_max;
            keep_control_bounds = logical(config.unit_norm.ccd_keep_control_bounds);
            if ~(isscalar(penalty_weight) && isreal(penalty_weight) ...
                    && isfinite(penalty_weight) && penalty_weight > 0) ...
                    || ~(isscalar(slack_max) && isreal(slack_max) ...
                    && isfinite(slack_max) && slack_max > 0)
                error('SCP:InvalidUnitNormConfig', ...
                    ['ccd 模式要求 ccd_penalty_weight（p）和 ccd_slack_max（ε 上界）' ...
                    '都是有限正实数，当前为 %s 和 %s。'], ...
                    mat2str(penalty_weight), mat2str(slack_max));
            end
            term_name = 'unit_norm_penalty';
            term_label = '单位范数罚项';
            term_kind = 'inequality_penalty';
        otherwise
            error('SCP:UnknownUnitNormMode', ...
                '未知的单位范数处理方式 unit_norm.mode = ''%s''，可选 regularized、ccd。', ...
                char(string(mode)));
    end

    UnitNorm = struct('mode', mode, 'is_ccd', is_ccd, ...
        'penalty_weight', penalty_weight, 'slack_max', slack_max, ...
        'keep_control_bounds', keep_control_bounds, ...
        'term_name', term_name, 'term_label', term_label, 'term_kind', term_kind);
end
