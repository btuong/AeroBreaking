function [r, v] = transform_elements2rv(el, mu)
% TRANSFORM_ELEMENTS2RV 由经典轨道根数计算中心天体惯性系 rv 矢量。
%
% 输入:
%   el  - 1x6 [半长轴, 偏心率, 倾角, 升交点赤经, 近地点幅角, 真近点角]
%   mu  - 引力常数（与 el(1) 同单位制）
%
% 输出:
%   r - 1x3 位置矢量
%   v - 1x3 速度矢量

    sma = el(1);
    ecc = el(2);
    incl = el(3);
    raan = el(4);
    argp = el(5);
    theta = el(6);

    nr = sma * (1 - ecc * ecc) / (1 + ecc * cos(theta));
    nv = sqrt(2 * mu / nr - mu / sma);

    gamma = atan(ecc * sin(theta) / (1 + ecc * cos(theta)));

    w = theta + argp;

    r = zeros(1, 3);
    r(1) = nr * (cos(w) * cos(raan) - sin(w) * cos(incl) * sin(raan));
    r(2) = nr * (cos(w) * sin(raan) + sin(w) * cos(incl) * cos(raan));
    r(3) = nr * (sin(w) * sin(incl));

    v = zeros(1, 3);
    v(1) = nv * (-sin(w - gamma) * cos(raan) ...
        - cos(w - gamma) * cos(incl) * sin(raan));
    v(2) = nv * (-sin(w - gamma) * sin(raan) ...
        + cos(w - gamma) * cos(incl) * cos(raan));
    v(3) = nv * (cos(w - gamma) * sin(incl));
end
