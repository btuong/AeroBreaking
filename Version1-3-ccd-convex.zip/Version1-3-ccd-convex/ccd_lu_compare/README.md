# ccd_lu_compare：文献 [20] 原文凹凸分解（`ccd_lu`）对比实验

在保持同一 SCP 外壳的条件下（`scp_config_default()` 基础上设 `iter.tolerance = 0`、固定信赖域 `r = 1`，带总脉冲平台停止：最近 5 个被接受轮极差 $\le 0.1\text{ m/s}$ 且对 P2 可行；关闭绘图与逐轮打印；不保存 `scp_run_full.mat` 与 `scp_run_scan.mat`），运行文献 [20]（Lu 2020）原文凹凸分解模式 `config.unit_norm.mode = 'ccd_lu'`（凹半平方线性化、零向量不替换、目标与 $J$ 不乘 $\omega_i$）的全部 12 个工况，并只读联合 `Version1-3-standard-5` 存档（5 个基线工况 + 7 个 $\omega_i$ 加权范数 CCD 工况），检验开关①、④、③及圆内/零初值行为。数据整理见阶段报告 `../docs/算法改进_阶段1_原文凹凸分解对比实验.md`。

## 工况清单（12 个 `ccd_lu` 工况，$\varepsilon_{\max} = 1$）

| 组别 | 工况名 | $p$（不乘 $\omega_i$） | 上限轮数 | 保 $\pm 1$ 箱形界 | 归一化初值 | 初始控制 |
|---|---|---|---|---|---|---|
| 主扫描（6 档） | `ccd_lu_p1e-5` .. `ccd_lu_p1e0` | $10^{-5}, 10^{-4}, 10^{-3}, 10^{-2}, 10^{-1}, 1$ | 50 | 否（放宽至 $\pm 2$） | 是 | 默认单位圆 |
| 等总权配对（2 档） | `ccd_lu_peq_1e-1` | $0.5/661 \approx 7.564\times 10^{-4}$ | 50 | 否 | 是 | 默认单位圆 |
|  | `ccd_lu_peq_1e0` | $5/661 \approx 7.564\times 10^{-3}$ | 50 | 否 | 是 | 默认单位圆 |
| 保边界对照 | `ccd_lukeep_p1e-2` | $10^{-2}$ | 50 | 是 | 是 | 默认单位圆 |
| 初值专项（3 档） | `ccd_lu_init0_p1e-2` | $10^{-2}$ | 10 | 否 | 是（零仍保持 0） | 全零 $u=0$ |
|  | `ccd_lu_init0p3_nonorm_p1e-2` | $10^{-2}$ | 10 | 否 | 否 | 模长缩为 $0.3$ |
|  | `ccd_lu_init0p3_nonorm_keep_p1e-2` | $10^{-2}$ | 10 | 是 | 否 | 模长缩为 $0.3$ |

## 运行方法

MATLAB 工作目录任意；入口脚本按自身路径只添加 `Version1-3-ccd-convex` 各模块与 `ccd_lu_compare/`，结束后自动恢复原路径：

```matlab
run('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-ccd-convex/ccd_lu_compare/SCP_ccd_lu_compare.m')
```

运行前可在工作区设置的可选变量：`rerun_existing`（默认 `false`）、`case_filter`（默认 `{}`）、`plateau_window`（默认 `5`）、`plateau_tolerance`（默认 `0.1`）、`results_folder`（默认 `'results'`）、`run_analysis`（默认 `true`）。

若全部 `case_metrics.mat` 已存在，单独重跑分析与作图：

```matlab
cd('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-ccd-convex/ccd_lu_compare');
[Summary, Groups, Check, SwitchTests] = analyze_ccd_lu_compare();
close all;
```

## 文件与产物清单

- `SCP_ccd_lu_compare.m`：对比实验批处理入口。
- `list_compare_cases.m`：12 个 `ccd_lu` 工况清单定义。
- `run_compare_case.m`：单工况运行与在线平台判据。
- `extract_compare_metrics.m`：提取 `case_metrics.mat`（含首轮不可行终止码及圆约束组分项账）。
- `analyze_ccd_lu_compare.m`：只读联合 12 个 `ccd_lu` 工况与 12 个 `Version1-3-standard-5` 存档（校验 `version_root` 与 `unit_norm_mode`），计算开关①/④/③与初值专项表并导出 6 张图。
- `results/<工况>/`：`scp_run_brief.txt`、`scp_run_detail.txt`、`scp_run_control.txt`、`scp_run_control.mat`、`case_metrics.mat`（无 `full_mat` 与 `scan_mat`）。
- `results/对比汇总.txt` 与 `results/对比汇总.mat`（含 `Summary`、`Groups`、`Check`、`SwitchTests`、`Options`）；`results/logs/` 存放批运行与分析日志。
- `pictures/`（6 张 PNG）：`对比-各轮总脉冲.png`、`对比-相对none差值.png`、`对比-欠罚失紧节点omega分布.png`、`对比-等总权开关4惯性与脉冲.png`、`对比-紧性衰减_前10轮.png`、`对比-末轮σ.png`。
