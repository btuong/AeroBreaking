# Version1-3-standard-5：CCD 模式（凹凸分解）实施方案

> **给执行的 agent：** 按下面的任务逐个实现，每完成一步把该步的 `- [ ]` 改成 `- [x]`。动手前先读仓库根 `AGENTS.md` 指定的三个 skill（`matlab-code-standards`、`matlab-scp-standards`、`trajectory-optimization-code-paradigm`）。执行方式按项目约定：由一个子 agent 实现，主会话核对。方案里有看不懂、与代码对不上或你认为不对的地方，停下来向主会话报告，不要自行改方案（勾选复选框和按任务追加的记录除外）。

**目标：** 在不改变现有行为的前提下，给单位范数约束 ‖u‖=1 增加一个可切换的处理方式——凹凸分解（CCD，Lu 2020），并按阶段3-1 的口径与现有的正则型无损凸化（W2）对比。

**做法：** 新增 `config.unit_norm.mode = 'ccd'`。CCD 下每个控制节点多一个松弛 ε_i：凸的一半 ‖u_i‖ ≤ 1 + ε_i 原样保留并罚 p·ω_i·ε_i，反凸的一半 ‖u_i‖ ≥ 1 在参考控制处线性化为 ē_i^T·u_i ≥ 1。除圆约束组外，动力学、信赖域、接受、判停、其余约束都不动。

**环境：** MATLAB R2025b + MOSEK（`D:/Program Files/MATLAB/R2025b/bin/matlab.exe`）。

**依据：** 规格文件 `../../凹凸分解_实现规格_对照现有方法.md`（第 2.1–2.6、2.8 节，第 4、5 节）。按用户 2026-11-23 的决定**不做**：2.8 节的判停（保持现状，只按步长停）、第 3 节的 `accept_all`、ratio 信赖域与收敛实验。对比按现有口径：fixed、r = 1、迭代到上限 50 轮、逐轮总脉冲与相对 none 的同轮差值。

## 全局约束

- **基线**：本版本自 `../Version1-3-standard-3` 复制（2026-11-23），复制时逐文件相同。**不得修改其他版本目录下的任何文件**；只改 `Version1-3-standard-5/` 内的文件，以及任务 10 指定的根目录两个文件（`docs/Version1-3-standard-5.md`、`README_bbb2.m`）。
- **默认模式逐位不变**：`config.unit_norm.mode = 'regularized'`（默认）下，变量布局、送进 MOSEK 的 problem、J 与 L 的分项名和类别、`results/` 下的 `scp_run_brief.txt`、`scp_run_detail.txt`、`scp_run_control.txt` 都必须与 standard-3 相同。
- **不动的部分**：`iteration/advance_scp_iteration.m`（判停）、`trust_region/` 的接受、半径和逐项账逻辑（`trust_region/evaluate_penalty_function.m` 只按任务 3 改圆约束组那一步）、`dynamics/`、`constraints/`、`validation/`、相邻节点 u1 差值约束、默认入口 `SCP.m` 的覆盖值（10 轮、norm、w_reg = 1e-4）。
- **名词与代码名**（全方案统一）:

  | 概念 | 代码名 |
  | --- | --- |
  | 单位范数约束 ‖u‖=1 | `unit_norm` |
  | 松弛 ε_i（凸一半的松弛；代码里不用 eps） | `unit_norm_slack` |
  | 反凸一半的线性化行（内逼近） | 行块 `unit_norm_inner` |
  | CCD 的罚项 p·Σω_i·[‖u_i‖−1]_+ | 分项 `unit_norm_penalty`，显示名“单位范数罚项”，短名“单位范数” |
  | 现有的控制正则项（W2） | 分项 `control_reg`（不变） |

- **分类**：CCD 的罚项归罚项 Θ（类别 `inequality_penalty`）；CCD 下没有附加项（Γ = 0）。
- **文件一律 UTF-8**；`.m` 按 `matlab-code-standards` 写（函数头的“数学形式”“代码形式”“本函数依次完成”，改代码时同步改）。
- **不使用 git**，不提交。
- **运行方式**：批处理命令的输出重定向到日志文件再查找关键行，不要只取输出的末尾几行（警告堆栈会把关键行挤掉）。每个 MATLAB 进程只加一个版本的路径。每轮 2–8 s，50 轮工况 3–7 分钟。
- **文档**：阶段编号 5-1；阶段报告只写数据，不写推导、结论和推荐；除任务 10 列出的文件外不生成其他报告。

## CCD 模式的数学定义

记 N 为节点数，ω_i 为按圈梯形权（每圈和为 1），ū_i = (ū1_i, ū2_i) 为参考控制，ē_i = ū_i/‖ū_i‖（‖ū_i‖ < 1e-6 时取 (1,1)/√2，与范数正则同一取法），p 为 `config.unit_norm.ccd_penalty_weight`，ε_max 为 `config.unit_norm.ccd_slack_max`。

| 对象 | regularized（默认，不变） | ccd |
| --- | --- | --- |
| 变量 | 无 ε | 每个节点一个 ε_i，共 N 个 |
| 控制锥 `control_disk` | (1, u1_i, u2_i) ∈ Q³，角色 `lossless` | (1 + ε_i, u1_i, u2_i) ∈ Q³，角色 `epigraph` |
| 线性行 | 无 | 行块 `unit_norm_inner`：−ē_i^T·u_i ≤ −1（i = 1..N；下界 −Inf） |
| ε 的边界 | — | 0 ≤ ε_i ≤ ε_max |
| u 的边界 | u1_i, u2_i ∈ [−1, 1] | `ccd_keep_control_bounds = false`（默认）：放宽到 [−(1+ε_max), 1+ε_max]；`true`：仍为 [−1, 1] |
| 目标里圆约束组的项 | 控制正则项（`build_objective` 第 5 步，不变） | p·Σω_i·ε_i；u 的系数全为 0；`objective_offset = 0` |
| J 里圆约束组的项 | Γ（不变） | Θ 多一项 p·Σω_i·max(‖u_i‖−1, 0)，用真实的 ‖u_i‖ |
| 初始参考 | 不变 | 控制归一化到圆上：u_i ← u_i/‖u_i‖ |

关于 u 的边界：现有 ±1 的箱形边界在无损凸化下由圆盘蕴含，是多余的；CCD 的迭代点在圆外，σ 接近 0°、±90°、180° 的节点会先碰到它，方法就被这条没有物理含义的约束改掉了。所以默认随凸的一半一起放宽，另留开关 `config.unit_norm.ccd_keep_control_bounds`，实验里多跑一个保留边界的对照工况。

其余不变：速率约束、路径约束、信赖域（u 不加）、接受规则、判停、动力学线性化、真空段映射。

## 复查重点（规格没说清、最容易出事的地方，各自的测试已排进任务）

1. **p 过小**（低于某些节点向外的需求）时 P3 必须仍有界并给出可用解，触到 ε_max 的节点要被报告 → 任务 4 `test_ccd_slack_cap_is_reported`，任务 6 玩具问题 p = 0.5。
2. **参考控制模长接近 0 的节点**：方向取 (1,1)/√2，内逼近行必须可行 → 任务 2 `test_ccd_assembled_p3_matches_formulas` 的退化节点断言。
3. **零步长可行性被破坏**（初始参考在圆内）：归一化 + 零步长检查 → 任务 4 `test_ccd_initial_reference_normalized`、`test_ccd_zero_step_feasible_on_unit_norm`。
4. **regularized 模式被悄悄改掉**（布局、数值、输出）→ 任务 2、3 的布局与分项测试，任务 6 的回归。
5. **CCD 下输出层崩溃**：没有 `control_reg` 项、旧配置没有 `unit_norm` 字段、P3 失败时的空控制量报告 → 任务 1 `test_describe_unit_norm_modes`，任务 4 的空报告断言，任务 5 的 CCD 全输出测试。
6. **保留箱形边界时与圆外的点冲突**（`ccd_keep_control_bounds = true`）→ 任务 6 `test_toy_kept_control_bounds_clip_before_cap`。

## 第一部分：实现（任务 1–7）

测试文件 `tests/test_unit_norm_ccd.m` 用 `functiontests`，在任务 1–5 里逐步加用例，任务 3 加入 `setupOnce`。运行测试的命令（下称“测试命令”; `tests/test_ccd_toy_problem.m` 在任务 6 才有，之前的任务把它从命令里去掉；`ccd_compare/results/logs/` 先建好）:

```powershell
& "D:/Program Files/MATLAB/R2025b/bin/matlab.exe" -wait -batch "cd('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-standard-5'); addpath('setup','dynamics','constraints','subproblem','trust_region','validation','iteration','output','tightness_diagnosis'); r = [runtests('tests/test_unit_norm_ccd.m'), runtests('tests/test_ccd_toy_problem.m'), runtests('tests/test_control_tightness_mechanisms.m')]; disp(table(r)); assert(all([r.Passed]) && isempty([r.Failed]) && isempty([r.Incomplete]))" > ccd_compare/results/logs/tests.log 2>&1
```

### 任务 1：模式开关与描述函数

**文件:** 修改 `setup/scp_config_default.m`；新建 `subproblem/describe_unit_norm.m`；测试 `tests/test_unit_norm_ccd.m`。

**接口:** `UnitNorm = describe_unit_norm(config)`，字段 `mode`、`is_ccd`（逻辑量）、`penalty_weight`（非 ccd 时为 0）、`slack_max`（非 ccd 时为 0）、`keep_control_bounds`（非 ccd 时为 false）、`term_name`、`term_label`、`term_kind`。regularized 时 `term_name = 'control_reg'`、`term_label = '控制正则项'`、`term_kind` 取 `describe_control_regularizer(config).kind`；ccd 时 `'unit_norm_penalty'`、`'单位范数罚项'`、`'inequality_penalty'`。

- [x] **步骤 1: 写失败的测试** `test_describe_unit_norm_modes`，断言:
  - 默认配置：`mode == 'regularized'`，`~is_ccd`，`term_name == 'control_reg'`，`term_kind == 'extra_nonconvex'`，`penalty_weight == 0`。
  - 去掉 `unit_norm` 字段的配置（`rmfield`）：按 regularized 处理。
  - `mode = 'ccd'`：`is_ccd`，`penalty_weight`、`slack_max`、`keep_control_bounds` 与配置相等，`term_name == 'unit_norm_penalty'`，`term_label == '单位范数罚项'`，`term_kind == 'inequality_penalty'`。
  - `mode = 'foo'` 报错 `SCP:UnknownUnitNormMode`；ccd 且 `ccd_penalty_weight <= 0` 或 `ccd_slack_max <= 0` 报错 `SCP:InvalidUnitNormConfig`。
- [x] **步骤 2: 运行测试命令**，确认因 `describe_unit_norm` 未定义而失败。
- [x] **步骤 3: 在 `scp_config_default.m` 的“迭代控制”之前加一段配置**，并在 `describe_unit_norm.m` 里实现。配置内容:

```matlab
    %% ===== 单位范数约束的处理方式 =====
    % P1 的 u1² + u2² = 1（u = (cos σ, sin σ)）在 P3 中怎样处理:
    %   'regularized'（默认）无损凸化：‖u_i‖ ≤ 1 作硬约束，目标里加控制正则项 Γ
    %                （config.objective.control_reg_type、weight_control_reg）把解推回圆周
    %   'ccd'          凹凸分解（Lu 2020）：凸的一半 ‖u_i‖ ≤ 1 + ε_i 原样保留，松弛 ε_i 罚 p·ω_i·ε_i；
    %                反凸的一半 ‖u_i‖ ≥ 1 在参考控制 ū_i 处线性化为 ē_i^T·u_i ≥ 1（ē_i = ū_i/‖ū_i‖）。
    %                没有控制正则项（Γ = 0），迭代点在圆上或圆外
    config.unit_norm.mode = 'regularized';            % 'regularized' 或 'ccd'
    config.unit_norm.ccd_penalty_weight = 1;          % p：ε 的罚权（再乘按圈梯形权 ω_i），只在 'ccd' 下使用
    config.unit_norm.ccd_slack_max = 1;               % ε 上界（只作安全上界；任一节点触到时报告 WARN）
    config.unit_norm.ccd_keep_control_bounds = false; % 'ccd' 下是否保留 u1、u2 的 ±1 边界；false 时放宽到 ±(1 + ε 上界)
```

- [x] **步骤 4: 运行测试命令**，通过。

### 任务 2：P3 的装配

**文件:** 修改 `subproblem/build_variable_index.m`、`build_variable_bounds.m`、`build_conic_constraints.m`、`build_linear_constraints.m`、`build_objective.m`；测试 `tests/test_unit_norm_ccd.m`。

**接口:** `build_conic_constraints` 的第 4 个输入由 `~` 改为 `config`（调用处 `solve_scp_subproblem.m` 已经在传 `config`，签名不用改）。regularized 下 `VariableIndex.unit_norm_slack = zeros(0, 1)`，ccd 下为 `(17N+26):(18N+25)`（排在 `t_f` 之后，其他变量的位置不变）。

- [x] **步骤 1: 写失败的测试**
  - `test_regularized_variable_layout_unchanged`：默认配置下 `isempty(VariableIndex.unit_norm_slack)`，`num_variables == 17*N + 25`，`VariableIndex.t_f == (17*N+21):(17*N+25)`。
  - `test_ccd_variable_layout`：ccd 下 `num_variables == 18*N + 25`，`unit_norm_slack` 的位置如上，`t_f` 位置不变。
  - `test_ccd_assembled_p3_matches_formulas`（在初始参考上，p = 1，ε_max = 1）:
    - `row_groups.unit_norm_inner` 共 N 行；每行两个非零系数等于 −ē_i，`upper` 全为 −1，`lower` 全为 −Inf。
    - 第 i 个 `control_disk` 锥：`mapping(1, unit_norm_slack(i)) == 1`，`mapping(2, u1(i)) == 1`，`mapping(3, u2(i)) == 1`，`offset == [1; 0; 0]`，`tightness_role == 'epigraph'`。
    - 边界：ε_i ∈ [0, 1]；u1_i、u2_i ∈ [−2, 2]；`ccd_keep_control_bounds = true` 时 u1_i、u2_i ∈ [−1, 1]。
    - 目标：`c(unit_norm_slack) == p·ω`（相对误差 ≤ 1e-15），`c(u1)`、`c(u2)` 全为 0，`objective_offset == 0`。
    - 退化节点：把参考控制第 3 个节点改成 (0, 0) 后，该行系数等于 −(1, 1)/√2。
    - regularized：`row_groups` 没有 `unit_norm_inner` 字段，`control_disk` 锥的行号仍是 `[2; 3]`。

  初始参考的生成放进局部函数 `build_test_problem`（任务 3 的 `setupOnce` 也用它）。
- [x] **步骤 2: 运行测试命令**，确认新用例失败。
- [x] **步骤 3: 实现**
  - `build_variable_index`：末尾按模式分配 `unit_norm_slack`；更新头部的变量布局说明。
  - `build_variable_bounds`：第 1 步控制量边界按上表的开关取值；第 5 步在 ccd 下加 ε_i ∈ [0, ε_max]。
  - `build_conic_constraints`：`control_disk` 在 ccd 下的三个行号、列号和角色如上；头部的数学形式、代码形式同步。
  - `build_linear_constraints`：新增局部函数 `build_unit_norm_inner_block(VariableIndex, CurrentReference, config)`，块放在 `control_continuity` 之后、`impulse_epigraph` 之前，只在 ccd 下发出（regularized 下 `row_groups` 不多出字段）；头部的约束类型清单加一行。ē 的取法在这个局部函数里按同一规则算，不改 `build_objective` 的范数正则分支。
  - `build_objective`：第 5 步按模式分支，ccd 下只给 ε 系数；头部同步。
- [x] **步骤 4: 运行测试命令**，通过。

### 任务 3：J、目标分项与解的提取

**文件:** 修改 `trust_region/evaluate_penalty_function.m`、`subproblem/compute_objective_terms.m`、`subproblem/extract_subproblem_solution.m`、`output/describe_penalty_term.m`；`subproblem/solve_scp_subproblem.m` 只改注释。测试 `tests/test_unit_norm_ccd.m`。

**接口:** `CurrentSolution.unit_norm_slack`（ccd 下 N×1，regularized 下为 `[]`）。J 与 L 的最后一个分项：regularized 仍是 `control_reg`；ccd 是 `unit_norm_penalty`（类别 `inequality_penalty`）。

- [x] **步骤 1: 加 `setupOnce` 并写失败的测试**
  - `setupOnce(testData)`：生成问题数据、初始参考（ccd 配置：p = 1，ε_max = 1）；按 `tests/compare_norm_vs_norm_gap.m` 里 `run_case` 的写法关掉绘图、打印、保存和梯形递推检查，跑 3 轮，把 3 条 `IterationRecord` 存进 `testData.ccd_history`。任务 2 的三个用例改读 `testData`，不再各自生成初始参考。
  - `test_regularized_term_list_unchanged`：regularized 下 `evaluate_penalty_function` 与 `compute_objective_terms` 的分项名依次都是 `terminal_inclination`、`terminal_apoapsis`、`impulse`、`point_slack`、`dyn_slack`、`control_reg`，类别相同。
  - `test_ccd_circle_term_matches_true_function`：对 3 轮里的每一轮，取 `Record.trust.evaluation`：`term_names` 的最后一项是 `unit_norm_penalty`、类别 `inequality_penalty`；`term_candidate` 等于 p·Σω_i·max(‖u_i‖−1, 0)（用控制量报告里的 `omega`、`u_norm` 重算，容差 1e-12）；`group.extra.candidate == 0`；`~isempty(Record.solution.unit_norm_slack)`。
- [x] **步骤 2: 运行测试命令**，确认新用例失败。
- [x] **步骤 3: 实现**
  - `evaluate_penalty_function` 第 2 步按 `describe_unit_norm` 分支：ccd 下 `control_sum = ω' * max(hypot(u1, u2) - 1, 0)`；最后一行的名称、显示名、类别取自 `UnitNorm`，值为 `UnitNorm.penalty_weight * control_sum`。头部写明 ccd 下 J = C + Θ、Θ 含单位范数罚项。
  - `compute_objective_terms`：最后一行的名称、显示名、类别取自 `UnitNorm`，ccd 下变量下标取 `VariableIndex.unit_norm_slack`；偏置只加给 `control_reg`。
  - `extract_subproblem_solution`：加 `unit_norm_slack` 字段。
  - `describe_penalty_term`：加 `unit_norm_penalty` → `单位范数`。
- [x] **步骤 4: 运行测试命令**，通过。

### 任务 4：控制量报告、对偶分解、乘子与初始参考

**文件:** 修改 `subproblem/compute_control_dual_split.m`、`evaluate_control_report.m`、`create_empty_control_report.m`、`summarize_control_report.m`、`create_empty_control_summary.m`、`evaluate_p3_multipliers.m`、`iteration/initialize_scp_run.m`；测试 `tests/test_unit_norm_ccd.m`。

**接口（新增字段，两种模式都有）:**

| 位置 | 字段 | 含义 | regularized 下 |
| --- | --- | --- | --- |
| `Split` 与 `ControlReport` | `s_inner`（N×2） | 内逼近行乘子传到 u 列上的作用 −A_u^T·y（行块 `unit_norm_inner`） | 全 0 |
| `ControlReport` | `lambda_inner`（N×1） | `vecnorm(s_inner, 2, 2)` | 全 0 |
| `ControlReport` | `unit_norm_slack`（N×1） | 候选解的 ε | NaN |
| `ControlReport` | `slack_capped`（N×1 逻辑量） | ε_i ≥ ε_max − 1e-9·max(1, ε_max) | 全 false |
| `ControlReport` | `cone_dual_leading`（N×1） | 第 i 个 `control_disk` 锥对偶解的首分量 κ̂_i（`doty` 的对应行）；对偶不可用时 NaN | 有值 |
| 汇总（逐圈与全程） | `max_inward_gap`、`max_outward_gap`、`num_slack_capped` | max(1−‖u‖, 0)、max(‖u‖−1, 0)、触上界的节点数 | 前两个有值，第三个为 0 |

驻点条件恒等式改为 `s_total = s_reg + s_inner + s_main`（regularized 下 s_inner 为 0，数值不变）。乘子报告在行块存在时多一类 `unit_norm_inner`（显示名“单位范数内逼近”，罚权 NaN，只给 max|y|）。

- [x] **步骤 1: 写失败的测试**
  - `test_ccd_zero_step_feasible_on_unit_norm`：对初始参考和 3 轮里每个被接受轮之后的参考（`reference_after`），用装配器（`build_variable_index`、`build_linear_constraints`、`build_conic_constraints`）建出这一参考的 P3，取 z 里 u = ū、ε = max(‖ū‖−1, 0)，断言：`control_disk` 各锥的可行性残差 ≤ 1e-12，`unit_norm_inner` 各行 `A·z − upper` 的残差对初始参考 ≤ 1e-12、对被接受轮之后的参考 ≤ `config.solver.co_tol_pfeas`（参考取自 P3 的解，残差在求解器的原始可行性容差以内），0 ≤ ε ≤ ε_max。
  - `test_ccd_candidates_stay_outside_and_term_is_exact`：3 轮里每轮 `min(u_norm) >= 1 - 1e-8`；`unit_norm_slack >= max(u_norm - 1, 0) - 1e-7`；单位范数罚项的 `term_prediction_error` 绝对值 ≤ 1e-6·max(1, p)；`~convex_error_flag`；单位范数内逼近行和控制锥在候选解处的原始残差 ≤ 1e-6（不用 P3 解检查的总通过标志：它的阈值 1e-7 在 regularized 下也会被终端、衔接行的原始残差偶尔超过，与 ccd 无关）。
  - `test_ccd_dual_split_residual`：对偶可用的轮，`max(abs(stationarity_residual), [], 'all') <= 1e-6`；逐节点 `s_inner(i,:) == ē_i·y_i`（y_i 取 `solver.dual.y` 在 `unit_norm_inner` 行上的值，容差 1e-12·max(1, max|y|)）；`cone_dual_leading(i) == p·ω_i − slx(ε_i) + sux(ε_i)`（AbsTol 1e-9·max(1, p)，RelTol 1e-3：求解器返回的对偶解在原始坐标下有 1e-6 量级的误差）。
  - `test_ccd_slack_cap_is_reported`：用 `testData.InitialReference` 和 p = 1e-6、ε_max = 0.1 的 ccd 配置跑 1 轮：P3 求解成功，`any(slack_capped)`，`summary_total.num_slack_capped == sum(slack_capped)`，`max(unit_norm_slack) >= 0.1 - 1e-9`。
  - `test_ccd_initial_reference_normalized`：把初始参考控制的第 1、2、3 个节点改成模长 0.5、1、1.5 的向量，ccd 下 `initialize_scp_run` 后 `current_reference.control` 各节点模长为 1（容差 1e-12），零向量节点得到 (1,1)/√2；regularized 下保持原值。
  - `test_empty_control_report_has_unit_norm_fields`：`create_empty_control_report('solver_failed')` 含上表全部字段，`create_empty_control_summary` 含三个新汇总字段。
- [x] **步骤 2: 运行测试命令**，确认新用例失败。
- [x] **步骤 3: 实现** 各文件的新增字段与分支；`initialize_scp_run` 的 `build_reference_view` 在 ccd 下归一化控制（`RunState.initial_reference` 保持原样，函数头写明）。
- [x] **步骤 4: 运行测试命令**，通过。

### 任务 5：输出层

**文件:** 修改 `output/print_scp_iteration.m`、`output/print_control_report.m`、`output/build_control_export.m`、`output/build_iteration_plot_data.m`、`SCP.m`；测试 `tests/test_unit_norm_ccd.m`。

regularized 下的终端输出和三个文本文件不得多出任何一行或一列。ccd 下:

- `print_p3_checks`（第 3 块）在“锥重构”一行之后加一行，格式 `'  %s 单位范数 ε最大 %.2e | 触上界 %d | |1-‖u‖| %.2e | 不紧 %d'`，有节点触上界时 `%s` 处写 `WARN`，否则写四个空格；显示宽度不超过 78 列。
- `print_control_report`：头部加一行 `'单位范数处理: ccd | p %.3e | ε上界 %.3e'`；[2] 第一张表加两列“ε最大”“触上界”；[4] 逐节点表加一列“ε”。
- `build_control_export` 加 `unit_norm_mode`、`ccd_penalty_weight`、`ccd_slack_max` 三个字段。
- `build_iteration_plot_data`：没有 `control_reg` 分项时附加项取 0。
- `SCP.m`：头注释提一句两种模式；“配置覆盖”里加一行 `config.unit_norm.mode = 'regularized';   % regularized（无损凸化，默认） ccd（凹凸分解）`，其余不动。

- [x] **步骤 1: 改代码。**
- [x] **步骤 2: 加测试 `test_ccd_entry_outputs_run`**（ccd 全输出的跑通检查）。ccd 配置（p = 1），`max_scp_iter = 2`，`plot.enable_iteration = true`、`enable_final = true`、`visibility = 'off'`、`save_figures = false`，`output.save` 里 `brief_text`、`detail_text`、`control_text`、`control_mat` 为 true、其余为 false，打印全部关闭；流程同 `SCP.m`（初始化、2 轮主循环、`finalize_scp_run`、`plot_scp_result`、`build_scp_result`、`save_scp_result`），结束后 `close all`。`save_scp_result` 把目录拼在版本根之下（`fullfile(version_root, directory)`），所以保存目录用版本根下的临时相对目录 `results/tmp_entry_check`，测试结束（包括断言失败时）删除。断言：`PlotReport.success`；详细文件每轮的乘子表里有“单位范数内逼近”一行（详细文件不含 P3 解检查块）；控制量文本头部有“单位范数处理: ccd”。
- [x] **步骤 3: 运行测试命令**，通过。

### 任务 6：玩具问题与回归

**文件:** 新建 `tests/test_ccd_toy_problem.m`。

玩具问题（规格第 4 节第 1 条）：min_u −q·d^T·u，q = 1，d = (1,0)，‖u‖ = 1，从 θ₀ = 30° 出发，不设信赖域。每轮解一个 3 变量（u1、u2、ε）的 SOCP：目标 `[−q; 0; p]`，锥 `(1+ε, u1, u2)`，行 `−ē^T·u ≤ −1`，边界 u ∈ [−(1+ε_max), 1+ε_max]、ε ∈ [0, ε_max]，**调用项目的 `solve_convex_subproblem`**；J = −q·d^T·u + p·max(‖u‖−1, 0)，L 取求解器返回的解按同一目标算出的值；ρ = (J_k − J_{k+1})/(J_k − L_{k+1})。

- [x] **步骤 1: 写 `test_ccd_toy_problem.m`（三个用例）**
  - `test_toy_p_above_demand`：p = 5，ε_max = 1，10 轮。每轮解在锥上取紧；第 1–5 轮 `|ρ − 1| <= 1e-4`；θ_1 ∈ [24.2°, 24.3°]，ε_1 ∈ [5.0e-3, 5.1e-3]；第 2–9 轮 θ_{k+1}/θ_k ∈ [0.80, 0.81]；每轮的 θ 和 ε 与解析递推一致（sin φ_k = 0.2·sin θ_k，ε_(k+1) = 1/cos φ_k − 1；θ 用 RelTol 1e-3，ε 用 AbsTol 1e-6）；ε_10 <= 1.1e-4（解析值 1.047e-4）；ε 逐轮严格减小；没有触上界。
  - `test_toy_p_below_demand_hits_cap`：p = 0.5，ε_max = 0.5，3 轮。第 1 轮后 θ = 0（|θ| <= 1e-4°），ε = ε_max（容差 1e-7），以后各轮不变；每轮都判为触上界（ε ≥ ε_max − 1e-9）；第 1 轮 ρ = 1（容差 1e-6）。
  - `test_toy_kept_control_bounds_clip_before_cap`：同上，但 u 的边界保留为 [−1, 1]。3 轮里第 k 轮后 θ_k = 30/2^k 度（容差 1e-5°），u1 = 1（容差 1e-7），ε_k = 1/cos(θ_k) − 1（容差 1e-6），不触上界。
- [x] **步骤 2: 运行测试**，三个用例通过。
- [x] **步骤 3: 回归 R1。** 在本版本目录用 MATLAB 批处理运行 `SCP.m`（默认入口，regularized，10 轮），日志写到 `ccd_compare/results/logs/entry_regularized.log`。核对:
  - `results/scp_run_brief.txt`、`scp_run_detail.txt`、`scp_run_control.txt` 与 `../Version1-3-standard-3/results/` 下的同名文件相同（用 `diff`；`scp_run_control.txt` 的第 2 行是版本目录名，必然不同）。比较的基准是复制时的 standard-3 及它已存下的结果文件。
  - 默认入口配置逐轮总脉冲与 `../Version1-3-standard-3/regularizer_converge/results/norm_w1e-4/case_metrics.mat` 里的 `Metrics.total_impulse_m_s(1:10)` 之差的最大值为 0（入口配置就是 norm、w = 1e-4）。

  两项不一致时原样报告差多少、从第几轮开始，不要调容差。
- [x] **步骤 4: 运行测试命令**（三个测试文件全部），全部通过。

### 任务 7：实现部分的文档

**文件:** 修改 `docs/algorithm_knowledge_base/气动辅助降轨算法知识库.md`、`README.md`（版本）、`tightness_diagnosis/README.md`；在本文件末尾追加“实现核对记录”。

- [x] **知识库**（只写代码已经实现的定义，未决项进第 7 节）: §0 加 2026-11-23 修订说明；§3.1“其他变换”加一条“单位范数约束的凹凸分解（可选）”，写明两种模式下 P2 约束、罚问题和 P3 的差别；§4.1 加 ccd 下 Θ 的单位范数罚项、Γ = 0；§5.3 第 7 条、§5.4 目标、§5.5 变量表各加 ccd 的写法；§6.1 写初始参考在 ccd 下归一化；§6.5 写 ccd 下控制锥按上图紧性检查、单位范数紧性由控制量报告给出、触上界报告 WARN；§7 加 D15，列出：p 的门槛（p·ω_i 不小于该节点向外的需求）、ε_max 的取法、中间迭代点 ‖u‖ > 1 使升力放大、保留箱形边界时与圆外的点冲突、罚问题的约束里多了非凸硬约束 ‖u‖ ≥ 1（靠内逼近保证迭代点满足）、半径扫描不支持 ccd。
- [x] **版本 `README.md`**: 标题和来历改为本版本（自 standard-3 复制，复制了模块、入口、README、知识库、`tests/` 和 `tightness_diagnosis/` 的代码，不含结果、图和 `regularizer_converge/`）；新增“## 阶段5-1：增加凹凸分解（CCD）模式（2026-11-23）”一节，写做法、改动的文件、怎样切换、不动的部分、验证结果（测试、R1 的数字），并指向本文件；standard-3 的各节改为“以下为 standard-3 起沿用的说明”，其中指向 `regularizer_converge/`、阶段3-1 报告的路径改成 `../Version1-3-standard-3/` 下的路径；目录结构表加 `ccd_compare/` 并更新 `tightness_diagnosis/`、`tests/`、`results/` 三行；“测试”一节改为本版本的五个脚本。
- [x] **`tightness_diagnosis/README.md`**: 开头加一句“代码自 Version1-3-standard-3 复制（2026-11-23），结果存档在 `../Version1-3-standard-3/tightness_diagnosis/`”。
- [x] **本文件追加“## 实现核对记录”**: 测试通过数、R1 两项核对的结果、ccd 默认入口的末轮总脉冲和 max|1−‖u‖|。

## 第二部分：对比实验（任务 8–10；主会话核对完第一部分之后再做）

口径与阶段3-1 相同：`scp_config_default()` 加覆盖——`max_scp_iter = 50`、`iter.tolerance = 0`（关步长停止）、fixed、r = 1，带总脉冲平台停止（最近 5 个被接受轮极差 ≤ 0.1 m/s 且对 P2 可行）；关闭绘图和逐轮打印；保存 `brief_text`、`detail_text`、`control_text`、`control_mat`。

**参照脚本（只读，不要改）:** `../Version1-3-standard-3/regularizer_converge/` 下的 `SCP_regularizer_converge.m`、`run_converge_case.m`、`extract_converge_metrics.m`、`analyze_regularizer_converge.m`（表格、图例、样式等辅助函数可以复制过来用）。

### 任务 8：实验脚本与试点

**文件（都在 `ccd_compare/`）:** `run_compare_case.m`（原样复制 `run_converge_case.m`）、`extract_compare_metrics.m`、`list_compare_cases.m`、`SCP_ccd_compare.m`。

- [x] **步骤 1: `Cases = list_compare_cases(p_exponents)`。** 返回 1×n 结构体数组，字段 `name`、`type`、`w`、`p`、`keep_control_bounds`（默认 false）。固定工况: `none`；`norm_w1e-4`（type `norm`，回归用）；`normgap_w1e-3`、`normgap_w1e-4`、`normgap_w1e-5`（type `norm_gap`）。CCD 工况: `p = 10^e`，e 取 `p_exponents`（默认 `[]` 表示用文件里写死的最终档位），名字 `sprintf('ccd_p1e%d', e)`；外加 `ccdkeep_p1e<默认档>`（`keep_control_bounds = true`）。w、p 一律用 `str2double(sprintf(...))` 得到，与字面量逐位相同。
- [x] **步骤 2: `Metrics = extract_compare_metrics(Result, RunInfo, case_name, Case, elapsed_seconds)`。** 在 `extract_converge_metrics` 的字段基础上加: `mode`、`p`；逐轮量 `max_inward_gap`、`max_outward_gap`、`num_slack_capped`、`num_bound_active`（‖s_bound,i‖ > 1e-12 的节点数）、`circle_predicted`、`circle_actual`、`circle_error`（圆约束组分项——regularized 是 `control_reg`，ccd 是 `unit_norm_penalty`——的预测下降、真实下降、预测误差）。没有候选解的轮记 NaN。
- [x] **步骤 3: `SCP_ccd_compare.m`。** 结构照搬 `SCP_regularizer_converge.m`，按 `Case.type` 设配置（ccd 时 `config.unit_norm.mode = 'ccd'`、`ccd_penalty_weight = p`、`ccd_slack_max = 1`、`ccd_keep_control_bounds`）。入口变量: `rerun_existing`、`case_filter`、`max_iter`（50）、`plateau_window`（5）、`plateau_tolerance`（0.1）、`results_folder`（`results`）、`run_analysis`、`p_exponents`。
- [x] **步骤 4: 回归工况。** 先跑 `none` 和 `norm_w1e-4`（50 轮）。两工况的逐轮总脉冲与 `../Version1-3-standard-3/regularizer_converge/results/<工况>/case_metrics.mat` 的 `total_impulse_m_s` 之差的最大值都应为 0；不是 0 就停下报告。
- [x] **步骤 5: 定 p 的档位。** 用 `results_folder = 'pilot'`、`max_iter = 10` 跑 `normgap_w1e-4`，取各轮控制量报告 `s_main_norm./omega` 在全部节点上的最大值 q_ref，记 e0 = floor(log10(q_ref))，把 `(e0-1):(e0+4)` 写成 `list_compare_cases` 的默认档位。报告 q_ref、e0。
- [x] **步骤 6: 试点 CCD。** 跑 `ccd_p1e(e0-1)`、`ccd_p1e(e0+1)`、`ccd_p1e(e0+3)`（结果直接存进 `results/`，之后不重跑）。核对每轮 P3 都求解成功、`|circle_error|` 的全程最大值、触上界的节点数、max|1−‖u‖| 随轮次的变化。若三档全部在多数轮触上界，或 max|1−‖u‖| 到第 50 轮仍大于 1e-2，停下报告，不要自己加档。

### 任务 9：正式运行与分析

**文件:** 新建 `ccd_compare/analyze_ccd_compare.m`；输出 `ccd_compare/results/对比汇总.txt`、`对比汇总.mat`（顶层 `Summary`、`Groups`、`Check`、`Options`）、`ccd_compare/pictures/` 下的图。

- [x] **步骤 1: 跑全部工况**（后台，日志进 `ccd_compare/results/logs/formal.log`，按 `[CASE]` 行和 `ALL_DONE` 监控）。
- [x] **步骤 2: 写 `analyze_ccd_compare.m`**，只读各工况的 `case_metrics.mat`、`scp_run_control.mat` 和阶段3-1 的两份存档。节点分组沿用阶段3-1：以 `none` 末轮为准，q_i = ‖s_main,i‖/ω_i，D = {q < 1e-6}，E 为其余节点。汇总文本的分节:

  1. 运行清单：工况、模式、w 或 p、轮数、停止原因、用时。
  2. 回归核对：`none`、`norm_w1e-4` 相对阶段3-1 存档的逐轮最大差。
  3. 自检：全部 ccd 轮的 `|circle_error|` 最大值、驻点残差最大值、`min(u_norm)` 的最小值。
  4. 末轮表（每个工况）: 末轮总脉冲、末 5 轮均值、末 10 轮每轮降幅、末 5 轮极差、相对 none 的同轮差值 d 的末轮值与末 5 轮极差、差值稳定轮（与阶段3-1 同一定义，δ = 0.1 m/s）、末轮与全程的 max|1−‖u‖|、末轮向内与向外的差、末轮不紧节点数（> 1e-6）、全程触上界节点数的最大值、末轮触箱形边界的节点数。
  5. 圆约束组的逐项账：各工况该项的 ΔL、ΔJ、D 的末轮值和全程 max|D|。
  6. 下降比：各工况末 5 轮 ρ、ΔL、ΔJ 的均值。
  7. 乘子（末轮，E 上）: κ̂/ω、‖s_main‖/ω 的中位数、5%、95% 分位、最小值、最大值；ccd 另给 λ_inner/ω 和 κ̂/(p·ω) 的同样统计。
  8. σ 偏差（末轮）: 各工况相对 `none` 的 |Δσ| 在 E、D 上的中位数；ccd 各档相对 `normgap_w1e-4` 的 |Δσ| 中位数和末轮总脉冲之差。
  9. 逐轮序列：各工况的总脉冲、max|1−‖u‖|、max ε。

  图（中文标签，字号 16，每扇窗底部一个共用图例，用 `output/save_plot_figure` 导出）: ①各轮总脉冲；②相对 none 的差值随轮次（画 ±0.1 带）；③末轮 |d| 随 p、w（双对数，画 δ 线）；④max|1−‖u‖| 与 max ε 随轮次；⑤末轮 κ̂/ω 的经验分布（ccd 各档各一个子图，画 p 处的竖线）与 ‖s_main‖/ω；⑥末轮 σ 叠画（每圈一个子图：`none`、`normgap_w1e-4`、`ccd_p1e<默认档>`）。
- [x] **步骤 3: 定默认 p。** 默认 p 取扫描中最小的一档，满足：全程没有节点触上界，且末轮 max|1−‖u‖| ≤ 1e-3。把 `scp_config_default.m` 里 `ccd_penalty_weight` 的默认值改成它，并在注释里写“由阶段5-1 的 p 扫描确定”，改完重跑测试命令（测试里显式设置 p，不依赖默认值）。没有满足的档就保持 1，并报告。
- [x] **步骤 4: 运行分析**，检查文本和 6 张图。

### 任务 10：实验部分的文档

- [x] **阶段报告** `docs/算法改进_阶段5-1_凹凸分解模式.md`: 只写数据，紧凑，分节为“判据与配置”“回归与自检”“末轮表”“圆约束组的逐项账”“乘子”“σ 偏差”“逐轮要点”，末尾注明试点和正式运行的用时。
- [x] **本文件追加“运行方法与产物”**: 入口用法、入口变量、文件清单、运行结果日期。
- [x] **版本 `README.md`**: 阶段5-1 一节补实验做法和指向阶段报告的一句话。
- [x] **根目录**: 新建 `docs/Version1-3-standard-5.md`（来历、区别、验证与实验的要点、指向阶段报告，篇幅与 `docs/Version1-3-standard-4.md` 相当）；在 `README_bbb2.m` 的 `Version1-3-standard-4` 条目之后加本版本一条（三四行）。

## 完成时向主会话报告

- 改动和新建的文件清单（按模块）。
- 测试命令的输出（通过、失败、未完成的个数）。
- R1 两项核对和回归工况的结果（具体数字）。
- q_ref、e0、p 的档位、默认 p 及其依据。
- 末轮表和第 3、5 节的数字。
- 与本方案不一致的任何地方，以及你认为方案有问题的地方。

## 实现核对记录（2026-11-24，第一部分任务 1–7）

**测试命令**（三个测试文件，日志 `results/logs/tests.log`）：23 个用例，通过 18、失败 5、未完成 0。`test_unit_norm_ccd.m` 13 个用例通过 10 个，`test_ccd_toy_problem.m` 3 个通过 1 个，`test_control_tightness_mechanisms.m` 7 个全部通过。5 个失败都是方案的断言阈值低于 MOSEK 的求解精度，实现与公式一致；按约定没有改阈值，逐条如下（数值来自 `results/logs/tests.log`、`diag_ccd_zero_step.log`、`diag_reg_residual.log`、`diag_r1_and_ccd.log`）：

| 用例 | 断言（方案阈值） | 实测 | 说明 |
| --- | --- | --- | --- |
| `test_ccd_zero_step_feasible_on_unit_norm` | 后续参考的内逼近行零步长残差 ≤ 1e-12 | 初始参考 −2.2e-16（通过）；被接受轮之后的 3 个参考 1.360e-10、1.275e-10、7.648e-11（各 33、73、86 个节点 > 1e-12） | 残差 = ‖ū‖−1，即上一轮候选解处内逼近行被 MOSEK 压到边界时的违反量（MOSEK 自报变量违反 0.8e-10～1.3e-10） |
| `test_ccd_candidates_stay_outside_and_term_is_exact` | 3 轮 `p3_check.solver_feasibility_report.success` | 第 1、2 轮为 false，第 3 轮为 true；其余断言（min‖u‖ ≥ 1−1e-8、ε 取紧、\|D\| ≤ 1e-6、`~convex_error_flag`）全部通过 | 第 1 轮 `A.unit_norm_inner` 残差 4.7e-7（阈值 1e-7，MOSEK 自报 con 违反 6.0e-7）；第 2 轮 `A.point_terminal` 1.16e-7、`A.point_inner_cir4` 1.43e-7。regularized 对照（`diag_reg_residual.log`）第 2、3 轮同样为 false（`A.point_terminal`、`A.point_inner_cir1/cir4` 1.06e-7～1.82e-7），与 ccd 无关 |
| `test_ccd_dual_split_residual` | κ̂_i = p·ω_i − slx(ε_i) + sux(ε_i)，容差 1e-9·max(1, p) | 最大绝对误差第 1 轮 1.5e-10、第 2 轮 9.9e-7、第 3 轮 7.4e-7（相对 1.3e-8、6.7e-5、5.3e-5）；190 个和 210 个节点超 1e-9 | u 列驻点残差 ≤ 1e-6 通过（最大 1.1e-10、7.0e-7、5.2e-7）；s_inner = ē·y 和 λ_inner = \|y\|（容差 1e-12·max(1, max\|y\|)）通过；MOSEK 自报对偶违反 1.4e-17，ε 列的残差是内点法在对偶解上的精度 |
| `test_toy_p_above_demand` | ε_10 ≤ 1e-4 | 1.047e-4 | 解析值：sin φ_k = −sin θ_k/p，ε_k = sec φ_k − 1，递推得 θ_10 = 3.326°、ε_10 = 1.043e-4；θ_1 = 24.26°、ε_1 = 5.04e-3、θ_{k+1}/θ_k ∈ [0.800, 0.806]、ρ = 1（\|ρ−1\| ≤ 1e-4）、ε 逐轮严格减小、不触上界，全部通过 |
| `test_toy_p_below_demand_hits_cap` | 第 1 轮后 \|θ\| ≤ 1e-6° | 1.3485e-5°（三轮相同） | 解析值 θ = 0；ε = ε_max（容差 1e-7）、每轮判为触上界、第 1 轮 ρ = 1（容差 1e-6）通过；偏差是 MOSEK 在 u2 上的原始解精度（2.4e-7） |

**R1 回归**（默认入口 `SCP.m`，regularized，10 轮，日志 `results/logs/entry_regularized.log`，175.75 s；10 轮全部求解并接受，`stop_reason = max_iterations`）：

- `results/scp_run_brief.txt`、`scp_run_detail.txt` 与 `../Version1-3-standard-3/results/` 下的同名文件逐字节相同（SHA256 一致，`cmp` 无差异）。`scp_run_control.txt` 只差第 2 行“版本: Version1-3-standard-5”（写的是版本目录名，由 `build_control_export` 给出），其余 57182 字节逐字节相同。
- 默认入口配置逐轮总脉冲与 `../Version1-3-standard-3/regularizer_converge/results/norm_w1e-4/case_metrics.mat` 的 `Metrics.total_impulse_m_s(1:10)` 之差的最大值为 0（10 轮全精度逐位相同，末轮 97.0825899956 m/s；`diag_r1_and_ccd.log`）。
- 终端输出里没有“单位范数”字样；“P3 解检查”块的行数和格式不变。

**ccd 入口**（`config.unit_norm.mode = 'ccd'`，p = 1，ε_max = 1，其余同默认入口，10 轮；`diag_r1_and_ccd.log`）：10 轮全部求解并接受，到上限停止。第 1 轮 max ε = 2.350e-1（总脉冲 122.3105 m/s，ρ = −4.06），第 2 轮 max ε = 1.145e-3，第 3～10 轮 max ε 在 7.3e-4～7.6e-4；末轮总脉冲 **126.5425 m/s**，末轮 max\|1−‖u‖\| = **7.322e-4**（等于 max ε，全部向外；min‖u‖−1 = −1.3e-10）。全程没有节点触上界；单位范数罚项的预测误差 \|D\| ≤ 5.6e-11；`solver_feasibility_report.success` 第 1、2、4 轮为 false、其余为 true。p = 1 时第 1 轮 ε 冲到 0.235、总脉冲比 regularized 高约 30 m/s，说明 p = 1 低于门槛（D15），档位由第二部分的任务 8 步骤 5 定。

**`test_ccd_entry_outputs_run`**（ccd，p = 1，2 轮，全输出）：通过；两轮的 max\|1−‖u‖\| 为 2.350e-1、1.145e-3（与上面 ccd 入口的第 1、2 轮相同）。

**与方案不一致或实现时的取舍**：

- `evaluate_penalty_function.m` 在 `trust_region/` 下：全局约束写“`trust_region/` 全部不动”，任务 3 又要求改它（J 必须改才能实现 ccd）。按任务 3 改了，只改圆约束组那一步，接受与半径逻辑没动。
- `setupOnce` 的签名按 `functiontests` 写成 `setupOnce(testCase)`，共享数据经 `testCase.TestData` 传递（方案写的 `setupOnce(testData)` 是简写）。
- `build_linear_constraints` 在 regularized 下不把空的内逼近块放进 `Blocks`（聚合函数对空块也会在 `row_groups` 里写一个空字段），所以 regularized 下 `row_groups` 没有多出字段。
- “详细文件每轮有‘单位范数’一行”：详细文件不打 `p3_checks` 块，这一行来自展开的乘子表（`unit_norm_inner` → “单位范数内逼近”）；终端的 `p3_checks` 块按方案在“锥重构”之后多一行。方案给的格式串在节点数和不紧节点数都是三位数时显示宽度约 79 列。
- 控制量文本头部新增行的格式：`'单位范数处理: ccd | p %.3e | ε上界 %.3e'`。
- regularized 下控制量报告的 `unit_norm_slack` 为 NaN（方案表格写 NaN）、`slack_capped` 全 false、`s_inner`/`lambda_inner` 全 0、`cone_dual_leading` 有值。
- 一次性诊断脚本 `diag_ccd_zero_step.m`、`diag_reg_residual.m`、`diag_r1_and_ccd.m` 和它们的日志留在 `results/logs/`，不在 `tests/` 里。

**主会话核对（2026-11-24）**：逐文件核对了改动，实现与本方案一致。`results/scp_run_brief.txt`、`scp_run_detail.txt` 与 standard-3 的存档逐字节相同（主会话用 `cmp` 复核），`scp_run_control.txt` 只差版本名一行。上表 5 个失败都是本方案的阈值定错了，由主会话改了测试和方案正文里的阈值，实现没有改:

| 用例 | 改成 | 依据 |
| --- | --- | --- |
| `test_ccd_zero_step_feasible_on_unit_norm` | 初始参考 ≤ 1e-12，之后的参考 ≤ `config.solver.co_tol_pfeas` | 参考取自 P3 的解，残差在求解器的原始可行性容差以内 |
| `test_ccd_candidates_stay_outside_and_term_is_exact` | 不再断言 `solver_feasibility_report.success`，改为单位范数内逼近行和控制锥的原始残差 ≤ 1e-6 | 总通过标志在 regularized 下也会被终端、衔接行的残差偶尔顶破 |
| `test_ccd_dual_split_residual` | κ̂ 的对比加 RelTol 1e-3 | 求解器返回的对偶解在原始坐标下有 1e-6 量级的误差 |
| `test_toy_p_above_demand` | ε_10 ≤ 1.1e-4；每轮的 θ、ε 与解析递推对比 | 解析值 ε_10 = 1.047e-4（上表写的 1.043e-4 是手算误差）。求解器在相对间隙 1e-10 处停止，解沿切线的位置误差约 6e-6，每轮折合最多 3.6e-4° 并逐轮累积，所以 θ 用相对容差 |
| `test_toy_p_below_demand_hits_cap` | \|θ\| ≤ 1e-4° | 解析值 0°，实测 1.3e-5° |

另改四处，都不影响 regularized 的数值和输出：对偶解不可用时 `s_inner` 为 NaN（原来误为 0）；`build_unit_norm_inner_block` 头注释的一处笔误；终端“单位范数”一行去掉“最大”两字，显示宽度不超过 78 列；知识库 §4.1 里单位范数罚项对应的是凸的一半（原来误写成反凸的一半）。

主会话重跑测试：整体运行 23 个用例通过 22（`results/logs/tests_main.log`），唯一没过的是玩具问题里角度对比的容差（当时还是 1e-4°），改成相对容差后玩具测试文件重跑 3 个全部通过（`tests_main_toy.log`）；其余两个文件（13 个、7 个用例）此后没有改动。

## 运行方法与产物（任务 10 追加，2026-11-24）

**第二部分的执行**: 实验脚本、回归工况、试点和全部工况的运行由子 agent 完成，它在写分析脚本时因用量上限中断；分析脚本的补完和运行、默认 p、任务 10 的文档由主会话完成。主会话另外核对了汇总文本的全部数字和六张图，并用一份临时脚本（仓库外，已删）核对了保留边界工况里边界乘子的量级。

**运行**（MATLAB 工作目录任意；入口按自身位置补路径，运行结束恢复）:

```matlab
run('E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-standard-5/ccd_compare/SCP_ccd_compare.m')   % 全部 13 个工况，已有 case_metrics.mat 的跳过，结束后自动分析
```

入口可先设的变量: `case_filter`（如 `{'ccd_p1e0'}`）、`rerun_existing`、`max_iter`（默认 50）、`plateau_window`（默认 5）、`plateau_tolerance`（默认 0.1）、`results_folder`（默认 `results`）、`run_analysis`（默认 true）、`p_exponents`（默认用 `list_compare_cases` 里的 −3:2）。单独重做分析与作图: `cd` 到本文件夹后运行 `analyze_ccd_compare()`，不重跑 SCP。长运行放后台并把输出重定向到 `results/logs/`，按 `[CASE]` 行和 `ALL_DONE` 监控；日志路径要写绝对路径（Shell 的工作目录是仓库根，不是本文件夹，相对路径的重定向会直接失败）。每个 50 轮工况 2～2.5 分钟。

**文件**:
- `SCP_ccd_compare.m`、`run_compare_case.m`（原样复制自阶段3-1 的 `run_converge_case.m`）、`list_compare_cases.m`、`extract_compare_metrics.m`、`analyze_ccd_compare.m`。
- `results/<工况>/`: `scp_run_brief.txt`、`scp_run_detail.txt`、`scp_run_control.txt`、`scp_run_control.mat`（`ControlExport`，约 15 MB，逐次尝试的控制量报告）、`case_metrics.mat`（`Metrics`，逐轮字段 K×1，在阶段3-1 的基础上加 `mode`、`p`、`keep_control_bounds`、`max_inward_gap`、`max_outward_gap`、`num_slack_capped`、`num_bound_active`（‖s_bound,i‖ > 1e-12 的节点数，内点法在不生效边界上的残值也计入，分析脚本不用它）、`circle_predicted`、`circle_actual`、`circle_error`、`max_eps`）。
- `results/对比汇总.txt`（九节，第 9 节是逐轮序列）、`results/对比汇总.mat`（`Summary`、`Groups`、`Check`、`Options`）；`results/logs/` 是各批运行、分析和测试的日志；`results` 合计约 196 MB。
- `pictures/` 六张: 对比-各轮总脉冲、对比-相对none差值（四个分块，第一个是 regularized 的纵轴放大）、对比-末轮差值随p和w、对比-紧性（上排 max|1−‖u‖|，下排 max ε）、对比-乘子分布、对比-末轮σ。
- 阶段报告 `../docs/算法改进_阶段5-1_凹凸分解模式.md`。

**与方案不一致之处**:
- 工况 13 个而不是 12 个。保留箱形边界的对照工况有两档: `ccdkeep_p1e-1` 是试点时预期的默认档，按方案先跑了；按判据定出的默认 p 是 1，又按“ccdkeep_p1e<默认档>”补跑 `ccdkeep_p1e0`，前者结果保留。
- 默认 p 的判据下 p = 0.1 不满足（末轮 1.262e-3 > 1e-3），默认 p = 1，与配置原值相同，只在 `scp_config_default.m` 里加了一句注释。
- 汇总表“末轮边界乘子”一列按 ‖s_bound,i‖ > 1e-6 算。方案任务 8 步骤 2 给的 1e-12 会把全部节点算进去（保留边界时内点法在不生效边界上留有 1e-11 量级的残值），`case_metrics.mat` 里的 `num_bound_active` 仍是按 1e-12 存的。
- 分析脚本在子 agent 的初稿上有四处一运行就报错的地方（读了不存在的字段、结构体数组各项字段不一致、回归核对的循环、调用了别的文件的局部函数），由主会话改正；画图的六张图和“定默认 p”是主会话补的。差值图多了一个 regularized 纵轴放大的分块，因为 ±0.1 的带在 ccd 的 ±40 m/s 尺度上看不见。
- `ccdkeep_p1e-1` 没有跑到上限: 第 19 次尝试 MOSEK 返回 UNKNOWN，按现有策略停止。

**运行结果（2026-11-24）**: 13 个工况都有结果，12 个到上限或平台停止。数据见阶段报告。全部改动完成后重跑测试命令，23 个用例全部通过（`results/logs/tests_final.log`）。
