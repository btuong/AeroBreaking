function notes = draw_log_history_tile(ax, iters, status, SeriesList, y_label, config)
% DRAW_LOG_HISTORY_TILE 画横轴为迭代序号的对数纵轴分块，负值按绝对值画并用向下三角标出。
%
% 输入:
%   ax         - 目标坐标轴
%   iters      - 1 x K 迭代序号
%   status     - 1 x K 元胞，各轮 'accepted' / 'rejected' / 'failed'
%   SeriesList - build_log_series 创建的曲线数组（含颜色、标记、线宽）
%   y_label    - 纵轴标签（分块的名字）
%   config     - 读取 config.plot.font_size
%
% 实际量画实线，非负的轮按接受/拒绝画实心/空心的该曲线标记，负的轮画向下三角；界、
% 门槛、阈值画虚线。粗线先画、细线后画，细线压在粗线上面。图例条目按 SeriesList 的
% 顺序另画（add_legend_entry），图例里同时显示线和标记。0 值和低于显示下限的值画在
% 下限，用一条点线标明。没算出的轮（NaN）留空，不补零。返回要写在窗口标题下面的
% 说明行（点线含义、向下三角含义）。

    notes = {};
    hold(ax, 'on');
    curve_list = cell(1, numel(SeriesList));
    for k = 1:numel(SeriesList)
        curve_list{k} = build_plot_curve(SeriesList(k).name, iters, ...
            SeriesList(k).values, 'line');
    end
    LogInfo = compute_log_display([curve_list{:}]);

    % 图例条目按给定顺序
    for k = 1:numel(SeriesList)
        Series = SeriesList(k);
        if Series.is_bound
            add_legend_entry(ax, Series.name, Series.color, '--', ...
                Series.line_width, 'none', false);
        else
            add_legend_entry(ax, Series.name, Series.color, '-', ...
                Series.line_width, Series.marker, true);
        end
    end

    % 粗线先画，细线后画（sort 对相同线宽保持原顺序）
    [~, draw_order] = sort(-[SeriesList.line_width]);
    has_negative = false;
    for k = draw_order
        Series = SeriesList(k);
        values = Series.values;
        magnitude = abs(values);
        magnitude(magnitude < LogInfo.floor_value) = LogInfo.floor_value;
        if Series.is_bound
            plot(ax, iters, magnitude, '--', 'Color', Series.color, ...
                'LineWidth', Series.line_width, 'HandleVisibility', 'off');
            continue;
        end
        plot(ax, iters, magnitude, '-', 'Color', Series.color, ...
            'LineWidth', Series.line_width, 'HandleVisibility', 'off');
        negative = values < 0;
        marked = magnitude;
        marked(negative) = NaN;
        mark_history_status(ax, iters, status, marked, Series.color, ...
            Series.marker);
        plot(ax, iters(negative), magnitude(negative), 'v', ...
            'Color', Series.color, 'MarkerFaceColor', 'w', 'MarkerSize', 9, ...
            'LineWidth', 1.5, 'HandleVisibility', 'off');
        has_negative = has_negative || any(negative);
    end

    set(ax, 'YScale', 'log');
    ylim(ax, [LogInfo.floor_value / 3, LogInfo.top_value * 3]);
    if LogInfo.has_clamped
        yline(ax, LogInfo.floor_value, ':', 'Color', [0.5, 0.5, 0.5], ...
            'LineWidth', 1.2, 'HandleVisibility', 'off');
        notes{end + 1} = '点线：0 值画在下限';
    end
    if has_negative
        notes{end + 1} = '▼ 负值（按绝对值画）';
    end
    mark_failed_rounds(ax, iters, status);
    finish_history_axes(ax, iters, y_label, config);
end
