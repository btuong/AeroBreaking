function [c, c_V, c_gamma, c_t_f] = linearize_coefficient_drdtau( ...
        V_k, gamma_k, t_f_k)
% LINEARIZE_COEFFICIENT_DRDTAU 计算 dr/dtau = V*sin(gamma)*t_f 的仿射系数。
%
% 数学形式:
%   F_r = t_f·V·sin γ。在参考点 (V̄, γ̄, t̄_f) 的一阶展开
%       F_r ≈ c + c_V·(V − V̄) + c_γ·(γ − γ̄) + c_tf·(t_f − t̄_f)
%   c = F_r(V̄, γ̄, t̄_f)，c_V = t̄_f sin γ̄，c_γ = t̄_f V̄ cos γ̄，c_tf = V̄ sin γ̄。
%   单位: V: VU，γ: rad，t_f: TU。F_r 不依赖 r、φ、ψ、u。
%
% 代码形式:
%   输出顺序 [c, c_V, c_gamma, c_t_f]，与上式一一对应；系数乘变量偏移，
%   不含参考值回移。

    V = V_k;
    gammaa = gamma_k;
    t_f = t_f_k;

    c = V * t_f * sin(gammaa);
    c_V = t_f * sin(gammaa);
    c_gamma = V * t_f * cos(gammaa);
    c_t_f = V * sin(gammaa);
end
