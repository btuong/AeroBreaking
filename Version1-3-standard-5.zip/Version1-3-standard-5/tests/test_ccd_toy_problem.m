function tests = test_ccd_toy_problem()
% TEST_CCD_TOY_PROBLEM 单节点玩具问题核验凹凸分解（ccd）模式的 P3 写法：p 高于需求时方向逐轮收缩、ε 趋于 0；
% p 低于需求时 ε 触上界并报告；保留箱形边界时 u1 先被裁到 1。
%
% 玩具问题（规格第 4 节第 1 条）：min_u −q·d^T·u，q = 1，d = (1, 0)，‖u‖ = 1，从 θ₀ = 30° 出发，不设信赖域。
% 每轮解一个 3 变量（u1、u2、ε）的 SOCP：目标 [−q; 0; p]，锥 (1 + ε, u1, u2)，行 −ē^T·u ≤ −1，
% 边界 u ∈ [−(1 + ε_max), 1 + ε_max]、ε ∈ [0, ε_max]，调用项目的 solve_convex_subproblem。
% J = −q·d^T·u + p·max(‖u‖ − 1, 0)，L 取求解器返回的解按同一目标算出的值，
% ρ = (J_k − J_{k+1})/(J_k − L_{k+1})。
% 运行前要把本版本各模块加到路径上（SCP.m 开头添加的那组模块）。

    tests = functiontests(localfunctions);
end


function test_toy_p_above_demand(testCase)
% p = 5：每轮锥取紧，ρ = 1，θ 每轮约乘 1 − q/p = 0.8，ε 逐轮严格减小趋于 0，不触上界。

    q = 1; d = [1; 0]; p = 5; slack_max = 1;
    keep_bounds = false;
    theta_deg = 30;
    theta_analytic = theta_deg;
    for k = 1:10
        Result = solve_toy_round(q, d, p, slack_max, keep_bounds, theta_deg);
        % 每轮解在锥上取紧：ε = ‖u‖ − 1
        verifyEqual(testCase, Result.epsilon, norm(Result.u) - 1, 'AbsTol', 1e-9);
        % ρ = 1：圆约束组是凸项，P3 里的值与 J 同算法，预测误差为 0
        if k <= 5
            verifyLessThanOrEqual(testCase, abs(Result.rho - 1), 1e-4);
        end
        theta_next = atan2d(Result.u(2), Result.u(1));
        % 与解析递推一致：sin φ_k = (q/p)·sin θ_k，ε_(k+1) = 1/cos φ_k − 1。求解器在相对间隙 1e-10
        % 处停止，解沿切线的位置误差约 sqrt(2·间隙/p) ≈ 6e-6，每轮折合最多 3.6e-4° 并逐轮累积，
        % 所以 θ 用相对容差
        [theta_analytic, epsilon_analytic] = toy_analytic_step(q, p, theta_analytic);
        verifyEqual(testCase, theta_next, theta_analytic, 'AbsTol', 1e-4, 'RelTol', 1e-3);
        verifyEqual(testCase, Result.epsilon, epsilon_analytic, 'AbsTol', 1e-6);
        if k == 1
            verifyGreaterThanOrEqual(testCase, theta_next, 24.2);
            verifyLessThanOrEqual(testCase, theta_next, 24.3);
            verifyGreaterThanOrEqual(testCase, Result.epsilon, 5.0e-3);
            verifyLessThanOrEqual(testCase, Result.epsilon, 5.1e-3);
        elseif k <= 9
            ratio = theta_next / theta_deg;
            verifyGreaterThanOrEqual(testCase, ratio, 0.80);
            verifyLessThanOrEqual(testCase, ratio, 0.81);
        end
        if k == 10
            % 第 10 轮后的解析值 1.047e-4（θ_9 = 4.15°）
            verifyLessThanOrEqual(testCase, Result.epsilon, 1.1e-4);
        end
        if k > 1
            verifyLessThan(testCase, Result.epsilon, epsilon_previous);
        end
        verifyFalse(testCase, Result.capped);
        epsilon_previous = Result.epsilon;
        theta_deg = theta_next;
    end
end


function test_toy_p_below_demand_hits_cap(testCase)
% p = 0.5 < q：ε 触上界 ε_max，第 1 轮后方向转到 0°，以后不变；每轮都判为触上界；第 1 轮 ρ = 1。

    q = 1; d = [1; 0]; p = 0.5; slack_max = 0.5;
    keep_bounds = false;
    theta_deg = 30;
    for k = 1:3
        Result = solve_toy_round(q, d, p, slack_max, keep_bounds, theta_deg);
        % 解析值为 0°；求解器返回的 u2 有 1e-6 量级的原始解误差
        verifyLessThanOrEqual(testCase, abs(atan2d(Result.u(2), Result.u(1))), 1e-4);
        verifyEqual(testCase, Result.epsilon, slack_max, 'AbsTol', 1e-7);
        verifyTrue(testCase, Result.capped);
        if k == 1
            verifyEqual(testCase, Result.rho, 1, 'AbsTol', 1e-6);
        end
        % 下一轮的参考是本轮的解
        theta_deg = atan2d(Result.u(2), Result.u(1));
    end
end


function test_toy_kept_control_bounds_clip_before_cap(testCase)
% 同上但保留 u 的边界 [−1, 1]：u1 被裁到 1，θ_k = 30/2^k 度，ε_k = 1/cos(θ_k) − 1，不触上界。

    q = 1; d = [1; 0]; p = 0.5; slack_max = 0.5;
    keep_bounds = true;
    theta_deg = 30;
    for k = 1:3
        Result = solve_toy_round(q, d, p, slack_max, keep_bounds, theta_deg);
        theta_expected = 30 / 2^k;
        verifyEqual(testCase, atan2d(Result.u(2), Result.u(1)), theta_expected, 'AbsTol', 1e-5);
        verifyEqual(testCase, Result.u(1), 1, 'AbsTol', 1e-7);
        verifyEqual(testCase, Result.epsilon, 1 / cosd(theta_expected) - 1, 'AbsTol', 1e-6);
        verifyFalse(testCase, Result.capped);
        % 下一轮的参考是本轮的解
        theta_deg = atan2d(Result.u(2), Result.u(1));
    end
end


function Result = solve_toy_round(q, d, p, slack_max, keep_bounds, theta_deg)
% SOLVE_TOY_ROUND 解一轮玩具问题的 P3，返回解、ε、是否触上界、J、ρ。
%
% 变量顺序 [u1; u2; ε]。参考方向 ē = (cos θ, sin θ)。ρ = (J_k − J_{k+1})/(J_k − L_{k+1})，
% J_k 在参考处（圆上，ε = 0）算，J_{k+1}、L_{k+1} 在解处算。

    config = scp_config_default();
    e_bar = unit_vector(theta_deg);

    objective = [-q * d; p];
    % 行 −ē^T·u ≤ −1
    LinearConstraints.matrix = sparse([-e_bar(1), -e_bar(2), 0]);
    LinearConstraints.lower = -Inf;
    LinearConstraints.upper = -1;
    LinearConstraints.row_groups = struct('unit_norm_inner', 1);
    % 锥 (1 + ε, u1, u2) ∈ Q³：变量顺序 [u1; u2; ε]，映射的第一行取 ε、后两行取 u1、u2
    ConicConstraints.mapping = sparse([0, 0, 1; 1, 0, 0; 0, 1, 0]);
    ConicConstraints.offset = [1; 0; 0];
    ConicConstraints.cones = struct('name', 'control_disk', 'type', 'quadratic', ...
        'dimension', 3, 'rows', (1:3).', 'tightness_role', 'epigraph', 'index', 1);
    if keep_bounds
        u_limit = 1;
    else
        u_limit = 1 + slack_max;
    end
    VariableBounds.lower = [-u_limit; -u_limit; 0];
    VariableBounds.upper = [u_limit; u_limit; slack_max];

    SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ConicConstraints, config);
    if ~SolverResult.success
        error('SCP:ToySolverFailed', '玩具问题 P3 求解失败：%s', SolverResult.status);
    end

    Result.u = SolverResult.primal(1:2);
    Result.epsilon = SolverResult.primal(3);
    Result.L = SolverResult.objective;
    Result.J = -q * (d.' * Result.u) + p * max(norm(Result.u) - 1, 0);
    Result.J_reference = -q * (d.' * e_bar);
    Result.rho = (Result.J_reference - Result.J) / (Result.J_reference - Result.L);
    Result.capped = Result.epsilon >= slack_max - 1e-9;
end


function [theta_next_deg, epsilon] = toy_analytic_step(q, p, theta_deg)
% TOY_ANALYTIC_STEP 玩具问题一轮的解析解：新的方向角 θ（deg）和向外的差 ε。
%
% 沿参考方向的切线走：sin φ = (q/p)·sin θ，t = tan φ，
% u = (cos θ + t·sin θ, sin θ − t·cos θ)，θ_next = atan2d(u2, u1)，ε = 1/cos φ − 1。

    sin_phi = (q / p) * sind(theta_deg);
    t = tand(asind(sin_phi));
    u = [cosd(theta_deg) + t * sind(theta_deg); ...
        sind(theta_deg) - t * cosd(theta_deg)];
    theta_next_deg = atan2d(u(2), u(1));
    epsilon = 1 / cosd(asind(sin_phi)) - 1;
end


function e = unit_vector(theta_deg)
% UNIT_VECTOR 角度 θ（deg）对应的单位向量。

    e = [cosd(theta_deg); sind(theta_deg)];
end
