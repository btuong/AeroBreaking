function print_scp_summary(FinalizedRun, ConstData)
% PRINT_SCP_SUMMARY 打印冻结 SCP 运行结果摘要。
%
% 数据来自 build_scp_result 的公共映射；运行时间由入口报告，不进入
% 本函数。ConstData 为已声明的只读单位换算扩展。
%
% 本函数依次完成：
%   1. 运行结论（含最后接受轮的驻点、对 P2 可行）。
%   2. 关键量逐轮演变。
%   3. 最终接受轮。
%   4. 各轮迭代概况（决策、r、ρ、ΔL、D、J、驻点上界、违反比；print_iteration_overview）。

    Result = build_scp_result(FinalizedRun);

    fprintf('\n');
    fprintf('==================================================\n');
    fprintf('                  SCP 运行摘要\n');
    fprintf('==================================================\n');

    %% 1. 运行结论
    if ~Result.has_accepted_solution
        fprintf('运行结论: 无接受解\n');
    elseif Result.scp_converged
        fprintf('运行结论: 存在接受解且 SCP 收敛\n');
    else
        fprintf('运行结论: 存在接受解但未收敛\n');
    end

    fprintf('状态:               %s\n', Result.status);
    fprintf('尝试迭代数:         %d\n', Result.num_attempted);
    fprintf('接受迭代数:         %d\n', Result.num_accepted);
    fprintf('最后尝试成功:       %s\n', ...
        logical_to_text(Result.last_attempt_success));
    fprintf('已停止:             %s\n', logical_to_text(Result.stop));
    fprintf('停止原因:           %s\n', ...
        empty_to_none(Result.stop_reason));
    if ~isempty(Result.stop_detail)
        fprintf('停止说明:           %s\n', Result.stop_detail);
    end
    fprintf('SCP 收敛:           %s\n', ...
        logical_to_text(Result.scp_converged));
    fprintf('达到收敛停止:       %s\n', ...
        logical_to_text(Result.convergence_stop_reached));
    % 驻点和对 P2 可行只报告：取最后接受轮的停止判定，驻点度量以该轮的参考点为基准
    if Result.has_accepted_solution
        FinalStop = Result.final_iteration.stop;
        fprintf('驻点（最后接受轮）: %s\n', logical_to_text(FinalStop.stationary));
        fprintf('对 P2 可行（最后接受轮）: %s\n', logical_to_text(FinalStop.feasible));
    end

    %% 2. 关键量逐轮演变
    print_key_metric_sequences(Result, ConstData);

    %% 3. 最终接受轮
    if ~Result.has_accepted_solution
        fprintf('\n最终接受解: NONE\n');
        fprintf('最终接受轮: NONE\n');
        fprintf('任务完成:   否（口径未决，知识库 D1）\n');
    else
        FinalIteration = Result.final_iteration;
        P2Feasibility = FinalIteration.subproblem.p2_feasibility;
        fprintf('\n最终接受轮: 第 %d 轮\n', FinalIteration.iter);
        fprintf('最终解指标:\n');
        fprintf('  总脉冲 Σ|P|:    %.2f m/s（末次脉冲按原关系重算）\n', ...
            P2Feasibility.performance_report.value);
        fprintf('  P0~P5 (m/s):    ');
        fprintf('%.2f  ', P2Feasibility.performance_report.components);
        fprintf('\n');
        fprintf('  终端倾角 i:     %.2f deg（P2 节点值 | 梯形递推 %s）\n', ...
            P2Feasibility.terminal_report.metrics(2).actual_value, ...
            summary_trapezoid_value(FinalIteration.trapezoid_check, ...
            'inclination'));
        if FinalIteration.trapezoid_check.success
            fprintf(['  梯形终端远地点违反量: %.4f km | 倾角违反量: %.6f deg' ...
                ' | 递推值与节点值最大差 %s\n'], ...
                FinalIteration.trapezoid_check.terminal_report.metrics(1).value, ...
                FinalIteration.trapezoid_check.terminal_report.metrics(2).value, ...
                summary_deviation_text(FinalIteration.trapezoid_check));
        else
            Recursion = FinalIteration.trapezoid_check.recursion_report;
            fprintf('  梯形递推: 未完成 (%s)\n', ...
                FinalIteration.trapezoid_check.failure_reason);
            if Recursion.evaluated
                fprintf(['  已完成区间 %d | 最后递推节点 %d | 失败区间 %d' ...
                    ' (试探残差 %.2e) | 后续未评价\n'], ...
                    Recursion.num_completed_intervals, Recursion.last_completed_node, ...
                    Recursion.failing_interval, Recursion.failure_step_residual);
            end
        end
        fprintf('  对 P2 可行:     %s（最大违反量/容差 %.3e，%s）\n', ...
            logical_to_text(P2Feasibility.feasible), ...
            P2Feasibility.max_ratio, P2Feasibility.max_name);
        fprintf('  P3 目标 L:      %.6e（性能指标加附加项加松弛罚项）\n', ...
            Result.final_solution.objective);
        print_final_penalty_lines(FinalIteration.trust.evaluation);
    end

    %% 4. 各轮迭代概况
    print_iteration_overview(1, Result.history);

    fprintf('==================================================\n');
end


function print_key_metric_sequences(Result, ConstData)
% PRINT_KEY_METRIC_SEQUENCES 打印关键量按尝试顺序的逐轮序列。
% 总 t_f 为 5 圈大气飞行时间之和（物理秒）。附加项是候选解处的 Γ（控制正则项）；
% 第 0 行取第一个评价过的轮的参考处的值，没有时显示 '-'。

    fprintf('\n关键量逐轮演变（含初始参考为第 0 行）:\n');
    fprintf(['  轮次  P2 倾角(deg)  脉冲(m/s)  梯形 ra_5(km)  总t_f(s)' ...
        '       附加项\n']);

    initial = Result.initial_reference;
    fprintf('  %4d  %14.4f  %14.2f  %12.2f  %10.1f  %11s\n', 0, ...
        rad2deg(initial.i), sum(abs(initial.control.P)) * ConstData.VU, ...
        initial.ra_list(5) * ConstData.LU / 1e3, ...
        sum(initial.t_f) * ConstData.TU, initial_extra_text(Result.history));

    for index = 1:numel(Result.history)
        Iteration = Result.history(index);
        if ~Iteration.subproblem.success
            fprintf('  %4d  %14s  %14s  %12s  %10s  %11s\n', ...
                Iteration.iter, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A');
            continue;
        end
        total_impulse = Iteration.subproblem.p2_feasibility ...
            .performance_report.value;
        if Iteration.trapezoid_check.success
            ra5 = Iteration.trapezoid_check.terminal_report ...
                .metrics(1).actual_value;
        else
            ra5 = NaN;
        end
        Evaluation = Iteration.trust.evaluation;
        if Evaluation.evaluated
            extra_text = sprintf('%.4e', Evaluation.group.extra.candidate);
        else
            extra_text = '-';
        end
        fprintf('  %4d  %14.4f  %14.2f  %12.2f  %10.1f  %11s\n', ...
            Iteration.iter, Iteration.subproblem.p2_feasibility ...
            .terminal_report.metrics(2).actual_value, ...
            total_impulse, ra5, ...
            sum(Iteration.solution.t_f) * ConstData.TU, extra_text);
    end
end


function text = initial_extra_text(History)
% INITIAL_EXTRA_TEXT 初始参考处的附加项：取第一个评价过的轮的参考处的值，没有时为 '-'。

    text = '-';
    for index = 1:numel(History)
        Evaluation = History(index).trust.evaluation;
        if Evaluation.evaluated
            text = sprintf('%.4e', Evaluation.group.extra.reference);
            return;
        end
    end
end


function print_final_penalty_lines(Evaluation)
% PRINT_FINAL_PENALTY_LINES 最终接受轮的罚函数 J 及其三部分、预测下降 ΔL、ρ 和驻点度量的上界。
% 三部分取候选解处的值：J = 性能指标 C + 附加项 Γ + 罚项 Θ。

    if ~Evaluation.evaluated
        return;
    end
    if Evaluation.ratio_available
        ratio_text = sprintf('%.4f', Evaluation.ratio);
    else
        ratio_text = '-';
    end
    fprintf('  罚函数 J:       %.6e | ΔL %.3e | ρ %s\n', ...
        Evaluation.candidate.total, Evaluation.predicted_reduction, ratio_text);
    Group = Evaluation.group;
    % 一行放不下 78 列，式子和数值分两行
    fprintf('  J = 性能指标 + 附加项 + 罚项:\n');
    fprintf('    %.6e = %.6e + %.6e + %.6e\n', ...
        Evaluation.candidate.total, Group.cost.candidate, ...
        Group.extra.candidate, Group.penalty.candidate);
    fprintf('  驻点度量的上界: %.3e（ε %.0e，只报告）\n', ...
        Evaluation.stationarity_bound, Evaluation.stationarity_tolerance);
end


function text = summary_trapezoid_value(TrapezoidCheck, which)
% SUMMARY_TRAPEZOID_VALUE 梯形递推解的终端值文本；未评价时给 '-'。

    if ~(TrapezoidCheck.evaluated && TrapezoidCheck.success)
        text = '-';
        return;
    end
    if strcmp(which, 'inclination')
        text = sprintf('%.2f', ...
            TrapezoidCheck.terminal_report.metrics(2).actual_value);
    else
        text = sprintf('%.2f', ...
            TrapezoidCheck.terminal_report.metrics(1).actual_value);
    end
end


function text = summary_deviation_text(TrapezoidCheck)
% SUMMARY_DEVIATION_TEXT 递推值与优化节点值的最大差（取各通道最大，物理单位）。

    Deviations = TrapezoidCheck.deviation_report;
    [worst, k] = max([Deviations.value]);
    text = sprintf('%.4g %s (%s)', worst, Deviations(k).unit, ...
        Deviations(k).name);
end


function text = logical_to_text(value)
% LOGICAL_TO_TEXT 将布尔值转为是/否文本。

    if value
        text = '是';
    else
        text = '否';
    end
end


function text = empty_to_none(value)
% EMPTY_TO_NONE 将空字符串显示为 NONE。

    if isempty(value)
        text = 'NONE';
    else
        text = value;
    end
end
