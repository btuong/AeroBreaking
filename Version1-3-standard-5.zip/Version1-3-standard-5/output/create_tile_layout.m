function layout = create_tile_layout(fig, num_tiles)
% CREATE_TILE_LAYOUT 按分块数在图窗上建分块布局，一扇窗最多 6 块。
% 1–3 块排一行，4 块 2×2，5–6 块 2×3；超过 6 块报错，由适配层按主题拆窗。

    if num_tiles > 6
        error('SCP:TooManyPlotTiles', ...
            '一扇图窗最多 6 个分块，当前 %d 个，请在 build_iteration_plot_data 中拆分。', ...
            num_tiles);
    end
    if num_tiles <= 3
        grid_size = [1, num_tiles];
    elseif num_tiles == 4
        grid_size = [2, 2];
    else
        grid_size = [2, 3];
    end
    layout = tiledlayout(fig, grid_size(1), grid_size(2), ...
        'TileSpacing', 'compact', 'Padding', 'compact');
end
