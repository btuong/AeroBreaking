function dy = evaluate_vacuum_dynamics(mu, J2, Re, y)
% EVALUATE_VACUUM_DYNAMICS 计算真空段 ECI 动力学右端项（中心引力 + J2）。
%
% 数学形式:
%       dr/dt = v,    dv/dt = −μ·r/‖r‖³ + a_J2(r)
%   r、v 为 ECI 位置、速度（归一化），μ 为引力常数，a_J2 为 J2 摄动加速度（含 Re²）。
%
% 代码形式:
%   dy = [y(4:6); −mu/‖y(1:3)‖³·y(1:3) + a_J2]，6×1 列向量。
%
% 输入:
%   mu, J2, Re - 归一化引力常数、J2 系数、地球半径
%   y          - 6x1 ECI 状态 [r; v]
%
% 输出:
%   dy - 6x1 状态导数

    a_J2 = 3 / 2 * mu * J2 * Re^2 / norm(y(1:3))^5 ...
        * (5 * y(3)^2 / (y(1:3)' * y(1:3)) * y(1:3) - y(1:3) ...
            - [0; 0; 2 * y(3)]);
    dy = [y(4:6);
        -mu / norm(y(1:3))^3 * y(1:3) + a_J2];
end
