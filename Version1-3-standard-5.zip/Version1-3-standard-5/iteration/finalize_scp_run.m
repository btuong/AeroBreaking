function FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory)
% FINALIZE_SCP_RUN 运行结束后，整理历史并确定最终结果（此后不再修改）。
%
% 本函数依次完成：
%   1. 去掉历史里没用到的预分配空位。
%   2. 取出最后一次尝试。
%   3. 找出最后一次被接受的轮次及其诊断。
%   4. 汇总成最终运行对象。
%   5. 检查汇总结果是否自洽。
%
% 无接受解时最终解、传播、接受轮及其诊断保持为空，初始参考保持初始身份。
% 不重新传播、不重新评价，不选择最佳候选解。

    %% 1. 去掉历史里没用到的预分配空位
    num_attempted = RunState.num_attempted;
    History = RunState.history(1:num_attempted);
    Diagnostics = DiagnosticsHistory(1:num_attempted);

    %% 2. 取出最后一次尝试
    if num_attempted == 0
        LastIteration = [];
        LastDiagnostics = [];
    else
        LastIteration = History(end);
        LastDiagnostics = Diagnostics(end);
    end

    %% 3. 找出最后一次被接受的轮次及其诊断
    if RunState.has_accepted_solution
        final_index = find(arrayfun( ...
            @(Record) Record.trust.accept_candidate, History), 1, 'last');
        if isempty(final_index)
            error('SCP:MissingAcceptedIteration', ...
                '运行状态声明已有接受解，但历史中不存在接受记录。');
        end
        FinalIteration = History(final_index);
        FinalDiagnostics = Diagnostics(final_index);
        FinalSolution = RunState.last_accepted_solution;
        FinalTrapezoidSolution = FinalDiagnostics.trapezoid_solution;
        status = 'accepted_solution_available';
    else
        FinalIteration = [];
        FinalDiagnostics = [];
        FinalSolution = [];
        FinalTrapezoidSolution = [];
        status = 'no_accepted_solution';
    end

    %% 4. 汇总成最终运行对象
    FinalizedRun.status = status;
    FinalizedRun.has_accepted_solution = RunState.has_accepted_solution;

    FinalizedRun.final_solution = FinalSolution;
    FinalizedRun.final_trapezoid_solution = FinalTrapezoidSolution;
    FinalizedRun.final_reference = RunState.current_reference;

    FinalizedRun.initial_reference = RunState.initial_reference;
    FinalizedRun.initial_propagation = RunState.initial_propagation;

    FinalizedRun.history = History;
    FinalizedRun.diagnostics = Diagnostics;
    FinalizedRun.last_iteration = LastIteration;
    FinalizedRun.last_diagnostics = LastDiagnostics;
    FinalizedRun.final_iteration = FinalIteration;
    FinalizedRun.final_diagnostics = FinalDiagnostics;

    FinalizedRun.num_attempted = RunState.num_attempted;
    FinalizedRun.num_accepted = RunState.num_accepted;
    FinalizedRun.last_attempt_success = RunState.last_attempt_success;

    FinalizedRun.stop = RunState.stop;
    FinalizedRun.stop_reason = RunState.stop_reason;
    FinalizedRun.stop_detail = RunState.stop_detail;

    FinalizedRun.scp_converged = RunState.has_accepted_solution ...
        && FinalIteration.stop.facts.convergence_reached;
    FinalizedRun.convergence_stop_reached = strcmp( ...
        RunState.stop_reason, 'scp_converged');
    FinalizedRun.trust_region = RunState.trust_region;

    %% 5. 检查汇总结果是否自洽
    check_finalized_run_contract(FinalizedRun, RunState);
end


function check_finalized_run_contract(FinalizedRun, RunState)
% CHECK_FINALIZED_RUN_CONTRACT 检查最终运行对象的数据一致性。

    num_attempted = FinalizedRun.num_attempted;
    if num_attempted ~= numel(FinalizedRun.history) ...
            || num_attempted ~= numel(FinalizedRun.diagnostics)
        error('SCP:InvalidFinalizedHistoryLength', ...
            '裁剪后迭代历史与诊断历史长度必须等于实际尝试次数。');
    end

    if FinalizedRun.num_accepted > num_attempted
        error('SCP:InvalidFinalizedAcceptCount', ...
            '接受次数不能超过实际尝试次数。');
    end

    if num_attempted > 0
        if ~all([FinalizedRun.history.complete]) ...
                || ~all([FinalizedRun.diagnostics.complete])
            error('SCP:IncompleteFinalizedHistory', ...
                '最终历史中存在未完成的迭代记录或诊断。');
        end
        if ~isequal([FinalizedRun.history.iter], ...
                [FinalizedRun.diagnostics.iter])
            error('SCP:MismatchedDiagnosticsHistory', ...
                '迭代历史与诊断历史的轮次必须逐项一致。');
        end
    end

    if FinalizedRun.has_accepted_solution
        if isempty(FinalizedRun.final_solution) ...
                || isempty(FinalizedRun.final_iteration)
            error('SCP:MissingFinalAcceptedData', ...
                '已有接受解时，最终解和接受轮不能为空。');
        end
        if ~FinalizedRun.final_iteration.trust.accept_candidate
            error('SCP:InvalidFinalAcceptedIteration', ...
                '最终接受轮必须具有 accept_candidate=true。');
        end
        if ~isequaln(FinalizedRun.final_iteration.solution, ...
                FinalizedRun.final_solution)
            error('SCP:InconsistentFinalAcceptedData', ...
                '最终解必须来自最终接受轮。');
        end
        if ~isequaln(FinalizedRun.final_diagnostics.trapezoid_solution, ...
                FinalizedRun.final_trapezoid_solution)
            error('SCP:InconsistentFinalTrapezoidSolution', ...
                '最终梯形递推必须来自最终接受轮的同轮诊断。');
        end
    elseif ~isempty(FinalizedRun.final_solution) ...
            || ~isempty(FinalizedRun.final_iteration) ...
            || ~isempty(FinalizedRun.final_diagnostics) ...
            || ~isempty(FinalizedRun.final_trapezoid_solution)
        error('SCP:UnexpectedFinalAcceptedData', ...
            '无接受解时，最终接受数据必须为空。');
    end

    if ~isequaln(FinalizedRun.final_reference, ...
            RunState.current_reference)
        error('SCP:InconsistentFinalReference', ...
            '最终参考必须等于已更新的当前参考。');
    end
end
