function P2Solution = compute_dependent_quantities(Solution, ConstData, ~)
% COMPUTE_DEPENDENT_QUANTITIES 由末圈出口真空映射重算终端状态与末次脉冲。
%
% 数学形式:
%   [x_ff;i_ff] = G_5([R_atm,V_out,γ_out,φ_out,ψ_out,0])，
%   P_5 = sqrt(2μ/R_aaim - 2μ/(R_aaim+R_paim)) - V_ff。
%   出口半径固定为 R_atm，与 P3 里真空映射线性化的取法一致。
%
% 代码形式:
%   保持输入网格、节点状态和控制不变，只替换 xff、i 和 control.P(6)。
%   输入里 P3 的终端变量和线性化得到的末次脉冲不用，依赖量一律按原映射重算。

    last_node = Solution.PointsBounds(end).end;
    exit_last = [ConstData.R_atm, Solution.state(last_node, 2:5), 0];
    terminal = evaluate_coast_exit_to_apoapsis(exit_last, ConstData);
    target_speed = sqrt(2 * ConstData.mu / ConstData.R_aaim ...
        - 2 * ConstData.mu / (ConstData.R_aaim + ConstData.R_paim));
    P2Solution = Solution;
    P2Solution.xff = terminal(1:5)';
    P2Solution.i = terminal(6);
    P2Solution.control.P(6) = target_speed - terminal(2);
end
