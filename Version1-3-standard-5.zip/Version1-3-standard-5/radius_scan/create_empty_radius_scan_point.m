function Point = create_empty_radius_scan_point()
% CREATE_EMPTY_RADIUS_SCAN_POINT 创建字段齐全的空扫描记录（数值为 NaN）。
%
% 一条记录对应一个半径上的一次 P3 求解和评价；不保存候选解本身。
% 字段与 solve_radius_scan_point 的输出一致；repair_* 是“修复检查”（以这个半径的
% 候选解为参考，再解一次小半径 P3）的结果，由 solve_radius_scan_round 填。
% 目标分三部分：性能指标（cost_*，只含总脉冲）、附加项（extra_*，控制正则项）、
% 罚项（penalty_*）。

    Point.radius_scale = NaN;           % 半径 r（基准半径的倍数）
    Point.is_actual_radius = false;     % 是否是这一轮运行时实际用的半径 r^k
    Point.success = false;              % P3 是否求解成功
    Point.solver_status = '';           % 求解器状态；求解出错时写错误信息
    Point.response_name = '';           % MOSEK 终止码（如 MSK_RES_TRM_STALL）
    Point.relaxed_tolerance = false;    % 是否是换上 scan.retry_solver 的容差后才解出的
    Point.predicted_reduction = NaN;    % 预测下降 ΔL
    Point.actual_reduction = NaN;       % 真实下降 ΔJ
    Point.prediction_error = NaN;       % 预测误差 D
    Point.ratio = NaN;                  % 下降比 ρ
    Point.ratio_available = false;
    Point.threshold = NaN;              % 门槛 (1−ρ1)ΔL
    Point.cost_predicted = NaN;         % 性能指标的预测下降
    Point.extra_predicted = NaN;        % 附加项的预测下降
    Point.penalty_predicted = NaN;      % 罚项的预测下降
    Point.cost_error = NaN;             % 性能指标的预测误差
    Point.extra_error = NaN;            % 附加项的预测误差（控制正则线性化在凹函数之上，不大于 0）
    Point.penalty_error = NaN;          % 罚项的预测误差
    Point.cost_actual = NaN;            % 性能指标的真实下降
    Point.extra_actual = NaN;           % 附加项的真实下降
    Point.penalty_actual = NaN;         % 罚项的真实下降
    Point.cost_p3 = NaN;                % P3 的性能指标 C̃ 在候选解处的值
                                        % （= 参考处性能指标 − 性能指标的预测下降）
    Point.extra_p3 = NaN;               % P3 的附加项 Γ̃ 在候选解处的值
    Point.reference_penalty = NaN;      % 参考处的罚项
    Point.candidate_penalty = NaN;      % 候选解处的罚项
    Point.slack_penalty = NaN;          % 松弛罚项
    Point.slack_zero = false;           % 松弛罚项是否为零
    Point.step_ratio = NaN;             % 步长/半径（最大通道）
    Point.step_ratio_channel = '';
    Point.step_ratio_channels = nan(1, 6);  % 通道 r, V, gamma, phi, psi, P 各自的步长/半径
    Point.time_change = [];             % 1 x M，各圈时长的相对变化 (t_f − 参考 t_f)/参考 t_f
    Point.curvature_estimate = NaN;     % K 估计 D/‖d‖²
    Point.remainder_split = create_empty_remainder_split();   % 动力学余项按阶拆分
    Point.max_feasibility_ratio = NaN;  % 候选解的最大违反量/容差

    % 修复检查: 以本半径的候选解为参考、半径取 repair_radius_scale 再解一次 P3
    Point.repair_evaluated = false;     % 做没做修复检查（本半径 P3 没解出时不做）
    Point.repair_success = false;       % 修复用的 P3 是否解出
    Point.repair_status = '';           % 修复用的 P3 的求解状态
    Point.repair_relaxed_tolerance = false;  % 是否放宽容差后才解出
    Point.repair_slack_penalty = NaN;   % 修复后的松弛罚项
    Point.repair_slack_zero = false;    % 修复后松弛罚项是否为零（留下的罚项修得掉）
    Point.repair_cost_p3 = NaN;         % 修复用的那次 P3 的性能指标 C̃（修复后的性能指标）
    Point.repair_extra_p3 = NaN;        % 修复用的那次 P3 的附加项 Γ̃（修复后的附加项）
end
