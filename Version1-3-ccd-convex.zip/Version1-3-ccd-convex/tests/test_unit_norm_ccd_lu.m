function tests = test_unit_norm_ccd_lu()
% TEST_UNIT_NORM_CCD_LU 核验单位范数约束 ‖u‖ = 1 的两种处理方式：regularized（无损凸化，默认）与 ccd_lu（Lu 2020 原文凹凸分解）。
%
% 覆盖：模式开关与描述函数、P3 的变量布局与平方内逼近行装配（含零节点保零与目标不乘 ω_i）、
% J 与目标分项、解的提取、3 轮主链与零步长可行性、控制量报告与对偶分解、初始参考归一化
% （零向量保持 [0, 0]）、触上界与全输出跑通检查。
% 运行前要把本版本各模块加到路径上（SCP.m 开头添加的那组模块）。

    tests = functiontests(localfunctions);
end


function setupOnce(testCase)
% SETUPONCE 生成问题数据、初始参考和 ccd_lu 模式下的 3 轮记录，供各用例共用。

    testData = testCase.TestData;
    testData.config_ccd = build_test_config('ccd_lu', 1e-2, 1, false);
    testData.config_reg = build_test_config('regularized', 1e-2, 1, false);

    [ConstData, InitialState] = initialize_problem(testData.config_ccd);
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, testData.config_ccd);
    testData.ConstData = ConstData;
    testData.InitialReference = InitialReference;
    testData.InitialPropagation = InitialPropagation;

    % 同时把 control_reg_type 设为 norm_gap，核验 ccd_lu 下 gamma_node 仍全为 0
    config = testData.config_ccd;
    config.objective.control_reg_type = 'norm_gap';
    [RunState, ~] = initialize_scp_run(InitialReference, InitialPropagation, config);
    History = repmat(create_empty_iteration_record(), 3, 1);
    for iter = 1:3
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
        History(iter) = IterationRecord;
    end
    testData.ccd_history = History;
    testData.ccd_history_config = config;
    testCase.TestData = testData;
end


function config = build_test_config(mode, penalty_weight, slack_max, keep_bounds)
% BUILD_TEST_CONFIG 默认配置加上单位范数模式设置，并关掉绘图、打印、保存和梯形递推检查。

    config = scp_config_default();
    config.unit_norm.mode = mode;
    config.unit_norm.ccd_penalty_weight = penalty_weight;
    config.unit_norm.ccd_slack_max = slack_max;
    config.unit_norm.ccd_keep_control_bounds = keep_bounds;

    config.plot.enable_initial = false;
    config.plot.enable_iteration = false;
    config.plot.enable_final = false;
    config.output.print_pre_iteration = false;
    config.output.print_iteration = false;
    config.output.print_summary = false;
    config.output.save.brief_text = false;
    config.output.save.detail_text = false;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    config.output.save.control_text = false;
    config.output.save.control_mat = false;
    config.validation.enable_trapezoid_check = false;
end


%% ===== 1. 模式开关与描述函数 =====

function test_describe_unit_norm_modes(testCase)
% 默认、缺字段、ccd_lu、非法模式和非法参数的检查。

    config = scp_config_default();
    UnitNorm = describe_unit_norm(config);
    verifyEqual(testCase, UnitNorm.mode, 'regularized');
    verifyFalse(testCase, UnitNorm.is_ccd_lu);
    verifyEqual(testCase, UnitNorm.penalty_weight, 0);
    verifyEqual(testCase, UnitNorm.slack_max, 0);
    verifyFalse(testCase, UnitNorm.keep_control_bounds);
    verifyFalse(testCase, UnitNorm.normalize_initial_control);
    verifyEqual(testCase, UnitNorm.term_name, 'control_reg');
    verifyEqual(testCase, UnitNorm.term_label, '控制正则项');
    verifyEqual(testCase, UnitNorm.term_kind, 'extra_nonconvex');

    % 缺 unit_norm 字段时按 regularized 处理
    legacy = rmfield(config, 'unit_norm');
    LegacyUnitNorm = describe_unit_norm(legacy);
    verifyEqual(testCase, LegacyUnitNorm.mode, 'regularized');
    verifyFalse(testCase, LegacyUnitNorm.is_ccd_lu);

    config.unit_norm.mode = 'ccd_lu';
    config.unit_norm.ccd_penalty_weight = 7;
    config.unit_norm.ccd_slack_max = 0.3;
    config.unit_norm.ccd_keep_control_bounds = true;
    config.unit_norm.ccd_normalize_initial_control = false;
    UnitNorm = describe_unit_norm(config);
    verifyTrue(testCase, UnitNorm.is_ccd_lu);
    verifyEqual(testCase, UnitNorm.penalty_weight, 7);
    verifyEqual(testCase, UnitNorm.slack_max, 0.3);
    verifyTrue(testCase, UnitNorm.keep_control_bounds);
    verifyFalse(testCase, UnitNorm.normalize_initial_control);
    verifyEqual(testCase, UnitNorm.term_name, 'unit_norm_penalty');
    verifyEqual(testCase, UnitNorm.term_label, '单位范数罚项');
    verifyEqual(testCase, UnitNorm.term_kind, 'inequality_penalty');

    config.unit_norm.mode = 'foo';
    verifyError(testCase, @() describe_unit_norm(config), 'SCP:UnknownUnitNormMode');
    config.unit_norm.mode = 'ccd';
    verifyError(testCase, @() describe_unit_norm(config), 'SCP:UnknownUnitNormMode');

    config.unit_norm.mode = 'ccd_lu';
    config.unit_norm.ccd_penalty_weight = 0;
    verifyError(testCase, @() describe_unit_norm(config), 'SCP:InvalidUnitNormConfig');
    config.unit_norm.ccd_penalty_weight = 7;
    config.unit_norm.ccd_slack_max = -1;
    verifyError(testCase, @() describe_unit_norm(config), 'SCP:InvalidUnitNormConfig');
    config.unit_norm.ccd_slack_max = Inf;
    verifyError(testCase, @() describe_unit_norm(config), 'SCP:InvalidUnitNormConfig');
end


%% ===== 2. 变量布局与 P3 装配 =====

function test_variable_layout_and_p3_assembly(testCase)
% regularized 布局不变；ccd_lu 布局、平方内逼近行（含非单位与零节点）、不乘 ω_i 目标与锥。

    testData = testCase.TestData;
    ConstData = testData.ConstData;
    Reference = testData.InitialReference;
    N = Reference.N;

    % regularized 下布局和行块不变
    config_reg = testData.config_reg;
    TrustReg = initialize_trust_region_state(config_reg);
    [IndexReg, num_vars_reg] = build_variable_index(Reference, ConstData, config_reg);
    verifyEmpty(testCase, IndexReg.unit_norm_slack);
    verifyEqual(testCase, num_vars_reg, 17 * N + 25);
    verifyEqual(testCase, IndexReg.t_f(:), ((17 * N + 21):(17 * N + 25)).');
    LinearReg = build_linear_constraints(IndexReg, Reference, ConstData, config_reg);
    ConicReg = build_conic_constraints(IndexReg, Reference, ConstData, config_reg);
    verifyFalse(testCase, isfield(LinearReg.row_groups, 'unit_norm_inner'));
    DisksReg = ConicReg.cones(strcmp({ConicReg.cones.name}, 'control_disk'));
    verifyEqual(testCase, DisksReg(1).tightness_role, 'lossless');
    verifyEqual(testCase, DisksReg(1).rows, (1:3).');

    % ccd_lu 下布局为 18*N + 25
    config_ccd = testData.config_ccd;
    TrustCcd = initialize_trust_region_state(config_ccd);
    [VariableIndex, num_variables] = build_variable_index(Reference, ConstData, config_ccd);
    verifyEqual(testCase, num_variables, 18 * N + 25);
    verifyEqual(testCase, VariableIndex.t_f(:), ((17 * N + 21):(17 * N + 25)).');
    verifyEqual(testCase, VariableIndex.unit_norm_slack(:), ...
        ((17 * N + 26):(18 * N + 25)).');

    % 非单位节点 + 零节点验证平方内逼近行：第 2 节点 [1.2; 0.5]，第 3 节点 [0; 0]
    TestRef = Reference;
    TestRef.control.u1(2) = 1.2;
    TestRef.control.u2(2) = 0.5;
    TestRef.control.u1(3) = 0;
    TestRef.control.u2(3) = 0;

    LinearConstraints = build_linear_constraints(VariableIndex, TestRef, ConstData, config_ccd);
    ConicConstraints = build_conic_constraints(VariableIndex, TestRef, ConstData, config_ccd);
    VariableBounds = build_variable_bounds( ...
        VariableIndex, TestRef, TrustCcd, ConstData, config_ccd);
    [objective, objective_offset] = build_objective( ...
        VariableIndex, TestRef, ConstData, config_ccd);

    rows = LinearConstraints.row_groups.unit_norm_inner;
    verifyEqual(testCase, numel(rows), N);
    A_inner = full(LinearConstraints.matrix(rows, :));
    u1_ref = TestRef.control.u1(:);
    u2_ref = TestRef.control.u2(:);
    verifyEqual(testCase, ...
        A_inner(sub2ind(size(A_inner), (1:N).', VariableIndex.u1(:))), ...
        -2 * u1_ref, 'AbsTol', 1e-15);
    verifyEqual(testCase, ...
        A_inner(sub2ind(size(A_inner), (1:N).', VariableIndex.u2(:))), ...
        -2 * u2_ref, 'AbsTol', 1e-15);
    verifyEqual(testCase, LinearConstraints.upper(rows), ...
        -(1 + u1_ref.^2 + u2_ref.^2), 'AbsTol', 1e-15);
    verifyTrue(testCase, all(isinf(LinearConstraints.lower(rows)) ...
        & LinearConstraints.lower(rows) < 0));

    % 第 2 节点显式检查 [-2.4, -1.0] 和 -(1 + 1.2^2 + 0.5^2)
    verifyEqual(testCase, A_inner(2, [VariableIndex.u1(2), VariableIndex.u2(2)]), ...
        [-2.4, -1.0], 'AbsTol', 1e-15);
    verifyEqual(testCase, LinearConstraints.upper(rows(2)), ...
        -(1 + 1.2^2 + 0.5^2), 'AbsTol', 1e-15);

    % 第 3 节点（零控制）系数必须为 [0, 0]，upper == -1（不填 (1, 1)/sqrt(2)）
    verifyEqual(testCase, A_inner(3, [VariableIndex.u1(3), VariableIndex.u2(3)]), ...
        [0, 0], 'AbsTol', 1e-15);
    verifyEqual(testCase, LinearConstraints.upper(rows(3)), -1, 'AbsTol', 1e-15);

    % 目标系数不乘 ω_i：c(ε) == p * ones(N, 1)，u 系数为 0，objective_offset == 0
    p = config_ccd.unit_norm.ccd_penalty_weight;
    verifyEqual(testCase, objective(VariableIndex.unit_norm_slack(:)), ...
        p * ones(N, 1), 'AbsTol', 1e-15);
    verifyEqual(testCase, objective(VariableIndex.u1(:)), zeros(N, 1));
    verifyEqual(testCase, objective(VariableIndex.u2(:)), zeros(N, 1));
    verifyEqual(testCase, objective_offset, 0);

    % control_disk 锥：tightness_role = 'epigraph'，[1 + ε_i; u1_i; u2_i] ∈ Q³
    Disks = ConicConstraints.cones(strcmp({ConicConstraints.cones.name}, 'control_disk'));
    verifyNumElements(testCase, Disks, N);
    F = full(ConicConstraints.mapping);
    g = ConicConstraints.offset;
    for i = 1:N
        verifyEqual(testCase, Disks(i).index, i);
        verifyEqual(testCase, Disks(i).tightness_role, 'epigraph');
        r = Disks(i).rows;
        verifyEqual(testCase, r, (3 * i - 2:3 * i).');
        verifyEqual(testCase, F(r(1), VariableIndex.unit_norm_slack(i)), 1);
        verifyEqual(testCase, F(r(2), VariableIndex.u1(i)), 1);
        verifyEqual(testCase, F(r(3), VariableIndex.u2(i)), 1);
        verifyEqual(testCase, g(r), [1; 0; 0]);
    end

    % 边界检查
    verifyEqual(testCase, VariableBounds.lower(VariableIndex.unit_norm_slack(:)), zeros(N, 1));
    verifyEqual(testCase, VariableBounds.upper(VariableIndex.unit_norm_slack(:)), ...
        config_ccd.unit_norm.ccd_slack_max * ones(N, 1));
    verifyEqual(testCase, VariableBounds.lower(VariableIndex.u1(:)), -2 * ones(N, 1));
    verifyEqual(testCase, VariableBounds.upper(VariableIndex.u1(:)), 2 * ones(N, 1));

    config_keep = config_ccd;
    config_keep.unit_norm.ccd_keep_control_bounds = true;
    BoundsKeep = build_variable_bounds( ...
        VariableIndex, TestRef, TrustCcd, ConstData, config_keep);
    verifyEqual(testCase, BoundsKeep.lower(VariableIndex.u1(:)), -ones(N, 1));
    verifyEqual(testCase, BoundsKeep.upper(VariableIndex.u1(:)), ones(N, 1));
end


%% ===== 3. 罚函数与 3 轮主链检查 =====

function test_penalty_function_and_3_rounds(testCase)
% regularized 分项列表不变；ccd_lu 3 轮下 J、L、零步长可行性、min‖u‖ 和 gamma_node 检查。

    testData = testCase.TestData;
    ConstData = testData.ConstData;
    Reference = testData.InitialReference;
    config_reg = testData.config_reg;
    TrustReg = initialize_trust_region_state(config_reg);
    expected_names = {'terminal_inclination', 'terminal_apoapsis', 'impulse', ...
        'point_slack', 'dyn_slack', 'control_reg'};
    expected_kinds = {'equality_penalty', 'equality_penalty', 'cost_nonconvex', ...
        'equality_penalty', 'equality_penalty', 'extra_nonconvex'};

    P2Reg = check_p2_feasibility(Reference, ConstData, config_reg);
    PenaltyReg = evaluate_penalty_function(Reference, P2Reg, ConstData, config_reg);
    verifyEqual(testCase, {PenaltyReg.terms.name}, expected_names);
    verifyEqual(testCase, {PenaltyReg.terms.kind}, expected_kinds);

    [IndexReg, ~] = build_variable_index(Reference, ConstData, config_reg);
    [obj_reg, obj_offset_reg] = build_objective(IndexReg, Reference, ConstData, config_reg);
    LinearReg = build_linear_constraints(IndexReg, Reference, ConstData, config_reg);
    BoundsReg = build_variable_bounds(IndexReg, Reference, TrustReg, ConstData, config_reg);
    ConicReg = build_conic_constraints(IndexReg, Reference, ConstData, config_reg);
    SolverReg = solve_convex_subproblem( ...
        obj_reg, LinearReg, BoundsReg, ConicReg, config_reg, obj_offset_reg);
    TermsReg = compute_objective_terms(obj_reg, SolverReg.primal, IndexReg, config_reg, obj_offset_reg);
    verifyEqual(testCase, {TermsReg.terms.name}, expected_names);
    verifyEqual(testCase, {TermsReg.terms.kind}, expected_kinds);
    SolReg = extract_subproblem_solution(SolverReg, IndexReg, Reference, ConstData, config_reg);
    verifyEmpty(testCase, SolReg.unit_norm_slack);

    % ccd_lu 3 轮核验
    config_ccd = testData.ccd_history_config;
    p = config_ccd.unit_norm.ccd_penalty_weight;
    History = testData.ccd_history;
    verifyNumElements(testCase, History, 3);

    for k = 1:numel(History)
        Record = History(k);
        Evaluation = Record.trust.evaluation;
        Report = Record.subproblem.control_report;
        verifyEqual(testCase, Evaluation.group.extra.candidate, 0);
        verifyEqual(testCase, Evaluation.term_names{end}, 'unit_norm_penalty');
        verifyEqual(testCase, Evaluation.term_kinds{end}, 'inequality_penalty');
        expected_penalty = p * sum(max(Report.u_norm - 1, 0));
        verifyEqual(testCase, Evaluation.term_candidate(end), expected_penalty, 'AbsTol', 1e-12);
        verifyLessThanOrEqual(testCase, abs(Evaluation.term_prediction_error(end)), 1e-6);
        verifyFalse(testCase, Evaluation.convex_error_flag);
        verifyGreaterThanOrEqual(testCase, min(Report.u_norm), 1 - 1e-8);
        verifyEqual(testCase, Report.gamma_node, zeros(Report.num_nodes, 1), 'AbsTol', 1e-15);
        verifyNumElements(testCase, Record.solution.unit_norm_slack, Record.solution.N);
    end

    % 零步长可行性：初始参考和每次被接受后的参考
    References = {testData.InitialReference};
    for k = 1:numel(History)
        if History(k).trust.accept_candidate
            References{end + 1} = History(k).reference_after; %#ok<AGROW>
        end
    end
    verifyGreaterThan(testCase, numel(References), 1);
    TrustCcd = initialize_trust_region_state(config_ccd);
    for r = 1:numel(References)
        Ref = References{r};
        [VariableIndex, num_variables] = build_variable_index(Ref, ConstData, config_ccd);
        LinearConstraints = build_linear_constraints(VariableIndex, Ref, ConstData, config_ccd);
        ConicConstraints = build_conic_constraints(VariableIndex, Ref, ConstData, config_ccd);
        build_variable_bounds(VariableIndex, Ref, TrustCcd, ConstData, config_ccd);
        z = zeros(num_variables, 1);
        z(VariableIndex.u1) = Ref.control.u1(:);
        z(VariableIndex.u2) = Ref.control.u2(:);
        z(VariableIndex.unit_norm_slack) = max(hypot(Ref.control.u1(:), Ref.control.u2(:)) - 1, 0);

        cone_values = ConicConstraints.mapping * z + ConicConstraints.offset;
        disks = ConicConstraints.cones(strcmp({ConicConstraints.cones.name}, 'control_disk'));
        for i = 1:Ref.N
            cone_res = norm(cone_values(disks(i).rows(2:3))) - cone_values(disks(i).rows(1));
            verifyLessThanOrEqual(testCase, cone_res, 1e-12);
        end
        rows = LinearConstraints.row_groups.unit_norm_inner;
        row_res = max(LinearConstraints.matrix(rows, :) * z - LinearConstraints.upper(rows));
        if r == 1
            tol = 1e-12;
        else
            tol = 2 * config_ccd.solver.co_tol_pfeas;
        end
        verifyLessThanOrEqual(testCase, row_res, tol);
    end
end


%% ===== 4. 对偶分解与驻点条件 =====

function test_dual_split_and_stationarity(testCase)
% 对偶驻点残差、平方线性化内逼近对偶贡献 2*ū_i*y_i、锥首分量对偶 κ̂_i = p - slx + sux（不含 ω）。

    testData = testCase.TestData;
    config = testData.ccd_history_config;
    p = config.unit_norm.ccd_penalty_weight;
    History = testData.ccd_history;

    num_checked = 0;
    for k = 1:numel(History)
        Record = History(k);
        Report = Record.subproblem.control_report;
        if ~Report.dual_available
            continue;
        end
        num_checked = num_checked + 1;
        verifyLessThanOrEqual(testCase, ...
            max(abs(Report.stationarity_residual), [], 'all'), 1e-6);

        Reference = Record.reference_before;
        [VariableIndex, ~] = build_variable_index(Reference, testData.ConstData, config);
        LinearConstraints = build_linear_constraints(VariableIndex, Reference, ...
            testData.ConstData, config);
        rows = LinearConstraints.row_groups.unit_norm_inner(:);
        y_inner = Record.subproblem.solver.dual.y(rows);
        u1_ref = Reference.control.u1(:);
        u2_ref = Reference.control.u2(:);
        y_tol = 1e-12 * max(1, max(abs(y_inner)));
        verifyEqual(testCase, Report.s_inner(:, 1), 2 * u1_ref .* y_inner, 'AbsTol', y_tol);
        verifyEqual(testCase, Report.s_inner(:, 2), 2 * u2_ref .* y_inner, 'AbsTol', y_tol);

        slx = Record.subproblem.solver.dual.slx(VariableIndex.unit_norm_slack(:));
        sux = Record.subproblem.solver.dual.sux(VariableIndex.unit_norm_slack(:));
        verifyEqual(testCase, Report.cone_dual_leading, ...
            p - slx + sux, 'AbsTol', 1e-6, 'RelTol', 1e-3);
    end
    verifyGreaterThan(testCase, num_checked, 0);
end


%% ===== 5. 初始参考归一化 =====

function test_initial_reference_normalization(testCase)
% ccd_lu 下非零节点归一化到圆上，零向量保持 [0, 0]；关闭开关或 regularized 下保持原值。

    testData = testCase.TestData;
    InitialReference = testData.InitialReference;
    InitialReference.control.u1(1:3) = [0.5; 1; 1.5] * sqrt(2) / 2;
    InitialReference.control.u2(1:3) = [0.5; 1; 1.5] * sqrt(2) / 2;
    InitialReference.control.u1(4) = 0;
    InitialReference.control.u2(4) = 0;

    [RunStateCcd, ~] = initialize_scp_run( ...
        InitialReference, testData.InitialPropagation, testData.config_ccd);
    u1_ccd = RunStateCcd.current_reference.control.u1;
    u2_ccd = RunStateCcd.current_reference.control.u2;
    norm_ccd = hypot(u1_ccd, u2_ccd);
    nonzero_mask = true(size(norm_ccd));
    nonzero_mask(4) = false;
    verifyEqual(testCase, norm_ccd(nonzero_mask), ones(sum(nonzero_mask), 1), 'AbsTol', 1e-12);
    % 第 4 节点零向量保持为 (0, 0)，不得替换为 (1, 1)/sqrt(2)
    verifyEqual(testCase, u1_ccd(4), 0, 'AbsTol', 1e-15);
    verifyEqual(testCase, u2_ccd(4), 0, 'AbsTol', 1e-15);

    config_no_norm = testData.config_ccd;
    config_no_norm.unit_norm.ccd_normalize_initial_control = false;
    [RunStateNoNorm, ~] = initialize_scp_run( ...
        InitialReference, testData.InitialPropagation, config_no_norm);
    verifyEqual(testCase, RunStateNoNorm.current_reference.control.u1, InitialReference.control.u1);
    verifyEqual(testCase, RunStateNoNorm.current_reference.control.u2, InitialReference.control.u2);

    [RunStateReg, ~] = initialize_scp_run( ...
        InitialReference, testData.InitialPropagation, testData.config_reg);
    verifyEqual(testCase, RunStateReg.current_reference.control.u1, InitialReference.control.u1);
    verifyEqual(testCase, RunStateReg.current_reference.control.u2, InitialReference.control.u2);
end


%% ===== 6. 触上界、空报告与全输出跑通 =====

function test_slack_cap_and_empty_report(testCase)
% 欠罚触上界被报告；空报告和空汇总含全部新字段。

    testData = testCase.TestData;
    config = build_test_config('ccd_lu', 1e-6, 0.1, false);
    ConstData = testData.ConstData;
    [RunState, ~] = initialize_scp_run( ...
        testData.InitialReference, testData.InitialPropagation, config);
    [~, SubproblemDiag] = solve_scp_subproblem( ...
        RunState.current_reference, RunState.trust_region, ConstData, config, 1);

    verifyTrue(testCase, SubproblemDiag.success);
    Report = SubproblemDiag.control_report;
    verifyTrue(testCase, any(Report.slack_capped));
    verifyEqual(testCase, Report.summary_total.num_slack_capped, sum(Report.slack_capped));
    verifyGreaterThanOrEqual(testCase, max(Report.unit_norm_slack), 0.1 - 1e-9);

    EmptyReport = create_empty_control_report('solver_failed');
    verifyTrue(testCase, isfield(EmptyReport, 's_inner'));
    verifyTrue(testCase, isfield(EmptyReport, 'lambda_inner'));
    verifyTrue(testCase, isfield(EmptyReport, 'unit_norm_slack'));
    verifyTrue(testCase, isfield(EmptyReport, 'slack_capped'));
    verifyTrue(testCase, isfield(EmptyReport, 'cone_dual_leading'));
    EmptySummary = create_empty_control_summary();
    verifyTrue(testCase, isfield(EmptySummary, 'max_inward_gap'));
    verifyTrue(testCase, isfield(EmptySummary, 'max_outward_gap'));
    verifyTrue(testCase, isfield(EmptySummary, 'num_slack_capped'));
end


function test_ccd_lu_entry_outputs_run(testCase)
% ccd_lu 全输出 2 轮跑通，核对 detail/control 文本和 control.mat 并清理临时目录。

    testData = testCase.TestData;
    ConstData = testData.ConstData;
    config = build_test_config('ccd_lu', 1, 1, false);
    config.iter.max_scp_iter = 2;
    config.plot.enable_iteration = true;
    config.plot.enable_final = true;
    config.plot.visibility = 'off';
    config.plot.save_figures = false;
    config.output.save.brief_text = true;
    config.output.save.detail_text = true;
    config.output.save.control_text = true;
    config.output.save.control_mat = true;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    save_directory = 'results/tmp_entry_check_lu';
    config.output.save.directory = save_directory;

    version_root = fileparts(fileparts(mfilename('fullpath')));
    output_directory = fullfile(version_root, save_directory);
    cleanup = onCleanup(@() remove_directory(output_directory));

    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        testData.InitialReference, testData.InitialPropagation, config);
    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ConstData, config, iter);
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);
    end
    close_figures = onCleanup(@() close('all')); %#ok<NASGU>
    FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory);
    PlotReport = plot_scp_result(FinalizedRun, ConstData, config);
    build_scp_result(FinalizedRun);
    SaveReport = save_scp_result(FinalizedRun, ConstData, config);
    verifyTrue(testCase, SaveReport.success);

    detail_text = fileread(SaveReport.files(strcmp({SaveReport.files.name}, 'detail_text')).path);
    num_rounds = numel(FinalizedRun.history);
    verifyEqual(testCase, numel(regexp(detail_text, '单位范数内逼近', 'match')), num_rounds);

    control_text = fileread(SaveReport.files(strcmp({SaveReport.files.name}, 'control_text')).path);
    verifyNotEmpty(testCase, regexp(control_text, ...
        '^单位范数处理: ccd_lu \| p 1\.000e\+00 \(不乘ω\) \| ε上界 ', ...
        'match', 'once', 'lineanchors'));

    Saved = load(SaveReport.files(strcmp({SaveReport.files.name}, 'control_mat')).path, 'ControlExport');
    verifyEqual(testCase, Saved.ControlExport.unit_norm_mode, 'ccd_lu');
    verifyEqual(testCase, Saved.ControlExport.ccd_penalty_weight, 1);
    verifyEqual(testCase, Saved.ControlExport.ccd_slack_max, 1);
    verifyTrue(testCase, PlotReport.success);
end


function remove_directory(directory)
% REMOVE_DIRECTORY 删除测试用的临时目录（不存在时不做任何事）。

    if isfolder(directory)
        rmdir(directory, 's');
    end
end
