function IterationRecord = create_empty_iteration_record()
% CREATE_EMPTY_ITERATION_RECORD 创建统一的空迭代记录。
%
% IterationRecord 只保存本轮的参考、解、检查结果和接受结果，由 advance_scp_iteration 写入。

    IterationRecord.iter = [];
    IterationRecord.reference_before = [];
    IterationRecord.reference_after = [];
    IterationRecord.solution = [];
    IterationRecord.subproblem = create_empty_subproblem_diag();
    IterationRecord.trust = create_empty_trust_result();
    IterationRecord.num_accepted_after = 0;
    IterationRecord.stop = create_empty_stop_decision();
    IterationRecord.complete = false;
end
