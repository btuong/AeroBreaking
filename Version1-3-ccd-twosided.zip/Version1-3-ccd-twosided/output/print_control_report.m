function print_control_report(file_id, ControlExport)
% PRINT_CONTROL_REPORT 向文件写控制量报告（control.txt）：头部、逐次尝试汇总、最后接受轮的逐圈汇总和逐节点表。
%
% 输入:
%   file_id       - fopen 得到的文件号（1 写终端）
%   ControlExport - build_control_export 的输出，只读，不重新求值
%
% 本函数依次完成：
%   1. 写头部：版本、w_reg、积分权的计算方式、Σω。
%   2. 写逐次尝试的全程汇总表。
%   3. 写最后被接受那轮的逐圈汇总表。
%   4. 写最后被接受那轮的逐节点表。

    %% 1. 写头部：版本、w_reg、积分权的计算方式、Σω
    Attempts = ControlExport.attempts;
    evaluated = arrayfun(@(Attempt) Attempt.control_report.evaluated, Attempts).';
    accepted = [Attempts.accepted] & evaluated;
    final_index = find(accepted, 1, 'last');
    if isempty(final_index)
        header_index = find(evaluated, 1, 'last');
    else
        header_index = final_index;
    end
    write_control_header(file_id, ControlExport, Attempts, header_index);

    %% 2. 写逐次尝试的全程汇总表
    is_twosided = isfield(ControlExport, 'unit_norm_mode') ...
        && strcmp(ControlExport.unit_norm_mode, 'twosided');
    write_attempt_tables(file_id, Attempts, is_twosided);

    %% 3. 写最后被接受那轮的逐圈汇总表
    if isempty(final_index)
        fprintf(file_id, '\n[3] 最后被接受那轮的逐圈汇总: NONE（没有被接受的轮）\n');
        fprintf(file_id, '\n[4] 最后被接受那轮的逐节点表: NONE（没有被接受的轮）\n');
        return;
    end
    FinalAttempt = Attempts(final_index);
    write_circuit_tables(file_id, FinalAttempt);

    %% 4. 写最后被接受那轮的逐节点表
    write_node_table(file_id, FinalAttempt);
end


function write_control_header(file_id, ControlExport, Attempts, header_index)
% WRITE_CONTROL_HEADER 写头部：版本、w_reg、积分权的计算方式和 Σω（全程与各圈）。

    fprintf(file_id, '控制量 u 导出 (control)\n');
    fprintf(file_id, '版本: %s\n', ControlExport.version_root);
    if isfield(ControlExport, 'unit_norm_mode') ...
            && strcmp(ControlExport.unit_norm_mode, 'twosided')
        fprintf(file_id, '单位范数处理: twosided | P %.3e | s上界 %.3e\n', ...
            ControlExport.twosided_penalty_weight, ...
            ControlExport.twosided_slack_max);
    end
    fprintf(file_id, 'w_reg: %.3e\n', ControlExport.w_reg);
    fprintf(file_id, '积分权: %s\n', ControlExport.weight_method);
    fprintf(file_id, '尝试数: %d | 最后被接受的轮: %s\n', numel(Attempts), ...
        format_iter(ControlExport.final_iter));
    if isempty(header_index)
        fprintf(file_id, 'Σω: 无成功求解的尝试\n');
        return;
    end
    Report = Attempts(header_index).control_report;
    circuit_text = strjoin(arrayfun(@(Summary) sprintf('%.4f', Summary.sum_omega), ...
        Report.summary_circuits(:).', 'UniformOutput', false), ' ');
    fprintf(file_id, 'Σω (第 %d 轮): 全程 %.4f | 各圈 %s\n', ...
        Attempts(header_index).iter, Report.summary_total.sum_omega, circuit_text);
    fprintf(file_id, '注: 正则项系数 c_reg 取自实际装配的目标向量；Γ̃ = Σ c_reg·u 是 P3 里的附加项（线性化值）。\n');
end


function write_attempt_tables(file_id, Attempts, is_twosided)
% WRITE_ATTEMPT_TABLES 写逐次尝试的全程汇总表（每次一行，分紧性与 σ、正则项偏向两张表）。

    fprintf(file_id, '\n[2] 逐次尝试的全程汇总\n');
    fprintf(file_id, 'σ≈-135 / σ≈+45: σ 落在 -135°±15° / +45°±15° 的节点比例；不紧: |1-‖u‖| 超容差的节点数\n');
    if is_twosided
        widths = [3, 6, 11, 11, 5, 10, 10, 6, 8, 8];
        print_table_row(file_id, {'轮', '决策', 'Γ', 'max|1-‖u‖|', '不紧', ...
            's1', 's2', '触上界', 'σ≈-135', 'σ≈+45'}, widths, 2, 2);
    else
        widths = [3, 6, 11, 11, 5, 8, 8];
        print_table_row(file_id, {'轮', '决策', 'Γ', 'max|1-‖u‖|', '不紧', ...
            'σ≈-135', 'σ≈+45'}, widths, 2, 2);
    end
    for k = 1:numel(Attempts)
        Attempt = Attempts(k);
        Report = Attempt.control_report;
        if ~Report.evaluated
            if is_twosided
                cells = {sprintf('%d', Attempt.iter), decide_text(Attempt), ...
                    '-', '-', '-', '-', '-', '-', '-', '-'};
            else
                cells = {sprintf('%d', Attempt.iter), decide_text(Attempt), ...
                    '-', '-', '-', '-', '-'};
            end
        else
            Total = Report.summary_total;
            if is_twosided
                cells = {sprintf('%d', Attempt.iter), decide_text(Attempt), ...
                    sprintf('%.4e', Total.gamma_sum), ...
                    sprintf('%.2e', Total.max_abs_tight_gap), ...
                    sprintf('%d', Total.num_untight), ...
                    sprintf('%.3e', Report.unit_norm_slack(1)), ...
                    sprintf('%.3e', Report.unit_norm_slack(2)), ...
                    sprintf('%d', Total.num_slack_capped), ...
                    sprintf('%.3f', Total.fraction_neg135), ...
                    sprintf('%.3f', Total.fraction_pos45)};
            else
                cells = {sprintf('%d', Attempt.iter), decide_text(Attempt), ...
                    sprintf('%.4e', Total.gamma_sum), ...
                    sprintf('%.2e', Total.max_abs_tight_gap), ...
                    sprintf('%d', Total.num_untight), ...
                    sprintf('%.3f', Total.fraction_neg135), ...
                    sprintf('%.3f', Total.fraction_pos45)};
            end
        end
        print_table_row(file_id, cells, widths, 2, 2);
    end

    fprintf(file_id, '\nratio = ‖s_reg‖/‖s_main‖；|Δσ| = |σ-σ_main| (deg)；驻点残差 = max|s_total-s_cone|\n');
    widths = [3, 6, 10, 8, 10, 10, 11];
    print_table_row(file_id, {'轮', '决策', 'ratio中位', 'ratio>1', ...
        '|Δσ|中位', '|Δσ|最大', '驻点残差'}, widths, 2, 2);
    for k = 1:numel(Attempts)
        Attempt = Attempts(k);
        Report = Attempt.control_report;
        if ~Report.evaluated
            cells = {sprintf('%d', Attempt.iter), decide_text(Attempt), ...
                '-', '-', '-', '-', '-'};
        else
            Total = Report.summary_total;
            cells = {sprintf('%d', Attempt.iter), decide_text(Attempt), ...
                sprintf('%.3e', Total.reg_ratio_median), ...
                format_count(Total.num_reg_ratio_gt1), ...
                sprintf('%.2f', Total.shift_abs_median), ...
                sprintf('%.2f', Total.shift_abs_max), ...
                sprintf('%.2e', Total.residual_max_abs)};
        end
        print_table_row(file_id, cells, widths, 2, 2);
    end
    if any(arrayfun(@(Attempt) Attempt.control_report.evaluated ...
            && ~Attempt.control_report.dual_available, Attempts))
        fprintf(file_id, '注: 有尝试的对偶解不可用，对偶相关列为 NaN（原因见 control.mat）。\n');
    end
end


function write_circuit_tables(file_id, Attempt)
% WRITE_CIRCUIT_TABLES 写最后被接受那轮的逐圈汇总表（5 圈加全程一行，分两张表）。

    Report = Attempt.control_report;
    summaries = [Report.summary_circuits(:); Report.summary_total];
    labels = [arrayfun(@(cir) sprintf('%d', cir), 1:Report.num_circuits, ...
        'UniformOutput', false), {'全程'}];

    fprintf(file_id, '\n[3] 最后被接受那轮（第 %d 轮）的逐圈汇总\n', Attempt.iter);
    widths = [4, 7, 11, 10, 5, 7, 7, 7, 6, 6];
    print_table_row(file_id, {'圈', 'Σω', 'Γ小计', 'max|gap|', '不紧', ...
        'σ均值', 'σ最小', 'σ最大', '-135', '+45'}, widths, 2, 1);
    for k = 1:numel(summaries)
        S = summaries(k);
        print_table_row(file_id, {labels{k}, sprintf('%.4f', S.sum_omega), ...
            sprintf('%.4e', S.gamma_sum), sprintf('%.2e', S.max_abs_tight_gap), ...
            sprintf('%d', S.num_untight), sprintf('%.1f', S.sigma_mean), ...
            sprintf('%.1f', S.sigma_min), sprintf('%.1f', S.sigma_max), ...
            sprintf('%.3f', S.fraction_neg135), ...
            sprintf('%.3f', S.fraction_pos45)}, widths, 2, 1);
    end
    fprintf(file_id, 'gap = 1-‖u‖；σ 单位 deg；-135 / +45 为 σ 落在 -135°±15° / +45°±15° 的节点比例\n');

    fprintf(file_id, '\n');
    widths = [4, 10, 10, 8, 10, 10, 11];
    print_table_row(file_id, {'圈', 'ratio中位', 'ratio最大', 'ratio>1', ...
        '|Δσ|中位', '|Δσ|最大', '驻点残差'}, widths, 2, 1);
    for k = 1:numel(summaries)
        S = summaries(k);
        print_table_row(file_id, {labels{k}, sprintf('%.3e', S.reg_ratio_median), ...
            sprintf('%.3e', S.reg_ratio_max), format_count(S.num_reg_ratio_gt1), ...
            sprintf('%.2f', S.shift_abs_median), sprintf('%.2f', S.shift_abs_max), ...
            sprintf('%.2e', S.residual_max_abs)}, widths, 2, 1);
    end
end


function write_node_table(file_id, Attempt)
% WRITE_NODE_TABLE 写最后被接受那轮的逐节点表。

    Report = Attempt.control_report;
    fprintf(file_id, '\n[4] 最后被接受那轮（第 %d 轮）的逐节点表\n', Attempt.iter);
    fprintf(file_id, 'σmain: 只听主问题时 u 指向的方向；Δσ = σ-σmain；单位 deg；Γ贡献 = c_reg·u（P3 线性化值）\n');
    widths = [3, 2, 5, 8, 6, 6, 6, 6, 6, 6, 7, 8];
    print_table_row(file_id, {'i', '圈', 'τ', 'ω', 'u1', 'u2', '‖u‖', 'σ', ...
        'σmain', 'Δσ', 'ratio', 'Γ贡献'}, widths, 0, 0);
    for i = 1:Report.num_nodes
        print_table_row(file_id, {sprintf('%d', Report.node(i)), ...
            sprintf('%d', Report.cir(i)), sprintf('%.3f', Report.tau(i)), ...
            sprintf('%.1e', Report.omega(i)), sprintf('%.3f', Report.u1(i)), ...
            sprintf('%.3f', Report.u2(i)), sprintf('%.4f', Report.u_norm(i)), ...
            sprintf('%.1f', Report.sigma_deg(i)), ...
            sprintf('%.1f', Report.sigma_main_deg(i)), ...
            sprintf('%.1f', Report.sigma_shift_deg(i)), ...
            sprintf('%.1e', Report.reg_ratio(i)), ...
            sprintf('%.1e', Report.gamma_node(i))}, widths, 0, 0);
    end
end


function print_table_row(file_id, cells, widths, indent, num_left)
% PRINT_TABLE_ROW 按显示宽度写一行表格：前 num_left 列左对齐，其余右对齐，列间空一格。

    parts = cell(1, numel(cells));
    for c = 1:numel(cells)
        num_spaces = max(widths(c) - measure_display_width(cells{c}), 0);
        if c <= num_left
            parts{c} = [cells{c}, blanks(num_spaces)];
        else
            parts{c} = [blanks(num_spaces), cells{c}];
        end
    end
    fprintf(file_id, '%s%s\n', blanks(indent), strjoin(parts, ' '));
end


function text = decide_text(Attempt)
% DECIDE_TEXT 候选解决策的简称：接受、拒绝、无候选。

    if ~Attempt.candidate_available
        text = '无候选';
    elseif Attempt.accepted
        text = '接受';
    else
        text = '拒绝';
    end
end


function text = format_count(value)
% FORMAT_COUNT 节点数文字；对偶不可用时为 NaN，显式写 NaN。

    if isnan(value)
        text = 'NaN';
    else
        text = sprintf('%d', value);
    end
end


function text = format_iter(iter)
% FORMAT_ITER 轮号文字；没有接受解时写 NONE。

    if isnan(iter)
        text = 'NONE';
    else
        text = sprintf('%d', iter);
    end
end
