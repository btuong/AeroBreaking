function Curve = build_plot_curve(label, x_values, y_values, style)
% BUILD_PLOT_CURVE 组装一条绘图曲线。
%
% 输入:
%   label    - 图例名称
%   x_values - 横轴数据（时间 s 或迭代序号），向量
%   y_values - 纵轴数据，物理单位，与 x_values 等长；NaN 处曲线断开
%   style    - 线型，见下
%
% style 取值:
%   'line'         实线（按节点的连续量）
%   'bold'         粗实线（同一分块里的总量，如总脉冲；同块其余曲线画细线）
%   'thin'         灰色细实线（参考量，如参考处的违反量）
%   'dashed'       虚线（如 P3 的松弛）
%   'marker'       圆圈标记（离散量，如各段脉冲、衔接点）
%   'marker_gray'  灰色空心小圆圈（离散的参考量）
%   'marker_cross' 叉号标记（离散的第三类量，与圆圈区分）
%   'thin_marker'、'dashed_marker'、'line_marker'
%                  与 thin、dashed、line 同线型，每个数据点另加标记（少量离散点
%                  也要与连续量共用图例时用，如衔接点）

    if numel(x_values) ~= numel(y_values)
        error('SCP:PlotCurveSizeMismatch', ...
            '曲线 %s 的横纵轴数据长度不一致（%d 与 %d）。', ...
            label, numel(x_values), numel(y_values));
    end
    valid_styles = {'line', 'bold', 'thin', 'dashed', 'marker', 'marker_gray', ...
        'marker_cross', 'thin_marker', 'dashed_marker', 'line_marker'};
    if ~any(strcmp(style, valid_styles))
        error('SCP:InvalidPlotCurveStyle', ...
            '曲线 %s 的 style 只能是 %s。', label, strjoin(valid_styles, '、'));
    end
    Curve.label = label;
    Curve.x = x_values(:);
    Curve.y = y_values(:);
    Curve.style = style;
end
