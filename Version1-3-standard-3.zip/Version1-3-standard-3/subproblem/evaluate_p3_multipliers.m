function MultiplierReport = evaluate_p3_multipliers( ...
        SolverResult, LinearConstraints, VariableBounds, ...
        CurrentReference, config)
% EVALUATE_P3_MULTIPLIERS 读 P3 的对偶解，报告各类约束的乘子和信赖域乘子。
%
% 只报告，不进 P3 解检查的 success，不参与接受、半径更新和停止。
%
% 数学形式:
%   P3 记为 min c'x，s.t. blc ≤ A x ≤ buc，blx ≤ x ≤ bux，及锥约束；最优值记为 L*（即 P3 的目标在最优步长处的值）。
%   乘子就是 L* 对约束右端和变量界的导数：
%       dL*/d(blc_i) = y_i（等式行的上下界同为 b_i，所以 dL*/db_i = y_i），
%       dL*/d(blx_j) = slx_j ≥ 0，dL*/d(bux_j) = −sux_j ≤ 0。
%   罚项类约束（动力学、衔接、终端倾角、终端远地点）里，松弛 ν 以系数 +1 进入
%   该行，目标里的松弛罚项是 w·|ν|，所以最优时 |y_i| ≤ w；松弛不为 0 的行 |y_i| = w。
%   |y_i|/w < 1 表示这一行没顶到罚权，在 P3 里等同硬约束（罚权再加大解也不变）。
%   信赖域：r, V, γ, φ, ψ（各节点）和脉冲 P0~P5 的信赖域界是 x̄_j ± r·b_j，
%   r 为半径（基准半径的倍数，代码里叫 scale），b_j 为基准半径（归一化单位）。
%   r 增大时每个有效的上下界各外移 b_j，所以对信赖域界有效的变量 j（有效界等于
%   信赖域界且乘子大于容差）有
%       dL*/dr = −Σ_j (slx_j + sux_j)·b_j，
%   也就是预测下降随半径的变化率 dΔL/dr = Σ_j (slx_j + sux_j)·b_j，
%   记为 trust_slope_total（只存，终端不显示）。
%
% 代码形式:
%   y 的行号与 LinearConstraints.matrix 一致，按 row_groups 的块名取行；
%   动力学行按“区间 × 5 个状态”排列，衔接行按“初始点、内点 1~4 × 5 个状态”排列，
%   松弛 ν 在这两类行里的系数都是 +1，不需要换算系数。终端衔接块的第 1 行是终端
%   远地点半径（罚权 weight_apoapsis），第 6 行是终端倾角（罚权 weight_inclination），
%   第 2~5 行是终端 V、γ、φ、ψ（没有罚权）。信赖域界取自 VariableBounds.trust_*。
%
% 本函数依次完成：
%   1. 检查对偶解是否可用。
%   2. 按约束类统计 max|y|、罚权比和位置。
%   3. 整理逐区间动力学乘子比和逐衔接点乘子比。
%   4. 统计信赖域乘子：生效个数、Σ(slx+sux)·b 和生效节点。

    MultiplierReport = create_empty_multiplier_report();

    %% 1. 检查对偶解是否可用
    Dual = SolverResult.dual;
    num_rows = size(LinearConstraints.matrix, 1);
    num_variables = size(LinearConstraints.matrix, 2);
    if numel(Dual.y) ~= num_rows || numel(Dual.slx) ~= num_variables ...
            || numel(Dual.sux) ~= num_variables
        MultiplierReport.reason = 'dual_unavailable';
        return;
    end
    MultiplierReport.evaluated = true;
    MultiplierReport.reason = '';

    %% 2. 按约束类统计 max|y|、罚权比和位置
    ClassSpecs = build_multiplier_classes(LinearConstraints.row_groups, ...
        config.objective);
    [interval_cir, interval_node] = list_interval_positions( ...
        CurrentReference.PointsBounds);
    class_list = cell(1, numel(ClassSpecs));
    for k = 1:numel(ClassSpecs)
        class_list{k} = summarize_multiplier_class(ClassSpecs(k), ...
            Dual.y, interval_cir, interval_node);
    end
    MultiplierReport.classes = [class_list{:}];

    %% 3. 整理逐区间动力学乘子比和逐衔接点乘子比
    dynamics_rows = LinearConstraints.row_groups.dynamics(:);
    junction_rows = collect_junction_rows(LinearConstraints.row_groups);
    % 行按“区间（或衔接点）× 5 个状态”排列，先按列塞满 5 行再转置
    MultiplierReport.dynamics_ratio = ...
        reshape(abs(Dual.y(dynamics_rows)), 5, []).' ...
        / config.objective.weight_dyn_slack;
    MultiplierReport.junction_ratio = ...
        reshape(abs(Dual.y(junction_rows)), 5, []).' ...
        / config.objective.weight_point_slack;

    %% 4. 统计信赖域乘子：生效个数、Σ(slx+sux)·b 和生效节点
    Trust = compute_trust_multipliers(Dual, VariableBounds, ...
        CurrentReference.N, config.trust_region.active_dual_tolerance);
    MultiplierReport.trust_active_count = Trust.active_count;
    MultiplierReport.trust_slope_channel = Trust.slope_channel;
    MultiplierReport.trust_slope_total = Trust.slope_total;
    MultiplierReport.trust_share = Trust.share;
    MultiplierReport.trust_active_node = Trust.active_node;
    MultiplierReport.trust_active_pulse = Trust.active_pulse;
    MultiplierReport.active_dual_tolerance = ...
        config.trust_region.active_dual_tolerance;
end


function ClassSpecs = build_multiplier_classes(row_groups, weights)
% BUILD_MULTIPLIER_CLASSES 列出要统计的约束类：名称、显示名、罚权和 A 的行号。
%
% 终端衔接块拆成三类（远地点、倾角、其余分量），其余按块名各占一类。
% 罚权为 NaN 表示这一类是硬约束，只给 max|y|。

    junction_rows = collect_junction_rows(row_groups);
    terminal_rows = row_groups.point_terminal(:);
    class_specs = {
        'dynamics',            '动力学',       weights.weight_dyn_slack,  row_groups.dynamics(:);
        'junction',            '衔接',         weights.weight_point_slack, junction_rows;
        'terminal_inclination', '终端倾角',    weights.weight_inclination, terminal_rows(6);
        'terminal_apoapsis',   '终端远地点',   weights.weight_apoapsis,   terminal_rows(1);
        'terminal_other',      '终端其余分量', NaN,                       terminal_rows(2:5);
        'insertion',           '入轨速度',     NaN,                       row_groups.insertion(:);
        'control_continuity',  '控制连续性',   NaN,                       row_groups.control_continuity(:);
        'impulse_epigraph',    '脉冲半平面',   NaN,                       row_groups.impulse_epigraph(:);
        'path_loads',          '路径约束',     NaN,                       row_groups.path_loads(:);
    };
    spec_list = cell(1, size(class_specs, 1));
    for k = 1:size(class_specs, 1)
        spec_list{k} = struct('name', class_specs{k, 1}, ...
            'label', class_specs{k, 2}, 'weight', class_specs{k, 3}, ...
            'rows', class_specs{k, 4});
    end
    ClassSpecs = [spec_list{:}];
end


function junction_rows = collect_junction_rows(row_groups)
% COLLECT_JUNCTION_ROWS 初始点衔接块和各内点衔接块的行号，按衔接点顺序拼成一列。

    group_names = fieldnames(row_groups);
    inner_names = group_names(startsWith(group_names, 'point_inner_cir'));
    junction_rows = row_groups.point_initial(:);
    for k = 1:numel(inner_names)
        junction_rows = [junction_rows; row_groups.(inner_names{k})(:)]; %#ok<AGROW>
    end
end


function Summary = summarize_multiplier_class(Spec, y, interval_cir, interval_node)
% SUMMARIZE_MULTIPLIER_CLASS 统计一类约束的 max|y|、罚权比和最大值所在位置。

    values = abs(y(Spec.rows));
    [max_abs, local_row] = max(values);
    Summary.name = Spec.name;
    Summary.label = Spec.label;
    Summary.weight = Spec.weight;
    Summary.num_rows = numel(Spec.rows);
    Summary.max_abs = max_abs;
    Summary.ratio = max_abs / Spec.weight;   % 罚权为 NaN 时 ratio 也是 NaN
    Summary.worst_row = Spec.rows(local_row);
    Summary.location = describe_multiplier_location( ...
        Spec.name, local_row, interval_cir, interval_node);
end


function text = describe_multiplier_location(class_name, local_row, ...
        interval_cir, interval_node)
% DESCRIBE_MULTIPLIER_LOCATION 把类内行号翻译成“圈、节点、通道”之类的位置说明。

    channel_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    switch class_name
        case 'dynamics'
            interval = ceil(local_row / 5);
            channel = mod(local_row - 1, 5) + 1;
            text = sprintf('圈%d 节点%d %s', interval_cir(interval), ...
                interval_node(interval), channel_names{channel});
        case 'junction'
            point = ceil(local_row / 5);
            channel = mod(local_row - 1, 5) + 1;
            if point == 1
                text = sprintf('初始 %s', channel_names{channel});
            else
                text = sprintf('内点%d %s', point - 1, channel_names{channel});
            end
        case 'terminal_other'
            other_names = {'V', 'gamma', 'phi', 'psi'};
            text = sprintf('终端 %s', other_names{local_row});
        otherwise
            text = sprintf('第 %d 行', local_row);
    end
end


function Trust = compute_trust_multipliers(Dual, VariableBounds, num_nodes, tolerance)
% COMPUTE_TRUST_MULTIPLIERS 统计各通道信赖域界生效的变量和 Σ(slx+sux)·b。
%
% 某个变量的信赖域界生效：它的最终界等于信赖域界（差在 1e-12 以内），
% 并且对应的乘子大于 tolerance。物理界或钉扎界更紧的变量不算。
% active_node 的列为 r, V, gamma, phi, psi，行为节点；active_pulse 为 P0~P5。

    bound_match = 1e-12;
    lower_active = abs(VariableBounds.lower - VariableBounds.trust_lower) ...
        <= bound_match & Dual.slx > tolerance;
    upper_active = abs(VariableBounds.upper - VariableBounds.trust_upper) ...
        <= bound_match & Dual.sux > tolerance;
    active = lower_active | upper_active;

    % 不受信赖域约束的变量基准半径是 NaN，先换成 0，避免 0 × NaN
    base_radius = VariableBounds.trust_base;
    base_radius(isnan(base_radius)) = 0;
    contribution = (lower_active .* Dual.slx + upper_active .* Dual.sux) ...
        .* base_radius;

    Trust.active_count = zeros(1, 6);
    Trust.slope_channel = zeros(1, 6);
    Trust.active_node = false(num_nodes, 5);
    Trust.active_pulse = false(6, 1);
    for c = 1:6
        members = find(VariableBounds.trust_channel == c);
        Trust.active_count(c) = sum(active(members));
        Trust.slope_channel(c) = sum(contribution(members));
        active_members = members(active(members));
        if c <= 5
            Trust.active_node(VariableBounds.trust_node(active_members), c) = true;
        else
            Trust.active_pulse(VariableBounds.trust_node(active_members)) = true;
        end
    end
    Trust.slope_total = sum(Trust.slope_channel);
    if Trust.slope_total > 0
        Trust.share = Trust.slope_channel / Trust.slope_total;
    else
        Trust.share = nan(1, 6);
    end
end


function [interval_cir, interval_node] = list_interval_positions(PointsBounds)
% LIST_INTERVAL_POSITIONS 按圈依次列出每个动力学区间所在的圈号和起点节点。

    cir_list = cell(1, numel(PointsBounds));
    node_list = cell(1, numel(PointsBounds));
    for cir = 1:numel(PointsBounds)
        nodes = (PointsBounds(cir).begin:(PointsBounds(cir).end - 1))';
        node_list{cir} = nodes;
        cir_list{cir} = cir * ones(size(nodes));
    end
    interval_cir = vertcat(cir_list{:});
    interval_node = vertcat(node_list{:});
end
