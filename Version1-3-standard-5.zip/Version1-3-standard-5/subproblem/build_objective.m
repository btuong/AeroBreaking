function [objective, objective_offset] = build_objective( ...
        VariableIndex, CurrentReference, ~, config)
% BUILD_OBJECTIVE 构建 M 圈大气跳跃 P3 的目标 L = c^T·x + c_fix 的系数与常数偏置。
%
% 数学形式:
%   最小化线性目标 L = c^T·x，展开为
%       L = w_i·t_if + w_ra·t_raf + w_P·Σ_(k=1..6) t_P,k
%           + w_poi·Σ_(k=1..5) Σ_s t_poi,s,k + w_dyn·Σ_(j=1..N−M) Σ_s t_dyn,s,j
%           + L_reg
%   t_if、t_raf 为终端倾角（rad）、远地点半径（LU）松弛（线性化终端量减目标值）的绝对值上图；t_P,k 为脉冲
%   |P_k|（VU）的上图；t_poi、t_dyn 为衔接松弛 ν_poi、动力学松弛 ν_dyn 的绝对值上图，
%   s ∈ {r, V, γ, φ, ψ}；上图量与被限量的关系由锥块给出（见 build_conic_constraints）。
%   最后一项 L_reg 是圆约束组在 P3 目标里的项，按 config.unit_norm.mode 取（见 describe_unit_norm）：
%   'regularized'（默认）时是附加项 Γ 在 P3 中的形式，按 config.objective.control_reg_type 取（见
%   describe_control_regularizer）：
%       'norm'（默认）Γ = −w_reg·Σ ω_i·‖u_i‖ 在参考控制 ū_i 处的线性化：
%           −‖u_i‖ ≈ −‖ū_i‖ − ē_i^T·(u_i − ū_i) = −ē_i^T·u_i，  ē_i = ū_i/‖ū_i‖
%           L_reg = −w_reg·Σ ω_i·(ē_i^T·u_i)
%           线性化在 u_i = ū_i 处与原函数相等，并且处处不小于原函数（−‖u‖ 是凹函数）。
%           ‖ū_i‖ < 1e-6 时方向没有定义，ē_i 取 (1, 1)/√2（初始参考的方向）。
%       'sum'   L_reg = w_reg·Σ ω_i·(u1_i + u2_i)
%       'u1'    L_reg = w_reg·Σ ω_i·u1_i
%       'u2'    L_reg = w_reg·Σ ω_i·u2_i
%       'none'  L_reg = 0（忽略 w_reg）
%       线性三种本身就是 u 的线性函数，P3 中的项与原函数相同。
%   'ccd' 时没有附加项（Γ = 0），圆约束组是罚项 Θ 的单位范数罚项 p·Σ ω_i·ε_i：
%           L_reg = p·Σ_(i=1..N) ω_i·ε_i，  ε_i ≥ 0 为单位范数松弛（锥 ‖u_i‖ ≤ 1 + ε_i 的首分量），
%       u1、u2 的系数全为 0，c_fix = 0；p 为 config.unit_norm.ccd_penalty_weight。
%   ω_i 为节点 i 的梯形积分权（按圈计算）；罚权和系数 w_* 取自 config.objective。
%   各项均为变量的线性项。
%
% 代码形式:
%   objective 为 num_variables×1 列向量，即 c，按决策向量排列，未列出的变量系数为 0：
%       VariableIndex.t_if                  ← w_i
%       VariableIndex.t_raf                 ← w_ra
%       VariableIndex.t_P                   ← w_P（6 个）
%       VariableIndex.t_poi_slack_<s>       ← w_poi（各 5 个）
%       VariableIndex.t_dyn_slack_<s>       ← w_dyn（各 N−M 个）
%       VariableIndex.u1                    ← 'norm': −w_reg·ω_i·ē_(1,i)；'sum'、'u1': w_reg·ω_i；
%                                              'u2'、'none'、ccd: 0（N×1）
%       VariableIndex.u2                    ← 'norm': −w_reg·ω_i·ē_(2,i)；'sum'、'u2': w_reg·ω_i；
%                                              'u1'、'none'、ccd: 0（N×1）
%       VariableIndex.unit_norm_slack       ← ccd: p·ω_i（N×1；regularized 下为空）
%   ū_i 取 CurrentReference.control.u1、u2（只有 'norm' 用到）。
%   配置字段: weight_inclination → w_i，weight_apoapsis → w_ra，weight_impulse → w_P，
%   weight_point_slack → w_poi，weight_dyn_slack → w_dyn，weight_control_reg → w_reg。
%
% 组成（全部为线性项，系数取向量）:
%   1. w_i * t_if + w_ra * t_raf           - 终端倾角/远地点松弛罚项
%   2. w_P * t_P                            - 性能指标：总脉冲 Σ|P_k|
%   3. w_poi * t_poi_slack_<s>              - 衔接松弛罚项（逐通道）
%   4. w_dyn * t_dyn_slack_<s>              - 动力学松弛罚项（逐通道）
%   5. L_reg                                - regularized：附加项（控制正则，形式由 control_reg_type 决定）；
%                                            ccd：单位范数罚项 p·Σω_i·ε_i
%
% 本函数依次完成：
%   1. 终端松弛罚项。
%   2. 性能指标（总脉冲）。
%   3. 衔接松弛罚项。
%   4. 动力学松弛罚项。
%   5. 圆约束组：按 unit_norm.mode 装配控制正则项或单位范数罚项的系数。

    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    num_variables = max(collect_index_values(VariableIndex));
    min_reference_norm = 1e-6;   % ‖ū_i‖ 低于此值时改用固定方向
    UnitNorm = describe_unit_norm(config);

    w_i = config.objective.weight_inclination;
    w_ra = config.objective.weight_apoapsis;
    w_P = config.objective.weight_impulse;
    w_dyn = config.objective.weight_dyn_slack;
    w_poi = config.objective.weight_point_slack;
    w_reg = config.objective.weight_control_reg;

    objective = zeros(num_variables, 1);
    objective_offset = 0;

    %% 1. 终端松弛罚项
    objective(VariableIndex.t_if) = w_i;
    objective(VariableIndex.t_raf) = w_ra;

    %% 2. 性能指标（总脉冲）
    objective(VariableIndex.t_P) = w_P;

    %% 3. 衔接松弛罚项
    for s = 1:numel(state_names)
        objective(VariableIndex.(['t_poi_slack_' state_names{s}])) = w_poi;
    end

    %% 4. 动力学松弛罚项
    for s = 1:numel(state_names)
        objective(VariableIndex.(['t_dyn_slack_' state_names{s}])) = w_dyn;
    end

    %% 5. 圆约束组：按 unit_norm.mode 装配控制正则项或单位范数罚项的系数
    integration_weights = compute_integration_weights( ...
        CurrentReference.tau, CurrentReference.PointsBounds);
    if UnitNorm.is_ccd
        % 凹凸分解：只罚 ε，u 的系数全为 0，没有附加项
        objective(VariableIndex.unit_norm_slack) = ...
            UnitNorm.penalty_weight * integration_weights(:);
    else
        Regularizer = describe_control_regularizer(config);
        switch Regularizer.type
            case {'norm', 'norm_gap'}
                % 范数正则：'norm' 为 −‖u_i‖，'norm_gap' 为 1 − ‖u_i‖，在参考控制处线性化
                u1_reference = CurrentReference.control.u1(:);
                u2_reference = CurrentReference.control.u2(:);
                reference_norm = hypot(u1_reference, u2_reference);
                % 参考控制接近原点时方向没有定义，改用 (1, 1)/√2
                degenerate = reference_norm < min_reference_norm;
                direction_u1 = u1_reference ./ max(reference_norm, min_reference_norm);
                direction_u2 = u2_reference ./ max(reference_norm, min_reference_norm);
                direction_u1(degenerate) = sqrt(2) / 2;
                direction_u2(degenerate) = sqrt(2) / 2;
                objective(VariableIndex.u1) = -w_reg * integration_weights .* direction_u1;
                objective(VariableIndex.u2) = -w_reg * integration_weights .* direction_u2;
                if strcmp(Regularizer.type, 'norm_gap')
                    objective_offset = w_reg * sum(integration_weights);
                end
            case 'sum'
                % 线性正则 u1 + u2：系数与参考无关
                objective(VariableIndex.u1) = w_reg * integration_weights;
                objective(VariableIndex.u2) = w_reg * integration_weights;
            case 'u1'
                objective(VariableIndex.u1) = w_reg * integration_weights;
            case 'u2'
                objective(VariableIndex.u2) = w_reg * integration_weights;
            case 'none'
                % 不加附加项：u 的系数保持 0，w_reg 被忽略
        end
    end

    if any(~isfinite(objective))
        error('SCP:InvalidObjectiveCoefficient', ...
            '目标向量包含 NaN 或 Inf。');
    end
end
