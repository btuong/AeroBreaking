function SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ...
        ConicConstraints, config, objective_offset)
% SOLVE_CONVEX_SUBPROBLEM 调用 MOSEK 求解本轮 SOCP。
%
% 本函数依次完成：
%   1. 组装 MOSEK 仿射锥模型（装配坐标，无额外缩放）。
%   2. 设置日志、可行性和相对间隙容差。
%   3. 调用 mosekopt，并把它的日志留成文本。
%   4. 解析内点解状态和 MOSEK 给出的数值信息。
%   5. 检查解向量长度。
%
% OPTIMAL 恒可用；NEAR_OPTIMAL 由 config.solver.accept_near_optimal 控
% 制（本项目默认 true）。预期内的不可行/数值失败返回 success=false，
% MOSEK 缺失或接口异常直接抛错。原始矩阵上的残差重算由
% evaluate_solver_feasibility 完成。

    if nargin < 6 || isempty(objective_offset)
        objective_offset = 0;
    end

    %% 1. 组装 MOSEK 仿射锥模型（装配坐标，无额外缩放）
    problem.c = objective;
    if objective_offset ~= 0
        problem.cfix = objective_offset;
    end
    problem.a = LinearConstraints.matrix;
    problem.blc = LinearConstraints.lower;
    problem.buc = LinearConstraints.upper;
    problem.blx = VariableBounds.lower;
    problem.bux = VariableBounds.upper;
    problem.f = ConicConstraints.mapping;
    problem.g = ConicConstraints.offset;
    problem.accs = build_mosek_accs(ConicConstraints.cones);

    if exist('mosekopt', 'file') == 0
        error('SCP:MosekNotFound', ...
            '未找到 MOSEK MATLAB 接口 mosekopt。');
    end

    %% 2. 设置日志、可行性和相对间隙容差
    parameters = build_mosek_parameters(config.solver);

    %% 3. 调用 mosekopt，并把它的日志留成文本
    % MOSEK 的数据警告（如 62/705/710）只写在日志里，用 evalc 截下来解析；
    % echo_log 为真时再原样打印到终端
    try
        solver_log = evalc(['[response_code, response] = ' ...
            'mosekopt(''minimize info'', problem, parameters);']);
    catch exception
        wrapped_exception = MException( ...
            'SCP:MosekCallFailed', ...
            'MOSEK 接口调用失败：%s', exception.message);
        wrapped_exception = addCause(wrapped_exception, exception);
        throw(wrapped_exception);
    end
    if config.solver.echo_log
        fprintf('%s', solver_log);
    end

    %% 4. 解析内点解状态和 MOSEK 给出的数值信息
    SolverResult = interpret_mosek_result( ...
        response_code, response, config.solver.accept_near_optimal);
    SolverResult.parameters = parameters;
    SolverResult.mosek_report = build_mosek_report( ...
        response, solver_log);

    %% 5. 检查解向量长度
    validate_solver_result(SolverResult, numel(objective));
end


function parameters = build_mosek_parameters(solver_config)
% BUILD_MOSEK_PARAMETERS 构建 MOSEK 内点法参数。

    parameters = struct();
    parameters.MSK_IPAR_LOG = solver_config.log_level;
    % 默认关闭时 info 中的解的残差（SOL_ITR_PVIOL* 等，MOSEK 称 violation）不会更新，恒为 0
    parameters.MSK_IPAR_AUTO_UPDATE_SOL_INFO = 'MSK_ON';
    parameters.MSK_DPAR_INTPNT_TOL_DFEAS = solver_config.tol_dfeas;
    parameters.MSK_DPAR_INTPNT_TOL_INFEAS = solver_config.tol_infeas;
    parameters.MSK_DPAR_INTPNT_TOL_PFEAS = solver_config.tol_pfeas;
    parameters.MSK_DPAR_INTPNT_TOL_REL_GAP = solver_config.tol_rel_gap;
    parameters.MSK_DPAR_INTPNT_CO_TOL_REL_GAP = solver_config.co_tol_rel_gap;
    parameters.MSK_DPAR_INTPNT_CO_TOL_PFEAS = solver_config.co_tol_pfeas;
    parameters.MSK_DPAR_INTPNT_CO_TOL_DFEAS = solver_config.co_tol_dfeas;
    parameters.MSK_DPAR_INTPNT_CO_TOL_INFEAS = solver_config.co_tol_infeas;
end


function accs = build_mosek_accs(cones)
% BUILD_MOSEK_ACCS 将统一锥元数据转换为 MOSEK ACC 描述。

    [~, symbol] = mosekopt('symbcon');
    accs = zeros(1, 2 * numel(cones));

    for cone_index = 1:numel(cones)
        if ~strcmp(cones(cone_index).type, 'quadratic')
            error('SCP:UnsupportedMosekConeType', ...
                'MOSEK 接口不支持锥类型 %s。', cones(cone_index).type);
        end
        accs(2 * cone_index - 1) = symbol.symbcon.MSK_DOMAIN_QUADRATIC_CONE;
        accs(2 * cone_index) = cones(cone_index).dimension;
    end
end


function SolverResult = interpret_mosek_result( ...
        response_code, response, accept_near_optimal)
% INTERPRET_MOSEK_RESULT 将 MOSEK 内点解转换为统一求解结果。

    SolverResult = create_empty_solver_result();
    SolverResult.response_code = response_code;

    if ~isfield(response, 'sol') || ~isfield(response.sol, 'itr')
        SolverResult.status = 'no_solution';
        SolverResult.message = 'MOSEK 未返回内点解。';
        return;
    end
    interior_solution = response.sol.itr;
    if ~isfield(interior_solution, 'xx') ...
            || isempty(interior_solution.xx)
        SolverResult.status = 'no_primal';
        SolverResult.message = 'MOSEK 内点解缺少原始变量。';
        return;
    end

    SolverResult.status = char(interior_solution.solsta);
    if isfield(interior_solution, 'prosta')
        SolverResult.problem_status = char(interior_solution.prosta);
    end

    usable_status = strcmp(SolverResult.status, 'OPTIMAL') ...
        || (accept_near_optimal ...
        && strcmp(SolverResult.status, 'NEAR_OPTIMAL'));

    if usable_status
        SolverResult.primal = interior_solution.xx(:);
        SolverResult.dual = read_dual_solution(interior_solution);
        SolverResult.objective = interior_solution.pobjval;
        SolverResult.success = true;
    else
        SolverResult.message = sprintf( ...
            'MOSEK 求解状态不可用：%s。', SolverResult.status);
    end
end


function Dual = read_dual_solution(interior_solution)
% READ_DUAL_SOLUTION 取出内点解的对偶变量，返回结构里缺失的项留空。
%
% y 是线性约束的乘子：min c'x、blc <= A x <= buc 时 y = slc - suc，
% 等式行的 y 就是目标最优值对该行右端的导数；slx、sux（都 >= 0）是变量下界、
% 上界的乘子；snx 是变量锥的乘子，doty 是仿射锥的乘子，本项目的锥都是仿射锥。
% MOSEK 没有直接返回 y 但返回了 slc、suc 时，用 slc - suc 补上。

    Dual = struct('y', [], 'slx', [], 'sux', [], 'snx', [], 'doty', []);
    dual_names = fieldnames(Dual);
    for k = 1:numel(dual_names)
        if isfield(interior_solution, dual_names{k})
            Dual.(dual_names{k}) = interior_solution.(dual_names{k})(:);
        end
    end
    if isempty(Dual.y) && isfield(interior_solution, 'slc') ...
            && isfield(interior_solution, 'suc')
        Dual.y = interior_solution.slc(:) - interior_solution.suc(:);
    end
end


function SolverResult = create_empty_solver_result()
% CREATE_EMPTY_SOLVER_RESULT 创建统一的空 MOSEK 求解结果。

    SolverResult.solver_name = 'mosek';
    SolverResult.success = false;
    SolverResult.status = 'not_solved';
    SolverResult.problem_status = 'unknown';
    SolverResult.primal = [];
    % 内点解的对偶变量（求解成功时填入；字段缺失时为空）：
    % y 线性约束乘子，slx/sux 变量下界/上界乘子，snx、doty 锥乘子
    SolverResult.dual = struct('y', [], 'slx', [], 'sux', [], ...
        'snx', [], 'doty', []);
    SolverResult.objective = NaN;
    SolverResult.response_code = NaN;
    SolverResult.message = '';
    SolverResult.parameters = struct();
    SolverResult.mosek_report = create_empty_mosek_report();
end


function validate_solver_result(SolverResult, num_variables)
% VALIDATE_SOLVER_RESULT 检查求解结果与决策变量数的一致性。

    if SolverResult.success ...
            && numel(SolverResult.primal) ~= num_variables
        error('SCP:InvalidPrimalSize', ...
            'MOSEK 解向量长度必须等于决策变量总数。');
    end
end


function MosekReport = create_empty_mosek_report()
% CREATE_EMPTY_MOSEK_REPORT 创建未求解时的 MOSEK 数值信息（缺失记为 NaN，不记为 0）。

    MosekReport.response_name = '';
    MosekReport.log_captured = false;
    MosekReport.warning_codes = [];
    MosekReport.warning_lines = {};
    MosekReport.num_iterations = NaN;
    MosekReport.primal_violation_con = NaN;
    MosekReport.primal_violation_var = NaN;
    MosekReport.primal_violation_acc = NaN;
    MosekReport.dual_violation_con = NaN;
    MosekReport.dual_norm_inf = NaN;
end


function MosekReport = build_mosek_report(response, solver_log)
% BUILD_MOSEK_REPORT 从 mosekopt 返回值和日志中取出数值相关的信息。
%
% 警告：日志里含 “warning <编号>” 的行，记录编号和原文；MSK_IPAR_LOG=0 时
% 日志为空，警告无从得知（log_captured=false）。
% info：内点迭代数与 MOSEK 自报的原始/对偶残差，字段缺失记为 NaN。
% 对偶量级：MOSEK 返回的全部乘子（y、slc、suc、slx、sux、doty）的最大绝对值。

    MosekReport = create_empty_mosek_report();
    if isfield(response, 'rcodestr')
        MosekReport.response_name = response.rcodestr;
    end

    % 日志中的警告行及其编号
    MosekReport.log_captured = ~isempty(strtrim(solver_log));
    warning_lines = regexp(solver_log, '[^\n]*[Ww]arning[^\n]*', 'match');
    warning_codes = zeros(1, numel(warning_lines));
    for k = 1:numel(warning_lines)
        token = regexp(warning_lines{k}, '[Ww]arning\D{0,3}(\d+)', ...
            'tokens', 'once');
        if isempty(token)
            warning_codes(k) = NaN;
        else
            warning_codes(k) = str2double(token{1});
        end
    end
    MosekReport.warning_codes = unique(warning_codes(~isnan(warning_codes)));
    MosekReport.warning_lines = strtrim(warning_lines);

    % MOSEK 自报的迭代数与残差
    MosekReport.num_iterations = read_info_item( ...
        response, 'MSK_IINF_INTPNT_ITER');
    MosekReport.primal_violation_con = read_info_item( ...
        response, 'MSK_DINF_SOL_ITR_PVIOLCON');
    MosekReport.primal_violation_var = read_info_item( ...
        response, 'MSK_DINF_SOL_ITR_PVIOLVAR');
    MosekReport.primal_violation_acc = read_info_item( ...
        response, 'MSK_DINF_SOL_ITR_PVIOLACC');
    MosekReport.dual_violation_con = read_info_item( ...
        response, 'MSK_DINF_SOL_ITR_DVIOLCON');

    % 对偶乘子的最大绝对值
    MosekReport.dual_norm_inf = compute_dual_norm(response);
end


function value = read_info_item(response, item_name)
% READ_INFO_ITEM 读取 mosekopt 的 info 项，缺失返回 NaN。

    value = NaN;
    if isfield(response, 'info') && isfield(response.info, item_name)
        value = double(response.info.(item_name));
    end
end


function dual_norm = compute_dual_norm(response)
% COMPUTE_DUAL_NORM 计算内点解全部对偶乘子的最大绝对值，没有乘子时返回 NaN。

    dual_norm = NaN;
    if ~isfield(response, 'sol') || ~isfield(response.sol, 'itr')
        return;
    end
    interior_solution = response.sol.itr;
    dual_names = {'y', 'slc', 'suc', 'slx', 'sux', 'doty'};
    dual_values = [];
    for k = 1:numel(dual_names)
        if isfield(interior_solution, dual_names{k})
            dual_values = [dual_values; ...
                interior_solution.(dual_names{k})(:)]; %#ok<AGROW>
        end
    end
    if ~isempty(dual_values)
        dual_norm = max(abs(dual_values));
    end
end
