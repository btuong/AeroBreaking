function print_radius_scan_summary(Summary)
% PRINT_RADIUS_SCAN_SUMMARY 打印多轮扫描的汇总: 每轮一行，三张表。
%
% 输入 Summary 为 build_radius_scan_summary 的输出。
%
% 三张表共用轮号列:
%   半径      轮、运行时的决策、本轮实际半径 r^k、r^k 的分区、松弛为零所需的半径（拐点）、
%             能维持的最大半径、ρ(r^k)、ΔJ(r^k)/max ΔJ、复现自检、参考处的罚项
%   性能指标  轮、G(r^k)、E(r^k)、阶段度量 ΔL:性能指标(r_top)、参考处的性能指标、
%             参考处的总脉冲 (m/s)
%   附加项    轮、G(r^k)、E(r^k)、阶段度量 ΔL:附加项(r_top)、参考处的附加项
% 没有的量显示 '-'。

    fprintf('\n半径扫描汇总 (第 %s 轮参考点):\n', strjoin(arrayfun(@num2str, ...
        Summary.iters, 'UniformOutput', false), ', '));

    %% 半径表
    widths = [4, 6, 7, 4, 7, 7, 8, 9, 4, 10];
    print_table_row({'轮', '决策', 'r^k', '分区', '拐点', '能维持', 'ρ(r^k)', ...
        'ΔJ比', '复现', '参考处罚项'}, widths);
    for m = 1:numel(Summary.iters)
        print_table_row({sprintf('%d', Summary.iters(m)), ...
            describe_status(Summary.status{m}), ...
            format_value(Summary.actual_radius(m), '%.4g'), ...
            format_zone(Summary.actual_zone{m}), ...
            format_value(Summary.zero_radius(m), '%.4g'), ...
            format_value(Summary.hold_radius(m), '%.4g'), ...
            format_value(Summary.actual_ratio(m), '%.4f'), ...
            format_value(Summary.actual_share(m), '%.4f'), ...
            Summary.replay_text{m}, ...
            format_value(Summary.reference_penalty(m), '%.3e')}, widths);
    end
    fprintf('  ΔJ比 = ΔJ(r^k)/max ΔJ(r)；拐点 = 松弛为零所需的半径；\n');
    fprintf('  复现 = r^k 那一行复现运行时这一轮的 ΔL、D\n');

    %% 性能指标表
    fprintf('\n  性能指标:\n');
    widths = [4, 12, 12, 12, 14, 11];
    print_table_row({'轮', 'G(r^k)', 'E(r^k)', '阶段度量', '参考处性能指标', ...
        '总脉冲(m/s)'}, widths);
    for m = 1:numel(Summary.iters)
        print_table_row({sprintf('%d', Summary.iters(m)), ...
            format_value(Summary.actual_gain_cost(m), '%.5e'), ...
            format_value(Summary.actual_effective_drop_cost(m), '%.5e'), ...
            format_value(Summary.stage_cost(m), '%.5e'), ...
            format_value(Summary.reference_cost(m), '%.6e'), ...
            format_value(Summary.reference_impulse(m), '%.3f')}, widths);
    end
    fprintf('  阶段度量 = ΔL:性能指标(r_top)，r_top 为扫到的最大半径\n');

    %% 附加项表
    fprintf('\n  附加项:\n');
    widths = [4, 12, 12, 12, 14];
    print_table_row({'轮', 'G(r^k)', 'E(r^k)', '阶段度量', '参考处附加项'}, widths);
    for m = 1:numel(Summary.iters)
        print_table_row({sprintf('%d', Summary.iters(m)), ...
            format_value(Summary.actual_gain_extra(m), '%.5e'), ...
            format_value(Summary.actual_effective_drop_extra(m), '%.5e'), ...
            format_value(Summary.stage_extra(m), '%.5e'), ...
            format_value(Summary.reference_extra(m), '%.6e')}, widths);
    end
    fprintf('  阶段度量 = ΔL:附加项(r_top)\n');
end


function text = describe_status(status)
% DESCRIBE_STATUS 运行时这一轮结果的中文。

    switch status
        case 'accepted'
            text = '接受';
        case 'rejected'
            text = '拒绝';
        otherwise
            text = 'P3失败';
    end
end


function text = format_zone(zone)
% FORMAT_ZONE 分区的文本；r^k 上 P3 没解出时为空，显示 '-'。

    if isempty(zone)
        text = '-';
    else
        text = zone;
    end
end


function text = format_value(value, format_spec)
% FORMAT_VALUE 数值的文本；NaN 显示为 '-'。

    if isfinite(value)
        text = sprintf(format_spec, value);
    else
        text = '-';
    end
end


function print_table_row(cells, widths)
% PRINT_TABLE_ROW 按终端显示宽度打印一行表格：首列左对齐，其余列右对齐，缩进两格。

    parts = cell(1, numel(cells));
    for c = 1:numel(cells)
        num_spaces = max(widths(c) - measure_display_width(cells{c}), 0);
        if c == 1
            parts{c} = [cells{c}, blanks(num_spaces)];
        else
            parts{c} = [blanks(num_spaces), cells{c}];
        end
    end
    fprintf('  %s\n', strjoin(parts, ' '));
end
