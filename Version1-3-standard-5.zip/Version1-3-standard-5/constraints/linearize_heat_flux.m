function [c, c_r, c_V] = linearize_heat_flux(ConstData, r_k, V_k)
% LINEARIZE_HEAT_FLUX 计算驻点热流 Qdot = kQ*sqrt(rho)*(V*VU)^3.15 的仿射系数。
%
% 数学形式:
%       Q̇(r, V) = k_Q·sqrt(ρ(r))·(V·VU)^3.15,    ρ(r) = ρ_0·exp((R_M − r)/h_s)
%   r 单位 LU，V 单位 VU（V·VU 为 m/s），Q̇ 单位 W/cm²。P3 中取参考点 (r̄, V̄)
%   的一阶展开 Q̇ ≈ c + c_r·(r − r̄) + c_V·(V − V̄)，其中
%       c_r = ∂Q̇/∂r = −Q̇/(2·h_s),    c_V = ∂Q̇/∂V = 3.15·VU·Q̇/(V·VU)
%
% 代码形式:
%   输出 c = Q̇(r_k, V_k)，c_r、c_V 为上述偏导；3.15 以 63/20 写出，
%   c_V 因 V 取归一化量而含因子 VU（链式法则）。

    Rho0 = ConstData.Rho0;
    RM = ConstData.RM;
    hs = ConstData.hs;
    kQ = ConstData.kQ;
    VU = ConstData.VU;

    r = r_k;
    V = V_k;

    c = kQ * (V * VU)^(63 / 20) * (Rho0 * exp((RM - r) / hs))^(1 / 2);
    c_r = -(Rho0 * kQ * exp((RM - r) / hs) * (V * VU)^(63 / 20)) ...
        / (2 * hs * (Rho0 * exp((RM - r) / hs))^(1 / 2));
    c_V = (63 * VU * kQ * (V * VU)^(43 / 20) ...
        * (Rho0 * exp((RM - r) / hs))^(1 / 2)) / 20;
end
