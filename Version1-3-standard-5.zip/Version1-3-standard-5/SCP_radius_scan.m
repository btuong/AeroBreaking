%% SCP_radius_scan.m — 半径扫描（试验脚本，与 SCP.m 并列，不属于 SCP 主流程）
%
% 读 SCP.m 保存的扫描用 MAT（results/scp_run_scan.mat），对指定的几轮各取出参考点，在一组
% 半径 r 上各解一次 P3 并评价: 预测下降 ΔL、预测误差 D、真实下降 ΔJ（各含性能指标、附加项、
% 罚项三部分；性能指标只含总脉冲，附加项是控制正则项）、ρ、松弛罚项、动力学余项按阶的
% 分量、各量随 r 的阶、K 估计。在此基础上评价这一轮运行时实际用的半径 r^k: 它在拐点
% （松弛为零所需的半径）和能维持的最大半径的哪一侧、ΔJ(r^k)/max_r ΔJ(r)、扣掉纯修复后
% 的预测下降 G(r)，以及修复检查（每个候选解当参考再解一次小半径 P3，看留下的罚项下一轮
% 修不修得掉，修得掉时算有效下降 E(r)）；G、E 和阶段度量按性能指标和附加项各算一份。
% 只调用已有的求解和评价函数，不改它们，不跑迭代循环，不碰 RunState；参考点、config、
% ConstData 都来自 MAT，所以不需要重新生成初始参考。
%
% 使用:
%   1. 先运行 SCP.m（config.output.save.scan_mat = true，默认打开），得到扫描用 MAT。
%   2. 改下面「扫描设置」里的 scan.iters（扫哪几轮的参考点，留空扫全部）和
%      scan.radius_scales（留空取 r_max ./ 2.^(0:7)，每轮再自动加上它的 r^k），运行本脚本。
%      每轮要解 2 x 半径个数次 P3（关掉修复检查则减半），轮多时较慢。
%
% 输出: 每轮终端八张表和结论、三扇图窗「半径扫描-第k轮-下降与下降比」「半径扫描-第k轮-
%      分三部分」「半径扫描-第k轮-收益与余项」；扫两轮以上时再有汇总表和一扇「半径扫描-多轮汇总」图窗。按下面的
%      保存开关写 results/radius_scan_iterNN.txt、results/radius_scan_iterNN.mat、
%      results/radius_scan_summary.txt 和 pictures/ 下各图窗的 PNG。

%% ── 环境准备 ──
clc; clear; close all;
tic;
version_root = fileparts(mfilename('fullpath'));
previous_path = path;
restore_scp_path = onCleanup(@() path(previous_path));
modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
    'trust_region', 'validation', 'iteration', 'output', 'radius_scan'};
for k = 1:numel(modules)
    addpath(fullfile(version_root, modules{k}));
end
rehash;

%% ── 扫描设置 ──
scan.mat_file = fullfile('results', 'scp_run_scan.mat');   % SCP.m 保存的扫描用 MAT
scan.iters = [];               % 扫描哪几轮的参考点（轮号，被拒绝的尝试也算一轮），如 [2 4 6]；留空扫全部
scan.radius_scales = [];       % 要扫的半径 r（基准半径的倍数）；留空取 r_max ./ 2.^(0:7)；每轮自动加上 r^k
% 按运行时的容差没解出的半径，换上这组容差再解一次（字段名同 config.solver）；解出的在
% 表里状态后面带 *。小半径下 P3 在锥容差 1e-12 时常数值停滞（UNKNOWN），放宽到 1e-8
% 一般能解出；这样得到的量只准到 1e-8 左右。不想重解就写 struct()
scan.retry_solver = struct('co_tol_pfeas', 1e-8, 'co_tol_dfeas', 1e-8, ...
    'co_tol_rel_gap', 1e-10);
scan.repair_check = true;      % 修复检查: 每个候选解当参考，再解一次小半径 P3（求解次数翻倍）
scan.repair_radius_scale = []; % 修复检查用的半径；留空取 radius_scales 里最小的
scan.plot_each_round = true;   % 每轮画三扇扫描图；扫的轮多时可关掉，只看汇总图

% 保存开关，一个开关管一个文件
scan.save_text = true;         % 每轮的扫描表 results/radius_scan_iterNN.txt
scan.save_mat = true;          % 每轮的扫描结果 results/radius_scan_iterNN.mat
scan.save_summary = true;      % 多轮汇总表 results/radius_scan_summary.txt（扫两轮以上才有）
scan.save_figure = true;       % 扫描图和汇总图的 PNG，存到 pictures/

%% ── 读入扫描用 MAT ──
% ScanInput 里有当时运行的 config、ConstData 和每轮的参考点，扫描直接用它们
[ScanInput, scan] = load_radius_scan_input(version_root, scan);
config = ScanInput.config;

%% ── 逐轮扫描 ──
round_list = cell(1, numel(scan.iters));
for n = 1:numel(scan.iters)
    fprintf('\n正在扫描第 %d 轮参考点（%d/%d）...\n', scan.iters(n), n, ...
        numel(scan.iters));

    % 1 在各半径上解 P3 并评价，做修复检查，算评价量
    ScanRound = solve_radius_scan_round(ScanInput, scan, scan.iters(n));
    round_list{n} = ScanRound;

    % 2 打印八张表和结论
    print_radius_scan(ScanRound, config);

    % 3 画三扇扫描图（关掉逐轮绘图或所有半径都没解出时不画）
    figs = gobjects(1, 0);
    if scan.plot_each_round && any([ScanRound.points.success])
        figs = plot_radius_scan(ScanRound, config);
    end

    % 4 按保存开关存表、MAT 和图
    SaveReport = save_radius_scan(ScanRound, scan, config, version_root, figs);
    print_radius_scan_save_report(SaveReport);
end

%% ── 多轮汇总 ──
% 只扫一轮时汇总就是上面的结论，不再重复
if numel(round_list) >= 2
    Summary = build_radius_scan_summary(round_list);
    print_radius_scan_summary(Summary);
    summary_fig = plot_radius_scan_summary(Summary, config);
    SaveReport = save_radius_scan_summary(Summary, scan, version_root, summary_fig);
    print_radius_scan_save_report(SaveReport);
end
fprintf('\n代码运行时间: %.2f 秒\n', toc);
