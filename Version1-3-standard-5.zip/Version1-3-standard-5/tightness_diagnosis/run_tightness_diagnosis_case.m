function Diagnosis = run_tightness_diagnosis_case(config)
% RUN_TIGHTNESS_DIAGNOSIS_CASE 运行代表工况并逐轮比较有/无速率约束的 P3。
%
% 主链每轮按原配置推进；对照解只把 enable_control_continuity 关闭，
% 固定同一 CurrentReference、TrustRegionState 和其他配置再解一次，不更新任何状态。
% 输出保留逐轮两份 ControlReport 和逐节点差值，不保存完整轨迹或大历史。

    [ConstData, InitialState] = initialize_problem(config);
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, config);
    [RunState, ~] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);
    rounds = cell(config.iter.max_scp_iter, 1);
    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        Comparison = solve_without_rate_at_same_reference( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter, SubproblemDiag.control_report);
        rounds{iter} = Comparison;
        [RunState, ~] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
    end
    Diagnosis.case_name = sprintf('%s_w%.0e', ...
        config.objective.control_reg_type, config.objective.weight_control_reg);
    Diagnosis.reg_type = config.objective.control_reg_type;
    Diagnosis.w_reg = config.objective.weight_control_reg;
    Diagnosis.rounds = vertcat(rounds{~cellfun(@isempty, rounds)});
    Diagnosis.stop_reason = RunState.stop_reason;
end


function Comparison = solve_without_rate_at_same_reference( ...
        CurrentReference, TrustRegionState, ConstData, config, iter, WithReport)
% SOLVE_WITHOUT_RATE_AT_SAME_REFERENCE 固定参考求解无速率约束 P3 并保留差值。

    AlternateConfig = config;
    AlternateConfig.constraints.enable_control_continuity = false;
    [~, AlternateDiag] = solve_scp_subproblem( ...
        CurrentReference, TrustRegionState, ConstData, AlternateConfig, iter);
    Comparison.iter = iter;
    Comparison.with_rate = WithReport;
    Comparison.without_rate = AlternateDiag.control_report;
    Comparison.alternate_success = AlternateDiag.success;
    Comparison.alternate_status = AlternateDiag.solver.status;
    if ~AlternateDiag.success || ~WithReport.evaluated ...
            || ~AlternateDiag.control_report.dual_available
        Comparison.margin_delta = [];
        Comparison.gap_delta = [];
        Comparison.cancellation_cosine_delta = [];
        Comparison.nonrate_margin = vecnorm( ...
            WithReport.s_reg + WithReport.s_dyn + WithReport.s_bound, 2, 2);
        Comparison.nonrate_cosine = cosine_between( ...
            WithReport.s_reg, WithReport.s_dyn + WithReport.s_bound);
        return;
    end
    WithoutReport = AlternateDiag.control_report;
    Comparison.margin_delta = WithoutReport.tightness_margin ...
        - WithReport.tightness_margin;
    Comparison.gap_delta = WithoutReport.tight_gap - WithReport.tight_gap;
    Comparison.cancellation_cosine_delta = WithoutReport.cancellation_cosine ...
        - WithReport.cancellation_cosine;
    Comparison.nonrate_margin = vecnorm( ...
        WithReport.s_reg + WithReport.s_dyn + WithReport.s_bound, 2, 2);
    Comparison.nonrate_cosine = cosine_between( ...
        WithReport.s_reg, WithReport.s_dyn + WithReport.s_bound);
end


function value = cosine_between(a, b)
% COSINE_BETWEEN 计算两组二维向量的逐行夹角余弦，零向量对应 NaN。

    denominator = vecnorm(a, 2, 2) .* vecnorm(b, 2, 2);
    value = nan(size(denominator));
    valid = denominator > 0;
    value(valid) = sum(a(valid, :) .* b(valid, :), 2) ./ denominator(valid);
end
