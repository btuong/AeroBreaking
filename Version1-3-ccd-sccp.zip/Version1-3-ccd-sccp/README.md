# Version1-3-ccd-sccp：气动辅助降轨 SCP（Deng et al. 2024 SCCP 单位范数模式）

自 `Version1-3-standard-3` 复制，在保留默认 `'regularized'`（无损凸化 + 控制正则项）行为不变的基础上，新增文献 [10]（Deng, Liu & Wang 2024）SCCP 方式的单位范数约束处理开关 `config.unit_norm.mode = 'sccp'`。

## SCCP 模式实现要点

- **配置**（`setup/scp_config_default.m`、`subproblem/describe_unit_norm.m`）：
  - `config.unit_norm.mode`：`'regularized'`（默认）或 `'sccp'`；
  - `config.unit_norm.sccp_penalty_weight`：$C_\eta$（默认 `1`），共用松弛 $\eta$ 的罚权；
  - `config.unit_norm.sccp_slack_max`：$\eta$ 上界（默认 `1e4`）。
- **数学定义**：
  - 凸的一半保持二阶锥 `control_disk`（$\|u_i\|_2 \le 1$，$u_1, u_2 \in [-1, 1]$），`'sccp'` 下设 `tightness_role = 'none'`；
  - 反凸的一半 $1 - \|u_i\|_2^2 \le 0$ 在参考控制 $\bar u_i$ 处线性化并引入共用标量松弛 $\eta \in [0, \eta_{\max}]$（位置 `17*N + 26`），每节点分配 $\eta / N$（线性约束块 `unit_norm_inner`，$-2\bar u_{1,i} u_{1,i} - 2\bar u_{2,i} u_{2,i} - \frac{1}{N}\eta \le -(1 + \bar u_{1,i}^2 + \bar u_{2,i}^2)$，不对近零 $\bar u_i$ 做替换）；
  - P3 目标为 $C_\eta \eta$（不加控制正则，`u1/u2` 系数为 0，`objective_offset = 0`），分项名 `unit_norm_penalty`（类别 `inequality_penalty`）；
  - P2 罚函数 $J$ 对应 $\Theta_{\text{unit}} = C_\eta N \max_i [1 - \|u_i\|_2^2]_+$。
- **改动/新建文件**：
  - 新增：`subproblem/describe_unit_norm.m`、`tests/test_unit_norm_sccp.m`、`tests/test_sccp_toy_problem.m`；
  - 修改：`setup/scp_config_default.m`、`subproblem/build_variable_index.m`、`subproblem/build_variable_bounds.m`、`subproblem/build_conic_constraints.m`、`subproblem/build_linear_constraints.m`、`subproblem/build_objective.m`、`subproblem/compute_objective_terms.m`、`subproblem/extract_subproblem_solution.m`、`trust_region/evaluate_penalty_function.m`、`subproblem/compute_control_dual_split.m`、`subproblem/create_empty_control_report.m`、`subproblem/create_empty_control_summary.m`、`subproblem/evaluate_control_report.m`、`subproblem/summarize_control_report.m`、`subproblem/evaluate_p3_multipliers.m`、`output/describe_penalty_term.m`、`output/print_scp_iteration.m`、`output/build_control_export.m`、`output/print_control_report.m`、`output/build_iteration_plot_data.m`、`SCP.m`。
- **验证**：
  - `tests/test_unit_norm_sccp.m`（6 用例）、`tests/test_sccp_toy_problem.m`（2 用例）、`tests/test_control_tightness_mechanisms.m`（7 用例）、`tests/test_control_reg_integration_weights.m`（3 用例）共 18 个用例全部 `Passed`；
  - 默认 `'regularized'`（10 轮 `SCP.m`）输出的 `results/scp_run_brief.txt` 与 `results/scp_run_detail.txt` 与 `../Version1-3-standard-3/results/` 同名文件 SHA256 完全一致，`scp_run_control.txt` 仅第 2 行版本名不同；
  - `'sccp'`（$C_\eta = 1$、$\eta_{\max} = 10^4$，10 轮保存到 `results/sccp_10iter/`）全部 `OPTIMAL` 并接受，末轮总脉冲 `138.8141 m/s`，$\eta = 5.1512\times 10^{-6}$，$\max|1-\|u\|| = 1.3070\times 10^{-8}$（`untight = 0`）。

### 阶段1：对比实验（2026-11-24）

在 `sccp_compare/` 按 `scp_config_default`（`iter.tolerance = 0`、fixed $r=1$、总脉冲平台判据 $\delta = 0.1\text{ m/s}$、$W = 5$、上限 50 轮）运行全部 13 个 `sccp` 工况（8 档 $C_\eta = 10^{-8}\dots 1$、2 个无速率对照、3 个 10 轮初值专项），并与只读复用的 5 个 `Version1-3-standard-5` 基线存档统一分析。运行方法与产物见 `sccp_compare/README.md`，实验数据见 `docs/算法改进_阶段1_SCCP模式对比实验.md`。

---

以下沿用基底 `Version1-3-standard-3` 的说明：

# Version1-3-standard-3：气动辅助降轨 SCP

自 Version1-3-standard-2 复制（2026-11-16；只复制模块、`SCP.m`、README 和知识库，复制时代码与 standard-2 相同）。此后本版本相对 standard-2 的代码改动都记在「阶段3-1」一节：2026-11-22 加控制正则方式 `'norm_gap'`，2026-11-23 加不紧诊断和速率约束开关，2026-11-24 加控制正则积分权开关；其余模块与 standard-2 相同。

本 README 沿用父版本的说明。阶段1、阶段2、阶段4 的阶段报告和结果，以及阶段2 的正则方式对比实验，没有复制过来：阶段1、阶段2 的在 `../Version1-3-standard-2/`（`docs/`、`results/`，对比实验在 `regularizer_compare/`），阶段4 的在 `../old/Version1-3/`（`docs/`、`results/`），正文相应位置已写成相对路径。本目录的 `docs/` 只有知识库和阶段3-1 报告。

默认入口 `SCP.m` 在 `scp_config_default()` 上覆盖三项：10 轮、`control_reg_type = 'norm'`、`weight_control_reg = 1e-4`，信赖域用默认的 fixed、r = 1。默认配置的输出有四处与 standard-2 相反：逐轮图开、全程图关、不导出 PNG、不存 `scp_run_control.mat`；其余保存开关相同（存简略文件、详细文件、扫描用 MAT、控制量 TXT，不存全量 MAT）。

求解对象和方法的数学定义见 `docs/algorithm_knowledge_base/气动辅助降轨算法知识库.md`（2026-11-12 按 P1、P2、罚问题、P3 四层重写）。信赖域方法由 `config.trust_region.method` 选择：`'fixed'`（默认，半径固定，P3 求解成功即接受）或 `'ratio'`（按下降比 ρ = 真实下降/预测下降 接受或拒绝并更新半径）。知识库没有随 2026-11-22、2026-11-23 的改动更新：速率约束开关和控制报告新增的量不在其中，以「阶段3-1」一节、`tightness_diagnosis/README.md` 和代码为准；2026-11-24 已补控制正则积分权开关。

## 阶段3-1：正则方式长迭代对比（2026-11-16）

这一步主代码不改。`regularizer_converge/` 把阶段2 的 21 个工况迭代到上限 50 轮（fixed、r = 1，步长停止用 `config.iter.tolerance = 0` 关掉），另带总脉冲平台停止（最近 5 个被接受轮极差 ≤ 0.1 m/s 且 P2 可行，仅 sum_w1e-2 触发）；主判据看相对 none 的同轮总脉冲差 d 的稳定。方案和运行方法见 `regularizer_converge/README.md`，数据见 `docs/算法改进_阶段3-1_正则方式长迭代对比.md`。

2026-11-22 增加控制正则方式 `'norm_gap'`：Γ = w_reg·Σω_i(1 − ‖u_i‖)，是与圆周的差，非负，各节点都在圆周上时为 0；类别 `extra_nonconvex`，图表里的名字是 `1-‖u‖`。P3 中在参考控制处线性化为 w_reg·Σω_i(1 − ē_i^T·u_i)：线性项与 `'norm'` 相同，另加常数项 w_reg·Σω_i（每圈权和为 1，M = 5，即 5·w_reg），由 `build_objective` 的第二个输出 `objective_offset` 给出，放进 MOSEK 的 `cfix`。所以 `'norm_gap'` 与 `'norm'` 的 P3 只差一个常数项，最优步相同；两者的 J、Γ 相差同一个常数，ΔJ、ΔL、D、ρ 相同。数值上的差别由 `tests/compare_norm_vs_norm_gap.m` 检查（见「测试」）。

同步修改 `describe_control_regularizer`、`build_objective`、`solve_convex_subproblem`（`cfix`）、`compute_objective_terms`（`control_reg` 项和 `total` 加偏置）、`solve_scp_subproblem`（传递偏置）、`evaluate_penalty_function`（J 用原函数 1 − ‖u_i‖）、`evaluate_control_report`（`'norm_gap'` 的逐节点 Γ 加常数 w_reg·ω_i）和 `scp_config_default`（注释）。`objective_offset` 在各函数里都可以省略，省略时为 0；`'norm'` 及其余方式的系数和求值没有改。

2026-11-23 增加第一、二类不紧的诊断：`ControlReport` 逐节点保存紧性余量、控制锥互补积、抵消比例及活跃速率行的弦向分量。`tightness_diagnosis/` 对 8 个代表工况逐轮固定参考比较有、无速率约束的 P3；速率约束开关默认开启，沿用本次诊断前的入口覆盖（10 轮、norm、w_reg = 1e-4），主链数值路径不变。运行方法见 `tightness_diagnosis/README.md`，结果仍记入上述阶段3-1报告。实现上，`control_continuity` 块从 `build_linear_constraints` 拆到 `subproblem/build_control_continuity_block.m`，`config.constraints.enable_control_continuity` 为 false 时不发该块，为 true 时行和系数与拆分前相同；新增 `subproblem/evaluate_control_tightness_mechanisms.m`，由 `evaluate_control_report` 调用，新增字段在 `create_empty_control_report` 里有空值；配置新增 `validation.chord_active_tolerance`（1e-8）和 `chord_flatness_tolerance`（0.05）；聚焦测试 `tests/test_control_tightness_mechanisms.m`（见「测试」）。

2026-11-24 新增 `config.objective.control_reg_use_integration_weights`，默认 true、保持原正则；false 时控制正则各节点不再乘 ω_i，只保留 w_reg。同步作用于 P3、J、norm_gap 常数和逐节点报告，其他目标项及罚项不变。`regularizer_converge/SCP_control_reg_weight_switch.m` 跑 sum/u1/u2/norm、w=1e-4 的开关两态各10轮；结果在 `regularizer_converge/results_weight_switch/`，运行方法见其 README，数值见阶段3-1报告。默认开启的4种正则前10轮与原存档逐项差为0；新增3项手算测试与原7项诊断测试均通过。

## 阶段2：控制正则方式对比（2026-11-16）

新增 `config.objective.control_reg_type`（默认 `'norm'`，`SCP.m` 行为不变，norm_w1e-5 末轮总脉冲 97.1366270954 与改前 97.1366270950 m/s 差 4e-10）：`'sum'`、`'u1'`、`'u2'` 为线性正则 w·Σω_i(u1+u2)、w·Σω_i·u1、w·Σω_i·u2（类别 `extra_convex`，P3 与 J 的项相同，预测误差 0），`'norm'` 为阶段1 的 −w·Σω_i‖u_i‖，`'none'` 不加。类别由新增的 `subproblem/describe_control_regularizer.m` 统一给出；`build_objective`、`evaluate_penalty_function`、`compute_objective_terms`（加 config 参数）、`build_control_export`（加 `reg_type`）、`scp_config_default` 同步修改。对比实验（21 个工况）在 `../Version1-3-standard-2/regularizer_compare/`，运行方法见其 `README.md`，数据见 `../Version1-3-standard-2/docs/算法改进_阶段2_正则方式对比.md`（阶段2 做在父版本目录，没有复制到本目录）。

## 阶段1：按圈积分权、控制正则改为 −w_reg·Σω_i‖u_i‖（2026-11-15）

自 Version1-3-analysis-2 复制（含控制量导出 `control_text`/`control_mat`），改两处：

- **积分权按圈计算**（`compute_integration_weights(tau, PointsBounds)`，与 Version1-3-standard 相同）：各权非负，每圈和为 1，修知识库 D11。调用方 `build_objective`、`evaluate_penalty_function`、`evaluate_control_report` 同步传 `PointsBounds`。
- **控制正则** Γ = −w_reg·Σ ω_i·‖u_i‖：在圆周上为常数，不偏向任何倾侧角。它是凹函数，归为非凸附加项 `extra_nonconvex`。P3 里在参考控制处线性化为 −w_reg·ω_i·ē_i^T·u_i（ē_i = ū_i/‖ū_i‖，‖ū_i‖ < 1e-6 时取 (1,1)/√2），系数由 `build_objective` 按参考点逐轮装配；罚函数 J 用原函数 −‖u_i‖（`evaluate_penalty_function`）。附加项的预测误差不大于 0，只在 u 的方向偏离参考时不为零，不再参与凸项一致性检查。

默认 w_reg = 1e-5，MOSEK 锥容差 `co_tol_pfeas`、`co_tol_dfeas` 为 1e-8，`co_tol_rel_gap` 为 1e-10（由 w_reg 扫描确定，见 `../Version1-3-standard-2/results/阶段1_w_reg扫描.md`；锥容差 1e-12 时除 w_reg = 1e-3 外各档首轮 P3 数值停滞）。阶段结果见 `../Version1-3-standard-2/docs/算法改进_阶段1_按圈权与范数正则.md` 和 `../Version1-3-standard-2/results/阶段1_*`（阶段1 做在父版本目录，没有复制到本目录）。以下各节是父版本的历史说明，其中 Γ = w_reg·Σω_i(u1+u2) 的写法已被本阶段取代。

## 拆分图窗、区分同一子图里的线（2026-11-15，同步自 Version1-3-analysis）

只改绘图，算法和保存的数据不变。绘图文件从同日改过绘图的 Version1-3-analysis 原样拷入（该版与本版的父版本 analysis-2 只差绘图），只把附加项部分的注释改为本版的写法：控制正则线性化后附加项的 D 不大于 0，不再恒为零，有非零值时照常画出。改前代码备份在本机临时目录，没有放进仓库。

**拆窗**（每块不超过三四条线）:

| 原来 | 现在 |
|---|---|
| 全程-预测下降与预测误差（6 块，每块 4 条） | 全程-预测下降与预测误差（ΔL 与 ΔJ；ΔL、门槛、D；ρ）+ 全程-预测下降与预测误差-分三部分（性能指标部分、附加项部分、罚项部分各一块，块里是该部分的 ΔL、D、ΔJ；罚项） |
| 全程-半径与判据（5 块） | 全程-半径与步长（r、最大步长/半径、K 估计）+ 全程-余项与驻点度量 |
| 半径扫描-第k轮-下降与下降比、-性能指标、附加项与罚项（各 4 块） | 半径扫描-第k轮-下降与下降比（3 块）+ -分三部分（4 块）+ -收益与余项（3 块） |

**区分线的办法**（`output/build_analysis_palette.m` 统一定义）:
- 颜色和标记形状都跟着量走，同名同色同标记，跨窗一致；同一块里的实际量标记两两不同（ΔL ○、D △、ΔJ ◇；参考处的罚项 ○、候选解处的罚项 ◇、松弛罚项 △、修复后的松弛罚项 ☆；余项四部分 ○◇△☆）。通道曲线（r、V、γ、φ、ψ）按顺序取 ○◇△☆▷。□ 只表示初始参考，▼ 只表示负值，红 × 只表示 P3 失败。
- 实心点表示接受，空心点表示拒绝（标题下的说明改成“实心点：接受 / 空心点：拒绝”）。
- 实际量实线，门槛、阈值、界虚线（不变）。
- 粗细分层级：同一块里有总量和分项时总量 2.5、分项 1.2（目前是 P3 性能指标块的总脉冲和 P5）；同级的线 1.5。粗线先画、细线压在上面，重合时也看得出两条。
- 图例条目另画（`output/add_legend_entry.m`），图例里同时显示线和标记。
- 全程状态量、控制量叠画: 最后接受解 3.0、其余 1.0；有解的轮超过 `config.plot.overlay_max_rounds`（默认 6）时只画第一轮、最后接受解和中间均匀取的几轮，标题下写画了哪几轮，设为 `Inf` 每轮都画。

**改动的文件**: `output/` 下 `build_analysis_palette`、`build_log_series`（加标记、线宽两个可选参数）、`mark_history_status`（加标记参数）、`draw_log_history_tile`、`draw_history_tiles`、`build_plot_curve` 和 `draw_time_tiles`（加 `'bold'` 画法）、`build_history_item`（加 style 参数）、`build_iteration_plot_data`（总脉冲用 `'bold'`）、`draw_prediction_tiles`、`draw_radius_tiles`、`draw_radius_plane_tiles`、`draw_overlay_tiles`、`describe_status_marks`、`finish_tile_window`（注释）、`plot_scp_result`；新增 `add_legend_entry`、`draw_prediction_part_tiles`、`draw_stationarity_tiles`。`radius_scan/plot_radius_scan`、`plot_radius_scan_summary`；`SCP_radius_scan.m`、`setup/scp_config_default.m`（只新增 `config.plot.overlay_max_rounds` 并改全程图注释，w_reg、锥容差和 `save_figures` 保持本版的值）。逐轮图（迭代-）没有改。

## 控制正则项单列为附加项（2026-11-13 晚）

cc 指出控制正则项不属于性能指标。目标改按三部分报告：性能指标 C（只含总脉冲 w_P·Σ|P_k|）、附加项 Γ（控制正则项 w_reg·Σω_i(u1+u2)，无损凸化引入）、罚项 Θ；J = C + Γ + Θ，L = C̃ + Γ̃ + Θ̃。依据：理论文档 `我的理解SCP_261111_v2_正则_完善.md` 1.6、2.1、2.2.1、2.4，知识库 §3.3、§6.2、D14。改前备份 `../Version1-3-analysis_改前_261113c.zip`。

**只改分组和报告，不改算法**：`build_objective`、P3 约束、J 与 L 的总值、ΔL、D、ρ、接受、半径更新、停止、配置默认值都不变，同一次运行的迭代概况表应与改前相同。松弛罚项 `slack_penalty` 和 `slack_zero` 也不变。

- **分组**：`control_reg` 的类别由 `cost_convex` 改为 `extra_convex`（`compute_objective_terms`、`evaluate_penalty_function`）；`evaluate_reduction_ratio` 按类别分三组 `group.cost`、`group.extra`、`group.penalty`，不属于任何一组的分项报错；`slack_penalty` 改为只取罚项（原来写的是“非性能指标”）；凸项检查同时看 `cost_convex` 和 `extra_convex`。
- **迭代分析块**：ΔL、D、ΔJ 三个等式各写三部分；“P3 抬升了性能指标/附加项”另起一行；罚项一行前加“性能指标”（含候选解的总脉冲 m/s）和“附加项”两行，各给参考处、候选解处、P3 值；展开的分项表分性能指标、附加项、罚项三组。
- **运行摘要**：P3 目标 L 注明“性能指标加附加项加松弛罚项”；罚函数 J 后加一行 J = 性能指标 + 附加项 + 罚项；关键量逐轮演变表加“附加项”列。简略结果文件多 `final_performance_index_C`、`final_extra_Gamma`、`final_penalty_Theta`。
- **全程图**：预测下降与预测误差窗的 ΔL、D、ΔJ 三块各加“附加项部分”（附加项的 D 恒为零，没有可画的点时不画）；「P3 性能指标与目标」窗改名「P3 性能指标、附加项与目标」，第 2 块叫“附加项（控制正则项）”。新颜色 `Palette.extra_part`（粉色）。
- **半径扫描**：扫描记录多 `extra_*`、`extra_p3`、`repair_extra_p3`；`reference_cost` 改取性能指标本身，新增 `reference_extra`、`reference_impulse`（m/s）、`impulse_factor`（VU/w_P）。G、E、阶段度量按性能指标和附加项各算一份（`gain_cost`/`gain_extra`、`effective_drop_cost`/`effective_drop_extra`、`stage_cost`/`stage_extra`，`actual_*` 同样成对），新增检查“拐点右边 G:性能指标 + G:附加项 随 r 不减”（`gain_sum_text`）。终端由六张表变八张（两部分表拆成 ΔL、ΔJ 两张，评价表拆成“分区与修复”和“G 与 E”两张）；汇总表拆成半径（加参考处罚项）、性能指标（加总脉冲）、附加项三张。图：窗 1 的 ΔL、ΔJ 加附加项部分；窗 2 改名「性能指标、附加项与罚项」，4 块（性能指标的收益、附加项的收益、罚项、余项）；汇总窗 4 块。弦的检查改称式 (2.15)。
- **旧扫描结论要重看**：11-13 之前扫描里的 `G`、`E`、阶段度量、“ΔL:性能指标”都含附加项，等于现在对应的性能指标与附加项两个量之和。G:性能指标在拐点右边可以为负（P3 用总脉冲的上升换附加项的下降），这是正常情况。改前保存的扫描结果字段不同，不要和新结果混用；`scp_run_scan.mat` 不受影响，不用重跑 `SCP.m`，直接重扫即可。

## 半径扫描：多轮扫描、评价 r^k、修复检查（2026-11-13 下午）

按理论线程对“怎样评价每轮的半径”的两条分析改 `SCP_radius_scan.m` 和 `radius_scan/`。主流程 `SCP.m` 没动。改前备份 `../Version1-3-analysis_改前_261113b.zip`。

- **一次扫多轮**：`scan.iter` 改成 `scan.iters`（如 `[2 4 6]`，留空扫全部保存的轮）。每轮自动把运行时实际用的半径 r^k 加进扫描半径，表里 r 后面带 `^` 的行就是它。扫两轮以上时最后打印汇总表、画「半径扫描-多轮汇总」窗。
- **评价量**（`radius_scan/compute_radius_scan_metrics.m`）：拐点 = 松弛为零的最小半径；按拐点和能维持的最大半径把每个半径分成偏小 / 合适 / 偏大；G(r) = ΔL:性能指标(r) − ΔL:性能指标(拐点)；ΔJ(r^k)/max_r ΔJ(r)；阶段度量 ΔL:性能指标(r_top)（r_top 是扫到的最大半径，默认 r_max）。
- **修复检查**（`scan.repair_check`，默认开，求解次数翻倍）：每个半径的候选解当参考，按 `scan.repair_radius_scale`（留空取扫描里最小的半径）再解一次 P3。修复后松弛为零就是“留下的罚项下一轮修得掉”，这时有效下降 E(r) = 拐点处 P3 的性能指标部分 − 修复后 P3 的性能指标部分，是 G(r) 的实测对照。
- **终端**：每轮六张表（预测、两部分、新增的评价表[分区、G、候选解处的罚项、修复后的松弛罚项、修得掉、E]、余项、阶、步长），结论里加上 r^k 的分区和 ρ、ΔJ 比、G(r^k)、E(r^k)、阶段度量。汇总表每轮一行：决策、r^k、分区、拐点、能维持的最大半径、ρ(r^k)、ΔJ 比、G、E、阶段度量、参考处的罚项和性能指标。
- **绘图拆窗**：每轮两扇。「下降与下降比」4 块（ΔL 及两部分、ΔJ 及两部分、ΔL·门槛·D、ρ）；「性能指标与罚项」3 块（G 与 E、罚项含修复后的松弛罚项、余项按阶）。每块都画三条竖线：r^k（红色虚线）、拐点（灰色点线）、能维持的最大半径（灰色点划线）。汇总窗 3 块：三种半径随轮号、ΔJ 比、G(r^k)·E(r^k)·阶段度量。扫的轮多时可设 `scan.plot_each_round = false` 只画汇总窗。
- **保存开关一个文件一个**：`scan.save_results` 拆成 `scan.save_text`（每轮表）和 `scan.save_mat`（每轮 MAT，顶层 `ScanResult` = 这一轮的 ScanRound 加上 scan 设置，不再存参考点本身），新增 `scan.save_summary`（`results/radius_scan_summary.txt`），`scan.save_figure` 管全部 PNG。
- **复现自检**：扫描复用主链的求解和评价函数，所以 r^k 那一行应复现运行时这一轮的 ΔL、D。`compute_radius_scan_metrics` 每轮比一次（相对差 |X_扫描 − X_运行|/|ΔL_运行| 都不超过 1e-6 记为复现），结论末尾打“复现自检: 复现 | WARN 对不上”和两个相对差、运行时与扫描的 ρ；汇总表加“复现”一列。对不上说明扫描和运行的设置不同（如求解器容差），先查清再读其他行。
- 文件：新增 `solve_radius_scan_round.m`、`compute_radius_scan_metrics.m`、`build_radius_scan_summary.m`、`print_radius_scan_summary.m`、`plot_radius_scan_summary.m`、`save_radius_scan_summary.m`；改写 `load_radius_scan_input.m`、`print_radius_scan.m`、`plot_radius_scan.m`、`save_radius_scan.m`、`print_radius_scan_save_report.m`；扫描记录多 `is_actual_radius`、`cost_p3` 和 `repair_*`；`build_analysis_palette.m` 加了 G、E、修复后的松弛罚项、三种半径和阶段度量的颜色。

## 扫描输出与 ρ、ΔJ 绘图（2026-11-13）

按理论线程对半径扫描结果的分析（ΔL 几乎全是罚项部分，性能指标部分不到 0.5%，三位有效数字定不准）改输出和图。**不改算法**，只多报告几个量。改前备份 `../Version1-3-analysis_改前_261113.zip`。

- 半径扫描终端表（`radius_scan/print_radius_scan.m`）由三张改为五张：预测表 r、状态、ΔL、D、ΔJ、ρ；两部分表 ΔL 与 ΔJ 各自的性能指标部分和罚项部分、松弛罚项；余项表 K 估计和余项四部分；阶表 ΔL、D、1−ρ 和余项四部分各自的阶（相邻两个解出的半径之间）；步长表多一列最大步长/半径。ΔL、D、ΔJ 及其两部分用 %.5e，余项四部分 %.4e，ρ %.4f。门槛不再单列（有 ρ）。
- 下降比的阶对 1−ρ = D/ΔL 算：ρ 趋于 1，对 ρ 本身取对数比没有意义；它等于 D 的阶减 ΔL 的阶，ΔL 平时接近 2。
- 迭代分析块（`output/print_scp_iteration.m`）：加一行“真实下降 ΔJ = 性能指标的真实下降 + 罚项的真实下降”；ΔL、D、ΔJ 及两部分、罚项、门槛改 %.5e，ρ %.6f；同一参考点的对比加 1−ρ 的阶，另起一行“余项的阶”写四部分各自的阶（阶保留两位小数）。为此 `previous_attempt` 多存余项四部分，`evaluate_reduction_ratio` 把余项拆分挪到同一参考点对比之前，`same_reference` 多 `ratio_gap_order`、`remainder_weighted`、`remainder_orders`。
- 迭代概况表的 ΔL、D 改 %.3e。
- 半径扫描图由四块改为六块：预测下降 ΔL（ΔL、性能指标部分、罚项部分）、真实下降 ΔJ（同样三条）、ΔL·门槛·D、下降比 ρ（原来的 D/ΔL = 1−ρ 改为直接画 ρ，线性纵轴夹在 [−1, 1.5]，超出画在边上，阈值线 ρ0、ρ1、ρ2 与全程图一致）、罚项（参考处、候选解处、松弛罚项）、动力学余项按阶。扫描记录多 `cost_actual`、`penalty_actual`。
- 全程「预测下降与预测误差」窗由五块改为六块，第 3 块新增真实下降 ΔJ（ΔJ、性能指标部分、罚项部分）；`build_iteration_plot_data` 的 trust_region 多 `cost_actual`、`penalty_actual`。
- 颜色（`build_analysis_palette.m`）：新增 ΔJ 青绿色；状态×状态改深蓝、状态×控制改橄榄色，免得在扫描窗里和性能指标部分、参考处的罚项撞色。

## 统一命名（2026-11-12）

按「我的理解SCP_261111_v2_整理_名词统一」把函数名、字段名、变量名和全部注释统一到四层的叫法：P1（连续最优控制问题）、P2（非线性规划）、罚问题（min J）、P3（凸子问题，目标 L）。**不改算法**，计算结果不变；变的是名字、注释、少数显示文字和保存文件里的键名。

本节以下各节是历次改动的记录。其中的函数名和字段名已经换成现在的名字，叙述保留当时的写法（例如把凸子问题叫 P2、把 P2 叫“离散 P1”、“缺陷”“迭代检查”“真实罚函数”）；与本节或知识库不一致的地方，以本节和知识库为准。

### 函数改名（文件同名改）

| 旧名 | 新名 | 做什么 |
| --- | --- | --- |
| `check_p2_solution` | `check_p3_solution` | P3 解检查 |
| `evaluate_p2_terminal_residuals` | `evaluate_terminal_remainder`（移到 `validation/`） | 终端映射的余项（P2 可行性检查的一项） |
| `check_discrete_solution` | `check_p2_feasibility` | P2 可行性检查 |
| `evaluate_discrete_defects` | `evaluate_dynamics_violation` | 动力学违反量 |
| `evaluate_junction_residuals` | `evaluate_junction_violation` | 衔接违反量 |
| `evaluate_p1_objective` | `evaluate_performance_index` | 性能指标（总脉冲） |
| `evaluate_penalty_merit` | `evaluate_penalty_function` | 罚函数 J |
| `evaluate_merit_reduction` | `evaluate_reduction_ratio` | 真实下降、预测下降、预测误差和下降比 |
| `create_empty_merit_evaluation` | `create_empty_ratio_evaluation` | 上一项的空结构 |

文件内的局部函数：`build_discrete_check` 改为 `build_p2_feasibility`，`create_discrete_metric` 改为 `create_violation_metric`，`summarize_discrete_metrics` 改为 `summarize_violation_metrics`，`print_worst_defect_intervals` 改为 `print_worst_dynamics_intervals`，`build_defect_tiles` 改为 `build_violation_tiles`，`compute_row_violations` 改为 `compute_row_residuals`，`compute_bound_violations` 改为 `compute_bound_residuals`。

### 字段和变量改名

| 旧名 | 新名 | 位置 |
| --- | --- | --- |
| `p2_check` | `p3_check` | `SubproblemDiag` |
| `discrete_check` | `p2_feasibility` | `SubproblemDiag` |
| `accepted_discrete_check` | `accepted_p2_feasibility` | `TrustResult` |
| `defect_report` | `dynamics_report` | P2 可行性检查的报告 |
| `objective_report` | `performance_report` | 同上 |
| `p2_check.terminal_residual_report` | `p2_feasibility.terminal_remainder_report` | 从 P3 解检查移到 P2 可行性检查 |
| `reference_merit` | `reference_penalty_function` | `TrustRegionState` |
| `model_value` | `p3_value` | `Evaluation`（P3 的目标 L 在候选解处的值） |
| `term_model` | `term_p3` | `Evaluation` |
| `group.violation` | `group.penalty` | `Evaluation`（罚项那一组） |
| `group.*.model`、`group.*.planned` | `group.*.p3`、`group.*.predicted` | `Evaluation` |
| `cost_planned`、`violation_planned`、`violation_error` | `cost_predicted`、`penalty_predicted`、`penalty_error` | 绘图数据 |
| `candidate_slack` | `slack_penalty` | `Evaluation`，半径扫描的结果 |
| `criticality_chord` | `stationarity_bound` | `Evaluation`（驻点度量的上界） |
| `nonfinite_merit` | `nonfinite_penalty_function` | 未评价原因 |
| `equality_violation`、`inequality_violation` | `equality_penalty`、`inequality_penalty` | 罚函数分项的类别 |
| `defects` | `violations` | `PlotData` |
| `tightness_residual` | `tightness_gap` | 锥紧性报告 |
| `max_lossless_residual`、`max_epigraph_residual` | `max_lossless_gap`、`max_epigraph_gap` | 同上 |
| `normalized_deviation` | `normalized_violation` | 终端违反量的度量 |
| `defect_tolerance` | `dynamics_tolerance` | `config.validation` |
| 度量名前缀 `defect_` | `dynamics_` | 动力学违反量的度量名 |
| 锥名 `apoapsis_deviation`、`inclination_deviation` | `apoapsis_slack_epigraph`、`inclination_slack_epigraph` | 锥块 |

`config.validation.max_apoapsis_deviation`、`max_inclination_deviation` 两个配置项删掉，阈值直接写在 `config.validation.terminal_tolerance`（`apoapsis` 10 km，`inclination` 0.1 deg）。

### P3 解检查和 P2 可行性检查的分工

- **P3 解检查**只看 P3 的解自身对不对，只用 P3 自己的量（返回解、装配矩阵、锥、对偶解）：原始矩阵残差、松弛、锥可行与紧性、乘子。不调用原非线性函数，不做积分。
- **P2 可行性检查**分两部分：一是逐区间的梯形动力学（节点值代入原大气动力学，算动力学违反量）；二是与真空段积分的对照（从节点值出发积分真空段，算衔接违反量、终端违反量和终端映射的余项）。
- 原来放在 P3 解检查里的「终端余项/入轨残差」拆开处理：终端映射的余项要用原映射积分，移到 P2 可行性检查，改为“积分得到的终端量减 P3 的终端量”，按 r、V、γ、φ、ψ、i 六个分量用物理单位报告（V 分量的相反数就是重算的 P5 与 P3 的 P5 之差），只报告，不计入对 P2 可行；入轨等式是 P3 的一行线性等式，它的残差本来就含在数值检查的原始矩阵残差里（`A.insertion` 块），不再单列。
- 终端输出的 P2 可行性检查块相应分成两组，并加上终端违反量一行。

### 没有改的名字

- 半径：`TrustRegionState.scale`、`initial_scale`、`min_scale`、`max_scale`、`scale_factor`（半径是基准半径的倍数，注释里写作 r）；
- ρ 的三个阈值：`accept_ratio`、`shrink_ratio`、`expand_ratio`（注释里写作 ρ0、ρ1、ρ2）；
- 系数和罚权：`config.objective.weight_*`（注释里分别叫系数和罚权）；
- 松弛变量：`point_slack`、`dyn_slack`；
- `actual_reduction`、`predicted_reduction`、`prediction_error`、`ratio`，以及分组的键 `cost`、`penalty`；
- 梯形递推检查里的 `node_deviation`、`step_residual`（递推值与节点值之差、牛顿迭代的残差）；
- 求解器一侧的 `feasibility_residual`、`primal_violation_*`（沿用 MOSEK 的叫法）。

### 运行后会看到的变化

- 详细和简略文本里的键名：`final_p2_*` 现在指 P2 可行性检查重算的量（`final_p2_apoapsis_km`、`final_p2_inclination_deg`、`final_p2_P5_m_per_s`、`final_p2_total_impulse_m_per_s`，原来叫 `final_p1_discrete_*`）；P3 解里的量改叫 `final_p3_*`（`final_p3_inclination_rad`、`final_p3_P_normalized`，原来叫 `final_p2_*`）。
- 全程图窗口「P2 罚函数」改名「罚函数 J」，保存的 PNG 文件名跟着变；逐轮图的窗口键 `defect` 改为 `violation`。
- 终端显示里几处文字：`终端映射的余项`、`递推值与节点值最大差`、`P3 目标 L`。
- **改名前存下的 `scp_run_scan.mat` 和 `scp_run_full.mat` 用的是旧字段名**，新代码读不了。先重跑一次 `SCP.m`，再跑 `SCP_radius_scan.m`。

## 按分析理论改版（2026-11-11）

按 cc 的「我的理解SCP_261111_v2_整理」第 2 部分（预测下降与预测误差、信赖域半径的影响、收敛判据）重做逐轮分析输出、全程图和保存的文件，并新增半径扫描试验脚本。基础是 `Version1-3-output`（未改动）。**不改算法**：P3 的构建、接受规则、半径更新和停止条件都没动，新增量全部只报告。下面「输出与绘图改版（2026-11-09）」一节里关于罚函数逐项、信赖域与半径、分区、κ、下降比窗、信赖域窗、保存文件的描述已被本节取代，其余仍有效。

### 2026-11-12 修正（图例和输出开关）

- 图例：预测下降与预测误差、半径与判据、半径平面三扇全程窗和半径扫描窗，原来每个分块在坐标区内各放一个图例，现在和其余全程图一样，每扇窗只在底部放一个共用图例。为了让一个图例讲清整扇窗，同一个量在各分块里同名同色（`build_analysis_palette.m`）：ΔL 蓝色，D 橙红色，门槛是 ΔL 颜色的虚线，ρ0、ρ1、ρ2 和 r 的上下限是黑色虚线。分块里只有一条曲线时（ρ、半径 r、最大步长/半径、K 估计）曲线画成深灰色，不进图例，纵轴标签就是它的名字。
- 预测下降 ΔL 和预测误差 D 两个分块里的两部分统一叫「性能指标部分」「罚项部分」，图例只列一次。
- 半径与判据窗的第 2 块由六个通道各一条线改为一条「最大步长/半径」，各通道的值在终端「迭代分析」块的展开表里。
- 半径扫描窗的 ρ 分块纵轴限在 [−1, 1.5]（与全程图一致），对数横轴的刻度写成 1/8、1/16 这样的分数。
- 输出开关：保存由一个总开关加一个附加开关，改成一个开关对应一个文件（见「输出开关和保存的文件」）；全量数据单独存 `scp_run_full.mat`，扫描用 MAT 改名 `scp_run_scan.mat`。详细文件开头加上运行结论和概况表。半径扫描脚本的 `scan.save_enabled` 拆成 `scan.save_results` 和 `scan.save_figure`，不再借用主运行的 `config.plot.save_figures`。
- 删除 `output/place_tile_legends.m`；新增 `output/build_analysis_palette.m`、`output/draw_ratio_thresholds.m`、`output/print_save_report.m`、`radius_scan/print_radius_scan_save_report.m`。

### 新旧显示名对照

字段名一律不改，只改显示文字和注释。

| 旧显示名 | 新显示名 |
| --- | --- |
| 动力学缺陷 | 动力学违反量 |
| 衔接残差 | 衔接违反量 |
| 终端偏差（约束违反时） | 终端违反量 |
| 动力学缺陷罚项、衔接残差罚项（J 一侧） | 动力学罚项、衔接罚项 |
| 动力学松弛罚项、端点松弛罚项（L 一侧） | 动力学松弛罚项、衔接松弛罚项 |
| 候选处松弛 | 松弛罚项 |
| 约束违反量（分组小计） | 罚项 |
| 计划 ΔL、实际 ΔJ | 预测下降 ΔL、真实下降 ΔJ |
| 最大偏差/容差、可行比 | 最大违反量/容差 |
| 候选 | 候选解 |
| 半径倍数 δ | 半径 r（代码里仍是倍数 `scale`，r_max = `max_scale`） |
| 驻点上界、弦上界 | 驻点度量的上界 |
| 缺陷与松弛窗 | 违反量与松弛窗 |
| 收益曲线、Ψ、κ、上升段/饱和段、半径分区、修完/未修完、切线界、dΨ/dδ、r_hold、r_rep | 删除 |

「缺陷」一词已从所有 `.m` 的输出、图和注释里去掉（`docs/` 里的知识库和本 README 的旧名对照除外）。

### 改动的文件

数据层（`trust_region/`）
- 新增 `create_empty_same_reference.m`、`create_empty_remainder_split.m`、`evaluate_remainder_split.m`、`initialize_trust_region_state.m`（从 `initialize_scp_run` 拆出）。
- 重写 `create_empty_ratio_evaluation.m`；改 `evaluate_reduction_ratio.m`（`fill_radius_and_stationarity`、`compare_with_previous_attempt`、`compute_radius_order`，第 8 步拆余项）、`evaluate_penalty_function.m`（标签）、`update_trust_region.m`（被拒绝时记 `previous_attempt`）、`scale_trust_region_radius.m`（注释）。
- `iteration/advance_scp_iteration.m`：驻点判定只看驻点度量的上界 ≤ ε；`initialize_scp_run.m`、`create_empty_stop_decision.m`。

输出层（`output/`）
- 逐轮日志：`print_scp_iteration.m` 改为十块，罚函数逐项与信赖域与半径两块并成「迭代分析」块（`print_iteration_analysis`）；`describe_penalty_term.m`、`print_scp_summary.m` 随之改叫法。
- 全程图：`plot_scp_result.m` 改为 8 组窗，删除下降比窗和信赖域窗，新增三扇窗：预测下降与预测误差（`draw_prediction_tiles.m`）、半径与判据（`draw_radius_tiles.m`）、半径平面（`draw_radius_plane_tiles.m`）。新辅助函数 `build_log_series.m`、`draw_log_history_tile.m`、`build_analysis_palette.m`（同一个量在各窗里同色）、`draw_ratio_thresholds.m`（ρ0、ρ1、ρ2 三条线）。三扇窗和其余全程图一样，每扇窗只在底部放一个共用图例（`finish_tile_window` → `place_shared_legend`），不加文字标注；实际量实线，门槛、阈值、界虚线。
- 保存：`save_scp_result.m`（现在要传 `ConstData`，按 `config.output.save` 的四个开关各写一个文件）、`print_save_report.m`（运行结束打印存了哪些文件）、`print_iteration_overview.m`（由 `print_scp_summary` 的局部函数独立出来，加 `file_id` 输入）、`build_scan_input.m`。删除 `draw_reduction_tiles.m`、`draw_trust_region_tiles.m`、`export_scp_iteration_blocks.m`。
- `build_iteration_plot_data.m`、`plot_scp_iteration.m`、`collect_trust_series.m`、`build_plot_curve.m`：逐轮图按新叫法。

配置与入口：`setup/scp_config_default.m`、`SCP.m`（保存调用与运行报告）。各目录的几个文件只改了注释里的「缺陷」。

### 增删的字段和配置

`Evaluation`（`TrustResult.evaluation`）
- 删除：`zone`、`trust_slope`、`saturation_raw`、`saturation`、`criticality_tangent`。
- 改名：`residual_repaired` → `slack_zero`。
- 新增：`prediction_error`（D）、`threshold`（门槛 (1−ρ1)ΔL）、`error_to_threshold`（D/门槛）、`step_norm`（‖d‖，基准半径为单位）、`curvature_estimate`（K 估计 D/‖d‖²）、`same_reference`、`remainder_split`。
- `same_reference`：`available`、`iter`、`radius_scale`、`predicted_reduction`、`prediction_error`、`error_order`（D 随半径变化的阶）、`reduction_order`（ΔL 的阶）。被拒绝后参考点不变、半径变小，相邻两次求解就是 ΔL(r)、D(r) 曲线上的两个点；接受之后的下一轮、以及第一轮，`available` 为假。依赖 `TrustRegionState.previous_attempt`（拒绝时写入，接受时清空）。
- `remainder_split`：动力学余项按随半径变化的阶拆成四部分——状态×状态（二次）、状态×控制（一次）、状态×时长（一次）、控制×时长（零次）。字段 `weighted`（1×4，罚权乘区间绝对值之和）、`weighted_channel`（4×5，按通道 r, V, γ, φ, ψ）、`total`、`closure`（区间余项与四部分之和的最大差，自检）。只拆动力学，衔接和终端的余项不拆。

配置
- `config.trust_region.repaired_slack_ratio` → `slack_zero_ratio`，值不变。
- `config.output.detail.penalty_terms`、`.trust_region` 删除，新增 `.analysis`（默认 false）。
- `config.output.save_enabled`、`config.output.directory`、`config.output.filename_prefix` 删除，改成 `config.output.save` 一组，一个开关对应一个文件（见下节）。
- 其余配置不变（`stationarity_tolerance` 的注释改为驻点度量的上界的阈值 ε）。

### 输出开关和保存的文件

`setup/scp_config_default.m` 里和输出有关的开关分三段，各管各的：

| 段 | 开关 | 管什么 |
| --- | --- | --- |
| 绘图 | `config.plot.enable_initial`、`enable_iteration`、`enable_final` | 迭代前、迭代中、结束后各画不画图 |
| | `config.plot.enable_numerics_iteration`、`enable_trust_region_iteration`、`enable_multiplier_iteration` | 逐轮图的三扇可选窗 |
| | `config.plot.save_figures` | 图是否导出 PNG 到 `pictures/` |
| 终端输出 | `config.output.print_pre_iteration`、`print_iteration`、`print_summary` | 迭代前、迭代中、结束后各打不打印 |
| | `config.output.detail.<块>`、`detail.all` | 逐轮日志的某一块是否展开全部明细。只管终端，不影响保存的文件 |
| 保存文件 | `config.output.save.brief_text` | `scp_run_brief.txt`，默认存 |
| | `config.output.save.detail_text` | `scp_run_detail.txt`，默认存 |
| | `config.output.save.scan_mat` | `scp_run_scan.mat`，默认存 |
| | `config.output.save.full_mat` | `scp_run_full.mat`，默认不存 |
| | `config.output.save.control_text` | `scp_run_control.txt`，默认存 |
| | `config.output.save.control_mat` | `scp_run_control.mat`，默认不存（本版本；standard-2 默认存） |
| | `config.output.save.directory`、`filename_prefix` | 保存目录（默认 `results`）和文件名前缀（默认 `scp_run`） |

保存的六个开关互不影响，一个开关对应一个文件，每次运行覆盖；运行结束时终端列出实际存了哪些文件。原来的 `scp_run.txt` 和 `scp_iteration_blocks.txt` 不再写。

| 文件 | 内容 |
| --- | --- |
| `scp_run_brief.txt` | 简略：运行结论（键: 值，键名不变）加各轮概况表（轮、决策、r、ρ、ΔL、D、J、驻点度量的上界、违反比） |
| `scp_run_detail.txt` | 详细：开头是和简略文件相同的运行结论和概况表，后面逐轮把求解、迭代分析、乘子、P2 可行性、收敛、结果六块全部展开。内容固定，不随终端的 `detail` 开关变化 |
| `scp_run_scan.mat` | 顶层 `ScanInput`（`config`、`ConstData`、`attempts`：每轮的 `iter`、`reference`、`radius_scale`、`subproblem_success`、`accept_candidate`、`predicted_reduction`、`prediction_error`、`ratio`、`slack_penalty`），给半径扫描用 |
| `scp_run_full.mat` | 顶层 `Result` 和 `FinalizedRun`，全部运行数据，几十 MB |
| `scp_run_control.txt` | 控制量 u 的结果导出（只加输出，算法不变）：头部（w_reg、积分权的计算方式、Σω）、逐次尝试的全程汇总（Γ、紧性、σ 分布、正则项偏向 ratio、驻点残差）、最后被接受轮的逐圈汇总和逐节点表。数据来自每次 P3 求解后算一次的 `SubproblemDiag.control_report`（`subproblem/evaluate_control_report.m`），正则项系数取自装配好的目标向量 c 的 u 列 |
| `scp_run_control.mat` | 顶层 `ControlExport`（`version_root`、`w_reg`、`weight_method`、`final_iter`、`attempts`：每次尝试的 `iter`、`accepted`、`radius_scale`、`t_f`、`t_f_s`、`control_report`），小文件，不含完整历史 |

### 半径扫描（试验脚本，未写进 skill）

`SCP_radius_scan.m` 与 `SCP.m` 并列，是平铺脚本，只依赖 `results/scp_run_scan.mat` 里的 `ScanInput`，不需要 `SCP.m` 留在工作区的变量。

用法：先运行 `SCP.m`（`config.output.save.scan_mat` 保持打开），再改 `SCP_radius_scan.m` 开头「扫描设置」里的 `scan.iter`（选哪一轮的参考点，含被拒绝的尝试）和 `scan.radius_scales`（留空取 r_max ./ 2.^(0:7)），运行。扫描脚本自己有两个保存开关：`scan.save_results`（扫描表和扫描结果 MAT）和 `scan.save_figure`（扫描图 PNG）。同一参考点对应多轮时选哪一轮结果相同，脚本会打印一行说明。

每个半径：用该轮的参考点和 MAT 里的 `config`，把信赖域状态的半径设成 r，调 `solve_scp_subproblem` 和 `evaluate_reduction_ratio`；参考处的 J 与 P2 可行性检查只在首个成功的半径上现算，之后沿用。半径从大到小扫。按运行时的容差没解出的半径（小半径下 P3 在锥容差 1e-12 时常数值停滞，状态 UNKNOWN），换上 `scan.retry_solver` 的容差再解一次（默认 `co_tol_pfeas`、`co_tol_dfeas` 1e-8，`co_tol_rel_gap` 1e-10，即配置里 2026-10-25 诊断给的放宽值；写 `struct()` 则不重解），解出的在表里状态后面带 `*`，这些半径上的量只准到 1e-8 左右。两次都没解出的记状态、继续下一个，表下面列出完整的求解状态和 MOSEK 终止码。

输出：终端三张表，r 列共用（一张表在 78 列里放不下）和四行结论（能维持的最大半径、松弛为零所需的半径、两者的先后、检查式 (2.14)）。三张表是：预测表（r、状态、ΔL、D、门槛、ρ、松弛罚项、步长/半径）；余项与曲率表（r、K 估计、D 的阶、动力学余项的状态×状态、状态×控制、状态×时长、控制×时长四部分；D 的阶是本行与上一个解出的更大半径之间 ln(D 之比)/ln(r 之比)）；步长表（r、V、gamma、phi、psi、P 六个通道各自的步长/半径，各圈时长的最大相对变化）。一扇图窗「半径扫描-第 k 轮参考点」四个分块，都是双对数坐标（ΔL、门槛、D；D/ΔL = 1−ρ 和画在 1−ρ0、1−ρ1、1−ρ2 处的三条阈值线；罚项；动力学余项按阶），图例在窗口底部共用。保存 `results/radius_scan_iterNN.txt` 与 `.mat`（顶层 `ScanResult`，每条记录多了 `step_ratio_channels`、`time_change`、`response_name`、`relaxed_tolerance`）、`pictures/半径扫描-第k轮参考点.png`。代码在 `radius_scan/`。

2026-11-12 按第 1 轮参考点的扫描结果改了三处：（1）图去掉线性坐标的一块和夹在 [-1, 1.5] 的 ρ 一块（D 比 ΔL 大两个数量级时这两块看不出东西），换成 D/ΔL 一块，纵轴标签缩短，不再压到标题；（2）表里加 D 的阶、余项四部分分列、各通道步长/半径和时长变化，用来判断 D 为什么不按半径的二次下降；（3）没解出的半径按放宽的容差重解。

### 需要 cc 运行后确认的三处

- `remainder_split.closure` 是否在 1e-9 量级。
- 三扇新窗和半径扫描窗底部的共用图例，字号 16 下占的高度是否合适（预测下降与预测误差窗 11 项，半径与判据窗 9 项，半径扫描窗 13 项）。
- 详细文件的大小是否合适（每轮六块全部展开）。

## 输出与绘图改版（2026-11-09）

按 cc 2026-11-09 的 SCP 理解重做逐轮终端输出、逐轮图和全程图。**不改算法**：P3 的构建、接受规则、半径更新和停止条件都没动，新增量全部只报告。叫法：P3 是凸子问题（旧代码和字段名仍叫 P2，如 `p3_check`），P2 是离散后的非凸问题（旧叫 P1 离散，字段名仍叫 `p2_feasibility`），J 是罚函数（旧记 𝓙），L 是 P3 的目标（旧记 𝓛）；**字段名一律不改，只改显示文字和注释**。

### 改动的文件

数据层
- `subproblem/compute_objective_terms.m`、`trust_region/evaluate_penalty_function.m`：各分项加 `kind`（`equality_penalty`、`inequality_penalty`、`cost_nonconvex`、`cost_convex`）。
- `subproblem/solve_convex_subproblem.m`：把 MOSEK 的对偶解存进 `SolverResult.dual`（`y`、`slx`、`sux`、`snx`、`doty`）。
- `subproblem/build_variable_bounds.m`：新增输出 `trust_lower`、`trust_upper`、`trust_base`、`trust_channel`、`trust_node`，记录信赖域界本身（最终界可能被物理界或钉扎界盖住）。
- `subproblem/evaluate_p3_multipliers.m`（新）、`subproblem/create_empty_multiplier_report.m`（新）、`subproblem/check_p3_solution.m`：P3 乘子报告，存在 `SubproblemDiag.p3_check.multiplier_report`。
- `trust_region/evaluate_reduction_ratio.m`（重写）、`trust_region/create_empty_ratio_evaluation.m`（重写）、`trust_region/update_trust_region.m`：逐项账、分区、κ、驻点度量。
- `iteration/create_empty_subproblem_diag.m`、`iteration/initialize_scp_run.m`、`iteration/create_empty_stop_decision.m`、`iteration/advance_scp_iteration.m`：空模式补字段；信赖域状态缓存参考处的 P2 可行性检查；停止判定处另报告收敛三项。

输出层
- `output/print_scp_iteration.m`（重写）：11 块逐轮日志。
- `output/describe_penalty_term.m`（新）：罚函数分项短名，终端表格和绘图共用。
- `output/export_scp_iteration_blocks.m`、`output/print_scp_summary.m`、`output/save_scp_result.m`：截取标记、概况表、最终值。
- `output/build_iteration_plot_data.m`（重写）、`output/plot_scp_iteration.m`、`output/plot_scp_result.m`（重写）、`output/draw_time_tiles.m`、`output/draw_history_tiles.m`、`output/draw_trust_region_tiles.m`（重写）、`output/build_plot_curve.m`：逐轮图和全程图。
- 新增 `output/draw_reduction_tiles.m`、`output/compute_log_display.m`、`output/collect_trust_series.m`、`output/finish_history_axes.m`、`output/mark_history_status.m`、`output/mark_failed_rounds.m`；删除 `output/draw_merit_tiles.m`。
- 新增（图例遮挡修正，见下）`output/place_shared_legend.m`、`output/finish_tile_window.m`、`output/describe_status_marks.m`、`output/measure_display_width.m`；`output/draw_overlay_tiles.m`、`output/mark_failed_rounds.m`、`output/finish_history_axes.m` 随之改动。
- `validation/propagate_trapezoid_solution.m`：只在牛顿步里加了有限性判断（见下，原有递推逻辑和结果不变）。
- `setup/scp_config_default.m`、`SCP.m` 以及若干文件的注释：配置项和叫法。

### 新增字段

- `SolverResult.dual`：`y`（线性约束乘子，`slc − suc`）、`slx`、`sux`、`snx`、`doty`。有一轮的稠密对偶向量要多占一份内存，一般只有变量个数量级的几个向量。
- `Evaluation`（`TrustResult.evaluation`）：
  - 逐项账：`reference_check`、`term_kinds`、`term_reference`、`term_candidate`、`term_p3`、`term_prediction_error`（D_m）、`term_error_share`（D_m/ΔL）、`group.cost/violation`（每组 `reference/candidate/p3/predicted/actual/error`）、`slack_penalty`、`convex_error_flag`、`convex_error_names`、`subterms`。
  - 步长：`step_ratio_channels`（6 个通道）、`step_ratio_node`（N×5）、`step_ratio_pulse`（6×1）。
  - 分区与驻点度量：`radius_scale`、`radius_scale_max`、`ratio_band`、`residual_repaired`、`ratio_held`、`zone`、`trust_slope`、`saturation_raw`、`saturation`（κ）、`stationarity_bound`、`criticality_tangent`、`stationarity_tolerance`。
- `multiplier_report`：`classes`、`dynamics_ratio`、`junction_ratio`、`trust_*`（生效个数、斜率分量、占比、生效节点）、`active_dual_tolerance`。
- `StopDecision`：`stationary`、`feasible`、`step_converged`、`stop_basis`（本项目只有 `{'step'}`）。
- `TrustRegionState.reference_check`：参考处的 P2 可行性检查，下一轮不再重算。

所有新字段在空模式（`create_empty_*`）里都有，P3 求解失败的轮、被拒绝的轮同样齐全。

### 新增配置

- `config.iter.stationarity_tolerance = 1e-4`（驻点度量的 ε，L 口径，只报告）。
- `config.trust_region.repaired_slack_ratio = 1e-6`（候选处松弛不超过参考处违反量的这个倍数就算“修完”）、`config.trust_region.active_dual_tolerance = 1e-9`（信赖域界乘子大于它才算“生效”）。
- `config.plot.enable_trust_region_iteration = false`、`config.plot.enable_multiplier_iteration = false`（可选逐轮窗）。
- `config.output.detail`：`p2_checks` 改名 `p3_checks`，`discrete_checks` 改名 `p2_feasibility`，新增 `penalty_terms`、`multipliers`，保留 `numerics`、`physics`、`trust_region`、`convergence`、`all`。默认 `penalty_terms`、`multipliers`、`trust_region`、`p2_feasibility`、`physics` 为 false。

### 终端日志（11 块）

1 P3 求解状态；2 数值检查；3 P3 解检查；4 罚函数逐项（参考 J、候选 J、计划 ΔL、实际 ΔJ、D/ΔL，按性能指标 C / 约束违反量分组，末行 ρ、1−ρ、候选处松弛）；5 P3 乘子（各罚项类 |λ|/w，信赖域 dΨ/dδ）；6 信赖域与半径（决策、ρ 所在经典表行、步长/半径与分区、κ、驻点度量）；7 P2 可行性检查；8 约束对照（P2 节点值｜梯形递推）；9 物理量；10 收敛（驻点、可行、步长，停止依据加 `*`）；11 本轮结果。每行不超过 78 个显示列。

### 逐轮图

状态量、控制量、缺陷与松弛（替换原松弛变量；对数纵轴，零值画在数据下限并有点线说明）、路径约束量；可选：步长与信赖域、乘子、数值健康。

### 全程图（7 扇窗，横轴为迭代序号）

各轮状态量、各轮控制量、P3 性能指标与目标、P3 关键约束与松弛、P2 罚函数（候选处，含第 0 次初始参考）、下降比、信赖域。原性能指标、P2 目标函数、最大松弛、P1 离散可行性、真实罚函数与模型目标五扇窗已并入或删除。`PlotReport` 的图组名同步改为 `state_history`、`control_history`、`p3_objective`、`p3_constraints`、`penalty`、`reduction`、`trust_region`。

### 第一轮反馈的修正（2026-11-09）

**1. 梯形递推的“矩阵为奇异值…RCOND = NaN”警告。** 这条警告不是改版带进来的：`propagate_trapezoid_solution.m` 里的 `solve_trapezoid_step` 原来只在“牛顿迭代的下一步”才检查试探点是否有限；试探点本身有限、但动力学右端或雅可比算出 NaN/Inf 时，照样去解线性方程，MATLAB 就报 RCOND = NaN，随后这一步按未收敛处理。原版同一个解会触发同一条警告。现在改为：残差含 NaN/Inf、或牛顿矩阵含 NaN/Inf 时，直接按未收敛返回，不再解线性方程。改动只有这一处（`solve_trapezoid_step` 里 10 行左右）。用真实动力学和 4000 组随机初值在 Octave 里对比旧逻辑：成功/失败判定逐一相同，成功的解和迭代次数逐位相同，其中旧逻辑会把非有限矩阵送进线性求解的约 450 组，现在一组也不再送入。失败时返回的残差记为 NaN，失败迭代次数可能比旧逻辑少 1（旧逻辑会多迭代一步才发现 NaN），两者只用于失败区间的显示。**没有处理的情形**：矩阵有限但接近奇异（RCOND 是很小的有限数）时，MATLAB 仍可能报“接近奇异”警告；这种步骤可能仍收敛，若在这里强行判失败会改变少量案例的成功/失败结果，所以没动。

**2. 图例遮挡曲线。** 原因是字号 16 下每个分块各放一个图例，图例比分块还大。现在每扇窗只放一个共用图例（`place_shared_legend`，放在 tiledlayout 底部 `Layout.Tile = 'south'`，列数按图窗宽度估算），规则：
- 只有一条曲线的分块，这条曲线不进图例（纵轴标签就是它的名字）；各分块里同名的条目只列一次。
- 接受/拒绝/初始参考/P3 失败的标记含义、点线（0 值画在下限）、画在范围外的参考线（容差、ε）、负值三角、ρ 未算的轮次，不再进图例，改写在窗口标题下面，按图窗宽度并成一两行（`finish_tile_window`、`describe_status_marks`）。
- 信赖域窗里 δ 的上下限、半径边界、ε 的名字直接写在线上，κ 的 0.5 虚线两侧写“上升段/饱和段”，都不占图例。
- 缺陷与松弛窗的曲线名缩成“参考处 z^k”“P3 松弛 ν”“候选处 z^k+d^k”（衔接点分块也用同样的线型加标记，所以六个分块共用同一份图例）；P3 关键约束窗里两个松弛分块的曲线名去掉“动力学松弛”“端点松弛”前缀，只写通道 r、V、γ、φ、ψ。
- 各轮状态量、控制量叠画窗不再放图例，标题下面写“粗线：最后接受解；虚线：被拒绝的轮”。
- 数值健康图、初始参考图原来就是单个图例，没动。

标记含义由图例移到标题下面后，标题最多多出两行。图窗大小仍用 MATLAB 默认（不设固定尺寸，与绘图规范一致）；如果觉得六个分块在默认大小里仍然拥挤，可以再决定要不要按分块数放大图窗，这一条没有擅自改。

### 需要 cc 知道的几处取舍

- 最大松弛窗里数据“全挤在 1e-6”的原因：对数轴的下限被写成“容差的千分之一”（容差 1e-3 时就是 1e-6），真实值 1e-11 被钳到这条线上。现在下限只看数据（`compute_log_display`），容差线落在范围外时不画，标题下面写出数值。
- “P3 关键约束”窗里终端远地点和倾角仍取 P2 可行性检查的重算值（和原“关键约束”窗一致），不是 P3 解里的终端变量。
- 下降比窗里负的 ΔL、ΔJ 用向下三角按绝对值画，没用空心圆（空心圆已经表示“拒绝”）。
- 衔接点那一块把五个通道的 |ε| 相加（归一化单位），三个量沿用各通道分块的颜色和线型并加标记。
- `save_scp_result` 另加了 `final_penalty_J` 等最终值（文本键名在 2026-11-12 统一命名时已改，见上面「运行后会看到的变化」）。

---

## 阶段4：三层结果检查

- `subproblem/check_p3_solution` 报告原始矩阵残差、松弛、锥可行与紧性，以及 P2 终端映射/入轨速度残差；本版本原本没有乘子报告，也没有新增分离罚权 σ。
- `validation/check_p2_feasibility` 在优化节点报告物理单位的梯形动力学缺陷、初始与圈间衔接残差、重算终端/末次脉冲、节点路径、P1 总脉冲。`trust_region/evaluate_penalty_function` 从同一离散报告读取终端、脉冲、缺陷与衔接，参考无缓存时调用相同检查函数；保留权重、ratio/fixed 规则。
- `TrustResult` 的 `accepted_solution`、`accepted_convergence_report`、`accepted_p2_feasibility`、`decision_point` 在普通候选接受时直接复制候选信息；拒绝或求解失败保留空报告。停止仍为“已接受且相邻解差达标”（或既有失败/半径/迭代上限条件），**离散可行性只报告，不进入接受或停止**。
- 被接受解在 postprocess 用隐式梯形格式从初始入口连续递推；后处理输出 `trapezoid_solution`、`trapezoid_check`，收尾和公开结果使用 `final_trapezoid_solution`，不再使用迭代后的 `propagation/post_validation`。失败时尚未递推的节点/区间标 NaN，并记录最后完成节点、失败区间与试探残差；未重算的终端/P5 不借用 P2 变量。初始参考生成的 `initial_propagation` 字段仍保留，语义不同于旧候选回放。
- 逐轮九区块日志、P1 约束对照（离散解｜梯形积分解）、全程 P1 离散可行性图组；原独立逐轮文本导出继续可用。文本结果把 P2 终端变量/P 向量与 P1 离散重算终端/P5/总脉冲分列命名，摘要 `ra_5` 明确是梯形值；P2 终端映射的非线性代回残差是线性化误差诊断，不计入 P2 成功判定。阈值为缺陷/衔接 r 0.1829 km、V 0.1829 m/s、角度 0.0572958 deg，终端 10 km/0.1 deg，节点路径峰值/上限 ≤1+1e-3。
- 详见 `../old/Version1-3/docs/算法改进_阶段4_三层结果检查.md` 与 `docs/algorithm_knowledge_base/气动辅助降轨算法知识库.md` 的三层结果检查一节（现为 §6.5）；旧章节以下为阶段1–3 的历史说明，字段布局与阶段4不同时以本节为准。短程运行保存在 `../old/Version1-3/results/阶段4_三层检查短程/`，仅导出小 TXT，不保存大 MAT。

## Version1-3 的改动

- 新增 `trust_region/evaluate_penalty_function`：真实罚函数 𝓙。把 P2 目标中被线性化的
  量换成真值（梯形动力学缺陷、真空映射衔接残差、末圈出口映射得到的终端 r_a、i 与 P5），
  权重与 P2 相同；路径约束不进 𝓙。
- 新增 `trust_region/evaluate_reduction_ratio`：ΔJ = 𝓙(参考) − 𝓙(候选)，
  ΔL = 𝓙(参考) − 𝓛(候选)（𝓛 为 P2 目标值），ρ = ΔJ/ΔL，各项分别给出；
  另算候选步长占半径的比例（是否贴边界）。𝓙(参考) 存在信赖域状态里，下一轮沿用。
- `update_trust_region`：`config.trust_region.method = 'ratio'` 时 ρ < η0 拒绝，
  ρ < η1 缩小、ρ ≥ η2 扩大；ΔL 过小时，相邻解差已达标就接受（按收敛），否则拒绝并缩小。
  `'fixed'` 保留 Version1-2 的固定半径、无条件接受，ρ 照样计算打印。
- 信赖域状态改为 倍数 δ × 基准半径（`scale_trust_region_radius`），只缩放 δ。
  信赖域加在 r/V/γ/φ/ψ 与全部脉冲 P0~P5 上（控制 u 仿射进入动力学，不加）；
  P5 虽只进入线性入轨等式，但无界时目标沿其增大方向单调获益、求解器数值
  停滞（首轮即失败），故与 P0~P4 一并加。
- 停止：P2 失败即停止；接受且相邻解差达标为 `scp_converged`，停止说明（`stop_detail`）
  写明是 ρ 接受还是 ΔL 过小，以及候选是否贴信赖域边界；拒绝且 δ 已在下限为
  `trust_region_stalled`。被拒绝的尝试也计入最大迭代数（`SCP.m` 中改为 40）。
- 输出：逐轮日志新增“信赖域”区块（决策、δ 变化、ρ、ΔJ（实际下降）、ΔL（预测
  下降）、步长/半径；`detail.trust_region` 展开按 𝓙 分项的实际/预测下降表，末行
  合计）。目标块中罚函数 𝓙（P1 真值）与 P2 目标（模型 𝓛）总分项上下对照打印，
  𝓙 的松弛项按真值含义命名（衔接残差罚项、动力学缺陷罚项）。物理量块单列各段
  t_f（优化变量）：`t_f (s): 各段值 | 总 | 较参考 ±Δ`，展开的逐段表加参考 t_f 列；
  迭代检查单列 t_f 显示通道并附物理差（t_f 是决策变量但不在收敛判据内，判据不变）。
  运行摘要新增停止说明，迭代概况新增 ρ、δ 列，关键量逐轮演变新增总 t_f(s) 列。
- “全程-各轮状态量”新增第六个 `t_f (s)` 分块：每圈一个标记，纵轴为该轮
  `solution.t_f` 换算的物理秒数，横轴为对应大气飞行段的时间中点。数据放在
  `PlotData.state_history`，逐轮状态量图仍使用 `PlotData.states`，保持五个分块。
- 最终图新增第七组“全程-信赖域更新”（`draw_trust_region_tiles`，数据由
  `build_iteration_plot_data` 的 `trust_region` 字段拼序列）：三块横轴为迭代序号——
  下降比 ρ（η₀/η₁/η₂ 三条阈值线，接受实心点/拒绝空心点，ΔL 过小或 P2 失败的轮
  留空并标注原因，不补零）、半径倍数 δ（对数纵轴的 δ_before→δ_after 台阶，画
  上下限，请求缩小/扩大但已钳位在限上的轮加空心方块，失败轮保留“半径保持”）、
  最大步长/半径（1 边界线与 0.99 贴边界判定线，贴边界轮标加号）。
  `PlotReport` 相应新增 `trust_region` 图组记录，单组失败不影响其他图组。
- 最终图新增第八组“全程-真实罚函数与模型目标”（`draw_merit_tiles`，`PlotReport.penalty_function`）：
  J 为本轮线性化参考处的真实罚函数值，图例标为“真实罚函数 J（参考）”；第 k 轮取
  同轮 `evaluation.reference.total`，拒绝轮参考不变故 J 平台。L 为各轮候选的 P2 目标
  `objective_terms.total`。J/L 都从第 1 轮开始，首轮 J 已代表初始参考，不重复画第 0 轮。
  失败轮 J/L 均留空。绘图只读已存评价，不重新计算罚函数。
- `compute_integration_weights` 从 `build_objective` 拆出，P2 正则项与 𝓙 共用。

---

以下为 Version1-2 的说明。

# Version1-2 — 气动辅助降轨 SCP（按 2026-10-23 新规范重构）

按 `matlab-scp-standards` 规范对 Version0 的框架重构。算法语义与
Version0 完全一致（固定半径信赖域、无条件接受、混合量纲收敛判据、
加权目标、MOSEK 线性+二阶锥），仅重组代码框架。

## 运行方式

在 MATLAB 中运行本目录下的 `SCP.m`（半径扫描另运行 `SCP_radius_scan.m`，见上文）。入口自行添加本版本模块路径
（`setup/ dynamics/ constraints/ subproblem/ trust_region/ validation/
iteration/ output/ tests/`）；路径保持已添加状态，直到工作区清空或入口重跑
（`onCleanup` 恢复）。

默认入口的覆盖见本文件开头；`regularizer_converge/` 和 `tightness_diagnosis/` 两个实验入口的运行方法见各自的 `README.md`。`results/` 里现存的 `scp_run_*` 是 2026-11-21 用入口的默认覆盖（10 轮、norm、w_reg = 1e-4）跑的：10 轮 P3 全部求解并接受，末轮总脉冲 97.0826 m/s，远地点 6677.826 km，倾角 86.0111°，P2 可行（违反比 0.806），到 10 轮上限未收敛。这次运行早于 11-22、11-23 两次改动。其中的 `scp_run_control.mat`（21:00）比其余四个文件（21:26）早，是更早一次运行留下的，当前默认配置不再写它。

## 目录结构

| 目录 | 职责 |
| --- | --- |
| `setup/` | 配置、固定问题数据（`initialize_problem`）、初始参考打靶（`generate_initial_reference`） |
| `dynamics/` | 大气段和真空段的原动力学、解析线性化、动力学约束的装配 |
| `constraints/` | 路径约束量（热流/过载/动压）的公式与 Jacobian |
| `subproblem/` | 单个 P3 的构建、求解（MOSEK）、提取候选解、P3 解检查和步长检查 |
| `validation/` | 真空段映射（求值和线性化）、坐标变换、事件、P2 可行性检查、被接受解的梯形递推检查 |
| `trust_region/` | `update_trust_region`：唯一的接受与半径决策点；罚函数 J、下降比和迭代分析各量的计算 |
| `iteration/` | RunState 生命周期、更新下一轮状态与停止判定（`advance_scp_iteration`）、只读后处理（`postprocess_scp_iteration`）、收尾、空 schema 构造器 |
| `output/` | 初始摘要、逐轮日志、公开 Result、摘要打印、绘图、保存 |
| `radius_scan/` | 半径扫描试验脚本 `SCP_radius_scan.m` 用的函数 |
| `regularizer_converge/` | 阶段3-1 的长迭代对比：入口 `SCP_regularizer_converge.m` 等 5 个文件；`results/` 存 21 个工况的结果和汇总，`pictures/` 存 10 张汇总图 |
| `tightness_diagnosis/` | 第一、二类不紧的机理诊断：入口 `SCP_tightness_diagnosis.m` 等 4 个文件；正式结果在 `results_v2/`（8 个代表工况），`results/`、`pilot/` 是接口试验，不作结果 |
| `tests/` | 三个独立脚本，见「测试」 |
| `results/` | 默认入口的运行产物（`scp_run_brief.txt`、`scp_run_detail.txt`、`scp_run_scan.mat`、`scp_run_control.txt`，可选 `scp_run_full.mat`、`scp_run_control.mat`；固定覆盖） |
| `pictures/` | `save_figures = true` 时导出的 PNG，现存 9 张全程图 |
| `docs/` | 算法知识库（`algorithm_knowledge_base/`）和阶段3-1 报告 |

## 单轮结构

```matlab
[CurrentSolution, SubproblemDiag] = solve_scp_subproblem(...);     % 求解并检查：步长检查、P3 解检查、P2 可行性检查
TrustResult = update_trust_region(...);                            % 决定：接受/拒绝 + 下一信赖域
[RunState, IterationRecord] = advance_scp_iteration(...);          % 更新：唯一修改 RunState
DiagnosticsHistory(iter) = postprocess_scp_iteration(...);         % 只读：梯形递推检查、打印、绘图
```

相对 Version1-base 的改动：
- 接受判定从 `advance_scp_iteration` 移出，改由 `update_trust_region` 的平凡策略给出；
  `IterationRecord` 去掉 `optimization_validation / propagation / post_validation /
  final_decision`，新增 `trust`；传播与后验放入 `IterationDiagnostics`，
  `finalize_scp_run(RunState, DiagnosticsHistory)` 按轮次配对。
- 停止只依据迭代检查（接受且单步收敛）；优化结果检查只报告。
- 优化结果检查补齐：`evaluate_objective_penalty_terms`（终端远地点/倾角罚项偏差，
  阈值 `validation.max_apoapsis_deviation`、`max_inclination_deviation`）；
  锥元数据 `check_tightness` 改为 `tightness_role`（`none/epigraph/lossless`），
  `control_disk` 为 `lossless`，检查 `|1-‖u‖|`（`validation.lossless_tightness_tolerance`）。
  `evaluate_slack_feasibility` 不再重复检查圆盘范数。
- 逐轮打印、绘图并入 `postprocess_scp_iteration`；`SCP.m` 不再直接调用。
- 新增配置：`validation.enable_iteration_propagation`（逐轮积分结果检查开关）。

## 按编排函数规范（2026-10-23）的改动

- 编排函数只展开一层，函数头步骤列表与块标题逐条同字：`advance_scp_iteration`
  （停止判断不再依赖先拼好的记录）、`update_trust_region`、
  `postprocess_scp_iteration`、`solve_scp_subproblem`（末步汇总诊断）。
- 积分结果检查拆成下一级编排函数 `validation/check_integrated_solution`：只用
  一条完整积分轨迹（初始状态出发，不在节点重新对齐）。各圈远地点半径改取自这条
  轨迹（原先是每圈从优化出口状态重新积分的半积分，已删除）；路径约束峰值也改在积分
  轨迹上算，并增加末圈远地点/倾角偏差与入轨速度残差。
- 优化结果检查（`check_optimization_result`）新增：`evaluate_path_constraints`
  （节点上用原非线性函数求动压/热流/过载，对比上限）、`evaluate_dynamics_defects`
  （节点上用原非线性动力学算梯形缺陷，与 P2 同一格式，按通道取区间最大值）、
  `evaluate_junction_violation`（真空段衔接与入轨速度残差，取分量最大值）。
  容差沿用 `max_dyn_slack`、`max_point_slack`；新增配置只有
  `validation.path_constraint_tolerance`（默认值为临时设定，待调）。
- 改名：`commit_accepted_candidate` → `use_candidate_as_next_reference`，
  `finalize_iteration_record` → `check_iteration_record`，
  `check_advance_input_contract` → `check_advance_inputs`。

## 按绘图规范补充的绘图（2026-10-23）

- 通用绘图代码原样取自规范包 `templates/plotting/`，放在 `output/`；项目适配层只有
  `build_iteration_plot_data`（取值、单位换算、拼时间，不调用模型函数）。
- 逐轮图 `plot_scp_iteration(IterationRecord, ConstData, config)`：4 扇窗，横轴为时间
  （5 次大气飞行段首尾相接，真空飞行不占时间轴）：状态量、控制量（u1、u2、‖u‖、sigma、
  脉冲 P）、松弛（各状态通道的动力学松弛与端点松弛）、路径约束（动压/热流/过载与上限）。
  `config.plot.iteration_figure_mode` 取 `'reuse'`（默认）或 `'accumulate'`。
  由 `postprocess_scp_iteration` 调用，外包 try/catch，失败只告警。
- 最终图 `plot_scp_result`：5 扇窗，横轴为迭代序号（总脉冲、终端远地点/倾角与目标线、
  最大松弛、各轮状态叠加、各轮控制叠加）。返回 `PlotReport`（含 `failed_groups`）。
- 报告新增字段：`PathConstraintReport.node_values`（N×3，列为 q、Q̇、n）；
  `PenaltyReport.metrics(k).actual_value / target_value`。
- 新增配置：`plot.iteration_figure_mode`、`plot.visibility`；`plot.enable_iteration`
  默认改为 `true`。
- 图窗导出（2026-11-09 起覆盖全部图）：`config.plot.save_figures = true` 时把全部图导出为 PNG（300 dpi）。初始参考图（3 扇，需 `enable_initial=true`）与全程图（9 扇，需 `enable_final=true`）按窗口名存 `pictures/<窗口名>.png`；逐轮图（需 `enable_iteration=true`）每轮最多 5 扇（状态量/控制量/松弛变量/路径约束量/数值健康）存 `pictures/iterations/iterNN/`，reuse 模式下也逐轮各存一份。单扇导出失败只告警，不阻塞其他图和求解。
- 图样式（cc 2026-10-23）：分块不加标题；纵轴标签用中文，无量纲量不写单位；
  `fit_axis_limits` 把参考线（上限/目标/容差）包进纵轴范围并留边，数据几乎不变时撑开范围以免刻度小数过多；
  最终图窗名以“全程-”开头，与逐轮图“迭代-”对应；初始参考两张图同样处理，窗名为“初始-”。
- 逐轮第 5 扇窗“数值健康”（`draw_numerics_scatter`，开关 `plot.enable_numerics_iteration`）：
  A 每行一个点，横轴行内跨度、纵轴原始矩阵相对残差，均为对数，按约束块着色；
  竖线 `solver.numerics.max_row_span`，横线 `solver.numerics.residual_reference`（1e-9）；
  标题含 MOSEK 响应和警告编号。数据存在 `coefficient_report.linear_rows`（span、block、
  block_names）和 `solver_feasibility_report.linear_rows`（relative、block、block_names）。
- 全程图加一扇“全程-P2 目标函数”：P2 总值 J 与除脉冲外各项（终端倾角罚、终端远地点罚、
  端点松弛罚、动力学松弛罚、控制正则）随迭代变化。各项由 `compute_objective_terms`
  在求解后按 c 的分项算好，存入 `SubproblemDiag.objective_terms`。
- 删除 `plot_iteration_diagnostics`；旧最终图（逐轮 ra/P 对比、全部迭代总图、最后接受解图）
  由新五组图取代。

## Version1-2 相对 Version1-1 的改动（框架层）

- 优化结果检查拆成下一级编排函数 `subproblem/check_optimization_result`：
  `solve_scp_subproblem` 只调用它一次，由它逐类调用 7 个 `evaluate_*`
  （原始矩阵残差、松弛、节点路径约束、锥与紧性、罚项偏差、节点动力学
  缺陷、段间衔接残差）并汇总；`SubproblemDiag` 各报告字段名不变，
  打印和绘图不受影响。
- `TrustResult` 换成通用字段：`reason` + `evaluation` 取代
  `merit_reduction` + `gate` 及其构造函数；`candidate_available`、
  `accept_candidate`、`next_state` 等其余字段不变，读取这些字段的地方
  （advance、finalize、postprocess、打印与绘图）不需要改。
- 顺带恢复 `docs/algorithm_knowledge_base/` 与 `pictures/` 内中文文件名
  的正常编码（此前是字面 `#UXXXX` 转义名）。

## 与 Version0 的行为差异（框架层）

- MOSEK 求解失败从 `error()` 崩溃改为：失败留痕（IterationRecord）+
  停止原因 `subproblem_failure` + 正常收尾输出。
- 逐轮日志/摘要按分层汇报规范重组；绘图字号统一 16。
- 死代码删除：`event_out_atm_rv`、`event_in_atm_x`、
  `getinitial_plot_tau`、`flag_plot_iter` 及未使用配置项
  （`min_gamma_end`、`bounds.min/max_phi`、`trust_region.inn_*`、
  `trust_region.t_f`）；默认关闭的逐轮检查图（原 `plot_check`、
  `plot_control`）已由新逐轮图取代；优化解与积分解的出口对比图不再提供。
- 默认启用结果保存到 `results/`（Version0 未保存）。

## 测试

本版本 `tests/` 有三个脚本。后两个是普通函数，自行补路径，关闭绘图、打印和文件保存，运行不改 `results/`，结果只打印到终端。

| 脚本 | 做什么 |
| --- | --- |
| `test_control_tightness_mechanisms.m` | 聚焦测试（2026-11-23），用合成的 P3 核验互补积和径向分量的符号、u1 弦向平坦与 u2 非平坦、控制报告接入、速率约束开关的默认值和关闭、对偶缺失回退、不可行速率行、不完整证据汇总，共七个用例。用 `runtests('tests/test_control_tightness_mechanisms.m')` 运行；它不自己补路径，要先让本版本各模块和 `tightness_diagnosis/` 在路径上（`SCP.m` 开头添加的那组模块，再加 `addpath('tightness_diagnosis')`）。2026-11-23 核对时七个用例全部通过 |
| `compare_norm_vs_norm_gap.m` | 对比 `'norm'` 与 `'norm_gap'`（2026-11-22）：w_reg = 1e-6、1e-5、1e-4、1e-3、1e-2、1e-1、1、10、100 九档，各跑 10 轮（fixed、r = 1）。每个工况打印求解成功的轮数、MOSEK 平均迭代数、末轮 P3 目标值、末轮总脉冲、全程和末轮的最大紧性差 gap = 1 − ‖u‖、末轮 gap 的中位数、P3 目标值与分项和之差；每档再打印两种写法的末轮总脉冲差、σ 最大差和末轮最大 gap 之比 |
| `diagnose_linear_reg_tightness.m` | 线性正则的取紧机制诊断：sum、u1、u2 在 w_reg = 1e-3、1e-4 下各跑 10 轮，打印全程和末轮的 gap 统计、主需求与正则项夹角大于 90° 的节点数及分区统计、全程 gap 最大的前 5 个节点（含 ‖s_rate‖）。与 `Version1-3-standard-4` 的同名脚本工况和口径相同，用来对照有、无速率约束的差别 |

以下为父版本的历史说明，这些测试文件不在本目录。

`CheckDynamics(CurrentSolution, CurrentReference, ConstData, config)`
在某轮解上核验动力学线性化的梯形增量与真值增量之差
（需要在工作区持有运行对象）。

`test_merit_reference_plot`（`tests/`，`runtests` 运行）：核验 J/L 全程图
从第 1 轮开始、J 图例标注“参考”、各轮参考 J 与候选 L 的取值，以及失败轮留空。


阶段4 新增 `test_discrete_solution`（离散检查与旧 𝓙 基线一致）、`test_trapezoid_solution`（从初始入口按隐式梯形连续递推）、`test_accepted_discrete_check`（接受/拒绝/失败报告与收敛停止）、`test_stage1_2_outputs`（九区块与离散可行性图组）；既有 `test_iteration_block_export` 在测试内将旧存档适配当前接口，不改历史存档。

## 结果文件结构（供诊断读取）

`config.output.save.full_mat = true` 时写 `results/<prefix>_full.mat`（`-v7.3`，HDF5）；标量摘要在 `<prefix>_brief.txt`（`config.output.save.brief_text`）。
`<prefix>_full.mat` 顶层只有两个变量，读法见 optimization-result-diagnosis skill 的 reading-result-mat。

| 路径 | 内容 |
|---|---|
| `FinalizedRun.history(k)` | 第 k 次尝试的 IterationRecord（k 与 `.iter` 一致，已裁剪到 num_attempted） |
| `  .iter` / `.trust.accept_candidate` / `.stop` | 迭代号、是否接受、停止决策 |
| `  .solution` | CurrentSolution（候选解）；P3 求解失败的轮为空。`.state`(N×5)、`.control.u1/u2`(N×1)、`.control.P`(6×1)、`.tau`、`.t_f`(5×1)、`.xff`、`.i`、`.dyn_slack`、`.point_slack`、`.objective` |
| `  .subproblem` | SubproblemDiag：`.solver`（含 `.primal` 完整决策向量、`.mosek_report`）、`.p3_check`（P3 解检查：原始矩阵残差、松弛、锥紧性、乘子）、`.p2_feasibility`（P2 可行性检查：动力学违反量、衔接违反量、终端违反量、终端映射的余项、节点路径约束、性能指标、是否对 P2 可行）、`.coefficient_report`、`.convergence_report`、`.objective_terms` |
| `  .trust` | 接受决策、半径、`evaluation`（罚函数、下降比和迭代分析各量）及 `accepted_solution`、`accepted_convergence_report`、`accepted_p2_feasibility`、`decision_point`；拒绝/失败为显式空报告 |
| `  .reference_before` / `.reference_after` | 本轮线性化所用参考 / 本轮后参考；`.PointsBounds` 给各圈节点范围（绘图拼时间轴用） |
| `FinalizedRun.diagnostics(k)` | 同轮的梯形递推轨迹及梯形递推检查的报告：`.trapezoid_solution`、`.trapezoid_check` |
| `FinalizedRun.final_iteration` / `.last_iteration` | 最后接受轮 / 最后一次尝试的记录（与 history 中对应元素相同） |
| `FinalizedRun.final_solution` / `.final_trapezoid_solution` | 最后接受解及其同轮梯形递推轨迹（递推失败时仍带失败状态） |
| `FinalizedRun.initial_reference` / `.initial_propagation` | 初始参考及其打靶轨迹，不是被接受解的梯形递推 |
| `Result.history(k)` | FinalizedRun.history(k) 与 diagnostics(k) 的投影（solution、subproblem、trust、trapezoid_solution、trapezoid_check、stop），**不含 reference_before** |

solution、subproblem 在 `FinalizedRun` 与 `Result` 中各存一份，诊断时读 `FinalizedRun` 即可。VariableIndex（primal 中各变量的位置）没有保存，需要从 primal 重取变量时按 `subproblem/build_variable_index.m` 在 MATLAB 端重建。

## 算法定义

数学定义以 `docs/algorithm_knowledge_base/气动辅助降轨算法知识库.md` 为准。同目录下的 PDF 是旧版知识库导出的，没有随 2026-11-12 的重写更新。
