function TrapezoidCheck = build_failed_trapezoid_check(RecursionReport)
% BUILD_FAILED_TRAPEZOID_CHECK 构造隐式递推未正常结束的报告。

    TrapezoidCheck = create_empty_trapezoid_check();
    TrapezoidCheck.evaluated = true;
    TrapezoidCheck.failure_reason = RecursionReport.failure_reason;
    TrapezoidCheck.recursion_report = RecursionReport;
end
