function LinearConstraints = build_linear_constraints( ...
        VariableIndex, CurrentReference, ConstData, config)
% BUILD_LINEAR_CONSTRAINTS 构建 M 圈大气跳跃 P3 的仿射约束。
%
% 约束类型（按行序）:
%   dynamics          - 梯形离散动力学等式（dynamics 模块发出）
%   point_initial     - 初始端点衔接等式：第 1 圈入口状态 = 初始点
%                       施加 P0 后的真空映射线性化 + 松弛
%   point_terminal    - 终端衔接等式：末圈远地点终态 [xff; xff_i] =
%                       末圈出口状态的真空映射线性化（无松弛）
%   point_inner       - 内点衔接等式：下一圈入口状态 = 本圈出口状态
%                       经远地点脉冲 P_{cir+1} 的真空映射线性化 + 松弛
%   insertion         - 入轨等式：P5 + xff(2) = 目标圆轨道远地点速度
%   control_continuity - 相邻节点 u1 差值有界（±consecutive_u）
%   impulse_epigraph  - |P_k| <= t_P_k 的线性半平面（锥约束的线性部分）
%   path_loads        - 热流/过载/动压在参考处线性化的单边上界（按各自上限归一化）
%
% 松弛处理：初始与内点衔接带 poi_slack；动力学带 dyn_slack；终端衔接与
% 入轨等式不带松弛。此处不检查锥可行性与上图紧性（由锥检查负责）。
%
% 本函数依次完成：
%   1. 动力学约束块。
%   2. 端点/内点/入轨/控制/路径约束块。
%   3. 聚合（保持上述行序）。

    %% 1. 动力学约束块
    DynamicsContract = build_dynamics_contract(config);
    DynamicsBlock = build_dynamics_constraints( ...
        DynamicsContract, VariableIndex, CurrentReference, ConstData, config);

    %% 2. 端点/内点/入轨/控制/路径约束块
    InitialPointBlock = build_initial_point_block( ...
        VariableIndex, CurrentReference, ConstData);
    TerminalPointBlock = build_terminal_point_block( ...
        VariableIndex, CurrentReference, ConstData);
    InnerPointBlocks = build_inner_point_blocks( ...
        VariableIndex, CurrentReference, ConstData);
    InsertionBlock = build_insertion_block(VariableIndex, ConstData);
    ControlBlock = build_control_continuity_block( ...
        VariableIndex, CurrentReference, config);
    ImpulseBlock = build_impulse_epigraph_block(VariableIndex);
    PathBlock = build_path_load_block( ...
        VariableIndex, CurrentReference, ConstData);

    %% 3. 聚合（保持上述行序）
    Blocks = [DynamicsBlock; InitialPointBlock; TerminalPointBlock; ...
        InnerPointBlocks(:); InsertionBlock; ControlBlock; ImpulseBlock; ...
        PathBlock];

    num_variables = max(collect_index_values(VariableIndex));
    LinearConstraints = assemble_linear_constraint_blocks( ...
        Blocks, num_variables);
end


function ConstraintBlock = build_initial_point_block( ...
        VariableIndex, CurrentReference, ConstData)
% BUILD_INITIAL_POINT_BLOCK 初始端点衔接等式（5 行）。
%
% 数学形式:
%   第 1 圈大气入口状态由初始点经初始脉冲 P0 和真空飞行映射得到：
%       x_in^(1) = Φ_0(P_0)
%   x = [r, V, γ, φ, ψ]^T 为 ECF 球坐标状态（r: LU，V: VU，角度: rad）。
%   P_0 为初始点沿速度方向的脉冲（VU）；初始 ECI 状态 rv00 固定。
%   Φ_0: R → R^5 为“施加脉冲 → 积分到首次进入大气层”的真空映射。
%   P3 在参考脉冲 P̄_0 一阶线性化，并加不限符号的松弛 ν^(1) ∈ R^5：
%       x_in^(1) + ν^(1) = Φ_0(P̄_0) + Φ_0,P·(P_0 − P̄_0)
%   Φ_0,P = dΦ_0/dP_0 ∈ R^5，由中心差分求得。松弛罚项 w_poi·|ν| 在 P3 的目标中。
%
% 代码形式（第 i 行，i = 1..5 依次对应 r, V, γ, φ, ψ）:
%   变量移到左侧、常数移到右侧，lower = upper = beq：
%       x_in(i) + ν(i) − Φ_0,P(i)·P_0 = Φ_0(i) − Φ_0,P(i)·P̄_0
%   变量列与系数:
%       x_in(i)  VariableIndex.{r,V,gamma,phi,psi}(PointsBounds(1).begin)  +1
%       ν(i)     VariableIndex.poi_slack_{r,V,gamma,phi,psi}(1)            +1
%       P_0      VariableIndex.P(1)                                        −C_P(i)
%   符号对应: Φ_0 → C，Φ_0,P → C_P，P̄_0 → P_k(1)，右端 → beq(i)。

    PointsBounds = CurrentReference.PointsBounds;
    P_k = CurrentReference.control.P;
    x00 = ConstData.rv00;

    ConstraintBlock.name = 'point_initial';
    ConstraintBlock.row_index = [];
    ConstraintBlock.column_index = [];
    ConstraintBlock.value = [];
    beq = zeros(5, 1);

    x_begin_index = [VariableIndex.r(PointsBounds(1).begin), ...
        VariableIndex.V(PointsBounds(1).begin), ...
        VariableIndex.gamma(PointsBounds(1).begin), ...
        VariableIndex.phi(PointsBounds(1).begin), ...
        VariableIndex.psi(PointsBounds(1).begin)];
    slack_index = [VariableIndex.poi_slack_r(1), ...
        VariableIndex.poi_slack_V(1), VariableIndex.poi_slack_gamma(1), ...
        VariableIndex.poi_slack_phi(1), VariableIndex.poi_slack_psi(1)];

    C_P = linearize_coast_to_entry_first(x00, P_k(1), ConstData);
    C = evaluate_coast_to_entry_first(x00, P_k(1), ConstData);

    for i = 1:5
        ConstraintBlock.row_index = [ ...
            ConstraintBlock.row_index; i; i; i];
        ConstraintBlock.column_index = [ ...
            ConstraintBlock.column_index; ...
            x_begin_index(i); slack_index(i); VariableIndex.P(1)];
        ConstraintBlock.value = [ConstraintBlock.value; 1; 1; -C_P(i)];
        beq(i) = C(i) - C_P(i) * P_k(1);
    end

    ConstraintBlock.lower = beq;
    ConstraintBlock.upper = beq;
end


function ConstraintBlock = build_terminal_point_block( ...
        VariableIndex, CurrentReference, ConstData)
% BUILD_TERMINAL_POINT_BLOCK 终端衔接等式（6 行，无松弛）。
%
% 数学形式:
%   末圈大气出口状态经真空飞行到最终远地点，得到终态与终端轨道倾角：
%       [x_ff; i_ff] = Φ_f(y_M),    M = 末圈（此处为第 5 圈）
%   x_ff = [r, V, γ, φ, ψ]_ff^T 为最终远地点 ECF 球坐标状态（LU, VU, rad），
%   i_ff 为终端轨道倾角（rad）。y_M = [V, γ, φ, ψ]^T 为末圈出口状态，
%   出口半径固定为 R_atm，不作变量。
%   Φ_f: R^4 → R^6 为“出口 → 积分到远地点”的真空映射。
%   P3 在参考点 ȳ_M 一阶线性化，不加松弛：
%       [x_ff; i_ff] = Φ_f(ȳ_M) + Φ_f,y·(y_M − ȳ_M)
%   Φ_f,y = ∂Φ_f/∂y ∈ R^(6×4)，由中心差分求得。
%
% 代码形式（第 i 行，i = 1..5 为 x_ff 的 r, V, γ, φ, ψ；第 6 行为 i_ff）:
%   变量移到左侧、常数移到右侧，lower = upper = beq：
%       x_ff(i) − Σ_j Φ_f,y(i, j)·y(j) = Φ_f(i) − Σ_j Φ_f,y(i, j)·ȳ(j)
%       i_ff    − Σ_j Φ_f,y(6, j)·y(j) = Φ_f(6) − Σ_j Φ_f,y(6, j)·ȳ(j)
%   变量列与系数:
%       x_ff(i)  VariableIndex.xff(i)                                      +1
%       i_ff     VariableIndex.xff_i                                       +1
%       y(j)     VariableIndex.{V,gamma,phi,psi}(PointsBounds(5).end)
%                                         −c_V(i), −c_gamma(i), −c_phi(i), −c_psi(i)
%   符号对应: Φ_f → C，ȳ → x_end_ref，右端 → beq(i)。
%   linearize_coast_exit_to_apoapsis 返回的 C_x 为 4×6（行 = 出口分量 V, γ, φ, ψ；
%   列 = 终态分量），即 Φ_f,y 的转置；c_V = C_x(1, :) 是 Φ_f,y 的第 1 列，
%   c_V(i) = Φ_f,y(i, 1)。

    PointsBounds = CurrentReference.PointsBounds;
    state_k = CurrentReference.state;

    ConstraintBlock.name = 'point_terminal';
    ConstraintBlock.row_index = [];
    ConstraintBlock.column_index = [];
    ConstraintBlock.value = [];
    beq = zeros(6, 1);

    x_end_index = [VariableIndex.V(PointsBounds(5).end), ...
        VariableIndex.gamma(PointsBounds(5).end), ...
        VariableIndex.phi(PointsBounds(5).end), ...
        VariableIndex.psi(PointsBounds(5).end)];
    x_end_ref = [state_k(PointsBounds(5).end, 2), ...
        state_k(PointsBounds(5).end, 3), ...
        state_k(PointsBounds(5).end, 4), ...
        state_k(PointsBounds(5).end, 5)];

    C_x = linearize_coast_exit_to_apoapsis( ...
        [ConstData.R_atm, x_end_ref, 0], ConstData);
    c_V = C_x(1, :); c_gamma = C_x(2, :); c_phi = C_x(3, :); c_psi = C_x(4, :);
    C = evaluate_coast_exit_to_apoapsis( ...
        [ConstData.R_atm, x_end_ref, 0], ConstData);

    for i = 1:5
        ConstraintBlock.row_index = [ ...
            ConstraintBlock.row_index; i; i; i; i; i];
        ConstraintBlock.column_index = [ ...
            ConstraintBlock.column_index; VariableIndex.xff(i); ...
            x_end_index(1); x_end_index(2); x_end_index(3); x_end_index(4)];
        ConstraintBlock.value = [ConstraintBlock.value; ...
            1; -c_V(i); -c_gamma(i); -c_phi(i); -c_psi(i)];
        beq(i) = C(i) - c_V(i) * x_end_ref(1) - c_gamma(i) * x_end_ref(2) ...
            - c_phi(i) * x_end_ref(3) - c_psi(i) * x_end_ref(4);
    end

    row = 6;
    ConstraintBlock.row_index = [ ...
        ConstraintBlock.row_index; row; row; row; row; row];
    ConstraintBlock.column_index = [ ...
        ConstraintBlock.column_index; VariableIndex.xff_i; ...
        x_end_index(1); x_end_index(2); x_end_index(3); x_end_index(4)];
    ConstraintBlock.value = [ConstraintBlock.value; ...
        1; -c_V(6); -c_gamma(6); -c_phi(6); -c_psi(6)];
    beq(6) = C(6) - c_V(6) * x_end_ref(1) - c_gamma(6) * x_end_ref(2) ...
        - c_phi(6) * x_end_ref(3) - c_psi(6) * x_end_ref(4);

    ConstraintBlock.lower = beq;
    ConstraintBlock.upper = beq;
end


function InnerPointBlocks = build_inner_point_blocks( ...
        VariableIndex, CurrentReference, ConstData)
% BUILD_INNER_POINT_BLOCKS 内点衔接等式（每圈 5 行，共 4 块）。
%
% 数学形式:
%   第 c 圈大气出口与第 c+1 圈大气入口由真空飞行映射连接：
%       x_in^(c+1) = Φ(y_c, P_(c+1)),    c = 1, ..., 4
%   x = [r, V, γ, φ, ψ]^T 为 ECF 球坐标状态（r: LU，V: VU，角度: rad）。
%   y_c = [V, γ, φ, ψ]^T 为第 c 圈出口状态，出口半径固定为 R_atm，不作变量。
%   P_(c+1) 为出口后远地点处沿速度方向的脉冲（VU）。
%   Φ: R^4 × R → R^5 为“出口 → 远地点 → 施加脉冲 → 下一圈入口”的两段真空映射。
%   P3 在参考点 (ȳ_c, P̄_(c+1)) 一阶线性化，并加不限符号的松弛 ν^(c+1) ∈ R^5：
%       x_in^(c+1) + ν^(c+1) = Φ(ȳ_c, P̄_(c+1))
%                            + Φ_y·(y_c − ȳ_c) + Φ_P·(P_(c+1) − P̄_(c+1))
%   Φ_y = ∂Φ/∂y ∈ R^(5×4)，Φ_P = ∂Φ/∂P ∈ R^5，均由中心差分求得。
%   松弛罚项 w_poi·|ν| 在 P3 的目标中。
%
% 代码形式（第 cir 块第 i 行，i = 1..5 依次对应 r, V, γ, φ, ψ）:
%   变量移到左侧、常数移到右侧，lower = upper = beq：
%       x_in(i) + ν(i) − Σ_j Φ_y(i, j)·y(j) − Φ_P(i)·P
%           = Φ(i) − Σ_j Φ_y(i, j)·ȳ(j) − Φ_P(i)·P̄
%   变量列与系数:
%       x_in(i)  VariableIndex.{r,V,gamma,phi,psi}(PointsBounds(cir+1).begin)  +1
%       ν(i)     VariableIndex.poi_slack_{r,V,gamma,phi,psi}(cir+1)            +1
%       y(j)     VariableIndex.{V,gamma,phi,psi}(PointsBounds(cir).end)
%                                         −c_V(i), −c_gamma(i), −c_phi(i), −c_psi(i)
%       P        VariableIndex.P(cir+1)                                        −C_P(i)
%   符号对应: Φ → C，Φ_P → C_P，ȳ → x_end_ref，P̄ → P_k(cir+1)，右端 → beq(i)。
%   linearize_coast_pass_to_entry 返回的 C_x 为 4×5（行 = 出口分量 V, γ, φ, ψ），
%   即 Φ_y 的转置；c_V = C_x(1, :) 是 Φ_y 的第 1 列，c_V(i) = Φ_y(i, 1)。

    PointsBounds = CurrentReference.PointsBounds;
    state_k = CurrentReference.state;
    P_k = CurrentReference.control.P;

    for cir = 1:4
        ConstraintBlock.name = ['point_inner_cir', num2str(cir)];
        ConstraintBlock.row_index = [];
        ConstraintBlock.column_index = [];
        ConstraintBlock.value = [];
        beq = zeros(5, 1);

        x_next_begin_index = [ ...
            VariableIndex.r(PointsBounds(cir + 1).begin), ...
            VariableIndex.V(PointsBounds(cir + 1).begin), ...
            VariableIndex.gamma(PointsBounds(cir + 1).begin), ...
            VariableIndex.phi(PointsBounds(cir + 1).begin), ...
            VariableIndex.psi(PointsBounds(cir + 1).begin)];
        x_end_index = [VariableIndex.V(PointsBounds(cir).end), ...
            VariableIndex.gamma(PointsBounds(cir).end), ...
            VariableIndex.phi(PointsBounds(cir).end), ...
            VariableIndex.psi(PointsBounds(cir).end)];
        x_end_ref = [state_k(PointsBounds(cir).end, 2), ...
            state_k(PointsBounds(cir).end, 3), ...
            state_k(PointsBounds(cir).end, 4), ...
            state_k(PointsBounds(cir).end, 5)];
        slack_index = [VariableIndex.poi_slack_r(cir + 1), ...
            VariableIndex.poi_slack_V(cir + 1), ...
            VariableIndex.poi_slack_gamma(cir + 1), ...
            VariableIndex.poi_slack_phi(cir + 1), ...
            VariableIndex.poi_slack_psi(cir + 1)];

        [C_x, C_P] = linearize_coast_pass_to_entry( ...
            [ConstData.R_atm, x_end_ref, 0], P_k(cir + 1), ConstData);
        c_V = C_x(1, :); c_gamma = C_x(2, :);
        c_phi = C_x(3, :); c_psi = C_x(4, :);
        C = evaluate_coast_pass_to_entry( ...
            [ConstData.R_atm, x_end_ref, 0], P_k(cir + 1), ConstData);

        for i = 1:5
            ConstraintBlock.row_index = [ ...
                ConstraintBlock.row_index; i; i; i; i; i; i; i];
            ConstraintBlock.column_index = [ ...
                ConstraintBlock.column_index; ...
                x_next_begin_index(i); slack_index(i); ...
                x_end_index(1); x_end_index(2); ...
                x_end_index(3); x_end_index(4); VariableIndex.P(cir + 1)];
            ConstraintBlock.value = [ConstraintBlock.value; ...
                1; 1; -c_V(i); -c_gamma(i); -c_phi(i); -c_psi(i); -C_P(i)];
            beq(i) = C(i) - c_V(i) * x_end_ref(1) ...
                - c_gamma(i) * x_end_ref(2) - c_phi(i) * x_end_ref(3) ...
                - c_psi(i) * x_end_ref(4) - C_P(i) * P_k(cir + 1);
        end

        ConstraintBlock.lower = beq;
        ConstraintBlock.upper = beq;
        InnerPointBlocks(cir) = ConstraintBlock;
    end
end


function ConstraintBlock = build_insertion_block(VariableIndex, ConstData)
% BUILD_INSERTION_BLOCK 入轨速度等式（1 行）。
%
% 数学形式:
%       P_6 + V_ff = v_aim,    v_aim = sqrt(2μ/R_aaim − 2μ/(R_aaim + R_paim))
%   P_6 为最终远地点处的入轨脉冲（VU），V_ff 为终态速度（VU，x_ff 的第 2 分量），
%   v_aim 为目标轨道（远地点半径 R_aaim、近地点半径 R_paim，LU）在远地点的速度，
%   μ 为归一化引力常数。线性等式，无需线性化，无松弛。
%
% 代码形式（1 行）:
%       P_6 + V_ff = b_eq,    lower = upper = b_eq = v_aim
%   变量列与系数: VariableIndex.P(6) +1，VariableIndex.xff(2) +1。
% 注：xff(2) 为 ECF 相对速度（经 gast=0 转换），与 P1 要求的惯性
% 速度口径不同（知识库 D2），此处保持既定实现。

    ConstraintBlock.name = 'insertion';
    ConstraintBlock.row_index = [1; 1];
    ConstraintBlock.column_index = [VariableIndex.P(6); VariableIndex.xff(2)];
    ConstraintBlock.value = [1; 1];

    b_eq = sqrt(2 * ConstData.mu / ConstData.R_aaim ...
        - 2 * ConstData.mu / (ConstData.R_aaim + ConstData.R_paim));
    ConstraintBlock.lower = b_eq;
    ConstraintBlock.upper = b_eq;
end


function ConstraintBlock = build_impulse_epigraph_block(VariableIndex)
% BUILD_IMPULSE_EPIGRAPH_BLOCK 脉冲绝对值上图的线性半平面（12 行）。
%
% 数学形式:
%       t_P,k ≥ |P_k|,    k = 1..6
%   P_k 为第 k 个脉冲（VU），t_P,k 为其绝对值上图变量（目标中带权 w_P）。
%   上式等价于两条半平面 t_P,k − P_k ≥ 0 与 t_P,k + P_k ≥ 0，
%   与锥块 impulse_epigraph（Q2）描述同一集合。
%
% 代码形式（脉冲 k 占第 2k−1、2k 行，lower = 0，upper = +Inf）:
%       第 2k−1 行: −P_k + t_P,k ≥ 0
%       第 2k   行: +P_k + t_P,k ≥ 0
%   变量列与系数: VariableIndex.P(k) 为 −1 / +1，VariableIndex.t_P(k) 为 +1。

    ConstraintBlock.name = 'impulse_epigraph';
    ConstraintBlock.row_index = [];
    ConstraintBlock.column_index = [];
    ConstraintBlock.value = [];

    for i = 1:6
        ConstraintBlock.row_index = [ ...
            ConstraintBlock.row_index; 2 * i - 1; 2 * i - 1];
        ConstraintBlock.column_index = [ ...
            ConstraintBlock.column_index; VariableIndex.P(i); ...
            VariableIndex.t_P(i)];
        ConstraintBlock.value = [ConstraintBlock.value; -1; 1];

        ConstraintBlock.row_index = [ ...
            ConstraintBlock.row_index; 2 * i; 2 * i];
        ConstraintBlock.column_index = [ ...
            ConstraintBlock.column_index; VariableIndex.P(i); ...
            VariableIndex.t_P(i)];
        ConstraintBlock.value = [ConstraintBlock.value; 1; 1];
    end

    ConstraintBlock.lower = zeros(12, 1);
    ConstraintBlock.upper = inf(12, 1);
end


function ConstraintBlock = build_path_load_block( ...
        VariableIndex, CurrentReference, ConstData)
% BUILD_PATH_LOAD_BLOCK 路径约束线性化单边上界（每节点 3 行）。
%
% 数学形式:
%   热流 Q̇、过载 n、动压 q 在全部大气段节点 i = 1..N 不超过上限，只依赖 r、V：
%       g(r_i, V_i) ≤ g_max,    g ∈ {Q̇, n, q}
%   r 单位 LU，V 单位 VU；ρ(r) = ρ_0·exp((R_M − r)/h_s)；
%   Q̇ [W/cm²]、n [无量纲，g_0 归一]、q [N/m²]，上限依次为 Qdot_max、N_max、q_max。
%   P3 在参考节点 (r̄_i, V̄_i) 一阶线性化，作为硬约束（不加松弛，不进罚项），并整行
%   除以 g_max（等价变换），使系数与右端回到 O(1)–O(10³)：
%       [g(r̄_i, V̄_i) + g_r·(r_i − r̄_i) + g_V·(V_i − V̄_i)] / g_max ≤ 1
%   g_r = ∂g/∂r、g_V = ∂g/∂V 在参考节点求值。不除时 q 行的 g_r 达 1e5 量级、
%   右端含 g_r·r̄（r̄≈36 LU）达 1e6 量级，与其余 O(1) 的行相差悬殊。
%
% 代码形式（节点 i 占第 3i−2、3i−1、3i 行，依次为 Q̇, n, q）:
%   单边不等式，lower = −Inf：
%       (g_r/g_max)·r_i + (g_V/g_max)·V_i
%           ≤ 1 − [g(r̄_i, V̄_i) − g_r·r̄_i − g_V·V̄_i] / g_max
%   变量列与系数: VariableIndex.r(i) → c_r/g_max，VariableIndex.V(i) → c_V/g_max。
%   符号对应: g(r̄_i, V̄_i) → c，g_r → c_r，g_V → c_V，r̄_i → r_k(i)，V̄_i → V_k(i)，
%   g_max → ConstData.Qdot_max / N_max / q_max。
%   c、c_r、c_V 由 linearize_heat_flux / linearize_load_factor /
%   linearize_dynamic_pressure 给出。

    N = CurrentReference.N;
    r_k = CurrentReference.state(:, 1);
    V_k = CurrentReference.state(:, 2);

    ConstraintBlock.name = 'path_loads';
    ConstraintBlock.row_index = [];
    ConstraintBlock.column_index = [];
    ConstraintBlock.value = [];
    lower = [];
    upper = [];

    row = 0;
    for i = 1:N
        % 热流密度
        row = row + 1;
        [c, c_r, c_V] = linearize_heat_flux(ConstData, r_k(i), V_k(i));
        ConstraintBlock.row_index = [ConstraintBlock.row_index; row; row];
        ConstraintBlock.column_index = [ ...
            ConstraintBlock.column_index; VariableIndex.r(i); ...
            VariableIndex.V(i)];
        ConstraintBlock.value = [ConstraintBlock.value; ...
            c_r / ConstData.Qdot_max; c_V / ConstData.Qdot_max];
        lower = [lower; -inf];
        upper = [upper; 1 - (c - c_r * r_k(i) - c_V * V_k(i)) ...
            / ConstData.Qdot_max];

        % 过载
        row = row + 1;
        [c, c_r, c_V] = linearize_load_factor(ConstData, r_k(i), V_k(i));
        ConstraintBlock.row_index = [ConstraintBlock.row_index; row; row];
        ConstraintBlock.column_index = [ ...
            ConstraintBlock.column_index; VariableIndex.r(i); ...
            VariableIndex.V(i)];
        ConstraintBlock.value = [ConstraintBlock.value; ...
            c_r / ConstData.N_max; c_V / ConstData.N_max];
        lower = [lower; -inf];
        upper = [upper; 1 - (c - c_r * r_k(i) - c_V * V_k(i)) ...
            / ConstData.N_max];

        % 动压
        row = row + 1;
        [c, c_r, c_V] = linearize_dynamic_pressure(ConstData, r_k(i), V_k(i));
        ConstraintBlock.row_index = [ConstraintBlock.row_index; row; row];
        ConstraintBlock.column_index = [ ...
            ConstraintBlock.column_index; VariableIndex.r(i); ...
            VariableIndex.V(i)];
        ConstraintBlock.value = [ConstraintBlock.value; ...
            c_r / ConstData.q_max; c_V / ConstData.q_max];
        lower = [lower; -inf];
        upper = [upper; 1 - (c - c_r * r_k(i) - c_V * V_k(i)) ...
            / ConstData.q_max];
    end

    ConstraintBlock.lower = lower;
    ConstraintBlock.upper = upper;
end


function LinearConstraints = assemble_linear_constraint_blocks( ...
        Blocks, num_variables)
% ASSEMBLE_LINEAR_CONSTRAINT_BLOCKS 聚合局部约束并组装稀疏矩阵。

    num_rows = sum(cellfun(@(Block) numel(Block.lower), ...
        num2cell(Blocks)));
    num_nonzeros = sum(cellfun(@(Block) numel(Block.value), ...
        num2cell(Blocks)));

    row_index = zeros(num_nonzeros, 1);
    column_index = zeros(num_nonzeros, 1);
    coefficient = zeros(num_nonzeros, 1);
    lower = zeros(num_rows, 1);
    upper = zeros(num_rows, 1);
    row_groups = struct();

    row_offset = 0;
    nonzero_offset = 0;
    for block_index = 1:numel(Blocks)
        ConstraintBlock = Blocks(block_index);
        validate_linear_constraint_block( ...
            ConstraintBlock, num_variables);

        block_rows = numel(ConstraintBlock.lower);
        block_nonzeros = numel(ConstraintBlock.value);
        row_range = row_offset + (1:block_rows);
        nonzero_range = nonzero_offset + (1:block_nonzeros);

        row_index(nonzero_range) = ...
            ConstraintBlock.row_index + row_offset;
        column_index(nonzero_range) = ConstraintBlock.column_index;
        coefficient(nonzero_range) = ConstraintBlock.value;
        lower(row_range) = ConstraintBlock.lower;
        upper(row_range) = ConstraintBlock.upper;
        row_groups.(ConstraintBlock.name) = row_range(:);

        row_offset = row_offset + block_rows;
        nonzero_offset = nonzero_offset + block_nonzeros;
    end

    LinearConstraints.matrix = sparse( ...
        row_index, column_index, coefficient, num_rows, num_variables);
    LinearConstraints.lower = lower;
    LinearConstraints.upper = upper;
    LinearConstraints.row_groups = row_groups;
end


function validate_linear_constraint_block( ...
        ConstraintBlock, num_variables)
% VALIDATE_LINEAR_CONSTRAINT_BLOCK 检查约束块的尺寸、数值和边界。

    if ~all(isfield(ConstraintBlock, ...
            {'name', 'row_index', 'column_index', 'value', ...
            'lower', 'upper'}))
        error('SCP:InvalidConstraintBlockSchema', ...
            '约束块 %s 字段不全。', ConstraintBlock.name);
    end
    if ~all(numel(ConstraintBlock.row_index) ...
            == numel(ConstraintBlock.column_index)) ...
            || numel(ConstraintBlock.row_index) ...
            ~= numel(ConstraintBlock.value)
        error('SCP:InvalidConstraintBlockTriplets', ...
            '约束块 %s 三元组长度不一致。', ConstraintBlock.name);
    end
    if ~isempty(ConstraintBlock.column_index) ...
            && (max(ConstraintBlock.column_index) > num_variables ...
            || min(ConstraintBlock.column_index) < 1)
        error('SCP:InvalidConstraintBlockColumns', ...
            '约束块 %s 变量列号越界。', ConstraintBlock.name);
    end
    if ~isempty(ConstraintBlock.value) ...
            && any(~isfinite(ConstraintBlock.value))
        error('SCP:InvalidConstraintBlockValues', ...
            '约束块 %s 系数含 NaN/Inf。', ConstraintBlock.name);
    end
    if numel(ConstraintBlock.lower) ~= numel(ConstraintBlock.upper) ...
            || any(isnan(ConstraintBlock.lower)) ...
            || any(isnan(ConstraintBlock.upper)) ...
            || any(ConstraintBlock.lower > ConstraintBlock.upper)
        error('SCP:InvalidConstraintBlockBounds', ...
            '约束块 %s 上下界无效。', ConstraintBlock.name);
    end
    if ~isempty(ConstraintBlock.row_index) ...
            && (max(ConstraintBlock.row_index) ...
            > numel(ConstraintBlock.lower) ...
            || min(ConstraintBlock.row_index) < 1)
        error('SCP:InvalidConstraintBlockRows', ...
            '约束块 %s 局部行号越界。', ConstraintBlock.name);
    end
end
