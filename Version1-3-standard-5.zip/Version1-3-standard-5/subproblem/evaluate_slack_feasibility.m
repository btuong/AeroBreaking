function SlackReport = evaluate_slack_feasibility( ...
        CurrentSolution, CurrentReference, config)
% EVALUATE_SLACK_FEASIBILITY 检查 P3 的解里各类松弛是否降到容差以内。
%
% 检查项：
%   1. 动力学等式松弛 dyn_slack 各状态通道最大绝对值（容差
%      config.validation.max_dyn_slack，归一化单位）。
%   2. 衔接松弛 point_slack 各通道最大绝对值（容差
%      config.validation.max_point_slack）。
% 控制圆盘可行性与无损凸化紧性由 evaluate_conic_reformulation_consistency
% 负责，原终端约束在节点值上的满足情况由 P2 可行性检查负责。
%
% 每条指标另存最大值所在位置：动力学松弛记 max_cir（圈号）和 max_node
% （区间起点节点）；衔接松弛记 max_point（1 为初始，c+1 为第 c 个内点）。
% 不适用的位置字段为 NaN。
%
% SlackReport.success 只表示上述松弛在容差以内，不表示求解器成功、
% 候选解被接受或任务完成。
%
% 本函数依次完成：
%   1. 动力学松弛。
%   2. 衔接松弛。
%   3. 汇总。

    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    metric_list = cell(1, 2 * numel(state_names));

    %% 1. 动力学松弛
    % dyn_slack 的第 k 行对应按圈依次排列的第 k 个区间，先求每行的圈号和起点节点
    [interval_cir, interval_node] = list_interval_positions( ...
        CurrentReference.PointsBounds);
    for s = 1:numel(state_names)
        [max_value, max_row] = max(abs(CurrentSolution.dyn_slack(:, s)));
        Metric = create_slack_metric(['dyn_slack_' state_names{s}], ...
            max_value, config.validation.max_dyn_slack, '1');
        Metric.max_cir = interval_cir(max_row);
        Metric.max_node = interval_node(max_row);
        Metric.max_point = NaN;
        metric_list{s} = Metric;
    end

    %% 2. 衔接松弛
    for s = 1:numel(state_names)
        [max_value, max_row] = max(abs(CurrentSolution.point_slack(:, s)));
        Metric = create_slack_metric(['point_slack_' state_names{s}], ...
            max_value, config.validation.max_point_slack, '1');
        Metric.max_cir = NaN;
        Metric.max_node = NaN;
        Metric.max_point = max_row;
        metric_list{numel(state_names) + s} = Metric;
    end

    %% 3. 汇总
    SlackReport = summarize_slack_metrics([metric_list{:}]);
end


function [interval_cir, interval_node] = list_interval_positions(PointsBounds)
% LIST_INTERVAL_POSITIONS 按圈依次列出每个动力学区间所在的圈号和起点节点。

    cir_list = cell(1, numel(PointsBounds));
    node_list = cell(1, numel(PointsBounds));
    for cir = 1:numel(PointsBounds)
        nodes = (PointsBounds(cir).begin:(PointsBounds(cir).end - 1))';
        node_list{cir} = nodes;
        cir_list{cir} = cir * ones(size(nodes));
    end
    interval_cir = vertcat(cir_list{:});
    interval_node = vertcat(node_list{:});
end
