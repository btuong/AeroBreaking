# tightness_diagnosis：第一、二类不紧机理诊断

代码自 Version1-3-standard-3 复制（2026-11-23），结果存档在 `../Version1-3-standard-3/tightness_diagnosis/`。

用于提纲问题1中的“抵消”和“弦上平坦”，独立于 `regularizer_converge/`，不覆盖其21工况存档。主链默认 `config.constraints.enable_control_continuity = true`，原 `SCP.m` 的约束不变；本入口每轮主解之后，用同一参考、同一信赖域和其余相同配置额外求解一次无速率约束 P3，只作对照，不推进对照解。

## 指标

每轮 `ControlReport` 新增：

- `tightness_margin`：$m_i=\|s_{\rm main,i}+s_{\rm reg,i}\|$；
- `cone_complementarity`：$\mu_i=\langle x_i,y_i^d\rangle$，由控制锥原始值和 `doty` 逐节点求内积；
- `complementarity_bound`：$\mu_i/m_i$，$m_i=0$ 时为 NaN。满足 $1-\|u_i\|\leq\mu_i/m_i$ 是数值核验，不把返回值默认称为精确中心路径点；
- `radial_main`、`radial_regularizer`：$-\bar e_i^\top s_{\rm main,i}$、$-\bar e_i^\top s_{\rm reg,i}$，参考方向的径向分量；
- `cancellation_cosine`：主需求与正则项的夹角余弦；`cancellation_strength`：$m_i/\max(\|s_{\rm main,i}\|,\|s_{\rm reg,i}\|)$，接近零表示严格抵消；
- `chord_active`、`chord_rank`、`chord_tangent`：活跃 `control_continuity` 行在该节点局部控制空间的零空间；
- `chord_reg_component`、`chord_flatness`：正则项在该零空间中的分量及其占正则范数的比例。比例接近零表示沿弦平坦；`chord_flat` 的阈值为0.05，不是因果证明。

控制报告的对偶分解含动力学、速率和变量边界。无速率约束 P3 中不存在弦，`chord_active=false`；它的 gap/余量用于 A/B 比较，不能当作弦平坦判据。`nonrate_margin` 和 `nonrate_cosine` 另在当前有约束解上删去 `s_rate`，用于区分速率乘子抵消与弦向平坦。

## 运行

在 MATLAB 中：

```matlab
run('Version1-3-standard-3/tightness_diagnosis/SCP_tightness_diagnosis.m')
```

代表工况为 `sum/u1/u2/norm_gap` × `w=1e-3,1e-4`，每个10轮，每轮两次P3。可预先设置：

- `case_filter`：如 `{'u1_w1e-04'}`；空则全部代表工况；
- `max_iter`：默认10；
- `results_folder`：默认 `results`；本次区分速率乘子的完整结果在 `results_v2/`；
- `rerun_existing`：已有工况MAT时是否重跑，默认false。

结果包括每工况一个小MAT（逐轮两份 `ControlReport`、A/B差值）和 `汇总.txt`、`.mat`。文本逐轮列出最大gap、最小余量、抵消节点、弦平坦不紧节点、互补积上界误差和驻点残差；大gap节点另列去速率乘子的反事实余量及无速率重解值。

聚焦测试：`tests/test_control_tightness_mechanisms.m`，用合成P3核验锥互补积符号、参考径向分量、u1弦向平坦/u2非平坦、控制报告接入、速率约束开关、对偶缺失回退、不可行速率行和不完整证据汇总。
