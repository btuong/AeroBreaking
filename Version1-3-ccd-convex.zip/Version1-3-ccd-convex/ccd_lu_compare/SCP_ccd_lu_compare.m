% 文献 [20]（Lu 2020 原文凹凸分解 ccd_lu）对比实验入口：在同一套 SCP 设置下
% 运行全部 12 个 ccd_lu 工况，每个工况只保存 brief/detail/control 文本、control MAT
% 与提取的 case_metrics.mat（严禁保存 full_mat 与 scan_mat），随后可调用
% analyze_ccd_lu_compare 联合只读的 standard-5 存档生成对比汇总与图片。
%
% 可选工作区变量（运行前设置，未设取默认）:
%   rerun_existing    - 默认 false；工况目录已有 case_metrics.mat 时跳过
%   case_filter       - 工况名元胞数组，空则全跑 12 个工况
%   plateau_window    - 平台判据窗口长度 W（被接受轮数），默认 5
%   plateau_tolerance - 平台判据总脉冲极差上限 δ (m/s)，默认 0.1
%   results_folder    - 结果文件夹名（在 ccd_lu_compare 下），默认 'results'
%   run_analysis      - 结束后是否自动调用 analyze_ccd_lu_compare，默认 true
%
% 日志行: [CASE] <工况名> start/done/failed/skipped，全部结束打印 ALL_DONE。

%% ===== 环境准备 =====
tic;
compare_root = fileparts(mfilename('fullpath'));
version_root = fileparts(compare_root);
previous_path = path;
restore_compare_path = onCleanup(@() path(previous_path));
modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
    'trust_region', 'validation', 'iteration', 'output'};
for k = 1:numel(modules)
    addpath(fullfile(version_root, modules{k}));
end
addpath(compare_root);
rehash;

if ~exist('rerun_existing', 'var')
    rerun_existing = false;
end
if ~exist('case_filter', 'var')
    case_filter = {};
end
if ~exist('plateau_window', 'var')
    plateau_window = 5;
end
if ~exist('plateau_tolerance', 'var')
    plateau_tolerance = 0.1;
end
if ~exist('results_folder', 'var')
    results_folder = 'results';
end
if ~exist('run_analysis', 'var')
    run_analysis = true;
end

%% ===== 平台判据与工况表 =====
plateau.window = plateau_window;
plateau.tolerance = plateau_tolerance;

Cases = list_compare_cases(case_filter);
results_root = fullfile(compare_root, results_folder);
fprintf(['版本目录: %s\n工况数: %d，平台判据: 最近 %d 个被接受轮极差 ≤ %g m/s，' ...
    '结果目录: %s\n'], version_root, numel(Cases), plateau.window, ...
    plateau.tolerance, results_root);

%% ===== 逐个运行工况 =====
for c = 1:numel(Cases)
    Case = Cases(c);
    case_directory = fullfile(results_root, Case.name);
    metrics_path = fullfile(case_directory, 'case_metrics.mat');
    if isfile(metrics_path) && ~rerun_existing
        fprintf('[CASE] %s skipped (已有 case_metrics.mat)\n', Case.name);
        continue;
    end

    fprintf('[CASE] %s start (max_iter=%d, p=%.6g, keep=%d, norm=%d, init=%s)\n', ...
        Case.name, Case.max_iter, Case.p, Case.keep_control_bounds, ...
        Case.normalize_init, Case.init_control_mode);
    case_timer = tic;
    try
        % 公共配置同阶段 3-1 / 5-1：关步长停止，fixed r=1，关闭绘图与逐轮打印
        config = scp_config_default();
        config.iter.max_scp_iter = Case.max_iter;
        config.iter.tolerance = 0;
        config.trust_region.method = 'fixed';
        config.trust_region.initial_scale = 1;

        config.plot.enable_initial = false;
        config.plot.enable_iteration = false;
        config.plot.enable_final = false;
        config.output.print_pre_iteration = false;
        config.output.print_iteration = false;
        config.output.print_summary = false;

        config.output.save.brief_text = true;
        config.output.save.detail_text = true;
        config.output.save.control_text = true;
        config.output.save.control_mat = true;
        config.output.save.scan_mat = false;
        config.output.save.full_mat = false;
        config.output.save.directory = ['ccd_lu_compare/' results_folder '/' Case.name];

        % Lu (2020) 原文凹凸分解模式配置
        config.unit_norm.mode = 'ccd_lu';
        config.unit_norm.ccd_penalty_weight = Case.p;
        config.unit_norm.ccd_slack_max = 1;
        config.unit_norm.ccd_keep_control_bounds = Case.keep_control_bounds;
        config.unit_norm.ccd_normalize_initial_control = Case.normalize_init;

        [Result, ~, SaveReport, RunInfo] = run_compare_case(config, plateau, Case);
        elapsed_seconds = toc(case_timer);

        if ~SaveReport.success
            error('CCDCompare:SaveFailed', '工况 %s 的结果文件未全部写入。', Case.name);
        end
        Metrics = extract_compare_metrics(Result, RunInfo, Case.name, Case, ...
            elapsed_seconds);
        save(metrics_path, 'Metrics');
        error_path = fullfile(case_directory, 'case_error.txt');
        if isfile(error_path)
            delete(error_path);
        end

        final_impulse = NaN;
        if ~isnan(Metrics.final_index)
            final_impulse = Metrics.total_impulse_m_s(Metrics.final_index);
        end
        fprintf(['[CASE] %s done %.1f s, stop=%s, first=%s, 尝试=%d, 接受=%d, ' ...
            '末轮总脉冲=%.10f m/s\n'], Case.name, elapsed_seconds, Metrics.stop_reason, ...
            Metrics.first_status, Metrics.num_attempted, Metrics.num_accepted, ...
            final_impulse);
    catch exception
        elapsed_seconds = toc(case_timer);
        if ~isfolder(case_directory)
            mkdir(case_directory);
        end
        error_id = fopen(fullfile(case_directory, 'case_error.txt'), 'w', 'n', 'UTF-8');
        fprintf(error_id, 'identifier: %s\nmessage: %s\n', ...
            exception.identifier, exception.message);
        for s = 1:numel(exception.stack)
            fprintf(error_id, 'at %s (line %d)\n', ...
                exception.stack(s).name, exception.stack(s).line);
        end
        fclose(error_id);
        fprintf('[CASE] %s failed %.1f s\n', Case.name, elapsed_seconds);
        fprintf('[CASE] %s ERROR: %s (%s)\n', Case.name, exception.message, ...
            exception.identifier);
    end
end
fprintf('ALL_DONE (%.1f s)\n', toc);

%% ===== 汇总分析 =====
if run_analysis && exist('analyze_ccd_lu_compare', 'file') == 2
    analyze_ccd_lu_compare();
end
