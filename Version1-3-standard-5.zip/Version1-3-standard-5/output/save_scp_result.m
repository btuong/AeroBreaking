function SaveReport = save_scp_result(FinalizedRun, ConstData, config)
% SAVE_SCP_RESULT 按 config.output.save 的开关把冻结的运行结果写成文件，一个开关对应一个文件。
%
% 文件都写到 <版本根>/<directory>/，文件名以 <filename_prefix> 开头，每次运行覆盖:
%   开关          文件                内容
%   brief_text    <前缀>_brief.txt    简略: 运行结论（键: 值 行）和各轮概况表
%   detail_text   <前缀>_detail.txt   详细: 运行结论，加每一轮分析要用的全部量
%                                     （逐轮六块全部展开，不看 config.output.detail）
%   scan_mat      <前缀>_scan.mat     顶层 ScanInput: 每轮的参考点和半径，
%                                     SCP_radius_scan.m 读它
%   full_mat      <前缀>_full.mat     顶层 Result 和 FinalizedRun: 全部运行数据（几十 MB）
%   control_text  <前缀>_control.txt  控制量 u 的结果导出: 逐次尝试的全程汇总，
%                                     最后被接受那轮的逐圈汇总和逐节点表
%   control_mat   <前缀>_control.mat  顶层 ControlExport: 每次尝试的 iter、是否接受、
%                                     半径、control_report，以及 w_reg、积分权的计算方式、
%                                     各圈 t_f（小 MAT，不含完整历史）
% 六个开关互不影响，全关时什么都不写。保存只读 FinalizedRun.history(k).subproblem.control_report，
% 不重新求值。
%
% 运行结论的键名: final_p3_* 是 P3 的解里的值，final_p2_* 是 P2 可行性检查按原关系
% 重算的值。
% 最后接受轮另有罚函数 J、预测下降 ΔL、ρ、驻点度量的上界和违反比的最终值。
% 保存失败只进 SaveReport，不改变算法状态。
%
% 输出 SaveReport:
%   requested        - 至少有一个开关打开
%   output_directory - 保存目录的完整路径
%   files            - 1 x 6 结构体数组，每个文件一个: name（开关名）、label（显示名）、
%                      path、requested（开关是否打开）、completed（是否写成）、
%                      error_identifier、error_message
%   success, status  - 'disabled'（全关）、'complete'、'partial_failure'、'failed'
%
% 本函数依次完成：
%   1. 列出六个文件的路径和开关。
%   2. 逐个写打开了开关的文件，各自记录完成或失败。
%   3. 汇总保存结果。

    %% 1. 列出六个文件的路径和开关
    % 每行: 开关名、显示名、文件名后缀、写这个文件的函数（六个函数的输入相同）
    SaveSwitch = config.output.save;
    file_specs = { ...
        'brief_text',  '简略文件',   '_brief.txt',  @write_brief_text; ...
        'detail_text', '详细文件',   '_detail.txt', @write_detail_text; ...
        'scan_mat',    '扫描用 MAT', '_scan.mat',   @write_scan_mat; ...
        'full_mat',    '全量 MAT',   '_full.mat',   @write_full_mat; ...
        'control_text', '控制量文件', '_control.txt', @write_control_text; ...
        'control_mat',  '控制量 MAT', '_control.mat', @write_control_mat};
    num_files = size(file_specs, 1);
    version_root = fileparts(fileparts(mfilename('fullpath')));   % output/ 的上一级为版本根
    output_directory = fullfile(version_root, SaveSwitch.directory);
    path_stem = fullfile(output_directory, SaveSwitch.filename_prefix);
    requested = false(1, num_files);
    for k = 1:num_files
        requested(k) = logical(SaveSwitch.(file_specs{k, 1}));
    end

    %% 2. 逐个写打开了开关的文件，各自记录完成或失败
    if any(requested) && ~isfolder(output_directory)
        mkdir(output_directory);
    end
    Result = build_scp_result(FinalizedRun);
    file_list = cell(1, num_files);
    for k = 1:num_files
        file_list{k} = run_save_task(file_specs{k, 1}, file_specs{k, 2}, ...
            [path_stem file_specs{k, 3}], requested(k), file_specs{k, 4}, ...
            Result, FinalizedRun, ConstData, config);
    end

    %% 3. 汇总保存结果
    SaveReport.requested = any(requested);
    SaveReport.output_directory = output_directory;
    SaveReport.files = [file_list{:}];
    completed = [SaveReport.files.completed];
    SaveReport.success = all(completed(requested));
    if ~any(requested)
        SaveReport.status = 'disabled';
    elseif SaveReport.success
        SaveReport.status = 'complete';
    elseif any(completed)
        SaveReport.status = 'partial_failure';
    else
        SaveReport.status = 'failed';
    end
end


function write_brief_text(brief_path, Result, ~, ~, ~)
% WRITE_BRIEF_TEXT 写简略文件: 运行结论和各轮概况表。

    file_id = open_text_file(brief_path);
    cleanup = onCleanup(@() fclose(file_id));
    write_run_conclusion(file_id, Result);
end


function write_detail_text(detail_path, Result, FinalizedRun, ConstData, config)
% WRITE_DETAIL_TEXT 写详细文件: 先写运行结论和各轮概况表，再逐轮写分析要用的全部量。
%
% 逐轮部分复用终端格式: 复制一份 config，把 output.detail.all 设为真，用 evalc 调
% print_scp_iteration 只打印 solver、analysis、multipliers、p2_feasibility、
% convergence、result 六块，把得到的文本写进文件。所以详细文件的内容不随终端的
% 展开开关变化。P3 失败的轮只剩 solver 和 result。

    ExpandedConfig = config;
    ExpandedConfig.output.detail.all = true;
    block_names = {'solver', 'analysis', 'multipliers', 'p2_feasibility', ...
        'convergence', 'result'};

    file_id = open_text_file(detail_path);
    cleanup = onCleanup(@() fclose(file_id));
    write_run_conclusion(file_id, Result);
    for k = 1:numel(FinalizedRun.history)
        Record = FinalizedRun.history(k);
        Diagnostics = FinalizedRun.diagnostics(k);
        iteration_text = evalc(['print_scp_iteration(Record, Diagnostics, ' ...
            'ConstData, ExpandedConfig, block_names)']);
        fprintf(file_id, '%s', iteration_text);
    end
end


function write_scan_mat(mat_path, ~, FinalizedRun, ConstData, config)
% WRITE_SCAN_MAT 写扫描用 MAT: 顶层只有 ScanInput（配置、常数、每轮的参考点和半径）。

    ScanInput = build_scan_input(FinalizedRun, ConstData, config);
    save(mat_path, 'ScanInput', '-v7.3');
end


function write_full_mat(mat_path, Result, FinalizedRun, ~, ~)
% WRITE_FULL_MAT 写全量 MAT: 顶层 Result（对外结果）和 FinalizedRun（冻结的运行对象）。

    save(mat_path, 'Result', 'FinalizedRun', '-v7.3');
end


function write_control_text(control_path, ~, FinalizedRun, ConstData, config)
% WRITE_CONTROL_TEXT 写控制量文件: 逐次尝试的全程汇总，最后被接受那轮的逐圈汇总和逐节点表。

    ControlExport = build_control_export(FinalizedRun, ConstData, config);
    file_id = open_text_file(control_path);
    cleanup = onCleanup(@() fclose(file_id));
    print_control_report(file_id, ControlExport);
end


function write_control_mat(mat_path, ~, FinalizedRun, ConstData, config)
% WRITE_CONTROL_MAT 写控制量 MAT: 顶层只有 ControlExport（每次尝试的控制量报告，不含完整历史）。

    ControlExport = build_control_export(FinalizedRun, ConstData, config);
    save(mat_path, 'ControlExport', '-v7.3');
end


function file_id = open_text_file(file_path)
% OPEN_TEXT_FILE 以 UTF-8 新建文本文件，打不开时报错。

    file_id = fopen(file_path, 'w', 'n', 'UTF-8');
    if file_id < 0
        error('SCP:OpenResultFileFailed', '无法打开结果文件：%s。', file_path);
    end
end


function write_run_conclusion(file_id, Result)
% WRITE_RUN_CONCLUSION 写运行结论: 稳定的键: 值 行，空一行后是各轮概况表。
% 简略文件只有这一部分，详细文件以它开头。

    fprintf(file_id, 'schema_version: %d\n', Result.schema_version);
    fprintf(file_id, 'status: %s\n', Result.status);
    fprintf(file_id, 'has_accepted_solution: %d\n', ...
        Result.has_accepted_solution);
    fprintf(file_id, 'num_attempted: %d\n', Result.num_attempted);
    fprintf(file_id, 'num_accepted: %d\n', Result.num_accepted);
    fprintf(file_id, 'last_attempt_success: %d\n', ...
        Result.last_attempt_success);
    fprintf(file_id, 'scp_converged: %d\n', Result.scp_converged);
    fprintf(file_id, 'convergence_stop_reached: %d\n', ...
        Result.convergence_stop_reached);
    fprintf(file_id, 'stop: %d\n', Result.stop);
    fprintf(file_id, 'stop_reason: %s\n', Result.stop_reason);
    fprintf(file_id, 'stop_detail: %s\n', Result.stop_detail);

    if Result.has_accepted_solution
        FinalSolution = Result.final_solution;
        fprintf(file_id, 'final_iteration: %d\n', ...
            Result.final_iteration.iter);
        fprintf(file_id, 'final_objective: %.10e\n', ...
            FinalSolution.objective);
        fprintf(file_id, 'final_p3_inclination_rad: %.10e\n', ...
            FinalSolution.i);
        fprintf(file_id, 'final_t_f: %s\n', format_vector( ...
            FinalSolution.t_f));
        fprintf(file_id, 'final_p3_P_normalized: %s\n', format_vector( ...
            FinalSolution.control.P));
        P2Feasibility = Result.final_iteration.subproblem.p2_feasibility;
        fprintf(file_id, 'final_p2_apoapsis_km: %.10e\n', ...
            P2Feasibility.terminal_report.metrics(1).actual_value);
        fprintf(file_id, 'final_p2_inclination_deg: %.10e\n', ...
            P2Feasibility.terminal_report.metrics(2).actual_value);
        fprintf(file_id, 'final_p2_P5_m_per_s: %.10e\n', ...
            P2Feasibility.performance_report.components(end));
        fprintf(file_id, 'final_p2_total_impulse_m_per_s: %.10e\n', ...
            P2Feasibility.performance_report.value);
        write_final_penalty_lines(file_id, Result.final_iteration);
    end

    % 各轮概况表和终端摘要里的是同一张
    print_iteration_overview(file_id, Result.history);
end


function write_final_penalty_lines(file_id, FinalIteration)
% WRITE_FINAL_PENALTY_LINES 写最后接受轮的罚函数 J 及其三部分（性能指标 C、附加项 Γ、罚项 Θ，
% 候选解处的值）、ΔL、ρ、驻点度量的上界和违反比。
%
% 驻点度量的上界取 (r_max/r)ΔL，以该轮的参考点为基准。
% 评价不可用（没有候选解）时不写 J 一类的键。

    Evaluation = FinalIteration.trust.evaluation;
    if Evaluation.evaluated
        fprintf(file_id, 'final_penalty_J: %.10e\n', Evaluation.candidate.total);
        fprintf(file_id, 'final_performance_index_C: %.10e\n', ...
            Evaluation.group.cost.candidate);
        fprintf(file_id, 'final_extra_Gamma: %.10e\n', ...
            Evaluation.group.extra.candidate);
        fprintf(file_id, 'final_penalty_Theta: %.10e\n', ...
            Evaluation.group.penalty.candidate);
        fprintf(file_id, 'final_predicted_reduction_dL: %.10e\n', ...
            Evaluation.predicted_reduction);
        fprintf(file_id, 'final_ratio_rho: %.10e\n', Evaluation.ratio);
        fprintf(file_id, 'final_stationarity_bound: %.10e\n', ...
            Evaluation.stationarity_bound);
    end
    fprintf(file_id, 'final_feasible_max_ratio: %.10e\n', ...
        FinalIteration.subproblem.p2_feasibility.max_ratio);
    fprintf(file_id, 'final_stationary: %d\n', FinalIteration.stop.stationary);
    fprintf(file_id, 'final_feasible: %d\n', FinalIteration.stop.feasible);
end


function text = format_vector(values)
% FORMAT_VECTOR 将短向量格式化为逗号分隔文本。

    if isempty(values)
        text = '[]';
        return;
    end
    parts = compose('%.10e', values);
    text = ['[', strjoin(parts, ','), ']'];
end


function SaveTask = run_save_task(name, label, file_path, requested, ...
        write_function, Result, FinalizedRun, ConstData, config)
% RUN_SAVE_TASK 开关打开时写一个文件，记录完成或失败；开关关闭时只记下没有请求。
%
% write_function 是 write_brief_text、write_detail_text、write_scan_mat、write_full_mat、
% write_control_text、write_control_mat 之一，输入都是 (文件路径, Result, FinalizedRun, ConstData, config)，用不到的输入忽略。

    SaveTask.name = name;
    SaveTask.label = label;
    SaveTask.path = file_path;
    SaveTask.requested = requested;
    SaveTask.completed = false;
    SaveTask.error_identifier = '';
    SaveTask.error_message = '';
    if ~requested
        return;
    end

    try
        write_function(file_path, Result, FinalizedRun, ConstData, config);
        SaveTask.completed = true;
    catch exception
        SaveTask.error_identifier = exception.identifier;
        SaveTask.error_message = exception.message;
    end
end
