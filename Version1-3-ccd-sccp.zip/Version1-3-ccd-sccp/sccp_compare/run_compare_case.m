function [Result, FinalizedRun, SaveReport, RunInfo] = ...
        run_compare_case(config, plateau, Case)
% RUN_COMPARE_CASE 按给定配置与工况完整跑一次 SCP，并按总脉冲平台判据停止。
%
% 流程与主链 SCP.m 相同，由调用方负责路径管理；支持按 Case 覆盖速率约束开关与
% 初始控制模式（'default' / 'scale_0p3' / 'zero'），在生成初始参考之后、
% initialize_scp_run 之前修改初始控制。主循环内判断最近 plateau.window 个
% 被接受轮总脉冲极差 ≤ plateau.tolerance 且均对 P2 可行时标记平台停止。
%
% 输入:
%   config  - 完整配置结构体（scp_config_default 加覆盖项）
%   plateau - 平台判据结构体：window（被接受轮数）、tolerance（极差上限，m/s）
%   Case    - 工况结构体（含 enable_control_continuity、init_control_mode）
%
% 输出:
%   Result       - 对外稳定结果（build_scp_result）
%   FinalizedRun - 冻结的运行对象
%   SaveReport   - 保存报告（save_scp_result）
%   RunInfo      - 平台判断结果与各轮用时 (s)
%
% 本函数依次完成：
%   1. 应用工况约束开关并初始化问题数据。
%   2. 生成初始参考轨迹并按工况调整初始控制。
%   3. 准备迭代数据结构。
%   4. SCP 主迭代循环（含总脉冲平台判断）。
%   5. 整理最终结果并保存。

    if nargin < 3 || isempty(Case)
        Case = struct('enable_control_continuity', true, ...
            'init_control_mode', 'default');
    end

    %% 1. 应用工况约束开关并初始化问题数据
    if isfield(Case, 'enable_control_continuity') ...
            && ~Case.enable_control_continuity
        config.constraints.enable_control_continuity = false;
    end
    [ConstData, InitialState] = initialize_problem(config);

    %% 2. 生成初始参考轨迹并按工况调整初始控制
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, config);
    if isfield(Case, 'init_control_mode')
        InitialReference = apply_initial_control_mode( ...
            InitialReference, Case.init_control_mode);
    end

    %% 3. 准备迭代数据结构
    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);
    if config.output.print_pre_iteration
        print_initial_summary(ConstData, InitialReference, InitialPropagation);
    end
    if config.plot.enable_initial
        plot_initial_reference(ConstData, InitialPropagation, config);
    end

    %% 4. SCP 主迭代循环（含总脉冲平台判断）
    accepted_iter = zeros(0, 1);        % 被接受轮的轮号
    accepted_impulse = zeros(0, 1);     % 被接受轮的总脉冲 (m/s)
    accepted_feasible = false(0, 1);    % 被接受轮是否对 P2 可行
    iter_seconds = nan(config.iter.max_scp_iter, 1);
    Plateau = create_plateau_result();
    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        iter_timer = tic;

        % 1 构建、求解本轮 P3，并做步长检查、P3 解检查与 P2 可行性检查
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);

        % 2 决定候选解是否接受、下一轮信赖域多大
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);

        % 3 更新下一轮参考和信赖域，判断是否停止，并记录本轮
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);

        % 4 被接受轮记下总脉冲与 P2 可行性，判断总脉冲是否进入平台
        if TrustResult.accept_candidate
            accepted_iter(end + 1, 1) = iter; %#ok<AGROW>
            accepted_impulse(end + 1, 1) = ...
                IterationRecord.subproblem.p2_feasibility.performance_report.value; %#ok<AGROW>
            accepted_feasible(end + 1, 1) = ...
                logical(TrustResult.accepted_p2_feasibility.feasible); %#ok<AGROW>
            Plateau = detect_performance_plateau( ...
                accepted_iter, accepted_impulse, accepted_feasible, plateau);
        end
        % 主代码已因 P3 失败等原因停止时不改停止原因；达到上限同时成立时以平台为准
        if Plateau.reached && (~RunState.stop ...
                || strcmp(RunState.stop_reason, 'max_iterations'))
            RunState = mark_plateau_stop(RunState, Plateau, plateau);
        end

        % 5 只读后处理：对被接受解做隐式梯形递推、逐轮打印与绘图
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);
        iter_seconds(iter) = toc(iter_timer);

        % 6 停止检查
        if RunState.stop
            break;
        end
    end

    %% 5. 整理最终结果并保存
    FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory);
    Result = build_scp_result(FinalizedRun);
    SaveReport = save_scp_result(FinalizedRun, ConstData, config);
    RunInfo = build_run_info(Plateau, strcmp(RunState.stop_reason, ...
        'performance_plateau'), iter_seconds(1:FinalizedRun.num_attempted));
end


function InitialReference = apply_initial_control_mode( ...
        InitialReference, init_control_mode)
% APPLY_INITIAL_CONTROL_MODE 按工况设定调整初始参考控制分量 u1 与 u2。

    switch init_control_mode
        case 'default'
            return;
        case 'scale_0p3'
            InitialReference.control.u1 = 0.3 * InitialReference.control.u1;
            InitialReference.control.u2 = 0.3 * InitialReference.control.u2;
        case 'zero'
            InitialReference.control.u1 = zeros(InitialReference.N, 1);
            InitialReference.control.u2 = zeros(InitialReference.N, 1);
        otherwise
            error('SCCPCompare:UnknownInitControlMode', ...
                '未知初始控制模式 %s。', init_control_mode);
    end
end


function Plateau = create_plateau_result()
% CREATE_PLATEAU_RESULT 创建“平台尚未成立”的判断结果。

    Plateau = struct('reached', false, 'start_iter', NaN, ...
        'mean_impulse', NaN, 'range', NaN);
end


function Plateau = detect_performance_plateau( ...
        accepted_iter, accepted_impulse, accepted_feasible, plateau)
% DETECT_PERFORMANCE_PLATEAU 判断最近 window 个被接受轮的总脉冲是否进入平台。

    Plateau = create_plateau_result();
    window = plateau.window;
    if numel(accepted_iter) < window
        return;
    end
    recent = numel(accepted_iter) - window + 1:numel(accepted_iter);
    window_impulse = accepted_impulse(recent);
    window_range = max(window_impulse) - min(window_impulse);
    if window_range <= plateau.tolerance && all(accepted_feasible(recent))
        Plateau.reached = true;
        Plateau.start_iter = accepted_iter(recent(1));
        Plateau.mean_impulse = mean(window_impulse);
        Plateau.range = window_range;
    end
end


function RunState = mark_plateau_stop(RunState, Plateau, plateau)
% MARK_PLATEAU_STOP 在 RunState 上写入平台停止标记（只写停止三项，不动参考和信赖域）。

    RunState.stop = true;
    RunState.stop_reason = 'performance_plateau';
    RunState.stop_detail = sprintf( ...
        '最近 %d 个被接受轮（自第 %d 轮起）总脉冲极差 %.2e ≤ %g m/s 且对 P2 可行', ...
        plateau.window, Plateau.start_iter, Plateau.range, plateau.tolerance);
end


function RunInfo = build_run_info(Plateau, stopped_by_plateau, iter_seconds)
% BUILD_RUN_INFO 整理本实验的运行信息；只有因平台停止时才记平台起始轮等量。

    RunInfo.plateau_reached = stopped_by_plateau;
    if stopped_by_plateau
        RunInfo.plateau_start_iter = Plateau.start_iter;
        RunInfo.plateau_mean_impulse = Plateau.mean_impulse;
        RunInfo.plateau_range = Plateau.range;
    else
        RunInfo.plateau_start_iter = NaN;
        RunInfo.plateau_mean_impulse = NaN;
        RunInfo.plateau_range = NaN;
    end
    RunInfo.iter_seconds = iter_seconds(:);
end
