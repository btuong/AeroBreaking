function [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config)
% INITIALIZE_SCP_RUN 初始化 SCP 参考、信赖域、计数器、迭代历史与诊断历史。
%
% 本函数依次完成：
%   1. 保存初始参考及其传播结果。
%   2. 设定当前参考、最后接受解（空）和初始信赖域。
%   3. 清零尝试/接受计数和停止标志。
%   4. 预先分配迭代历史和诊断历史的空位。
%
% 初始参考不是第零轮接受解。
% config.unit_norm.mode = 'ccd_lu' 且 ccd_normalize_initial_control = true 时，
% 当前参考的非零控制节点在 build_reference_view 里归一化到圆上（零向量节点保持 (0, 0)，
% RunState.initial_reference 保持原样）；regularized 下不做任何改动。

    %% 1. 保存初始参考及其传播结果
    RunState.initial_reference = InitialReference;
    RunState.initial_propagation = InitialPropagation;

    %% 2. 设定当前参考、最后接受解（空）和初始信赖域
    RunState.current_reference = build_reference_view(InitialReference, config);
    RunState.last_accepted_solution = [];
    RunState.trust_region = initialize_trust_region_state(config);

    %% 3. 清零尝试/接受计数和停止标志
    RunState.num_attempted = 0;
    RunState.num_accepted = 0;
    RunState.has_accepted_solution = false;
    RunState.last_attempt_success = false;
    RunState.stop = false;
    RunState.stop_reason = '';
    RunState.stop_detail = '';

    %% 4. 预先分配迭代历史和诊断历史的空位
    RunState.history = repmat( ...
        create_empty_iteration_record(), config.iter.max_scp_iter, 1);
    DiagnosticsHistory = repmat( ...
        create_empty_iteration_diagnostics(), config.iter.max_scp_iter, 1);
end


function Reference = build_reference_view(InitialReference, config)
% BUILD_REFERENCE_VIEW 从初始参考构造当前参考视图。
%
% 参考只携带 P3 消费的节点数据：网格元数据（N, tau, PointsBounds）
% 与可变参考量（state, control, t_f）；打靶诊断字段不进入参考。
% ccd_lu 模式且 ccd_normalize_initial_control = true 时，仅对非零控制节点归一化
% u_i ← u_i/‖u_i‖_2；零向量节点不替换，保持为 (0, 0)。regularized 下控制保持原值。

    Reference.N = InitialReference.N;
    Reference.tau = InitialReference.tau;
    Reference.PointsBounds = InitialReference.PointsBounds;
    Reference.state = InitialReference.state;
    Reference.control = InitialReference.control;
    Reference.t_f = InitialReference.t_f;

    UnitNorm = describe_unit_norm(config);
    if UnitNorm.is_ccd_lu && UnitNorm.normalize_initial_control
        u1 = Reference.control.u1(:);
        u2 = Reference.control.u2(:);
        norm_u = hypot(u1, u2);
        nonzero = norm_u >= 1e-12;
        u1(nonzero) = u1(nonzero) ./ norm_u(nonzero);
        u2(nonzero) = u2(nonzero) ./ norm_u(nonzero);
        Reference.control.u1 = u1;
        Reference.control.u2 = u2;
    end
end
