function ControlReport = evaluate_control_report( ...
        SolverResult, VariableIndex, objective, LinearConstraints, ...
        ConicConstraints, CurrentReference, config)
% EVALUATE_CONTROL_REPORT 由 P3 的解和对偶解算出控制量报告：紧性、σ 的偏向和 u 列驻点条件的对偶分解。
%
% 只报告，不参与接受、半径更新和停止。每次 P3 求解成功后算一次，存进
% SubproblemDiag.control_report；打印和保存只读它。
%
% 数学形式:
%   u_i = (u1_i, u2_i)，σ_i = atan2d(u2_i, u1_i)，紧性差 1 − ‖u_i‖（无损凸化取紧时为 0）。
%   正则项系数 c_reg,i = (c(u1_i), c(u2_i))，直接取装配好的目标向量 c 的 u 列，
%   不按公式重算；Γ 的节点贡献 gamma_node,i = c_reg,i · u_i。
%   u 列的驻点条件按来源拆成 s_reg、s_dyn、s_rate、s_bound，锥贡献 s_cone
%   （见 compute_control_dual_split）。主问题需求 s_main = s_dyn + s_rate + s_bound：
%       reg_ratio       = ‖s_reg‖ / ‖s_main‖
%       σ_main          = atan2d(−s_main,2, −s_main,1)，只听主问题时 u 会指向的方向
%       σ_shift         = σ − σ_main，规约到 (−180°, 180°]，正则项把 σ 拉偏的量
%
% 代码形式:
%   ω_i 取本版本 build_objective 用的梯形积分权（compute_integration_weights）。
%   对偶解不可用时对偶相关字段为 NaN，dual_available = false 并记原因，其余照算。
%   逐圈汇总和全程汇总由 summarize_control_report 给出。
%
% 本函数依次完成：
%   1. 取节点信息：序号、所属圈、圈内 τ、积分权。
%   2. 取控制量、紧性差和 σ。
%   3. 取正则项系数和 u 列驻点条件的对偶分解。
%   4. 算由分解导出的分析量。
%   5. 算余量、互补积、抵消和弦上平坦指标。
%   6. 逐圈汇总和全程汇总。

    num_nodes = CurrentReference.N;
    u_index = [VariableIndex.u1(:), VariableIndex.u2(:)];
    primal = SolverResult.primal(:);

    %% 1. 取节点信息：序号、所属圈、圈内 τ、积分权
    ControlReport = create_empty_control_report('');
    ControlReport.evaluated = true;
    ControlReport.num_nodes = num_nodes;
    ControlReport.num_circuits = numel(CurrentReference.PointsBounds);
    ControlReport.tightness_tolerance = ...
        config.validation.lossless_tightness_tolerance;
    ControlReport.node = (1:num_nodes).';
    ControlReport.cir = list_node_circuits( ...
        CurrentReference.PointsBounds, num_nodes);
    ControlReport.tau = CurrentReference.tau(:);
    ControlReport.omega = compute_integration_weights( ...
        CurrentReference.tau, CurrentReference.PointsBounds);
    regularizer_weights = ControlReport.omega;
    if ~describe_control_regularizer(config).use_integration_weights
        regularizer_weights = ones(num_nodes, 1);
    end

    %% 2. 取控制量、紧性差和 σ
    ControlReport.u1 = primal(u_index(:, 1));
    ControlReport.u2 = primal(u_index(:, 2));
    ControlReport.u_norm = hypot(ControlReport.u1, ControlReport.u2);
    ControlReport.tight_gap = 1 - ControlReport.u_norm;
    ControlReport.sigma_deg = atan2d(ControlReport.u2, ControlReport.u1);

    %% 3. 取正则项系数和 u 列驻点条件的对偶分解
    % 系数直接取自实际装配的目标向量，改正则项后这里不用改
    ControlReport.c_reg = reshape(objective(u_index(:)), num_nodes, 2);
    Split = compute_control_dual_split( ...
        SolverResult.dual, objective, LinearConstraints, ConicConstraints, u_index);
    ControlReport.dual_available = Split.available;
    ControlReport.dual_reason = Split.reason;
    ControlReport.s_reg = Split.s_reg;
    ControlReport.s_dyn = Split.s_dyn;
    ControlReport.s_rate = Split.s_rate;
    ControlReport.s_bound = Split.s_bound;
    ControlReport.s_total = Split.s_total;
    ControlReport.s_cone = Split.s_cone;
    ControlReport.stationarity_residual = Split.stationarity_residual;
    ControlReport.s_main = Split.s_main;

    %% 4. 算由分解导出的分析量
    ControlReport.s_reg_norm = vecnorm(ControlReport.s_reg, 2, 2);
    ControlReport.s_main_norm = vecnorm(ControlReport.s_main, 2, 2);
    ControlReport.reg_ratio = ...
        ControlReport.s_reg_norm ./ ControlReport.s_main_norm;
    ControlReport.sigma_main_deg = atan2d( ...
        -ControlReport.s_main(:, 2), -ControlReport.s_main(:, 1));
    ControlReport.sigma_shift_deg = wrap_angle_deg( ...
        ControlReport.sigma_deg - ControlReport.sigma_main_deg);
    ControlReport.gamma_node = ControlReport.c_reg(:, 1) .* ControlReport.u1 ...
        + ControlReport.c_reg(:, 2) .* ControlReport.u2;
    if strcmp(describe_control_regularizer(config).type, 'norm_gap')
        ControlReport.gamma_node = ControlReport.gamma_node ...
            + config.objective.weight_control_reg * regularizer_weights;
    end

    %% 5. 算余量、互补积、抵消和弦上平坦指标
    MechanismReport = evaluate_control_tightness_mechanisms( ...
        SolverResult, LinearConstraints, ConicConstraints, ...
        CurrentReference, Split, config, u_index);
    ControlReport.tightness_margin = MechanismReport.margin;
    ControlReport.cone_complementarity = MechanismReport.complementarity;
    ControlReport.complementarity_bound = MechanismReport.complementarity_bound;
    ControlReport.radial_main = MechanismReport.radial_main;
    ControlReport.radial_regularizer = MechanismReport.radial_regularizer;
    ControlReport.cancellation_cosine = MechanismReport.cancellation_cosine;
    ControlReport.cancellation_strength = MechanismReport.cancellation_strength;
    ControlReport.cancellation_candidate = MechanismReport.cancellation_candidate;
    ControlReport.chord_active = MechanismReport.chord_active;
    ControlReport.chord_rank = MechanismReport.chord_rank;
    ControlReport.chord_tangent = MechanismReport.chord_tangent;
    ControlReport.chord_reg_component = MechanismReport.chord_reg_component;
    ControlReport.chord_flatness = MechanismReport.chord_flatness;
    ControlReport.chord_flat = MechanismReport.chord_flat;

    %% 6. 逐圈汇总和全程汇总
    circuit_list = cell(ControlReport.num_circuits, 1);
    for cir = 1:ControlReport.num_circuits
        circuit_list{cir} = summarize_control_report( ...
            ControlReport, ControlReport.cir == cir);
    end
    ControlReport.summary_circuits = vertcat(circuit_list{:});
    ControlReport.summary_total = summarize_control_report( ...
        ControlReport, true(num_nodes, 1));
end


function node_cir = list_node_circuits(PointsBounds, num_nodes)
% LIST_NODE_CIRCUITS 每个节点所属的圈号（N x 1）。

    node_cir = zeros(num_nodes, 1);
    for cir = 1:numel(PointsBounds)
        node_cir(PointsBounds(cir).begin:PointsBounds(cir).end) = cir;
    end
end
