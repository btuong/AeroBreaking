function Summary = build_radius_scan_summary(round_list)
% BUILD_RADIUS_SCAN_SUMMARY 把多轮扫描的评价量排成按轮的数组，供多轮汇总的表和图共用（只抄已算好的量）。
%
% 输入:
%   round_list - 元胞，每个元素是一轮的 ScanRound（solve_radius_scan_round 的输出）
%
% 输出 Summary（各字段都是 1 x M，M 为扫描的轮数，顺序同 round_list）:
%   iters                  轮号
%   status                 运行时这一轮的结果: 'accepted' / 'rejected' / 'failed'（P3 失败）
%   actual_radius          本轮实际半径 r^k
%   actual_zone            r^k 的分区（元胞）
%   zero_radius            松弛为零所需的半径（拐点）
%   hold_radius            能维持的最大半径
%   actual_ratio           扫描在 r^k 上算出的 ρ
%   actual_share           ΔJ(r^k)/max_r ΔJ(r)
%   actual_gain_cost、actual_gain_extra
%                          G(r^k)，性能指标和附加项各一份
%   actual_effective_drop_cost、actual_effective_drop_extra
%                          E(r^k)，性能指标和附加项各一份
%   stage_radius、stage_cost、stage_extra
%                          r_top 和阶段度量 ΔL:性能指标(r_top)、ΔL:附加项(r_top)
%   reference_penalty、reference_cost、reference_extra、reference_impulse
%                          参考处的罚项、性能指标、附加项、总脉冲 (m/s)
%   replay_text            复现自检: '是' / '否' / '-'（无可比）（元胞）

    num_rounds = numel(round_list);
    Summary.iters = zeros(1, num_rounds);
    Summary.status = cell(1, num_rounds);
    Summary.actual_zone = cell(1, num_rounds);
    Summary.replay_text = cell(1, num_rounds);
    names = {'actual_radius', 'zero_radius', 'hold_radius', 'actual_ratio', ...
        'actual_share', 'actual_gain_cost', 'actual_gain_extra', ...
        'actual_effective_drop_cost', 'actual_effective_drop_extra', ...
        'stage_radius', 'stage_cost', 'stage_extra'};
    for n = 1:numel(names)
        Summary.(names{n}) = nan(1, num_rounds);
    end
    Summary.reference_penalty = nan(1, num_rounds);
    Summary.reference_cost = nan(1, num_rounds);
    Summary.reference_extra = nan(1, num_rounds);
    Summary.reference_impulse = nan(1, num_rounds);

    for m = 1:num_rounds
        ScanRound = round_list{m};
        Summary.iters(m) = ScanRound.iter;
        if ~ScanRound.attempt.subproblem_success
            Summary.status{m} = 'failed';
        elseif ScanRound.attempt.accept_candidate
            Summary.status{m} = 'accepted';
        else
            Summary.status{m} = 'rejected';
        end
        Summary.actual_zone{m} = ScanRound.metrics.actual_zone;
        if ~ScanRound.metrics.replay_available
            Summary.replay_text{m} = '-';
        elseif ScanRound.metrics.replay_ok
            Summary.replay_text{m} = '是';
        else
            Summary.replay_text{m} = '否';
        end
        for n = 1:numel(names)
            Summary.(names{n})(m) = ScanRound.metrics.(names{n});
        end
        Summary.reference_penalty(m) = ScanRound.reference_penalty;
        Summary.reference_cost(m) = ScanRound.reference_cost;
        Summary.reference_extra(m) = ScanRound.reference_extra;
        Summary.reference_impulse(m) = ScanRound.reference_impulse;
    end
end
