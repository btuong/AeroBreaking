function sigma_deg = transform_u2sigma(sinx, cosx)
% TRANSFORM_U2SIGMA 由倾侧角分量 (u1, u2) 恢复倾侧角角度（度）。
%
% 输入:
%   sinx - sin(sigma)
%   cosx - cos(sigma)
%
% 输出:
%   sigma_deg - sigma 角度值 (deg)，范围 [0, 360)

    x = atan2(sinx, cosx);

    if x < 0
        x = x + 2 * pi;
    end
    if abs(x - 2 * pi) < eps(x)
        x = 0;
    end
    sigma_deg = rad2deg(x);
end
