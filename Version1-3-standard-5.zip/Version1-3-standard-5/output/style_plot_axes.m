function style_plot_axes(ax, x_label, y_label, config)
% STYLE_PLOT_AXES 统一设置坐标轴字号、轴标签和网格；分块不加标题。
% 字号只读 config.plot.font_size，绘图代码中不另写字号。

    font_size = config.plot.font_size;
    set(ax, 'FontSize', font_size);
    xlabel(ax, x_label, 'FontSize', font_size);
    ylabel(ax, y_label, 'FontSize', font_size);
    grid(ax, 'on');
    box(ax, 'on');
end
