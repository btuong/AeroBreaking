% 运行文献 [15] 双侧共用松弛 CCD 对比实验全部 12 个工况，结束后自动调用汇总分析。
% 公共设置：scp_config_default() 基础上设 iter.tolerance = 0、fixed 信赖域 (r = 1)、
% 在线总脉冲平台停止（最近 5 个被接受轮极差 <= 0.1 m/s 且对 P2 可行），关闭绘图与逐轮打印；
% 严格设置 full_mat = false、scan_mat = false，仅保存 brief_text/detail_text/control_text/control_mat
% 与小文件 case_metrics.mat。
%
% 可选工作区变量（未设则取默认值）:
%   rerun_existing    - 默认 false，已有 case_metrics.mat 时跳过
%   case_filter       - 工况名元胞数组，默认 {} 全跑
%   plateau_window    - 平台窗口长度，默认 5
%   plateau_tolerance - 平台极差阈值 (m/s)，默认 0.1
%   results_folder    - 结果文件夹名（在 twosided_compare 下），默认 'results'
%   run_analysis      - 结束后是否调用 analyze_twosided_compare()，默认 true
% 输出: twosided_compare/<results_folder>/<工况名>/ 下结果文件与 case_metrics.mat。

%% ===== 环境准备 =====
% 本入口保留工作区过滤变量，路径在脚本结束时自动恢复
tic;
compare_root = fileparts(mfilename('fullpath'));
version_root = fileparts(compare_root);
previous_path = path;
restore_compare_path = onCleanup(@() path(previous_path));
modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
    'trust_region', 'validation', 'iteration', 'output'};
for k = 1:numel(modules)
    addpath(fullfile(version_root, modules{k}));
end
addpath(compare_root);
rehash;

if ~exist('rerun_existing', 'var')
    rerun_existing = false;
end
if ~exist('case_filter', 'var')
    case_filter = {};
end
if ~exist('plateau_window', 'var')
    plateau_window = 5;
end
if ~exist('plateau_tolerance', 'var')
    plateau_tolerance = 0.1;
end
if ~exist('results_folder', 'var')
    results_folder = 'results';
end
if ~exist('run_analysis', 'var')
    run_analysis = true;
end

%% ===== 平台判据与工况表 =====
plateau.window = plateau_window;
plateau.tolerance = plateau_tolerance;

Cases = list_compare_cases();
if ~isempty(case_filter)
    Cases = Cases(ismember({Cases.name}, case_filter));
end
results_root = fullfile(compare_root, results_folder);
fprintf(['版本目录: %s\n工况数: %d，平台判据: 最近 %d 个被接受轮极差 <= %g m/s 且对 P2 可行，' ...
    '结果目录: %s\n'], version_root, numel(Cases), plateau.window, ...
    plateau.tolerance, results_root);

%% ===== 逐个运行工况 =====
for c = 1:numel(Cases)
    Case = Cases(c);
    case_directory = fullfile(results_root, Case.name);
    metrics_path = fullfile(case_directory, 'case_metrics.mat');
    if isfile(metrics_path) && ~rerun_existing
        fprintf('[CASE] %s skipped (已有 case_metrics.mat)\n', Case.name);
        continue;
    end

    fprintf('[CASE] %s start (max_iter=%d, P=%.3e, keep=%d, cont=%d, init=%s)\n', ...
        Case.name, Case.max_iter, Case.p, Case.keep_control_bounds, ...
        Case.enable_control_continuity, Case.init_control_mode);
    case_timer = tic;
    try
        config = scp_config_default();
        config.iter.max_scp_iter = Case.max_iter;
        config.iter.tolerance = 0;                 % 关掉步长停止
        config.trust_region.method = 'fixed';
        config.plot.enable_initial = false;
        config.plot.enable_iteration = false;
        config.plot.enable_final = false;
        config.output.print_pre_iteration = false;
        config.output.print_iteration = false;
        config.output.print_summary = false;
        config.output.save.brief_text = true;
        config.output.save.detail_text = true;
        config.output.save.control_text = true;
        config.output.save.control_mat = true;
        config.output.save.scan_mat = false;
        config.output.save.full_mat = false;
        config.output.save.directory = ['twosided_compare/' results_folder '/' Case.name];

        config.unit_norm.mode = 'twosided';
        config.unit_norm.twosided_penalty_weight = Case.p;
        config.unit_norm.twosided_slack_max = Case.slack_max;
        config.unit_norm.twosided_keep_control_bounds = Case.keep_control_bounds;
        config.constraints.enable_control_continuity = Case.enable_control_continuity;

        [Result, ~, SaveReport, RunInfo] = run_compare_case(config, plateau, Case);
        elapsed_seconds = toc(case_timer);

        if ~SaveReport.success
            error('TwosidedCompare:SaveFailed', ...
                '工况 %s 的结果文件未完整写入。', Case.name);
        end
        Metrics = extract_compare_metrics(Result, RunInfo, Case.name, Case, ...
            elapsed_seconds);
        save(metrics_path, 'Metrics');
        error_path = fullfile(case_directory, 'case_error.txt');
        if isfile(error_path)
            delete(error_path);
        end
        final_impulse = NaN;
        if ~isnan(Metrics.final_index)
            final_impulse = Metrics.total_impulse_m_s(Metrics.final_index);
        end
        fprintf(['[CASE] %s done %.1f s, first=%s, stop=%s, 末轮=%d, 平台起始轮=%g, ' ...
            '总脉冲=%.6f m/s\n'], Case.name, elapsed_seconds, Metrics.first_status, ...
            Metrics.stop_reason, Metrics.final_index, Metrics.plateau_start_iter, ...
            final_impulse);
    catch exception
        elapsed_seconds = toc(case_timer);
        if ~isfolder(case_directory)
            mkdir(case_directory);
        end
        error_id = fopen(fullfile(case_directory, 'case_error.txt'), 'w', 'n', 'UTF-8');
        fprintf(error_id, 'identifier: %s\nmessage: %s\n', ...
            exception.identifier, exception.message);
        for s = 1:numel(exception.stack)
            fprintf(error_id, 'at %s (line %d)\n', ...
                exception.stack(s).name, exception.stack(s).line);
        end
        fclose(error_id);
        fprintf('[CASE] %s failed %.1f s: %s (%s)\n', ...
            Case.name, elapsed_seconds, exception.message, exception.identifier);
    end
end
fprintf('ALL_DONE (%.1f s)\n', toc);

%% ===== 汇总分析 =====
if run_analysis && exist('analyze_twosided_compare', 'file') == 2
    analyze_twosided_compare();
end
