function [VariableIndex, num_variables] = build_variable_index( ...
        CurrentReference, ~, config)
% BUILD_VARIABLE_INDEX 构建 M 圈大气跳跃 P3 的决策变量索引。
%
% 变量布局（装配顺序，归一化单位）：
%   r/V/gamma/phi/psi (各 N)      - 大气段节点状态
%   u1/u2 (各 N)                  - 节点倾侧角分量
%   dyn_slack_<s> (各 N-M)        - 动力学等式松弛（s = r..psi）
%   t_dyn_slack_<s> (各 N-M)      - 动力学松弛绝对值上图
%   xff (5) / xff_i (1)           - 末圈远地点终态与倾角
%   t_raf (1) / t_if (1)          - 终端远地点/倾角松弛绝对值上图
%   P (6) / t_P (6)               - 脉冲 P0~P5 及其绝对值上图
%   poi_slack_<s> (各 5)          - 初始+4 内点衔接松弛
%   t_poi_slack_<s> (各 5)        - 衔接松弛绝对值上图
%   t_f (5)                       - 各圈飞行时间
%   unit_norm_slack (N)           - 单位范数松弛 ε（只在 config.unit_norm.mode = 'ccd' 下分配，
%                                  VariableIndex.unit_norm_slack 为 (17N+26):(18N+25)；
%                                  regularized 下为空，变量总数 17N + 25）
%
% 本函数只分配索引，不设置目标系数、约束或边界。

    N = CurrentReference.N;
    total_cir = config.scenario.total_cir;
    UnitNorm = describe_unit_norm(config);

    num_dyn_points = N - total_cir;
    current_index = 0;
    VariableIndex = struct();

    %% 状态变量（大气飞行段）
    VariableIndex.r = current_index + (1:N);
    current_index = current_index + N;
    VariableIndex.V = current_index + (1:N);
    current_index = current_index + N;
    VariableIndex.gamma = current_index + (1:N);
    current_index = current_index + N;
    VariableIndex.phi = current_index + (1:N);
    current_index = current_index + N;
    VariableIndex.psi = current_index + (1:N);
    current_index = current_index + N;

    %% 控制变量
    VariableIndex.u1 = current_index + (1:N);
    current_index = current_index + N;
    VariableIndex.u2 = current_index + (1:N);
    current_index = current_index + N;

    %% 动力学等式松弛及其绝对值上图
    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    for s = 1:numel(state_names)
        VariableIndex.(['dyn_slack_' state_names{s}]) = ...
            current_index + (1:num_dyn_points);
        current_index = current_index + num_dyn_points;
    end
    for s = 1:numel(state_names)
        VariableIndex.(['t_dyn_slack_' state_names{s}]) = ...
            current_index + (1:num_dyn_points);
        current_index = current_index + num_dyn_points;
    end

    %% 终端状态变量（第 5 圈远地点）
    VariableIndex.xff = current_index + (1:5);
    current_index = current_index + 5;   % [r, V, gamma, phi, psi]
    VariableIndex.xff_i = current_index + 1;
    current_index = current_index + 1;   % 终态轨道倾角

    % 目标函数绝对值上图
    VariableIndex.t_raf = current_index + 1;
    current_index = current_index + 1;   % |ra_f - ra_aim|
    VariableIndex.t_if = current_index + 1;
    current_index = current_index + 1;   % |i_f - i_aim|

    %% 脉冲变量（P0~P5）
    VariableIndex.P = current_index + (1:6);
    current_index = current_index + 6;
    VariableIndex.t_P = current_index + (1:6);
    current_index = current_index + 6;   % |P| 上图

    %% 端点/内点衔接松弛（初始点 + 4 个内点）
    for s = 1:numel(state_names)
        VariableIndex.(['poi_slack_' state_names{s}]) = ...
            current_index + (1:5);
        current_index = current_index + 5;
    end
    for s = 1:numel(state_names)
        VariableIndex.(['t_poi_slack_' state_names{s}]) = ...
            current_index + (1:5);
        current_index = current_index + 5;
    end

    %% 各圈飞行时间
    VariableIndex.t_f = current_index + (1:5);
    current_index = current_index + 5;

    %% 单位范数松弛 ε（只在 ccd 模式下分配，排在最后，其余变量的位置不变）
    if UnitNorm.is_ccd
        VariableIndex.unit_norm_slack = current_index + (1:N);
        current_index = current_index + N;
    else
        VariableIndex.unit_norm_slack = zeros(0, 1);
    end

    %% 检查索引连续性和唯一性
    num_variables = current_index;
    all_indices = collect_index_values(VariableIndex);

    if numel(all_indices) ~= num_variables
        error('SCP:IncompleteVariableIndex', ...
            '变量索引数量与 num_variables 不一致。');
    end
    if ~isequal(sort(all_indices), (1:num_variables).')
        error('SCP:InvalidVariableIndex', ...
            '变量索引必须从 1 到 num_variables 连续且唯一。');
    end
end
