function PlotReport = plot_scp_result(FinalizedRun, ConstData, config)
% PLOT_SCP_RESULT 画全程图: 各轮状态量和控制量，P3 求解情况，罚函数 J，预测下降与预测误差，半径与判据，半径平面。
%
% 共 10 扇窗，分五部分:
%   1. 全程优化变量: 各轮状态量、各轮控制量（叠画，横轴为物理时间，颜色表示
%      迭代序号，最后接受解加粗；轮数超过 config.plot.overlay_max_rounds 时只画
%      其中几轮；状态量窗另有各圈 t_f 分块）。
%   2. P3 凸子问题求解情况（横轴为迭代序号，取各轮候选解）:
%      P3 性能指标、附加项与目标（总脉冲和 P5、附加项即控制正则项、P3 目标 L 总值）；
%      P3 关键约束与松弛（终端远地点半径和倾角、动力学松弛、衔接松弛）。
%   3. 罚函数 J: 候选解处的动力学罚项、衔接罚项、终端罚项和 J 总值，
%      第 0 次迭代画初始参考。
%   4. 预测下降与预测误差，两扇窗: 总量（ΔL 与 ΔJ，ΔL、门槛与 D，ρ）；
%      分三部分（性能指标、附加项、罚项三部分各一块的 ΔL、D、ΔJ，罚项）。
%      半径与判据，两扇窗: 半径与步长（半径 r、最大步长/半径、K 估计）；
%      余项与驻点度量（动力学余项按阶、驻点度量）。
%      半径平面: 横轴 r，ΔL、门槛、D 的实测曲线（同一参考点上的求解连线）。
% 横轴为迭代序号的窗里，接受实心点、拒绝空心点、P3 失败画红叉。每扇窗只在底部放一个
% 共用图例（finish_tile_window），分块的坐标区内不放图例。同一分块里的几条线靠颜色和
% 标记形状区分，总量和分项同块时总量粗、分项细，界画虚线（build_analysis_palette）。
% 每扇窗是一个独立图组，单组失败只记进 PlotReport，不影响其他组和后续输出。
% 各轮数据由 build_iteration_plot_data 整理，本函数不随场景改动。
% config.plot.save_figures 为 true 时，各图组画完后按窗口名导出 PNG 到 pictures/。
%
% 本函数依次完成:
%   1. 把各轮记录整理成按迭代排列的绘图序列。
%   2. 画各轮状态量叠加。
%   3. 画各轮控制量叠加。
%   4. 画 P3 性能指标、附加项与目标。
%   5. 画 P3 关键约束与松弛。
%   6. 画罚函数 J。
%   7. 画预测下降与预测误差（两扇窗）。
%   8. 画半径与判据（两扇窗）。
%   9. 画半径平面。
%   10. 汇总各图组的完成、跳过和失败情况。

    PlotReport = create_empty_plot_report();
    if ~config.plot.enable_final
        % 配置关闭了最终绘图
        PlotReport.status = 'disabled';
        PlotReport.success = true;
        return;
    end
    if isempty(FinalizedRun.history)
        % 一轮都没有尝试，没有可画的数据，不算绘图失败
        PlotReport.status = 'no_plot_data';
        PlotReport.success = true;
        return;
    end

    %% 1. 把各轮记录整理成按迭代排列的绘图序列
    HistorySeries = collect_history_series(FinalizedRun, ConstData);

    %% 2. 画各轮状态量叠加
    if ~HistorySeries.has_solution
        % 所有轮 P3 都失败，没有解可叠画
        PlotReport.state_history = create_skipped_plot_group( ...
            'state_history', 'no_solution');
    else
        PlotReport.state_history = run_plot_group('state_history', config, ...
            @() plot_overlay_window('各轮状态量', HistorySeries, ...
                'state_history', config));
    end

    %% 3. 画各轮控制量叠加
    if ~HistorySeries.has_solution
        % 所有轮 P3 都失败，没有解可叠画
        PlotReport.control_history = create_skipped_plot_group( ...
            'control_history', 'no_solution');
    else
        PlotReport.control_history = run_plot_group('control_history', config, ...
            @() plot_overlay_window('各轮控制量', HistorySeries, ...
                'controls', config));
    end

    %% 4. 画 P3 性能指标、附加项与目标
    PlotReport.p3_objective = run_plot_group('p3_objective', config, ...
        @() plot_history_window('P3 性能指标、附加项与目标', HistorySeries.iter, ...
            HistorySeries.status, HistorySeries.p3_objective_tiles, config));

    %% 5. 画 P3 关键约束与松弛
    PlotReport.p3_constraints = run_plot_group('p3_constraints', config, ...
        @() plot_history_window('P3 关键约束与松弛', HistorySeries.iter, ...
            HistorySeries.status, HistorySeries.p3_constraint_tiles, config));

    %% 6. 画罚函数 J
    % 所有轮 P3 都失败时没有罚函数可画
    if isempty(HistorySeries.penalty_tiles)
        PlotReport.penalty = create_skipped_plot_group('penalty', 'no_candidate');
    else
        PlotReport.penalty = run_plot_group('penalty', config, ...
            @() plot_history_window('罚函数 J', HistorySeries.penalty_iter, ...
                HistorySeries.penalty_status, HistorySeries.penalty_tiles, ...
                config));
    end

    %% 7. 画预测下降与预测误差（两扇窗）
    if ~HistorySeries.has_solution
        PlotReport.prediction = create_skipped_plot_group('prediction', 'no_candidate');
    else
        PlotReport.prediction = run_plot_group('prediction', config, ...
            @() plot_prediction_window(HistorySeries, config));
    end

    %% 8. 画半径与判据（两扇窗）
    PlotReport.radius = run_plot_group('radius', config, ...
        @() plot_radius_window(HistorySeries, config));

    %% 9. 画半径平面
    % 全部求解的半径都相同（如固定半径方法）时画不出曲线，跳过
    if ~has_multiple_radii(HistorySeries)
        PlotReport.radius_plane = create_skipped_plot_group( ...
            'radius_plane', 'single_radius');
    else
        PlotReport.radius_plane = run_plot_group('radius_plane', config, ...
            @() plot_radius_plane_window(HistorySeries, config));
    end

    %% 10. 汇总各图组的完成、跳过和失败情况
    PlotReport = summarize_plot_groups(PlotReport);
end


function HistorySeries = collect_history_series(FinalizedRun, ConstData)
% COLLECT_HISTORY_SERIES 逐轮整理绘图数据，并把标量指标拼成随迭代变化的序列。
%
% 输出 HistorySeries:
%   iter, status          - 1 x K 迭代序号与各轮状态（accepted/rejected/failed）
%   plot_data             - 1 x K 元胞，各轮 build_iteration_plot_data 的输出
%   final_index           - 最后接受解在序列中的位置，无接受解为空
%   has_solution          - 是否至少有一轮有解
%   p3_objective_tiles    - P3 性能指标、附加项与目标分块（总脉冲和 P5、附加项、L 总值）
%   p3_constraint_tiles   - P3 关键约束（参考线为目标值）和最大松弛（对数纵轴，
%                           参考线为容差）分块
%   penalty_tiles         - 候选解处 J 的分项分块，横轴含第 0 次（初始参考）
%   penalty_iter, penalty_status - 含第 0 次的迭代序号与状态（第 0 次为 'initial'）

    History = FinalizedRun.history;
    num_iters = numel(History);
    plot_data = cell(1, num_iters);
    for k = 1:num_iters
        plot_data{k} = build_iteration_plot_data(History(k), ConstData);
    end

    HistorySeries.iter = cellfun(@(d) d.iter, plot_data);
    HistorySeries.status = cellfun(@(d) d.status, plot_data, ...
        'UniformOutput', false);
    HistorySeries.plot_data = plot_data;
    HistorySeries.has_solution = any(~strcmp(HistorySeries.status, 'failed'));

    HistorySeries.final_index = [];
    if FinalizedRun.has_accepted_solution
        HistorySeries.final_index = find( ...
            HistorySeries.iter == FinalizedRun.final_iteration.iter, 1);
    end

    iters = HistorySeries.iter;
    HistorySeries.p3_objective_tiles = build_history_tiles( ...
        collect_named_items(plot_data, 'p3_objective'), iters, false);
    key_tiles = build_history_tiles( ...
        collect_named_items(plot_data, 'key_constraints'), iters, false);
    slack_tiles = build_history_tiles( ...
        collect_named_items(plot_data, 'max_slack'), iters, true);
    % 空的分块数组不能直接和非空的拼接，先挑出非空的再拼
    constraint_parts = {key_tiles, slack_tiles};
    constraint_parts = constraint_parts(~cellfun(@isempty, constraint_parts));
    HistorySeries.p3_constraint_tiles = [constraint_parts{:}];

    [HistorySeries.penalty_tiles, HistorySeries.penalty_iter, ...
        HistorySeries.penalty_status] = build_penalty_tiles( ...
        plot_data, iters, HistorySeries.status);
end


function Items = collect_named_items(plot_data, field_name)
% COLLECT_NAMED_ITEMS 按名称把各轮的同名标量指标拼成 K x 1 序列。
%
% 以第一个有该字段数据的轮次为准确定指标清单；失败轮或缺该项的轮记 NaN。

    num_iters = numel(plot_data);
    Items = struct([]);
    template_index = find(cellfun(@(d) ~isempty(d.(field_name)), plot_data), 1);
    if isempty(template_index)
        return;
    end

    Items = rmfield(plot_data{template_index}.(field_name), 'value');
    for j = 1:numel(Items)
        Items(j).values = nan(num_iters, 1);
    end
    for k = 1:num_iters
        Current = plot_data{k}.(field_name);
        for m = 1:numel(Current)
            j = find(strcmp({Items.name}, Current(m).name), 1);
            if ~isempty(j)
                Items(j).values(k) = Current(m).value;
            end
        end
    end
end


function Tiles = build_history_tiles(Items, iters, log_scale)
% BUILD_HISTORY_TILES 按 group 把指标分到各分块，同组每项一条曲线。
%
% 同组指标共用纵轴标签和参考线（取组内第一项的 reference）。曲线名去掉分块名
% 前缀，各分块里同一通道的曲线同名，共用图例里只列一次。

    Tiles = struct([]);
    if isempty(Items)
        return;
    end

    % 先放进元胞再一次拼成结构体数组，避免逐个下标赋值时的类型问题
    groups = unique({Items.group}, 'stable');
    tile_list = cell(1, numel(groups));
    for g = 1:numel(groups)
        members = Items(strcmp({Items.group}, groups{g}));
        curve_list = cell(1, numel(members));
        for m = 1:numel(members)
            % 曲线名去掉分块名前缀（“动力学松弛 r”在“动力学松弛”块里写成“r”），
            % 不同分块里同一通道的名字才一样，共用图例里只列一次
            curve_label = members(m).name;
            prefix = [groups{g} ' '];
            if startsWith(curve_label, prefix)
                curve_label = curve_label(numel(prefix) + 1:end);
            end
            curve_list{m} = build_plot_curve(curve_label, iters, ...
                members(m).values, members(m).style);
        end
        tile_list{g} = build_plot_tile(groups{g}, members(1).y_label, ...
            [curve_list{:}], members(1).reference, ...
            members(1).reference_label, log_scale);
    end
    Tiles = [tile_list{:}];
end


function [Tiles, penalty_iter, penalty_status] = build_penalty_tiles( ...
        plot_data, iters, status)
% BUILD_PENALTY_TILES 候选解处罚函数 J 的分项分块: 动力学罚项、衔接罚项、终端罚项、J 总值。
%
% 数学形式:
%   画的是 J 在各轮候选解处的分项值，第 0 次迭代画初始参考处的值。初始参考取
%   第一个评价过的轮的 evaluation.reference，不另外计算（第一次评价之前没有
%   接受过候选解，参考就是初始参考）。松弛为 0 时，罚项各分项就等于余项乘罚权求和。
%   性能指标和附加项画在 P3 那扇窗里，这里不重复画。
%
% 代码形式:
%   前三块用对数纵轴（终端倾角罚项和终端远地点罚项两条线画在同一块），J 总值用线性
%   纵轴。P3 失败轮没有候选解，留空。所有轮都没有候选解时 Tiles 为空。

    Tiles = struct([]);
    penalty_iter = [0, iters];
    penalty_status = [{'initial'}, status];
    template_index = find(cellfun(@(d) d.penalty.evaluated, plot_data), 1);
    if isempty(template_index)
        return;
    end
    Template = plot_data{template_index}.penalty;
    names = Template.names;

    % 第 1 行是初始参考，第 k + 1 行是第 k 轮候选解
    values = nan(numel(iters) + 1, numel(names));
    totals = nan(numel(iters) + 1, 1);
    values(1, :) = Template.reference;
    totals(1) = Template.reference_total;
    for k = 1:numel(iters)
        Penalty = plot_data{k}.penalty;
        if ~Penalty.evaluated
            continue;
        end
        for m = 1:numel(names)
            j = find(strcmp(Penalty.names, names{m}), 1);
            if ~isempty(j)
                values(k + 1, m) = Penalty.candidate(j);
            end
        end
        totals(k + 1) = Penalty.candidate_total;
    end

    column = @(name) values(:, strcmp(names, name));
    dynamics_curve = build_plot_curve('动力学罚项', penalty_iter, ...
        column('dyn_slack'), 'line');
    junction_curve = build_plot_curve('衔接罚项', penalty_iter, ...
        column('point_slack'), 'line');
    terminal_curves = [ ...
        build_plot_curve('终端倾角罚项', penalty_iter, ...
            column('terminal_inclination'), 'line'), ...
        build_plot_curve('终端远地点罚项', penalty_iter, ...
            column('terminal_apoapsis'), 'line')];
    total_curve = build_plot_curve('罚函数 J', penalty_iter, totals, 'line');
    Tiles = [ ...
        build_plot_tile('动力学罚项', '动力学罚项 (候选解处)', ...
            dynamics_curve, NaN, '', true), ...
        build_plot_tile('衔接罚项', '衔接罚项 (候选解处)', ...
            junction_curve, NaN, '', true), ...
        build_plot_tile('终端罚项', '终端罚项 (候选解处)', ...
            terminal_curves, NaN, '', true), ...
        build_plot_tile('罚函数 J', '罚函数 J (候选解处)', total_curve)];
end


function fig = plot_history_window(name, iters, status, Tiles, config)
% PLOT_HISTORY_WINDOW 新开一扇横轴为迭代序号的窗口并画分块；窗口名以“全程-”开头，与逐轮图的“迭代-”对应。
% iters 与 status 与 Tiles 的曲线横轴一致（罚函数窗含第 0 次）。

    fig = figure('Name', ['全程-' name], 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    draw_history_tiles(fig, iters, status, Tiles, name, config);
end


function fig = plot_overlay_window(name, HistorySeries, field_name, config)
% PLOT_OVERLAY_WINDOW 新开全程窗口，叠画指定 PlotData 分块字段。
% 状态量传 state_history（含各圈 t_f），控制量传 controls。

    fig = figure('Name', ['全程-' name], 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    draw_overlay_tiles(fig, HistorySeries, field_name, name, config);
end


function figs = plot_prediction_window(HistorySeries, config)
% PLOT_PREDICTION_WINDOW 新开两扇窗口画预测下降与预测误差: 总量一扇，三部分一扇。
%
% 总量窗: ΔL 与 ΔJ，ΔL、门槛与 D，ρ。三部分窗: 性能指标、附加项、罚项三部分各一块
% （块里是这一部分的 ΔL、D、ΔJ），再加罚项一块。拆开是为了每块不超过三四条线。

    figs = gobjects(1, 2);
    figs(1) = figure('Name', '全程-预测下降与预测误差', 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    draw_prediction_tiles(figs(1), HistorySeries, config);
    figs(2) = figure('Name', '全程-预测下降与预测误差-分三部分', ...
        'NumberTitle', 'off', 'Visible', config.plot.visibility);
    draw_prediction_part_tiles(figs(2), HistorySeries, config);
end


function figs = plot_radius_window(HistorySeries, config)
% PLOT_RADIUS_WINDOW 新开两扇窗口画半径与判据: 半径与步长一扇，余项与驻点度量一扇。

    figs = gobjects(1, 2);
    figs(1) = figure('Name', '全程-半径与步长', 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    draw_radius_tiles(figs(1), HistorySeries, config);
    figs(2) = figure('Name', '全程-余项与驻点度量', 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    draw_stationarity_tiles(figs(2), HistorySeries, config);
end


function fig = plot_radius_plane_window(HistorySeries, config)
% PLOT_RADIUS_PLANE_WINDOW 新开一扇窗口画半径平面: 横轴 r，ΔL、门槛、D。

    fig = figure('Name', '全程-半径平面', 'NumberTitle', 'off', ...
        'Visible', config.plot.visibility);
    draw_radius_plane_tiles(fig, HistorySeries, config);
end


function has_multiple = has_multiple_radii(HistorySeries)
% HAS_MULTIPLE_RADII 评价过的求解里是否出现了两种及以上的半径 r。

    TrustData = collect_trust_series(HistorySeries);
    evaluated = [TrustData.evaluated];
    radius = [TrustData.scale_before];
    has_multiple = numel(unique(radius(evaluated))) >= 2;
end


function PlotGroup = run_plot_group(name, config, plot_function)
% RUN_PLOT_GROUP 执行一个独立图组，记录图形句柄或失败信息。
% config.plot.save_figures 为 true 时，图组画完后把每扇窗导出为 PNG。

    PlotGroup = create_empty_plot_group(name);
    PlotGroup.requested = true;
    try
        PlotGroup.figure_handles = plot_function();
        PlotGroup.completed = true;
    catch exception
        PlotGroup.error_identifier = exception.identifier;
        PlotGroup.error_message = exception.message;
        warning('SCP:PlotGroupFailed', '图组 %s 绘制失败：%s', ...
            name, exception.message);
    end
    if PlotGroup.completed && config.plot.save_figures
        export_plot_group_figures(PlotGroup);
    end
end


function export_plot_group_figures(PlotGroup)
% EXPORT_PLOT_GROUP_FIGURES 把已完成图组的每扇窗按窗口名导出到 pictures/。
% 单扇失败只告警，不影响其他窗和后续输出。

    for fig = PlotGroup.figure_handles(:).'
        try
            save_plot_figure(fig, fullfile('pictures', fig.Name));
        catch exception
            warning('SCP:FigureExportFailed', ...
                '图组 %s 导出失败：%s', PlotGroup.name, exception.message);
        end
    end
end


function PlotGroup = create_skipped_plot_group(name, reason)
% CREATE_SKIPPED_PLOT_GROUP 创建一个明确跳过的图组记录。

    PlotGroup = create_empty_plot_group(name);
    PlotGroup.skipped = true;
    PlotGroup.skip_reason = reason;
end


function PlotGroup = create_empty_plot_group(name)
% CREATE_EMPTY_PLOT_GROUP 创建统一 schema 的空图组记录。

    PlotGroup.name = name;
    PlotGroup.requested = false;
    PlotGroup.completed = false;
    PlotGroup.skipped = false;
    PlotGroup.skip_reason = '';
    PlotGroup.figure_handles = gobjects(0);
    PlotGroup.error_identifier = '';
    PlotGroup.error_message = '';
end


function PlotReport = create_empty_plot_report()
% CREATE_EMPTY_PLOT_REPORT 创建统一 schema 的空绘图报告，各图组均未执行。

    PlotReport.status = 'not_run';
    PlotReport.success = false;
    PlotReport.failed_groups = {};
    for name = plot_group_names()
        PlotReport.(name{1}) = create_empty_plot_group(name{1});
    end
end


function PlotReport = summarize_plot_groups(PlotReport)
% SUMMARIZE_PLOT_GROUPS 汇总各图组：请求了却没完成的算失败。

    names = plot_group_names();
    is_failed = cellfun(@(n) PlotReport.(n).requested ...
        && ~PlotReport.(n).completed, names);
    PlotReport.failed_groups = names(is_failed);
    PlotReport.success = ~any(is_failed);
    if PlotReport.success
        PlotReport.status = 'completed';
    else
        PlotReport.status = 'partially_failed';
    end
end


function names = plot_group_names()
% PLOT_GROUP_NAMES 默认图组的名称；追加图组时在这里同步加名称。

    names = {'state_history', 'control_history', 'p3_objective', ...
        'p3_constraints', 'penalty', 'prediction', 'radius', 'radius_plane'};
end
