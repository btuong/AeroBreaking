function [ConstData, InitialState] = initialize_problem(~)
% INITIALIZE_PROBLEM 初始化气动辅助降轨问题的物理常数、归一化尺度和固定初始状态。
%
% 本函数依次完成：
%   1. 设置地球/大气/载具物理常数和 LU-TU 归一化尺度。
%   2. 组装路径约束上限与目标圆轨道数据到 ConstData。
%   3. 从 121 km 标称大气入口状态反向积分构造 P1 初始 ECI 状态 rv00。
%   4. 记录标称入口状态与 rv00 的轨道根数诊断到 InitialState。
%
% ConstData 字段（除注明外均为归一化单位）：
%   物理常数  M,C_D,C_L,S,J2,we,Rho0,hs,RM,hatm,mu,R_atm,g0,kU
%   尺度      LU=hatm (m)，TU=1000 (s)，VU,AU 为派生速度/加速度单位
%   路径上限  Qdot_max (W/cm^2)，N_max，q_max (N/m^2)，kQ
%   目标轨道  R_aaim,R_paim,i_aim
%   初始状态  rv00 - 1x6 ECI [r,v]，P1 的固定初始点 y0

    ConstData = struct();
    InitialState = struct();

    %% 1. 设置地球/大气/载具物理常数和 LU-TU 归一化尺度
    ConstData.M = 10387;        % 航天器质量 (kg)
    ConstData.C_D = 1.37;       % 阻力系数
    ConstData.C_L = 1.37 * 0.27;  % 升力系数
    ConstData.S = 19.86;        % 参考迎风面积 (m^2)
    ConstData.J2 = 1.0826269e-3;
    ConstData.we = 2 * pi / (23 * 3600 + 56 * 60 + 4);  % 地球自转角速度 (rad/s)

    ConstData.Rho0 = 1.225;     % 海平面大气密度 (kg/m^3)
    ConstData.hs = 7100;        % 大气标高 (m)
    ConstData.RM = 6378.137 * 10^3;  % 地球半径 (m)
    ConstData.hatm = 182.9 * 1e3;   % 大气层高度 (m)
    ConstData.mu = 398600.4415 * 10^9;  % 地球引力常数 (m^3/s^2)

    ConstData.LU = ConstData.hatm;  % 长度单位 (m)
    ConstData.TU = 1000;            % 时间单位 (s)
    ConstData.VU = ConstData.LU / ConstData.TU;
    ConstData.AU = ConstData.LU / ConstData.TU^2;

    scale_values = [ConstData.LU; ConstData.TU; ConstData.VU; ConstData.AU];
    if any(~isfinite(scale_values) | scale_values <= 0)
        error('SCP:InvalidNormalizationScale', ...
            '归一化尺度必须为有限正数。');
    end

    % 归一化后的常用常数
    ConstData.hs = ConstData.hs / ConstData.LU;
    ConstData.RM = ConstData.RM / ConstData.LU;
    ConstData.hatm = ConstData.hatm / ConstData.LU;
    ConstData.R_atm = ConstData.hatm + ConstData.RM;
    ConstData.mu = ConstData.mu / ConstData.LU^3 * ConstData.TU^2;
    ConstData.g0 = ConstData.mu / ConstData.RM^2;
    ConstData.we = ConstData.we * ConstData.TU;

    %% 2. 组装路径约束上限与目标圆轨道数据到 ConstData
    ConstData.Qdot_max = 800;   % 热流密度上限 (W/cm^2)
    ConstData.N_max = 3;        % 过载上限
    ConstData.q_max = 10 * 1e3;  % 动压上限 (N/m^2)
    ConstData.kQ = 9.4369e-9;   % 热流系数

    ConstData.R_aaim = 6678e3 / ConstData.LU;  % 目标圆轨道半径
    ConstData.R_paim = 6678e3 / ConstData.LU;
    ConstData.i_aim = deg2rad(86);             % 目标轨道倾角

    %% 3. 从 121 km 标称大气入口状态反向积分构造 P1 初始 ECI 状态 rv00
    % 标称状态取在 121 km 高度（仅用于构造 rv00，不是 P1 的约束）
    x_nominal = [ ...
        ConstData.RM + 121e3 / ConstData.LU; ...
        12.02 * 1e3 / ConstData.VU; ...
        deg2rad(-5.91); ...
        deg2rad(-46.67); ...
        deg2rad(0); ...
        deg2rad(-116.5)];

    % 反向积分到大气边界 R_atm
    opts_entry = odeset( ...
        'Events', @(t, y) event_atmosphere_exit_state(t, y, ConstData.R_atm, 0), ...
        'RelTol', 1e-9, 'AbsTol', 1e-10);
    [~, x_list] = ode45( ...
        @(t, x) evaluate_atmospheric_dynamics(t, x, 1, 0, ConstData), ...
        [0, -500 / ConstData.TU], x_nominal, opts_entry);
    x_atm = x_list(end, :);

    [r_atm_ecf, v_atm_ecf] = transform_state2rv(x_atm);
    [r_atm_eci, v_atm_eci] = transform_ecf2eci( ...
        0, ConstData.we, r_atm_ecf, v_atm_ecf);

    % 大气边界处在真空中反向积分 24 h
    opts_vacuum = odeset('RelTol', 1e-11, 'AbsTol', 1e-11);
    [~, rv_list] = ode45( ...
        @(t, x) evaluate_vacuum_dynamics( ...
            ConstData.mu, ConstData.J2, ConstData.RM, x), ...
        [0, -24 * 3600 / ConstData.TU], ...
        [r_atm_eci; v_atm_eci], opts_vacuum);

    r24 = rv_list(end, 1:3);
    v24 = rv_list(end, 4:6);
    ele24 = transform_rv2elements(r24, v24, ConstData.mu);
    rp24 = ele24(1) * (1 - ele24(2));
    vp24 = norm(cross(r24, v24)) / rp24;

    ConstData.rv00 = [r24, v24];
    if any(~isfinite(ConstData.rv00))
        error('SCP:InvalidInitialState', ...
            '初始 ECI 状态 rv00 必须全部有限。');
    end

    %% 4. 记录标称入口状态与 rv00 的轨道根数诊断到 InitialState
    InitialState.x_nominal = x_nominal;  % 6x1 ECF 球坐标（构造用标称点）
    InitialState.x_atm = x_atm;          % 1x6 反向积分得到的大气边界状态
    InitialState.r24 = r24;              % 1x3 ECI 位置
    InitialState.v24 = v24;              % 1x3 ECI 速度
    InitialState.ele24 = ele24;          % 1x6 轨道根数 [a e i RA w TA]
    InitialState.rp24 = rp24;            % 近地点半径
    InitialState.vp24 = vp24;            % 近地点速度
end
