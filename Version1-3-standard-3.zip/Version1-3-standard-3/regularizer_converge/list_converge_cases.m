function Cases = list_converge_cases()
% LIST_CONVERGE_CASES 列出控制正则长迭代对比实验的 21 个工况（与阶段2 相同）。
%
% 工况 = type ∈ {sum, u1, u2, norm} × w ∈ {1e-2, 1e-3, 1e-4, 1e-5, 1e-6}，再加 none。
% 入口脚本与分析函数共用这张表，保证工况名和顺序一致。
%
% 输出 Cases（1 x 21 结构体数组）:
%   name - 工况名，如 'sum_w1e-3'、'norm_w1e-5'、'none'
%   type - 控制正则方式 'sum'、'u1'、'u2'、'norm'、'none'
%   w    - 控制正则系数 w_reg；'none' 忽略 w，记 NaN

    type_list = {'sum', 'u1', 'u2', 'norm'};
    exponent_list = [2, 3, 4, 5, 6];   % w = 1e-exponent
    case_list = cell(1, numel(type_list) * numel(exponent_list) + 1);
    count = 0;
    for t = 1:numel(type_list)
        for e = 1:numel(exponent_list)
            count = count + 1;
            % 用字符串转换得到与字面量 1e-5 逐位相同的 w（10^(-5) 与 1e-5 末位可能不同，
            % 而 SCP 对 w 的末位扰动敏感）
            case_list{count} = struct( ...
                'name', sprintf('%s_w1e-%d', type_list{t}, exponent_list(e)), ...
                'type', type_list{t}, 'w', str2double(sprintf('1e-%d', exponent_list(e))));
        end
    end
    case_list{end} = struct('name', 'none', 'type', 'none', 'w', NaN);
    Cases = [case_list{:}];
end
