% R1 第二项（逐轮总脉冲对照阶段3-1 存档，全精度重跑）、κ̂ 残差的最大值、ccd 入口 10 轮的末轮量（一次性脚本，不进主链）。
version_root = 'E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-standard-5';
s3_root = 'E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-standard-3';
cd(version_root);
addpath('setup','dynamics','constraints','subproblem','trust_region','validation','iteration','output');

%% 1. R1 第二项：按入口配置（regularized，10 轮，norm，w_reg = 1e-4）重跑，逐轮总脉冲与阶段3-1 存档比较
config = quiet_config(scp_config_default());
config.iter.max_scp_iter = 10;
config.objective.control_reg_type = 'norm';
config.objective.weight_control_reg = 1e-4;
config.unit_norm.mode = 'regularized';
[ConstData, InitialState] = initialize_problem(config);
[InitialReference, InitialPropagation] = generate_initial_reference(ConstData, InitialState, config);
[RunState, ~] = initialize_scp_run(InitialReference, InitialPropagation, config);
impulse = nan(1, 10);
for iter = 1:10
    [Sol, Diag] = solve_scp_subproblem(RunState.current_reference, RunState.trust_region, ConstData, config, iter);
    TR = update_trust_region(Sol, Diag, RunState.current_reference, RunState.trust_region, ConstData, config, iter);
    [RunState, ~] = advance_scp_iteration(RunState, Sol, Diag, TR, ConstData, config, iter);
    impulse(iter) = Diag.p2_feasibility.performance_report.value;
end
S = load(fullfile(s3_root, 'regularizer_converge', 'results', 'norm_w1e-4', 'case_metrics.mat'));
ref = S.Metrics.total_impulse_m_s(1:10);
fprintf('R1-2: s5 = %s\n', mat2str(impulse, 17));
fprintf('R1-2: s3 = %s\n', mat2str(ref(:).', 17));
diffv = abs(impulse(:) - ref(:));
fprintf('R1-2: max |diff| = %.3e, first nonzero at iter %d, num nonzero = %d, s5 case name %s\n', max(diffv), find(diffv > 0, 1), sum(diffv > 0), S.Metrics.case_name);
% 入口 SCP.m 刚跑的 brief 里的末轮总脉冲（文本 10 位有效数字）
brief = fileread(fullfile(version_root, 'results', 'scp_run_brief.txt'));
tok = regexp(brief, 'final_p2_total_impulse_m_per_s: ([0-9.e+-]+)', 'tokens', 'once');
fprintf('R1-2: brief final impulse = %s, rerun final = %.10e, s3 final = %.10e\n', tok{1}, impulse(end), ref(end));

%% 2. κ̂ 残差的最大值（ccd，p = 1，3 轮）
config = quiet_config(scp_config_default());
config.unit_norm.mode = 'ccd';
config.validation.enable_trapezoid_check = false;
[ConstData, InitialState] = initialize_problem(config);
[InitialReference, InitialPropagation] = generate_initial_reference(ConstData, InitialState, config);
[RunState, ~] = initialize_scp_run(InitialReference, InitialPropagation, config);
p = config.unit_norm.ccd_penalty_weight;
for iter = 1:3
    Ref = RunState.current_reference;
    [Sol, Diag] = solve_scp_subproblem(Ref, RunState.trust_region, ConstData, config, iter);
    TR = update_trust_region(Sol, Diag, Ref, RunState.trust_region, ConstData, config, iter);
    [RunState, ~] = advance_scp_iteration(RunState, Sol, Diag, TR, ConstData, config, iter);
    [VI, ~] = build_variable_index(Ref, ConstData, config);
    R = Diag.control_report;
    slx = Diag.solver.dual.slx(VI.unit_norm_slack(:)); sux = Diag.solver.dual.sux(VI.unit_norm_slack(:));
    res = R.cone_dual_leading - (p * R.omega - slx + sux);
    fprintf('ccd iter %d: max|kappa - (p w - slx + sux)| = %.3e, max rel = %.3e, max|stationarity_residual(u)| = %.3e, mosek dviol con %.2e\n', ...
        iter, max(abs(res)), max(abs(res) ./ max(abs(R.cone_dual_leading), 1e-300)), ...
        max(abs(R.stationarity_residual), [], 'all'), Diag.solver.mosek_report.dual_violation_con);
end

%% 3. ccd 入口 10 轮（p = 1，ε_max = 1，其余同默认入口）：末轮总脉冲和 max|1-‖u‖|
config = scp_config_default();
config.iter.max_scp_iter = 10;
config.objective.control_reg_type = 'norm';
config.objective.weight_control_reg = 1e-4;
config.unit_norm.mode = 'ccd';
config = quiet_config(config);
[ConstData, InitialState] = initialize_problem(config);
[InitialReference, InitialPropagation] = generate_initial_reference(ConstData, InitialState, config);
[RunState, ~] = initialize_scp_run(InitialReference, InitialPropagation, config);
maxgap = nan(1, 10); maxeps = nan(1, 10); ncapped = nan(1, 10); imp = nan(1, 10);
for iter = 1:10
    [Sol, Diag] = solve_scp_subproblem(RunState.current_reference, RunState.trust_region, ConstData, config, iter);
    TR = update_trust_region(Sol, Diag, RunState.current_reference, RunState.trust_region, ConstData, config, iter);
    [RunState, ~] = advance_scp_iteration(RunState, Sol, Diag, TR, ConstData, config, iter);
    if Diag.success
        R = Diag.control_report;
        maxgap(iter) = R.summary_total.max_abs_tight_gap; maxeps(iter) = max(R.unit_norm_slack);
        ncapped(iter) = R.summary_total.num_slack_capped; imp(iter) = Diag.p2_feasibility.performance_report.value;
        fprintf('ccd entry iter %d: accepted %d, impulse %.4f, max|1-|u|| = %.3e, max eps = %.3e, capped %d, min(u_norm)-1 = %.3e, feasibility_report.success %d, rho %.6f, unit_norm_penalty D %.3e\n', ...
            iter, TR.accept_candidate, imp(iter), maxgap(iter), maxeps(iter), ncapped(iter), min(R.u_norm) - 1, ...
            Diag.p3_check.solver_feasibility_report.success, TR.evaluation.ratio, TR.evaluation.term_prediction_error(end));
    else
        fprintf('ccd entry iter %d: FAILED (%s)\n', iter, Diag.solver.status);
    end
    if RunState.stop, break; end
end
fprintf('ccd entry: stop %d (%s), accepted %d, final impulse %.4f m/s, final max|1-|u|| = %.3e, final max eps = %.3e\n', ...
    RunState.stop, RunState.stop_reason, RunState.num_accepted, imp(RunState.num_accepted), maxgap(RunState.num_accepted), maxeps(RunState.num_accepted));
disp('DIAG_DONE');

function config = quiet_config(config)
% QUIET_CONFIG 关掉绘图、打印和保存（一次性诊断脚本用）。
    config.plot.enable_initial = false; config.plot.enable_iteration = false; config.plot.enable_final = false;
    config.output.print_pre_iteration = false; config.output.print_iteration = false; config.output.print_summary = false;
    config.output.save.brief_text = false; config.output.save.detail_text = false; config.output.save.scan_mat = false;
    config.output.save.full_mat = false; config.output.save.control_text = false; config.output.save.control_mat = false;
end
