function compare_norm_vs_norm_gap()
% COMPARE_NORM_VS_NORM_GAP 对比 -‖u‖ ('norm') 与 1-‖u‖ ('norm_gap') 在不同罚权 w 下的表现。
%
% 覆盖常规小权 (1e-6..1e-2) 与大权 (1e-1..1e2)，各跑 10 轮 (fixed r=1，不覆盖 results/)，
% 重点检查：
%   1) 求解成功率、MOSEK 内点迭代数、末轮 P3 目标值 pobj（验证 cfix 是否生效）；
%   2) 末轮物理总脉冲 C (m/s) 及两种写法的差值；
%   3) 全程与末轮紧性差 gap = 1 - ‖u‖（验证大 w 时 MOSEK 相对对偶间隙是否卡住 -‖u‖ 的紧性）；
%   4) 目标分解一致性 |pobj - ObjectiveTerms.total| 与 Γ 预测误差 D_Gamma。

    tests_dir = fileparts(mfilename('fullpath'));
    version_root = fileparts(tests_dir);
    [~, version_name] = fileparts(version_root);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));

    modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
        'trust_region', 'validation', 'iteration', 'output', 'tests'};
    for k = 1:numel(modules)
        addpath(fullfile(version_root, modules{k}));
    end
    rehash;

    weights = [1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1, 10, 100];
    reg_types = {'norm', 'norm_gap'};

    fprintf('=== %s: -‖u‖ (norm) vs 1-‖u‖ (norm_gap) 不同罚权对比 (10 轮, fixed r=1) ===\n\n', ...
        version_name);
    fprintf('%-8s %7s | %4s | %9s | %11s | %10s | %10s | %10s | %5s | %9s\n', ...
        'type', 'w_reg', 'ok', 'DV(m/s)', 'pobj_last', 'maxGapAll', 'maxGapEnd', 'medGapEnd', 'mIter', 'objErr');
    fprintf('%s\n', repmat('-', 1, 106));

    for iw = 1:numel(weights)
        w_reg = weights(iw);
        res = cell(1, 2);
        for it = 1:2
            res{it} = run_case(reg_types{it}, w_reg);
            r = res{it};
            fprintf('%-8s %7.0e | %2d/10 | %9.4f | %11.3e | %10.2e | %10.2e | %10.2e | %5.1f | %9.2e\n', ...
                r.reg_type, r.w_reg, r.ok_iters, r.dv_last, r.pobj_last, ...
                r.max_gap_all, r.max_gap_last, r.med_gap_last, r.mean_mosek_iter, r.max_obj_err);
        end
        if res{1}.ok_iters == 10 && res{2}.ok_iters == 10
            dv_diff = res{2}.dv_last - res{1}.dv_last;
            sig_diff = max(abs(wrap_angle_deg(res{2}.sigma_last - res{1}.sigma_last)));
            fprintf('  -> 差值(1-‖u‖ 减 -‖u‖): ΔDV = %+.4e m/s | max|Δσ| = %.4f deg | maxGapEnd比 = %.3f\n', ...
                dv_diff, sig_diff, res{2}.max_gap_last / max(res{1}.max_gap_last, 1e-30));
        end
        fprintf('\n');
    end
end


function Summary = run_case(reg_type, w_reg)
% RUN_CASE 运行单个 (reg_type, w_reg) 工况并返回汇总指标。

    config = scp_config_default();
    config.iter.max_scp_iter = 10;
    config.iter.tolerance = 0;
    config.objective.control_reg_type = reg_type;
    config.objective.weight_control_reg = w_reg;

    config.plot.enable_initial = false;
    config.plot.enable_iteration = false;
    config.plot.enable_final = false;
    config.output.print_pre_iteration = false;
    config.output.print_iteration = false;
    config.output.print_summary = false;
    config.output.save.brief_text = false;
    config.output.save.detail_text = false;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    config.output.save.control_text = false;
    config.output.save.control_mat = false;
    config.validation.enable_trapezoid_check = false;

    [ConstData, InitialState] = initialize_problem(config);
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, config);
    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);

    ok_iters = 0;
    max_gap_all = 0;
    max_obj_err = 0;
    mosek_iters = [];
    dv_last = NaN;
    pobj_last = NaN;
    max_gap_last = NaN;
    med_gap_last = NaN;
    sigma_last = [];

    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);

        if SubproblemDiag.success
            ok_iters = ok_iters + 1;
            CR = SubproblemDiag.control_report;
            max_gap_all = max(max_gap_all, max(CR.tight_gap));
            obj_err = abs(SubproblemDiag.solver.objective - SubproblemDiag.objective_terms.total);
            max_obj_err = max(max_obj_err, obj_err);
            mosek_iters(end + 1) = SubproblemDiag.solver.mosek_report.num_iterations; %#ok<AGROW>
            dv_last = SubproblemDiag.p2_feasibility.performance_report.value;
            pobj_last = SubproblemDiag.solver.objective;
            max_gap_last = max(CR.tight_gap);
            med_gap_last = median(CR.tight_gap);
            sigma_last = CR.sigma_deg;
        end
    end

    Summary = struct( ...
        'reg_type', reg_type, ...
        'w_reg', w_reg, ...
        'ok_iters', ok_iters, ...
        'dv_last', dv_last, ...
        'pobj_last', pobj_last, ...
        'max_gap_all', max_gap_all, ...
        'max_gap_last', max_gap_last, ...
        'med_gap_last', med_gap_last, ...
        'mean_mosek_iter', mean(mosek_iters, 'omitnan'), ...
        'max_obj_err', max_obj_err, ...
        'sigma_last', sigma_last);
end
