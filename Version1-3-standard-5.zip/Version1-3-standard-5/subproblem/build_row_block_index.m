function [block_index, block_names] = build_row_block_index(row_groups, num_rows)
% BUILD_ROW_BLOCK_INDEX 给线性约束矩阵 A 的每一行标出所属约束块。
%
% 输出:
%   block_index - num_rows x 1，第 i 行所属块在 block_names 中的序号；不属于任何块记 0
%   block_names - 1 x 块数元胞，块名（与 row_groups 字段名相同）

    block_names = fieldnames(row_groups).';
    block_index = zeros(num_rows, 1);
    for g = 1:numel(block_names)
        block_index(row_groups.(block_names{g})) = g;
    end
end
