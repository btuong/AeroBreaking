function PenaltyFunction = evaluate_penalty_function(Point, P2Feasibility, ConstData, config)
% EVALUATE_PENALTY_FUNCTION 用同一份 P2 可行性检查计算罚函数 J。
%
% J 是 P2（梯形离散后的问题）的罚函数：P3 的目标 L 中每个被线性化的量换成原非线性
% 函数的值，罚权与 P3 相同。在参考点上 J 与 L 取值相同，候选解处二者之差就是
% 预测误差 D，用于算下降比 ρ。
%
% 数学形式:
%   J = w_i·|i_ff-i_aim| + w_ra·|r_ff-R_aaim|
%       + w_P·( Σ_(k=0..4)|P_k| + |v_aim-V_ff| )
%       + w_poi·Σ_(j=0..4)‖g_poi,j‖_1 + w_dyn·Σ_i‖g_dyn,i‖_1
%       + J_circle，
%   第 6 项 J_circle 按 config.unit_norm.mode 取（describe_unit_norm）：
%       'regularized'（默认）取附加项 Γ（按 config.objective.control_reg_type，
%       describe_control_regularizer），ω_i 为按圈计算的梯形积分权，u_i = (u1_i, u2_i)：
%           'norm'（默认） Γ = −w_reg·Σ_(i=1..N) ω_i·‖u_i‖，  ‖u_i‖ = √(u1_i² + u2_i²)
%           'sum'          Γ = w_reg·Σ ω_i·(u1_i + u2_i)
%           'u1'           Γ = w_reg·Σ ω_i·u1_i
%           'u2'           Γ = w_reg·Σ ω_i·u2_i
%           'none'         Γ = 0
%           config.objective.control_reg_use_integration_weights = false 时，Γ 各式去掉 ω_i。
%       'ccd_lu'（Lu 2020 原文 Eq. (40)/(74)）没有控制正则项（Γ = 0），取单位范数罚项
%       Θ_unit = p·Σ_(i=1..N) max(‖u_i‖ − 1, 0)（不乘 ω_i），类别 inequality_penalty，
%       p = config.unit_norm.ccd_penalty_weight。
%   终端 [r_ff,V_ff,…,i_ff] 由末圈出口的原真空映射 G_5 重算，
%   P_5 = v_aim − V_ff 由该终端确定（P3 中入轨为硬等式）；
%   g_poi,j 为衔接违反量、g_dyn,i 为动力学违反量（梯形格式，与 P3 的动力学约束同一格式），全部取
%   P2Feasibility 的同一份报告，路径约束不进 J；全部为归一化单位
%   （LU、VU、rad），与 P3 的目标同口径。'norm' 的原函数 −‖u_i‖ 在 P3 的目标里是它在参考控制处的
%   线性化（build_objective），二者在参考点相等，候选解处之差不大于 0；线性三种与 'none' 在 P3
%   里的项与原函数相同，差为 0；ccd_lu 模式下最优处 ε_i = max(‖u_i‖ − 1, 0)，Θ_unit 在 P3 与 J
%   中采用同一罚权 p 且均不乘 ω_i，预测误差应为 0。
%
% 代码形式:
%   Point 提供节点控制与网格，P2Feasibility 必须是由同一点算出的报告
%   （check_p2_feasibility）。六个分项的顺序与 compute_objective_terms
%   一致，保留原求和顺序；point_slack/dyn_slack 的 label 按原函数一侧命名
%   （衔接罚项、动力学罚项），不用 P3 一侧的松弛罚项名。每项带 kind
%   （类别），同名项与 compute_objective_terms 一致。J = C + Γ + Θ 分三部分：
%     性能指标 C（只含总脉冲）:
%       'cost_nonconvex'   非凸性能指标（脉冲项：末次脉冲 P5 由原映射算出的终端状态
%                          重算，所以这一项在罚函数里不是凸的）
%       'cost_convex'      凸性能指标（本项目没有）
%     附加项 Γ（无损凸化引入、P1 的目标里没有对应的项；regularized 下类别取自 describe_control_regularizer）:
%       'extra_convex'     凸附加项（控制正则取 'sum'、'u1'、'u2'、'none'）
%       'extra_nonconvex'  非凸附加项（控制正则取 'norm'、'norm_gap'）
%     罚项 Θ:
%       'equality_penalty'   等式约束的罚项（终端倾角/远地点违反量、衔接违反量、动力学违反量）
%       'inequality_penalty' 不等式约束的罚项（ccd_lu 模式下的单位范数罚项）
%
% 本函数依次完成：
%   1. 从 P2 可行性检查取终端违反量、脉冲、衔接违反量和动力学违反量。
%   2. 按 unit_norm.mode 计算圆约束组（控制正则项或单位范数罚项）。
%   3. 乘罚权和系数后汇总。

    %% 1. 从 P2 可行性检查取终端违反量、脉冲、衔接违反量和动力学违反量
    Terminal = P2Feasibility.terminal_report.metrics;
    inclination_violation = abs(Terminal(2).normalized_violation);
    apoapsis_violation = abs(Terminal(1).normalized_violation);
    impulse_sum = P2Feasibility.performance_report.normalized_value;
    junction_sum = P2Feasibility.junction_report.sum_abs;
    dynamics_sum = P2Feasibility.dynamics_report.sum_abs;
    P5 = P2Feasibility.performance_report.components(6) / ConstData.VU;

    %% 2. 按 unit_norm.mode 计算圆约束组（控制正则项或单位范数罚项）
    UnitNorm = describe_unit_norm(config);
    u1 = Point.control.u1(:);
    u2 = Point.control.u2(:);
    weights = config.objective;
    if UnitNorm.is_ccd_lu
        % ccd_lu（Lu 2020 原文 Eq. (40)/(74)）：p·Σ max(‖u_i‖ − 1, 0)，不乘 ω_i
        control_sum = sum(max(hypot(u1, u2) - 1, 0));
        circle_weight = UnitNorm.penalty_weight;
        circle_kind = UnitNorm.term_kind;
    else
        % 按 control_reg_type 取附加项 Γ 的原函数值（不含罚权 w_reg），符号已含在内
        integration_weights = compute_integration_weights( ...
            Point.tau, Point.PointsBounds);
        Regularizer = describe_control_regularizer(config);
        if ~Regularizer.use_integration_weights
            integration_weights = ones(numel(Point.control.u1), 1);
        end
        switch Regularizer.type
            case 'norm'
                control_sum = -integration_weights(:)' * hypot(u1, u2);
            case 'norm_gap'
                control_sum = integration_weights(:)' * (1 - hypot(u1, u2));
            case 'sum'
                control_sum = integration_weights(:)' * (u1 + u2);
            case 'u1'
                control_sum = integration_weights(:)' * u1;
            case 'u2'
                control_sum = integration_weights(:)' * u2;
            case 'none'
                control_sum = 0;
        end
        circle_weight = weights.weight_control_reg;
        circle_kind = Regularizer.kind;
    end

    %% 3. 乘罚权和系数后汇总
    term_specs = {
        'terminal_inclination', '终端倾角罚项', 'equality_penalty', ...
            weights.weight_inclination * inclination_violation;
        'terminal_apoapsis',    '终端远地点罚项', 'equality_penalty', ...
            weights.weight_apoapsis * apoapsis_violation;
        'impulse',              '脉冲项', 'cost_nonconvex', ...
            weights.weight_impulse * impulse_sum;
        'point_slack',          '衔接罚项', 'equality_penalty', ...
            weights.weight_point_slack * junction_sum;
        'dyn_slack',            '动力学罚项', 'equality_penalty', ...
            weights.weight_dyn_slack * dynamics_sum;
        UnitNorm.term_name,     UnitNorm.term_label, circle_kind, ...
            circle_weight * control_sum;
    };

    PenaltyFunction.terms = cell2struct(term_specs, ...
        {'name', 'label', 'kind', 'value'}, 2)';
    PenaltyFunction.total = sum([PenaltyFunction.terms.value]);
    PenaltyFunction.P5 = P5;
end
