function dxdt = evaluate_atmospheric_dynamics(~, x, u1, u2, ConstData)
% EVALUATE_ATMOSPHERIC_DYNAMICS 计算大气段 ECF 球坐标动力学右端项。
%
% 输入:
%   x       - 6x1 状态 [r, V, gamma, phi, psi, theta]，归一化单位
%   u1, u2  - 倾侧角分量 cos(sigma), sin(sigma)
%
% 输出:
%   dxdt - 6x1 状态导数，theta 为记账分量（不是优化变量）
%
% 数学形式:
%   x = [r, V, γ, φ, ψ, θ]^T，对物理时间 t 的导数，归一化单位：
%       dr/dt = V sin γ
%       dV/dt = −D + 引力项 + 地球自转离心项 + J2 项
%       dγ/dt = L·u1/V + 引力/离心/科氏/J2 项
%       dφ/dt = V cos γ cos ψ / r
%       dψ/dt = L·u2/(V cos γ) + 运动学/科氏/离心/J2 项
%       dθ/dt = V cos γ sin ψ / (r cos φ)
%   D = C_D·LU·ρ·S·V²/(2M)，L = C_L·LU·ρ·S·V²/(2M)，ρ = ρ_0·exp((R_M − r)/h_s)。
%   u1 = cos σ，u2 = sin σ 为倾侧角分量（P2 中单位模等式经无损凸化写成 ‖u‖ ≤ 1）。
%
% 代码形式:
%   dxdt 为 6×1 列向量，行序 r, V, γ, φ, ψ, θ；对 t 的导数，不含 t_f 与 dτ 缩放
%   （乘 t_f 在线性化函数 linearize_coefficient_* 中进行）。
%
% 模型含指数大气、J2 摄动和地球自转（离心与科氏项），是大气段唯一的
% 原始连续动力学源，线性化、传播和各项检查都用它。

    M = ConstData.M;
    Rho0 = ConstData.Rho0;
    S = ConstData.S;
    C_D = ConstData.C_D;
    C_L = ConstData.C_L;
    mu = ConstData.mu;
    RM = ConstData.RM;
    hs = ConstData.hs;
    LU = ConstData.LU;
    we = ConstData.we;
    J2 = ConstData.J2;

    r = x(1);
    V = x(2);
    gammaa = x(3);
    phi = x(4);
    psi = x(5);

    drdt = sin(gammaa) * V;
    dVdt = r * we^2 * cos(phi) * (cos(phi) * sin(gammaa) ...
        - cos(gammaa) * cos(psi) * sin(phi)) ...
        - (mu * sin(gammaa)) / r^2 ...
        + (J2 * RM^2 * mu * (sin(gammaa) * ((9 * sin(phi)^2) / 2 - 3 / 2) ...
            - (3 * sin(2 * phi) * cos(gammaa) * cos(psi)) / 2)) / r^4 ...
        - (C_D * LU * Rho0 * S * V^2 * exp((RM - r) / hs)) / (2 * M);
    dgammadt = 2 * we * cos(phi) * sin(psi) ...
        - (cos(gammaa) * (-r * V^2 + mu)) / (V * r^2) ...
        + (r * we^2 * cos(phi) * (cos(gammaa) * cos(phi) ...
            + cos(psi) * sin(gammaa) * sin(phi))) / V ...
        + (J2 * RM^2 * mu * (cos(gammaa) * ((9 * sin(phi)^2) / 2 - 3 / 2) ...
            + (3 * sin(2 * phi) * cos(psi) * sin(gammaa)) / 2)) / (V * r^4) ...
        + (C_L * LU * Rho0 * S * V * u1 * exp((RM - r) / hs)) / (2 * M);
    dphidt = (V * cos(gammaa) * cos(psi)) / r;
    dpsidt = 2 * we * (sin(phi) - cos(phi) * cos(psi) * tan(gammaa)) ...
        + (V * cos(gammaa) * sin(psi) * tan(phi)) / r ...
        + (r * we^2 * cos(phi) * sin(phi) * sin(psi)) / (V * cos(gammaa)) ...
        + (3 * J2 * RM^2 * mu * sin(2 * phi) * sin(psi)) ...
            / (2 * V * r^4 * cos(gammaa)) ...
        + (C_L * LU * Rho0 * S * V * u2 * exp((RM - r) / hs)) ...
            / (2 * M * cos(gammaa));
    dthetadt = V * cos(gammaa) .* sin(psi) ./ (r * cos(phi));

    dxdt = [drdt; dVdt; dgammadt; dphidt; dpsidt; dthetadt];
end
