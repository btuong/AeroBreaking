function Split = compute_control_dual_split( ...
        Dual, objective, LinearConstraints, ConicConstraints, u_index)
% COMPUTE_CONTROL_DUAL_SPLIT 把 P3 驻点条件在控制 u 列上的各项按来源拆开（N x 2，列为 u1、u2）。
%
% 数学形式（MOSEK 手册的对偶约束，对 u 列取分量）:
%   P3 记为 min c'x，s.t. blc ≤ A x ≤ buc，blx ≤ x ≤ bux，F x + g ∈ K（仿射锥）。
%   对偶可行（驻点）条件 c − Aᵀy − s_lx + s_ux − Fᵀ·doty = 0，y = s_lc − s_uc，
%   s_lx、s_ux ≥ 0 为变量下、上界乘子，doty 属于锥的对偶锥。取 u1_i、u2_i 两列:
%       s_reg   = c_u                       目标里 u 的系数（regularized 为控制正则项；ccd_lu 为 0）
%       s_inner = −A_uᵀ y（单位范数内逼近行 −2·ū_i^T·u_i ≤ −(1 + ‖ū_i‖_2^2)，只在 ccd_lu
%                 模式下有这一行块；行 i 只含 u_i，所以 s_inner,i = 2·ū_i·y_i；regularized 下全为 0）
%       s_dyn   = −A_uᵀ y（动力学行）
%       s_rate  = −A_uᵀ y（控制连续性行，相邻节点 |Δu1| 上界）
%       s_bound = −s_lx,u + s_ux,u          u 的物理边界乘子
%       s_total = s_reg + s_inner + s_dyn + s_rate + s_bound
%       s_cone  = F_uᵀ·doty                 控制圆盘锥对 u 列的贡献
%       stationarity_residual = s_total − s_cone    驻点条件的残差，应接近 0
%   s_main = s_dyn + s_rate + s_bound 是主问题（不含正则项和内逼近行）对 u 的需求。
%
% 代码形式:
%   u_index 为 N x 2 的列号（VariableIndex.u1(:)、u2(:)）。行号按
%   LinearConstraints.row_groups 的块名取：dynamics、control_continuity、unit_norm_inner
%   （没有 unit_norm_inner 块时 s_inner 全为 0）。
%   对偶解长度与 P3 的行数、变量数、锥行数不符时 available = false，各分量为 NaN
%   （s_inner 也是）；对偶可用而没有 unit_norm_inner 块时 s_inner 全为 0。
%
% 输出 Split 字段: available、reason、s_reg、s_inner、s_dyn、s_rate、s_bound、s_total、
%   s_cone、stationarity_residual、s_main。

    num_nodes = size(u_index, 1);
    u_columns = [u_index(:, 1); u_index(:, 2)];
    unavailable_values = nan(num_nodes, 2);

    Split.available = false;
    Split.reason = '';
    Split.s_reg = reshape(objective(u_columns), num_nodes, 2);
    Split.s_inner = unavailable_values;
    Split.s_dyn = unavailable_values;
    Split.s_rate = unavailable_values;
    Split.s_bound = unavailable_values;
    Split.s_total = unavailable_values;
    Split.s_cone = unavailable_values;
    Split.stationarity_residual = unavailable_values;
    Split.s_main = unavailable_values;

    %% 1. 检查对偶解的长度
    num_rows = size(LinearConstraints.matrix, 1);
    num_variables = size(LinearConstraints.matrix, 2);
    num_cone_rows = size(ConicConstraints.mapping, 1);
    if numel(Dual.y) ~= num_rows || numel(Dual.slx) ~= num_variables ...
            || numel(Dual.sux) ~= num_variables ...
            || numel(Dual.doty) ~= num_cone_rows
        Split.reason = sprintf( ...
            'dual_unavailable (y %d/%d, slx %d/%d, sux %d/%d, doty %d/%d)', ...
            numel(Dual.y), num_rows, numel(Dual.slx), num_variables, ...
            numel(Dual.sux), num_variables, numel(Dual.doty), num_cone_rows);
        return;
    end
    Split.available = true;
    % 没有内逼近行块（regularized）时 s_inner 保持为 0
    Split.s_inner = zeros(num_nodes, 2);

    %% 2. 按来源拆开 u 列的驻点条件
    row_groups = LinearConstraints.row_groups;
    A_u = LinearConstraints.matrix(:, u_columns);
    dynamics_rows = row_groups.dynamics(:);
    rate_rows = row_groups.control_continuity(:);
    if isfield(row_groups, 'unit_norm_inner') && ~isempty(row_groups.unit_norm_inner)
        inner_rows = row_groups.unit_norm_inner(:);
        Split.s_inner = reshape( ...
            -(A_u(inner_rows, :).' * Dual.y(inner_rows)), num_nodes, 2);
    end
    Split.s_dyn = reshape( ...
        -(A_u(dynamics_rows, :).' * Dual.y(dynamics_rows)), num_nodes, 2);
    Split.s_rate = reshape( ...
        -(A_u(rate_rows, :).' * Dual.y(rate_rows)), num_nodes, 2);
    Split.s_bound = reshape( ...
        -Dual.slx(u_columns) + Dual.sux(u_columns), num_nodes, 2);
    Split.s_cone = reshape( ...
        ConicConstraints.mapping(:, u_columns).' * Dual.doty, num_nodes, 2);

    %% 3. 求和并算驻点残差
    Split.s_main = Split.s_dyn + Split.s_rate + Split.s_bound;
    Split.s_total = Split.s_reg + Split.s_inner + Split.s_main;
    Split.stationarity_residual = Split.s_total - Split.s_cone;
end
