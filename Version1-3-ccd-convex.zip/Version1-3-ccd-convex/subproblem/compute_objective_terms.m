function ObjectiveTerms = compute_objective_terms( ...
        objective, primal, VariableIndex, config, objective_offset)
% COMPUTE_OBJECTIVE_TERMS 把 P3 的目标值 L = c^T·x + c_fix 按项拆开，记录各项在本轮解上的值。
%
% 数学形式:
%   L = L_i + L_ra + L_P + L_poi + L_dyn + L_reg，各项为 c 与 x 在对应变量上的内积：
%   L_i = w_i·t_if，L_ra = w_ra·t_raf，L_P = w_P·Σ t_P，L_poi = w_poi·Σ t_poi，
%   L_dyn = w_dyn·Σ t_dyn，L_reg 为附加项 Γ 在 P3 中的形式（按 config.objective.control_reg_type：
%   'norm' 为 −w_reg·Σ ω_i·ē_i^T·u_i，即 −w_reg·Σ ω_i·‖u_i‖ 在参考控制处的线性化，
%   ē_i = ū_i/‖ū_i‖；'sum'、'u1'、'u2' 为 w_reg·Σ ω_i·(u1_i + u2_i)、w_reg·Σ ω_i·u1_i、
%   w_reg·Σ ω_i·u2_i；'none' 为 0，见 build_objective）。
%   全部为求解器装配口径的无量纲值，与 SolverResult.objective 相同。
%
% 输出 ObjectiveTerms:
%   total  - 各项之和 c^T·x
%   terms  - 结构体数组，字段 name（英文名）、label（图上名称）、kind（项的类别）、value
%
% kind 的取值与 evaluate_penalty_function 同名项一致，用来把各项分成三组
% （L = 性能指标 C̃ + 附加项 Γ̃ + 松弛罚项 Θ̃）：
%   'cost_nonconvex'     - 非凸性能指标（脉冲项：罚函数里末次脉冲由原映射算出的终端状态重算，
%                          所以这一项在罚函数里不是凸的）
%   'cost_convex'        - 凸性能指标（本项目没有）
%   'extra_convex'       - 凸附加项（控制正则取 'sum'、'u1'、'u2' 或 'none' 时）
%   'extra_nonconvex'    - 非凸附加项（控制正则取 'norm' 时：−w_reg·Σ ω_i·‖u_i‖，无损凸化引入，
%                          不属于性能指标；P3 里是它的线性化）
%   'equality_penalty'   - 等式约束的罚项（终端倾角/远地点松弛罚项、衔接松弛罚项、动力学松弛罚项）
%   'inequality_penalty' - 不等式约束的罚项（ccd_lu 模式下的单位范数罚项 p·Σ ε_i，不乘 ω_i）
% 圆约束组的名称、显示名、类别与变量下标取自 describe_unit_norm。

    if nargin < 5 || isempty(objective_offset)
        objective_offset = 0;
    end
    UnitNorm = describe_unit_norm(config);
    if UnitNorm.is_ccd_lu
        circle_index = VariableIndex.unit_norm_slack(:);
    else
        circle_index = [VariableIndex.u1, VariableIndex.u2];
    end
    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    point_index = [];
    dyn_index = [];
    for s = 1:numel(state_names)
        point_index = [point_index, VariableIndex.(['t_poi_slack_' state_names{s}])]; %#ok<AGROW>
        dyn_index = [dyn_index, VariableIndex.(['t_dyn_slack_' state_names{s}])]; %#ok<AGROW>
    end

    % 每行：英文名、图上名称、类别、该项包含的变量下标（与 build_objective 的分项一致）
    term_specs = {
        'terminal_inclination', '终端倾角罚项',   'equality_penalty', VariableIndex.t_if;
        'terminal_apoapsis',    '终端远地点罚项', 'equality_penalty', VariableIndex.t_raf;
        'impulse',              '脉冲项',         'cost_nonconvex',     VariableIndex.t_P;
        'point_slack',          '衔接松弛罚项',   'equality_penalty', point_index;
        'dyn_slack',            '动力学松弛罚项', 'equality_penalty', dyn_index;
        UnitNorm.term_name,     UnitNorm.term_label, UnitNorm.term_kind, circle_index;
    };

    term_list = cell(1, size(term_specs, 1));
    for k = 1:size(term_specs, 1)
        index = term_specs{k, 4};
        term_value = objective(index).' * primal(index);
        if strcmp(term_specs{k, 1}, 'control_reg')
            term_value = term_value + objective_offset;
        end
        term_list{k} = struct('name', term_specs{k, 1}, ...
            'label', term_specs{k, 2}, 'kind', term_specs{k, 3}, ...
            'value', term_value);
    end
    ObjectiveTerms.terms = [term_list{:}];
    ObjectiveTerms.total = objective(:).' * primal(:) + objective_offset;
end
