function place_shared_legend(tile_axes, config)
% PLACE_SHARED_LEGEND 整扇窗只放一个图例，放在分块布局的底部，不压曲线。
%
% 为什么要有这个函数：每个分块各放一个图例时，字号 16 下图例比分块还大，会盖住
% 曲线。现在各分块里有名字（DisplayName）的对象合并成一个图例，同名只列一次，
% 顺序按第一次出现的先后。两条规则让图例保持短：
%   - 只有一条曲线的分块，这条曲线不进图例（纵轴标签已经是它的名字）。曲线在画的
%     时候用 Tag = 'series' 标出；参考线、阈值线等其他对象照常进图例。
%   - 没有名字的对象（HandleVisibility 关掉的标记、文字）不进图例。
%
% 输入:
%   tile_axes - 本窗全部分块的坐标轴，按分块顺序排列
%   config    - 读取 config.plot.font_size
%
% 图例挂在最后一个分块上，别的分块里的条目用样式相同、数据为 NaN 的占位对象
% 补进去，占位对象不画任何数据。没有可列的条目时不画图例。
% 图例放进 tiledlayout 底部的独立一格（Layout.Tile = 'south'），分块自动让出位置；
% 列数按图窗宽度和最长条目估算。

    font_size = config.plot.font_size;
    names = {};
    prototypes = gobjects(1, 0);
    for k = 1:numel(tile_axes)
        children = flipud(get(tile_axes(k), 'Children'));
        is_series = false(size(children));
        for m = 1:numel(children)
            is_series(m) = strcmp(get(children(m), 'Tag'), 'series');
        end
        skip_series = nnz(is_series) == 1;
        for m = 1:numel(children)
            if ~isprop(children(m), 'DisplayName')
                continue;
            end
            name = get(children(m), 'DisplayName');
            if isempty(name) || any(strcmp(names, name)) ...
                    || (skip_series && is_series(m))
                continue;
            end
            names{end + 1} = name; %#ok<AGROW>
            prototypes(end + 1) = children(m); %#ok<AGROW>
        end
    end
    if isempty(names)
        return;
    end

    % 条目都挂在最后一个分块上；不在它里面的条目补一个占位对象
    host = tile_axes(end);
    handles = gobjects(1, numel(names));
    for m = 1:numel(names)
        if isequal(get(prototypes(m), 'Parent'), host)
            handles(m) = prototypes(m);
        else
            handles(m) = make_legend_proxy(host, prototypes(m), names{m});
        end
    end

    widths = cellfun(@measure_display_width, names);
    entry_pixels = (0.67 * max(widths) + 3.5) * font_size;
    figure_pixels = get(ancestor(host, 'figure'), 'Position');
    columns = max(1, min(numel(names), floor(figure_pixels(3) / entry_pixels)));
    legend_handle = legend(host, handles, names, 'FontSize', font_size, ...
        'Interpreter', 'none', 'NumColumns', columns);
    legend_handle.Layout.Tile = 'south';
end


function proxy = make_legend_proxy(host, prototype, name)
% MAKE_LEGEND_PROXY 在 host 里画一个数据为 NaN 的对象，线型、颜色和标记取自原对象。

    property_names = {'Color', 'LineStyle', 'LineWidth', 'Marker', ...
        'MarkerSize', 'MarkerFaceColor', 'MarkerEdgeColor'};
    style_args = {};
    for k = 1:numel(property_names)
        if isprop(prototype, property_names{k})
            style_args = [style_args, ...
                {property_names{k}, get(prototype, property_names{k})}]; %#ok<AGROW>
        end
    end
    proxy = plot(host, NaN, NaN, style_args{:}, 'DisplayName', name);
end
