function TerminalRemainderReport = evaluate_terminal_remainder( ...
        CurrentSolution, ConstData, config)
% EVALUATE_TERMINAL_REMAINDER 算终端映射的余项：从末圈出口积分到远地点得到的终端量，减去 P3 的解里的终端量（P2 可行性检查的一项，只报告）。
%
% 数学形式:
%   R = G_5([R_atm,V_out,γ_out,φ_out,ψ_out,0]) − [x_ff;i_f]
%   G_5 为原真空映射（积分），取候选解末圈出口节点的值；[x_ff;i_f] 是 P3 的解里
%   的终端变量，即 G_5 在参考点处的线性化值。终端映射在 P3 里是不带松弛的线性化
%   等式，所以 R 就是终端映射在候选解处的泰勒余项。六个分量依次为远地点处的
%   r、V、γ、φ、ψ 和倾角 i。
%   r 和 i 两个分量：候选解处的终端违反量 = P3 的终端松弛 + 余项。
%   V 分量：入轨脉冲由终端速度确定，重算的 P_5 减 P3 的 P_5 等于 −R_V。
%
% 代码形式:
%   每个分量一条指标，数值为 |R| 的物理单位值（km、m/s、deg），components 为带符号值；
%   容差取衔接违反量各通道的容差（config.validation.junction_tolerance），倾角用
%   角度通道的容差。values 保存归一化的带符号余项（1 x 6）。
%   只报告：不计入 p2_feasibility.feasible，也不参与接受、半径或停止。
%   只有 P3 的解带终端变量，所以本函数只对候选解调用；参考点的 P2 可行性检查里
%   这一项为未评价。
%
% 本函数依次完成：
%   1. 从末圈出口积分到远地点，减去 P3 的终端变量。
%   2. 按分量换成物理单位并与容差比较。
%   3. 汇总各分量。

    %% 1. 从末圈出口积分到远地点，减去 P3 的终端变量
    exit_last = [ConstData.R_atm, ...
        CurrentSolution.state(CurrentSolution.PointsBounds(end).end, 2:5), 0];
    mapped = evaluate_coast_exit_to_apoapsis(exit_last, ConstData);
    values = mapped - [CurrentSolution.xff', CurrentSolution.i];

    %% 2. 按分量换成物理单位并与容差比较
    component_names = {'r', 'V', 'gamma', 'phi', 'psi', 'i'};
    tolerance_names = {'r', 'V', 'gamma', 'phi', 'psi', 'psi'};
    scales = [ConstData.LU / 1e3, ConstData.VU, ...
        180 / pi, 180 / pi, 180 / pi, 180 / pi];
    units = {'km', 'm/s', 'deg', 'deg', 'deg', 'deg'};
    metric_list = cell(1, numel(component_names));
    for s = 1:numel(component_names)
        value = abs(values(s)) * scales(s);
        tolerance = config.validation.junction_tolerance.(tolerance_names{s});
        metric_list{s} = struct( ...
            'name', ['terminal_remainder_' component_names{s}], ...
            'value', value, 'max_value', value, ...
            'tolerance', tolerance, 'unit', units{s}, ...
            'ratio', value / tolerance, ...
            'satisfied', isfinite(value) && value <= tolerance, ...
            'active', true, 'evaluated', true, ...
            'components', values(s) * scales(s));
    end

    %% 3. 汇总各分量
    Metrics = [metric_list{:}];
    TerminalRemainderReport.success = all([Metrics.satisfied]);
    TerminalRemainderReport.evaluated = true;
    TerminalRemainderReport.metrics = Metrics;
    TerminalRemainderReport.failed_names = {Metrics(~[Metrics.satisfied]).name};
    [TerminalRemainderReport.max_ratio, max_index] = max([Metrics.ratio]);
    TerminalRemainderReport.max_name = Metrics(max_index).name;
    TerminalRemainderReport.values = values;
    TerminalRemainderReport.scale = scales;
end
