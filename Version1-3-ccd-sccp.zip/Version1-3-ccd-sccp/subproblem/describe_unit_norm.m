function UnitNorm = describe_unit_norm(config)
% DESCRIBE_UNIT_NORM 按 config.unit_norm 返回单位范数约束的处理方式、罚权和目标项信息。
%
% 数学形式:
%   原约束为 ‖u_i‖_2 = 1（u_i = (u1_i, u2_i)，i = 1..N）。两种处理方式:
%       'regularized'（默认） P2 中放宽为 ‖u_i‖_2 ≤ 1 并在目标中加附加项 Γ；
%       'sccp'                Deng et al. (2024) SCCP：保留凸半 ‖u_i‖_2 ≤ 1，
%                             反凸半 1 − ‖u_i‖_2² ≤ 0 在参考控制 ū_i 处线性化并
%                             引入共用非负标量松弛 η（每节点分配 η/N），在目标中罚 C_η·η；
%                             P2 罚函数对应不等式罚项 Θ_unit = C_η·N·max_i [1 − ‖u_i‖_2²]_+。
%
% 代码形式:
%   输入 config 无 unit_norm 字段或无 mode 字段时按 'regularized' 处理。
%   未知 mode 抛错 SCP:UnknownUnitNormMode；'sccp' 下要求 sccp_penalty_weight 与
%   sccp_slack_max 为有限正实数，否则抛错 SCP:InvalidUnitNormConfig。
%   返回 UnitNorm 字段:
%       mode           - 'regularized' 或 'sccp'
%       is_sccp        - logical 标量
%       penalty_weight - C_η（非 sccp 为 0）
%       slack_max      - η 上界（非 sccp 为 0）
%       term_name      - 'control_reg' 或 'unit_norm_penalty'
%       term_label     - '控制正则项' 或 '单位范数罚项'
%       term_kind      - 'regularized' 取 describe_control_regularizer(config).kind，
%                        'sccp' 取 'inequality_penalty'

    mode = 'regularized';
    has_unit_norm = isstruct(config) && isfield(config, 'unit_norm') ...
        && isstruct(config.unit_norm);
    if has_unit_norm && isfield(config.unit_norm, 'mode') ...
            && ~isempty(config.unit_norm.mode)
        mode = char(string(config.unit_norm.mode));
    end

    switch mode
        case 'regularized'
            Regularizer = describe_control_regularizer(config);
            UnitNorm.mode = 'regularized';
            UnitNorm.is_sccp = false;
            UnitNorm.penalty_weight = 0;
            UnitNorm.slack_max = 0;
            UnitNorm.term_name = 'control_reg';
            UnitNorm.term_label = '控制正则项';
            UnitNorm.term_kind = Regularizer.kind;
        case 'sccp'
            if ~has_unit_norm ...
                    || ~isfield(config.unit_norm, 'sccp_penalty_weight') ...
                    || ~isfield(config.unit_norm, 'sccp_slack_max')
                error('SCP:InvalidUnitNormConfig', ...
                    'sccp 模式必须提供 sccp_penalty_weight 和 sccp_slack_max。');
            end
            penalty_weight = config.unit_norm.sccp_penalty_weight;
            slack_max = config.unit_norm.sccp_slack_max;
            validate_positive_scalar(penalty_weight, 'sccp_penalty_weight');
            validate_positive_scalar(slack_max, 'sccp_slack_max');

            UnitNorm.mode = 'sccp';
            UnitNorm.is_sccp = true;
            UnitNorm.penalty_weight = double(penalty_weight);
            UnitNorm.slack_max = double(slack_max);
            UnitNorm.term_name = 'unit_norm_penalty';
            UnitNorm.term_label = '单位范数罚项';
            UnitNorm.term_kind = 'inequality_penalty';
        otherwise
            error('SCP:UnknownUnitNormMode', ...
                '未知的单位范数约束模式 unit_norm.mode = ''%s''，可选 regularized、sccp。', ...
                mode);
    end
end


function validate_positive_scalar(value, field_name)
% VALIDATE_POSITIVE_SCALAR 检查配置参数是否为有限正实数标量。

    if ~isnumeric(value) || ~isscalar(value) || ~isreal(value) ...
            || ~isfinite(value) || value <= 0
        error('SCP:InvalidUnitNormConfig', ...
            'config.unit_norm.%s 必须为有限正实数标量。', field_name);
    end
end
