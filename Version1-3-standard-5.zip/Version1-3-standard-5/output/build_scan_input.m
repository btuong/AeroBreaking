function ScanInput = build_scan_input(FinalizedRun, ConstData, config)
% BUILD_SCAN_INPUT 把半径扫描脚本要用的数据组装成 ScanInput（只读历史，不重新求值）。
%
% 输出 ScanInput:
%   config    - 本次运行的配置
%   ConstData - 常数与尺度
%   attempts  - K x 1 结构体数组，每轮一个，字段:
%       iter                  轮号
%       reference             该轮线性化所在的参考点（IterationRecord.reference_before）
%       radius_scale          该轮用的半径 r（trust_region_update.scale_before）
%       subproblem_success    P3 是否求解成功
%       accept_candidate      候选解是否被接受
%       predicted_reduction   预测下降 ΔL
%       prediction_error      预测误差 D
%       ratio                 下降比 ρ
%       slack_penalty         松弛罚项
%     后四个在 P3 失败时为 NaN。同一参考点上的几轮 reference 相同。

    History = FinalizedRun.history;
    attempt_list = cell(1, numel(History));
    for k = 1:numel(History)
        Record = History(k);
        Evaluation = Record.trust.evaluation;
        attempt_list{k} = struct( ...
            'iter', Record.iter, ...
            'reference', Record.reference_before, ...
            'radius_scale', Record.trust.trust_region_update.scale_before, ...
            'subproblem_success', logical(Record.subproblem.success), ...
            'accept_candidate', logical(Record.trust.accept_candidate), ...
            'predicted_reduction', Evaluation.predicted_reduction, ...
            'prediction_error', Evaluation.prediction_error, ...
            'ratio', Evaluation.ratio, ...
            'slack_penalty', Evaluation.slack_penalty);
    end

    ScanInput.config = config;
    ScanInput.ConstData = ConstData;
    if isempty(attempt_list)
        ScanInput.attempts = struct('iter', {}, 'reference', {}, ...
            'radius_scale', {}, 'subproblem_success', {}, ...
            'accept_candidate', {}, 'predicted_reduction', {}, ...
            'prediction_error', {}, 'ratio', {}, 'slack_penalty', {});
    else
        ScanInput.attempts = [attempt_list{:}]';
    end
end
