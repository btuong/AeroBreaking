function print_scp_iteration( ...
        IterationRecord, IterationDiagnostics, ConstData, config, block_names)
% PRINT_SCP_ITERATION 打印一轮 SCP 尝试的过程日志（十区块）。
%
% 只读使用同轮 IterationRecord（本轮记录）与 IterationDiagnostics
% （梯形递推检查）；本项目另传入只读 ConstData，用于把归一化量换成物理单位。
% 叫法：P3 是凸子问题（罚问题在参考点处线性化、加信赖域），P2 是离散后的
% 非线性规划，罚函数 J 在 P2 上用原非线性函数求值，L 是 P3 的目标。违反量、罚项是
% 原函数一侧（P2、J），松弛、松弛罚项是线性化函数一侧（P3、L）。
%
% 区块（每块回答一个问题，顺序即阅读顺序；块名用于第 5 个输入 block_names）:
%   1. P3 求解状态与规模     solver         求解器解出来没有
%   2. 数值检查              numerics       这轮解能不能信
%   3. P3 解检查             p3_checks      P3 的解对不对：松弛、锥、无损凸化紧性
%   4. 迭代分析              analysis       预测下降与预测误差各由什么组成，
%                                           ρ、门槛、半径、K 估计、驻点度量的上界、决策
%   5. P3 乘子               multipliers    P3 的解为什么是这样：各类约束的乘子、信赖域界生效多少
%   6. P2 可行性检查         p2_feasibility 节点值代入 P2 差多少：逐区间的梯形动力学，
%                                           以及与真空段积分的对照
%   7. 约束对照              comparison     同一约束在 P2 节点值和梯形递推上各是多少
%   8. 物理量                physics        脉冲、t_f、终端实际值
%   9. 收敛                  convergence    驻点、对 P2 可行、步长三项
%   10. 本轮结果             result         决策、计数、停止
%
% 打印规则:
%   - 每块先打结论；有 FAIL/WARN 时只展开出问题的行。
%   - config.output.detail.<块> = true 时该块展开全部明细和定位信息：
%     numerics、p3_checks、analysis、multipliers、p2_feasibility、physics、
%     convergence；detail.all = true 时全部展开。
%   - block_names（可选，块名元胞）只打印被选中的块；缺省或为空时全部打印。
%   - 块与块之间空一行（每块打印时先输出一个空行）。
%   - 表格按终端显示宽度对齐（中文占两格），每行不超过约 78 列。
%   - P3 求解失败时只剩 solver、numerics、result 三块（按选中与否打印）。
%
% 本函数依次完成：
%   1. 打印 P3 求解状态与问题规模。
%   2. 打印数值检查：原始矩阵残差、解的量级、MOSEK 警告、系数量级。
%   3. 打印 P3 解检查：松弛、锥重构。
%   4. 打印迭代分析：预测下降、预测误差、ρ、门槛、半径、K 估计、驻点度量的上界、决策。
%   5. 打印 P3 乘子：各罚项类 |λ|/w 和信赖域界生效个数。
%   6. 打印 P2 可行性检查：动力学违反量，衔接违反量、终端违反量和终端映射的余项。
%   7. 打印约束对照表：P2 节点值与梯形递推并排。
%   8. 打印物理量。
%   9. 打印收敛：驻点、对 P2 可行、步长。
%   10. 打印本轮结果。

    if nargin < 5
        block_names = {};
    end
    SubproblemDiag = IterationRecord.subproblem;
    Detail = read_detail_flags(config.output.detail);
    % 节点所在的圈从本轮参考的网格读取（解与参考共用同一网格）
    PointsBounds = IterationRecord.reference_before.PointsBounds;
    fprintf('\n========== SCP 迭代 %d / %d ==========\n', ...
        IterationRecord.iter, config.iter.max_scp_iter);

    %% 1. 打印 P3 求解状态与问题规模
    if is_block_selected('solver', block_names)
        print_solver_status(SubproblemDiag);
    end

    %% 2. 打印数值检查：原始矩阵残差、解的量级、MOSEK 警告、系数量级
    if is_block_selected('numerics', block_names)
        print_numerics_checks(SubproblemDiag, Detail.numerics);
    end
    if ~SubproblemDiag.success
        % 求解失败没有候选解，后面依赖解的区块都不打印
        if is_block_selected('result', block_names)
            print_iteration_key_results(IterationRecord);
        end
        return;
    end

    %% 3. 打印 P3 解检查：松弛、锥重构
    if is_block_selected('p3_checks', block_names)
        print_p3_checks(SubproblemDiag, IterationRecord.solution, ...
            PointsBounds, ConstData, Detail.p3_checks);
    end

    %% 4. 打印迭代分析：预测下降、预测误差、ρ、门槛、半径、K 估计、驻点度量的上界、决策
    if is_block_selected('analysis', block_names)
        print_iteration_analysis(IterationRecord.trust, ...
            SubproblemDiag.p2_feasibility, config, Detail.analysis);
    end

    %% 5. 打印 P3 乘子：各罚项类 |λ|/w 和信赖域界生效个数
    if is_block_selected('multipliers', block_names)
        print_multipliers(SubproblemDiag.p3_check.multiplier_report, ...
            Detail.multipliers);
    end

    %% 6. 打印 P2 可行性检查：动力学违反量，衔接违反量、终端违反量和终端映射的余项
    if is_block_selected('p2_feasibility', block_names)
        print_p2_feasibility(SubproblemDiag.p2_feasibility, ...
            IterationRecord.solution, ConstData, Detail.p2_feasibility, config);
    end

    %% 7. 打印约束对照表：P2 节点值与梯形递推并排
    if is_block_selected('comparison', block_names)
        print_constraint_comparison(SubproblemDiag.p2_feasibility, ...
            IterationDiagnostics.trapezoid_check);
    end

    %% 8. 打印物理量
    if is_block_selected('physics', block_names)
        print_physical_quantities(IterationRecord.solution, SubproblemDiag, ...
            IterationDiagnostics.trapezoid_check, IterationRecord.reference_before, ...
            ConstData, Detail.physics);
    end

    %% 9. 打印收敛：驻点、对 P2 可行、步长
    if is_block_selected('convergence', block_names)
        print_convergence(IterationRecord, PointsBounds, ConstData, ...
            Detail.convergence);
    end

    %% 10. 打印本轮结果
    if is_block_selected('result', block_names)
        print_iteration_key_results(IterationRecord);
    end
end


function selected = is_block_selected(block_name, block_names)
% IS_BLOCK_SELECTED 块名在 block_names 里（或 block_names 为空，即全部打印）时为真。

    selected = isempty(block_names) || any(strcmp(block_name, block_names));
end


function Detail = read_detail_flags(DetailConfig)
% READ_DETAIL_FLAGS 读取各块的展开开关；all 为 true 时全部展开。

    names = {'numerics', 'p3_checks', 'analysis', 'multipliers', ...
        'p2_feasibility', 'physics', 'convergence'};
    for k = 1:numel(names)
        Detail.(names{k}) = DetailConfig.all || DetailConfig.(names{k});
    end
end


%% ===== 1. P3 求解状态 =====

function print_solver_status(SubproblemDiag)
% PRINT_SOLVER_STATUS 打印求解器状态、MOSEK 响应码和问题规模（两行）。

    MosekReport = SubproblemDiag.solver.mosek_report;
    fprintf('求解: %s (%s) | %s | 内点迭代 %g\n', ...
        SubproblemDiag.solver.status, SubproblemDiag.status, ...
        MosekReport.response_name, MosekReport.num_iterations);

    % 线性约束行数取自系数扫描的逐行记录，求解失败时也有
    num_linear_rows = numel(SubproblemDiag.coefficient_report.linear_rows.span);
    fprintf('规模: 变量 %d | 线性约束 %d 行 | 节点 %d\n', ...
        SubproblemDiag.num_variables, num_linear_rows, ...
        SubproblemDiag.num_nodes);
end


%% ===== 2. 数值检查 =====

function print_numerics_checks(SubproblemDiag, show_all)
% PRINT_NUMERICS_CHECKS 打印求解数值是否可信：先残差和解的量级，再 MOSEK 警告和系数量级。
%
% 判断以原始矩阵残差为准；系数量级只提示风险，所以超阈值记 WARN，
% 出现 NaN/Inf 才记 FAIL。读法见 notes/数值检查输出解读.md。
% 展开时另列“相对残差最大的 5 行”和“行内跨度最大的 5 行”，把同一行的
% 残差和跨度放在一起对照。

    fprintf('\n数值检查:\n');
    FeasibilityReport = SubproblemDiag.p3_check.solver_feasibility_report;
    CoefficientReport = SubproblemDiag.coefficient_report;
    print_residual_summary(FeasibilityReport, show_all);
    if show_all && FeasibilityReport.evaluated
        print_worst_linear_rows('相对残差最大的 5 行', ...
            FeasibilityReport.linear_rows, CoefficientReport.linear_rows, ...
            'relative');
    end
    print_mosek_warnings(SubproblemDiag.solver.mosek_report, show_all);
    print_coefficient_summary(CoefficientReport, show_all);
    if show_all && CoefficientReport.evaluated && FeasibilityReport.evaluated
        print_worst_linear_rows('行内跨度最大的 5 行', ...
            FeasibilityReport.linear_rows, CoefficientReport.linear_rows, ...
            'span');
    end
end


function print_residual_summary(Report, show_all)
% PRINT_RESIDUAL_SUMMARY 打印返回解在原始矩阵上的违反量和解的量级。

    if ~Report.evaluated
        fprintf('  原始矩阵残差 NOT_AVAILABLE (没有返回解)\n');
        return;
    end

    % 报告里 A.* 和 x_bounds 是残差行，*_norm_inf 是原始解和对偶解的 ‖·‖∞
    Metrics = Report.metrics;
    is_norm = endsWith({Metrics.name}, '_norm_inf');
    Residuals = Metrics(~is_norm);
    Norms = Metrics(is_norm);

    % 两行结论：残差取相对值最大的一行，量级给出原始解和对偶解
    [~, worst] = max([Residuals.relative_value]);
    fprintf('  原始矩阵残差 %s | 最大相对值 %.2e (%s 第 %d 行)\n', ...
        status_to_text(all([Residuals.satisfied])), ...
        Residuals(worst).relative_value, Residuals(worst).name, ...
        Residuals(worst).worst_row);
    norm_text = arrayfun(@(M) sprintf('%s %.2e', ...
        erase(M.name, '_norm_inf'), M.value), Norms, 'UniformOutput', false);
    fprintf('  解的量级 %s | %s | 上限 %.1e\n', ...
        status_to_text(all([Norms.satisfied])), ...
        strjoin(norm_text(:)', ' '), Norms(1).tolerance);

    % 只展开超容差的行，展开开关打开时全部列出
    show_rows = show_all | ~[Metrics.satisfied];
    if ~any(show_rows)
        return;
    end
    widths = [18, 11, 11, 11, 6, 13];
    print_table_row({'名称', '数值', '相对值', '容差', '最坏行', '状态'}, ...
        widths, 4);
    for m = find(show_rows)
        if Metrics(m).evaluated
            status_text = status_to_text(Metrics(m).satisfied);
        else
            status_text = 'NOT_AVAILABLE';
        end
        print_table_row({Metrics(m).name, ...
            format_number(Metrics(m).value), ...
            format_number(Metrics(m).relative_value), ...
            format_number(Metrics(m).tolerance), ...
            format_integer(Metrics(m).worst_row), status_text}, widths, 4);
    end
end


function print_worst_linear_rows(title, ResidualRows, SpanRows, sort_by)
% PRINT_WORST_LINEAR_ROWS 按相对残差或行内跨度列出最大的 5 行，并给出同一行的另一项。
%
% ResidualRows 与 SpanRows 按 A 的行号一一对应（见 evaluate_solver_feasibility
% 与 scan_problem_coefficients）。块内行是该行在所属块行列表中的序号。

    if strcmp(sort_by, 'relative')
        [~, order] = sort(ResidualRows.relative, 'descend', 'MissingPlacement', 'last');
    else
        [~, order] = sort(SpanRows.span, 'descend', 'MissingPlacement', 'last');
    end
    order = order(1:min(5, numel(order)));

    fprintf('    %s:\n', title);
    widths = [18, 6, 10, 10];
    print_table_row({'块', '块内行', '相对残差', '行内跨度'}, widths, 4);
    for row = order(:)'
        block = ResidualRows.block(row);
        if block > 0
            block_name = ['A.', ResidualRows.block_names{block}];
            local_row = sum(ResidualRows.block(1:row) == block);
        else
            block_name = '(无块)';
            local_row = row;
        end
        print_table_row({block_name, format_integer(local_row), ...
            format_short(ResidualRows.relative(row)), ...
            format_short(SpanRows.span(row))}, widths, 4);
    end
end


function print_mosek_warnings(Report, show_all)
% PRINT_MOSEK_WARNINGS 打印 MOSEK 日志中的警告；展开时附原文和 MOSEK 自报的违反量。

    if ~Report.log_captured
        fprintf('  MOSEK 警告 NOT_AVAILABLE (log_level=0，日志为空)\n');
    elseif isempty(Report.warning_lines)
        fprintf('  MOSEK 警告 无\n');
    else
        fprintf('  MOSEK 警告 WARN | 编号 %s\n', ...
            strjoin(arrayfun(@num2str, Report.warning_codes, ...
            'UniformOutput', false), ', '));
        for k = 1:numel(Report.warning_lines)
            print_warning_line(Report.warning_lines{k}, show_all);
        end
    end

    if show_all
        fprintf(['  MOSEK 自报违反 | 原始 线性 %.1e 变量 %.1e 锥 %.1e | ' ...
            '对偶 %.1e\n'], Report.primal_violation_con, ...
            Report.primal_violation_var, Report.primal_violation_acc, ...
            Report.dual_violation_con);
    end
end


function print_warning_line(line_text, show_all)
% PRINT_WARNING_LINE 打印一条 MOSEK 警告：展开时打原文，否则只打名称和指向的行/列号。

    if show_all
        % 原文较长，按 72 列折行
        print_wrapped(line_text, 72);
        return;
    end
    % 例如 MSK_RES_WRN_ZEROS_IN_SPARSE_COL (A 的 3304)，MOSEK 从 0 起数
    name = regexp(line_text, 'MSK_RES_WRN_\w+', 'match', 'once');
    position = regexp(line_text, ...
        '\((\d+)\) of matrix ''(\w+)''', 'tokens', 'once');
    if isempty(name)
        return;
    elseif isempty(position)
        fprintf('    %s\n', name);
    else
        fprintf('    %s (%s 的 %s)\n', name, position{2}, position{1});
    end
end


function print_coefficient_summary(Report, show_all)
% PRINT_COEFFICIENT_SUMMARY 打印求解前系数量级扫描，超阈值的块列表展开。

    if ~Report.evaluated
        fprintf('  系数量级 NOT_AVAILABLE (没有装配矩阵)\n');
        return;
    end

    % 系数量级只提示风险：超阈值记 WARN，有 NaN/Inf 才记 FAIL
    if Report.num_nonfinite > 0
        status_text = 'FAIL';
    elseif ~Report.success
        status_text = 'WARN';
    else
        status_text = 'PASS';
    end
    fprintf('  系数量级 %s | 超阈值 %d 块 | 小系数 %d 个 | 非法值 %d 个\n', ...
        status_text, numel(Report.flagged_names), Report.num_tiny, ...
        Report.num_nonfinite);

    % 默认只列出超阈值的块（阈值见 config.solver.numerics）；展开时列出
    % 全部块，超阈值的块名后加 *
    if show_all
        Blocks = Report.blocks;
    else
        Blocks = Report.blocks([Report.blocks.flagged]);
    end
    if isempty(Blocks)
        return;
    end
    widths = [19, 9, 6, 9, 9, 6, 9];
    print_table_row({'块', '行内跨度', '块内行', '最小系数', '最大系数', ...
        '小系数', '最大界值'}, widths, 4);
    for b = 1:numel(Blocks)
        block_name = Blocks(b).name;
        if show_all && Blocks(b).flagged
            block_name = [block_name, '*']; %#ok<AGROW>
        end
        print_table_row({block_name, ...
            format_short(Blocks(b).max_row_span), ...
            format_integer(Blocks(b).worst_row), ...
            format_short(Blocks(b).min_abs), ...
            format_short(Blocks(b).max_abs), ...
            format_integer(Blocks(b).num_tiny), ...
            format_short(Blocks(b).max_abs_bound)}, widths, 4);
    end
end


%% ===== 3. P3 解检查 =====

function print_p3_checks(SubproblemDiag, Solution, PointsBounds, ...
        ConstData, show_all)
% PRINT_P3_CHECKS 打印 P3 解检查：松弛、锥可行性、无损紧性；ccd_lu 模式下再加一行单位范数 ε。

    fprintf('\nP3 解检查:\n');
    print_metric_group('松弛', SubproblemDiag.p3_check.slack_report.metrics, ...
        Solution, ConstData, show_all, false);
    print_reformulation_check(SubproblemDiag.p3_check.reformulation_report, ...
        Solution, PointsBounds, ConstData, show_all);
    print_unit_norm_line(SubproblemDiag.control_report);
end


function print_unit_norm_line(ControlReport)
% PRINT_UNIT_NORM_LINE ccd_lu 模式（控制量报告里有 ε）时在锥重构一行之后加一行：
% ε 最大值、触上界的节点数（有节点触上界记 WARN）、|1-‖u‖| 最大值和不紧的节点数。
%
% regularized 下 control_report.unit_norm_slack 全为 NaN，不打这一行。

    if ~ControlReport.evaluated || isempty(ControlReport.unit_norm_slack) ...
            || all(isnan(ControlReport.unit_norm_slack))
        return;
    end
    Summary = ControlReport.summary_total;
    if any(Summary.num_slack_capped > 0)
        mark = 'WARN';
    else
        mark = '    ';
    end
    fprintf('  %s 单位范数 ε最大 %.2e | 触上界 %d | |1-‖u‖| %.2e | 不紧 %d\n', ...
        mark, max(ControlReport.unit_norm_slack), Summary.num_slack_capped, ...
        Summary.max_abs_tight_gap, Summary.num_untight);
end


function print_metric_group(label, Metrics, Solution, ConstData, ...
        show_all, show_altitude)
% PRINT_METRIC_GROUP 打印一组检查指标：先一行结论，再按需展开明细表。
%
% 全部通过时结论行给出相对容差最大的一项；有不通过的项时只展开这些项，
% 展开开关打开时列出全部。数值按 convert_metric_to_display 换成物理单位
% 显示；show_altitude 为 true 时在位置后加该节点的高度。
% Metrics 为空（该组检查未评价）时只打一行 NOT_AVAILABLE。

    if isempty(Metrics)
        fprintf('  %s NOT_AVAILABLE (未评价)\n', label);
        return;
    end
    row_list = cell(1, numel(Metrics));
    for m = 1:numel(Metrics)
        row_list{m} = convert_metric_to_display(Metrics(m));
    end
    Rows = [row_list{:}];

    failed = ~[Metrics.satisfied];
    if any(failed)
        fprintf('  %s FAIL | %d 项超容差\n', label, sum(failed));
    else
        [~, worst] = max([Metrics.ratio]);
        fprintf('  %s PASS | 最大 %s %s (%s)\n', label, ...
            format_number(Rows(worst).value), Rows(worst).unit, ...
            Rows(worst).name);
    end

    show_rows = show_all | failed;
    if ~any(show_rows)
        return;
    end
    headers = {'名称', '数值', '容差', '单位', '状态', '位置'};
    widths = [18, 11, 11, 7, 6, 11];
    if show_altitude
        headers{end + 1} = '高度 km';
        widths = [8, 11, 11, 6, 6, 11, 8];
    end
    print_table_row(headers, widths, 4);
    for m = find(show_rows)
        cells = {Rows(m).name, format_number(Rows(m).value), ...
            format_number(Rows(m).tolerance), Rows(m).unit, ...
            status_to_text(Metrics(m).satisfied), Rows(m).location};
        if show_altitude
            cells{end + 1} = format_altitude(Solution, Rows(m).node, ...
                ConstData); %#ok<AGROW>
        end
        print_table_row(cells, widths, 4);
    end
end


function print_reformulation_check(Report, Solution, PointsBounds, ...
        ConstData, show_all)
% PRINT_REFORMULATION_CHECK 打印锥可行性、上图紧性、无损紧性；展开时定位到锥和节点。

    fprintf('  锥重构 %s | 可行性 %.2e | 上图紧性 %.2e | 无损紧性 %.2e\n', ...
        status_to_text(Report.success), Report.max_feasibility_residual, ...
        Report.max_epigraph_gap, Report.max_lossless_gap);
    if ~show_all
        return;
    end

    Metrics = Report.metrics;
    % 可行性和上图紧性：给出最大值所在的锥名和它在同名锥中的序号
    [value, k] = max([Metrics.feasibility_residual]);
    fprintf('    可行性   最大 %.2e (%s 第 %d 个)\n', value, ...
        Metrics(k).name, Metrics(k).index);
    Epigraph = Metrics(strcmp({Metrics.tightness_role}, 'epigraph'));
    if ~isempty(Epigraph)
        [value, k] = max([Epigraph.tightness_gap]);
        fprintf('    上图紧性 最大 %.2e (%s 第 %d 个)\n', value, ...
            Epigraph(k).name, Epigraph(k).index);
    end

    Lossless = Metrics(strcmp({Metrics.tightness_role}, 'lossless'));
    if ~isempty(Lossless)
        print_lossless_detail(Lossless, Solution, PointsBounds, ConstData);
    end
end


function print_lossless_detail(Lossless, Solution, PointsBounds, ConstData)
% PRINT_LOSSLESS_DETAIL 无损紧性定位：每圈一行统计，再列 ‖u‖ 偏离 1 最多的 5 个节点。
%
% control_disk 锥的 index 就是节点号（见 build_conic_constraints），
% ‖u‖ 取自锥检查记下的 vector_norm。

    nodes = [Lossless.index];
    unorm = [Lossless.vector_norm];
    gap = [Lossless.tightness_gap];
    failed = ~[Lossless.tightness_satisfied];
    fprintf('    无损紧性 %s | 超容差 %d 个节点 / 共 %d | 最小 ‖u‖ %.4f\n', ...
        status_to_text(~any(failed)), sum(failed), numel(nodes), min(unorm));

    % 每圈一行
    widths = [3, 6, 6, 8, 8, 8];
    print_table_row({'圈', '节点数', '超容差', '最小‖u‖', '所在节点', ...
        '高度 km'}, widths, 6);
    for cir = 1:numel(PointsBounds)
        in_cir = nodes >= PointsBounds(cir).begin ...
            & nodes <= PointsBounds(cir).end;
        [cir_min, k] = min(unorm(in_cir));
        cir_nodes = nodes(in_cir);
        print_table_row({sprintf('%d', cir), sprintf('%d', sum(in_cir)), ...
            sprintf('%d', sum(failed(in_cir))), sprintf('%.4f', cir_min), ...
            sprintf('%d', cir_nodes(k)), ...
            format_altitude(Solution, cir_nodes(k), ConstData)}, widths, 6);
    end

    % 偏离最多的 5 个节点
    [~, order] = sort(gap, 'descend');
    order = order(1:min(5, numel(order)));
    fprintf('      |1-‖u‖| 最大的 5 个节点:\n');
    widths = [5, 3, 8, 8, 7, 8, 8, 7];
    print_table_row({'节点', '圈', '圈内位置', '高度 km', '‖u‖', 'u1', ...
        'u2', 'σ deg'}, widths, 6);
    for k = order(:)'
        node = nodes(k);
        [cir, position, count] = locate_node(node, PointsBounds);
        u1 = Solution.control.u1(node);
        u2 = Solution.control.u2(node);
        print_table_row({sprintf('%d', node), sprintf('%d', cir), ...
            sprintf('%d/%d', position, count), ...
            format_altitude(Solution, node, ConstData), ...
            sprintf('%.4f', unorm(k)), sprintf('%.4f', u1), ...
            sprintf('%.4f', u2), sprintf('%.1f', transform_u2sigma(u2, u1))}, ...
            widths, 6);
    end
end


%% ===== 4. 迭代分析 =====

function print_iteration_analysis(TrustResult, P2Feasibility, config, show_all)
% PRINT_ITERATION_ANALYSIS 打印迭代分析：预测下降、预测误差和真实下降的组成、ρ、门槛、半径、K 估计、驻点度量的上界和决策。
%
% 数学形式:
%   目标分三部分: 性能指标 C（总脉冲）、附加项 Γ（控制正则项）、罚项 Θ。
%   预测下降 ΔL = 性能指标的预测下降 + 附加项的预测下降 + 罚项的预测下降
%   预测误差 D  = 性能指标的预测误差 + 附加项的预测误差 + 罚项的预测误差
%   真实下降 ΔJ = 性能指标的真实下降 + 附加项的真实下降 + 罚项的真实下降 = ΔL − D
%   ρ = 1 − D/ΔL = ΔJ/ΔL；门槛 (1−ρ1)ΔL，D 不超过它时 ρ ≥ ρ1；
%   K 估计 D/‖d‖²（‖d‖ 以基准半径为单位）；
%   驻点度量的上界 (r_max/r)ΔL 不超过 ε 时驻点判据成立。
%   同一参考点上被拒绝后再求解时，给出 D、ΔL、1−ρ 和动力学余项四部分随半径变化的阶 p:
%   p 接近 2 是二次项为主，接近 1 是一次项为主，接近 0 是与半径无关的项为主；
%   ΔL 的阶在 0 和 1 之间（ΔL(r) 是凹的）；余项四部分按理论依次接近 2、1、1、0。
%   动力学余项按阶: 二次 = 状态×状态，一次 = 状态×控制 + 状态×时长，
%   与半径无关 = 控制×时长。
%
% 代码形式:
%   默认内容（每行不超过 78 个显示列）按行读 trust.evaluation:
%     预测下降两行（文字行 + 数值行，数值按列对齐；P3 抬升了性能指标或附加项时
%     另起一行注明）、预测误差两行、真实下降两行、性能指标两行（参考处、候选解处、
%     P3 值一行，候选解的总脉冲 m/s 另起一行；总脉冲取 P2Feasibility.performance_report）、
%     附加项一行、罚项一行、下降比一行、门槛一行、半径一行、K 估计一行、同一参考点两行（D、ΔL、
%     1−ρ 的阶一行，“余项的阶”一行写四部分各自的阶；有才打）、动力学余项按阶一行、
%     驻点度量的上界一行、决策一行。ΔL、D、ΔJ 及其三部分、三部分在三处的值、门槛
%     用 6 位有效数字（%.5e），性能指标和附加项部分常比罚项部分小两三个数量级，
%     位数少了定不准。
%   展开（show_all）时再列四张表: 分项表、子项表、各通道步长/半径、余项按阶逐通道。
%   这些量都只报告，不参与接受、半径更新和停止。

    fprintf('\n迭代分析 (参考点 z^k -> 候选解 z^k+d^k):\n');
    Evaluation = TrustResult.evaluation;
    if ~Evaluation.evaluated
        fprintf('  NOT_AVAILABLE (%s)\n', Evaluation.reason);
        return;
    end

    %% 预测下降、预测误差和真实下降的组成
    Group = Evaluation.group;
    group_names = {'性能指标的预测下降', '附加项的预测下降', '罚项的预测下降'};
    print_equation_lines('预测下降 ΔL', group_names, ...
        [Evaluation.predicted_reduction, Group.cost.predicted, ...
        Group.extra.predicted, Group.penalty.predicted]);
    print_raised_parts(Group.cost.predicted < 0, Group.extra.predicted < 0);
    group_names = {'性能指标的预测误差', '附加项的预测误差', '罚项的预测误差'};
    print_equation_lines('预测误差 D ', group_names, ...
        [Evaluation.prediction_error, Group.cost.error, ...
        Group.extra.error, Group.penalty.error]);
    group_names = {'性能指标的真实下降', '附加项的真实下降', '罚项的真实下降'};
    print_equation_lines('真实下降 ΔJ', group_names, ...
        [Evaluation.actual_reduction, Group.cost.actual, ...
        Group.extra.actual, Group.penalty.actual]);

    %% 三部分在参考处、候选解处和 P3 的值
    % 第一行超过 78 列，总脉冲另起一行，与“参考处”对齐
    fprintf('  性能指标: 参考处 %s | 候选解处 %s | P3 值 %s\n', ...
        format_long(Group.cost.reference), ...
        format_long(Group.cost.candidate), format_long(Group.cost.p3));
    fprintf('            总脉冲 %.3f m/s\n', ...
        P2Feasibility.performance_report.value);
    fprintf('  附加项:   参考处 %s | 候选解处 %s | P3 值 %s\n', ...
        format_long(Group.extra.reference), ...
        format_long(Group.extra.candidate), format_long(Group.extra.p3));
    fprintf('  罚项: 参考处 %s | 候选解处 %s | 松弛罚项 %s\n', ...
        format_long(Evaluation.group.penalty.reference), ...
        format_long(Evaluation.group.penalty.candidate), ...
        format_long(Evaluation.slack_penalty));

    %% 下降比和门槛
    if Evaluation.ratio_available
        fprintf('  下降比 ρ = 1 - D/ΔL = ΔJ/ΔL = %.6f\n', Evaluation.ratio);
        if Evaluation.ratio_held
            held_text = '(ρ ≥ ρ1, 能维持)';
        else
            held_text = '(ρ < ρ1)';
        end
        fprintf('  门槛 (1-ρ1)ΔL = %s | D/门槛 = %.2f %s\n', ...
            format_long(Evaluation.threshold), ...
            Evaluation.error_to_threshold, held_text);
    else
        fprintf('  下降比 ρ 未算 (%s)\n', Evaluation.reason);
    end

    %% 半径、步长、K 估计
    fprintf('  半径 r = %.4g (r_max %.4g) | 步长/半径 %.2f (%s) | 松弛为零 %s\n', ...
        Evaluation.radius_scale, Evaluation.radius_scale_max, ...
        Evaluation.step_ratio, Evaluation.step_ratio_channel, ...
        logical_to_text(Evaluation.slack_zero));
    if isfinite(Evaluation.curvature_estimate)
        fprintf('  K 估计 D/‖d‖² = %s\n', ...
            format_short(Evaluation.curvature_estimate));
    else
        fprintf('  K 估计 D/‖d‖² 未算 (步长为 0 或值非有限)\n');
    end

    %% 同一参考点上一次求解、动力学余项按阶
    if Evaluation.same_reference.available
        print_same_reference_line(Evaluation.same_reference, Evaluation);
    end
    Split = Evaluation.remainder_split;
    if Split.evaluated
        fprintf('  动力学余项按阶: 二次 %s | 一次 %s | 与半径无关 %s\n', ...
            format_short(Split.weighted(1)), ...
            format_short(Split.weighted(2) + Split.weighted(3)), ...
            format_short(Split.weighted(4)));
        % closure 是余项拆分的自检；超限说明符号、区间顺序或 t_f 的单位有一处不对
        if Split.closure > 1e-6 * max(Split.total / config.objective.weight_dyn_slack, 1e-12)
            fprintf('  WARN 余项拆分对不上 (closure %s)\n', format_short(Split.closure));
        end
    end

    %% 驻点度量的上界
    if isfinite(Evaluation.stationarity_bound)
        if Evaluation.stationarity_bound <= Evaluation.stationarity_tolerance
            compare_text = '≤';
        else
            compare_text = '>';
        end
        fprintf('  驻点度量的上界 (r_max/r)ΔL = %s %s ε %.1e\n', ...
            format_short(Evaluation.stationarity_bound), compare_text, ...
            Evaluation.stationarity_tolerance);
    else
        fprintf('  驻点度量的上界 未算 (ΔL 为负)\n');
    end

    %% 决策
    if Evaluation.convex_error_flag
        short_names = cellfun(@describe_penalty_term, ...
            Evaluation.convex_error_names, 'UniformOutput', false);
        fprintf('  WARN 凸项 %s 的 D 不为 0 (J 与 L 对凸项应同算法)\n', ...
            strjoin(short_names, ', '));
    end
    if strcmp(config.trust_region.method, 'ratio') && Evaluation.ratio_available
        fprintf('  ρ 所在行: %s\n', describe_ratio_band(Evaluation.ratio_band));
    end
    print_decision_line(TrustResult, config);

    if show_all
        print_analysis_tables(Evaluation);
    end
end


function print_equation_lines(left_name, part_names, values)
% PRINT_EQUATION_LINES 打印“左 = 部分一 + 部分二 + ...”的文字行和下一行与之按列对齐的数值行。
%
% values 为 [左, 各部分]，与 part_names 一一对应，按 %.5e（6 位有效数字）写。

    left_text = ['  ' left_name];
    fprintf('%s = %s\n', left_text, strjoin(part_names, ' + '));
    number_cells = cell(1, numel(part_names));
    for p = 1:numel(part_names)
        number_cells{p} = pad_text(format_long(values(p + 1)), ...
            display_width(part_names{p}), 'right');
    end
    fprintf('%s = %s\n', ...
        pad_text(format_long(values(1)), display_width(left_text), 'right'), ...
        strjoin(number_cells, ' + '));
end


function print_raised_parts(cost_raised, extra_raised)
% PRINT_RAISED_PARTS P3 抬升了性能指标或附加项（该部分的预测下降为负）时另起一行注明。

    if cost_raised && extra_raised
        fprintf('  P3 抬升了性能指标和附加项\n');
    elseif cost_raised
        fprintf('  P3 抬升了性能指标\n');
    elseif extra_raised
        fprintf('  P3 抬升了附加项\n');
    end
end


function print_same_reference_line(SameReference, Evaluation)
% PRINT_SAME_REFERENCE_LINE 打印同一参考点上一次求解和这一次的 r、D 对比，D、ΔL、1−ρ 随半径变化的阶，以及动力学余项四部分各自的阶。
%
% 余项四部分的阶按理论依次接近 2、1、1、0；哪一部分的阶明显偏离，D 不按半径的
% 二次下降就出在那一部分。下降比的阶对 1−ρ = D/ΔL 算（ρ 趋于 1），等于 D 的阶减
% ΔL 的阶：ΔL 不随半径变时接近 2，ΔL 按一次变时接近 1。

    pieces = { ...
        sprintf('  同一参考点: r %.4g -> %.4g', SameReference.radius_scale, ...
            Evaluation.radius_scale), ...
        sprintf('D %s -> %s', format_short(SameReference.prediction_error), ...
            format_short(Evaluation.prediction_error)), ...
        sprintf('D 的阶 %s', format_order(SameReference.error_order)), ...
        sprintf('ΔL 的阶 %s', format_order(SameReference.reduction_order)), ...
        sprintf('1-ρ 的阶 %s', format_order(SameReference.ratio_gap_order))};
    print_joined_pieces(pieces, 78);

    labels = Evaluation.remainder_split.labels;
    orders = SameReference.remainder_orders;
    pieces = cell(1, numel(labels));
    for p = 1:numel(labels)
        pieces{p} = sprintf('%s %s', labels{p}, format_order(orders(p)));
    end
    pieces{1} = ['  余项的阶: ' pieces{1}];
    print_joined_pieces(pieces, 78);
end


function text = format_order(order)
% FORMAT_ORDER 阶的文本：保留两位小数，无法定义时显示 '-'。

    if isfinite(order)
        text = sprintf('%.2f', order);
    else
        text = '-';
    end
end


function print_decision_line(TrustResult, config)
% PRINT_DECISION_LINE 打印决策（原因）和半径动作，请求与实际不同时另起一行说明。
%
% method 为 'fixed' 时行尾注明固定半径、ρ 只报告。

    Update = TrustResult.trust_region_update;
    pieces = {sprintf('  决策 %s (%s)', decision_to_text(TrustResult), ...
        TrustResult.reason), ...
        sprintf('r %.4g -> %.4g', Update.scale_before, Update.scale_after)};
    if strcmp(config.trust_region.method, 'fixed')
        pieces{end + 1} = '(固定半径, ρ 只报告)';
    end
    % 原因词最长可达 35 个字符，超宽时在句间换行
    print_joined_pieces(pieces, 78);
    if ~strcmp(Update.requested_action, Update.applied_action)
        fprintf('    请求 %s，r 已在上下限，实际保持\n', Update.requested_action);
    end
end


function print_analysis_tables(Evaluation)
% PRINT_ANALYSIS_TABLES 展开表: 分项表、子项表、各通道步长/半径、余项按阶逐通道。

    %% 分项表: 性能指标、附加项和罚项三组，各带小计，最后合计 J
    fprintf('  分项 (J 参考处/候选解处, L 为 P3 值, ΔL = J参考 - L, D = J候选解 - L):\n');
    widths = [16, 10, 10, 10, 10, 10];
    print_table_row({'分项', '参考处 J', '候选解处 J', 'P3 值 L', 'ΔL', 'D'}, ...
        widths, 4);
    is_cost = ismember(Evaluation.term_kinds, {'cost_convex', 'cost_nonconvex'});
    is_extra = ismember(Evaluation.term_kinds, {'extra_convex', 'extra_nonconvex'});
    is_penalty = ismember(Evaluation.term_kinds, ...
        {'equality_penalty', 'inequality_penalty'});
    print_ledger_group('性能指标', Evaluation.group.cost, find(is_cost), ...
        Evaluation, widths);
    print_ledger_group('附加项', Evaluation.group.extra, find(is_extra), ...
        Evaluation, widths);
    print_ledger_group('罚项', Evaluation.group.penalty, find(is_penalty), ...
        Evaluation, widths);
    print_table_row({'合计 J', format_short(Evaluation.reference.total), ...
        format_short(Evaluation.candidate.total), ...
        format_short(Evaluation.p3_value), ...
        format_short(Evaluation.predicted_reduction), ...
        format_short(Evaluation.prediction_error)}, widths, 4);

    %% 子项表: 动力学违反量按通道和圈，衔接违反量按衔接点
    if ~isempty(Evaluation.subterms)
        fprintf('  子项 (动力学违反量按通道和圈, 衔接违反量按衔接点, 加权后):\n');
        widths_sub = [20, 10, 10, 10, 10];
        print_table_row({'子项', '参考处', '候选解处', '松弛罚项', 'D'}, ...
            widths_sub, 4);
        for k = 1:numel(Evaluation.subterms)
            Sub = Evaluation.subterms(k);
            print_table_row({Sub.label, format_short(Sub.reference), ...
                format_short(Sub.candidate), format_short(Sub.p3), ...
                format_short(Sub.candidate - Sub.p3)}, widths_sub, 4);
        end
    end

    %% 各通道步长/半径
    fprintf('  各通道步长/半径:\n');
    channel_names = {'r', 'V', 'gamma', 'phi', 'psi', 'P'};
    print_table_row({'通道', '步长/半径'}, [8, 10], 4);
    for c = 1:numel(channel_names)
        print_table_row({channel_names{c}, ...
            sprintf('%.3f', Evaluation.step_ratio_channels(c))}, [8, 10], 4);
    end

    %% 余项按阶逐通道
    Split = Evaluation.remainder_split;
    if ~Split.evaluated
        return;
    end
    fprintf('  动力学余项按阶 (加权 w·Σ|R|, 逐通道):\n');
    widths_split = [10, 2, 8, 8, 8, 8, 8, 8];
    print_table_row({'部分', '阶', 'r', 'V', 'γ', 'φ', 'ψ', '合计'}, ...
        widths_split, 4);
    for p = 1:numel(Split.names)
        channel_cells = arrayfun(@format_short, Split.weighted_channel(p, :), ...
            'UniformOutput', false);
        print_table_row([{Split.labels{p}, sprintf('%d', Split.orders(p))}, ...
            channel_cells, {format_short(Split.weighted(p))}], widths_split, 4);
    end
    fprintf('    动力学余项 w·Σ|R| = %s\n', format_short(Split.total));
end


function print_ledger_group(title, Group, members, Evaluation, widths)
% PRINT_LEDGER_GROUP 打印一组的小计行，再缩进列出这一组的各分项。

    print_table_row({title, format_short(Group.reference), ...
        format_short(Group.candidate), format_short(Group.p3), ...
        format_short(Group.predicted), format_short(Group.error)}, widths, 4);
    for k = members(:)'
        print_table_row({['  ' Evaluation.term_labels{k}], ...
            format_short(Evaluation.term_reference(k)), ...
            format_short(Evaluation.term_candidate(k)), ...
            format_short(Evaluation.term_p3(k)), ...
            format_short(Evaluation.term_predicted_reduction(k)), ...
            format_short(Evaluation.term_prediction_error(k))}, widths, 4);
    end
end


function text = describe_ratio_band(band)
% DESCRIBE_RATIO_BAND ρ 所在经典表行及该行的动作（ρ0、ρ1、ρ2 即 accept_ratio、shrink_ratio、expand_ratio）。

    switch band
        case 'below_rho0'
            text = '第 1 行 ρ < ρ0: 拒绝, 缩小';
        case 'rho0_rho1'
            text = '第 2 行 ρ0 ≤ ρ < ρ1: 接受, 缩小';
        case 'rho1_rho2'
            text = '第 3 行 ρ1 ≤ ρ < ρ2: 接受, 保持';
        case 'above_rho2'
            text = '第 4 行 ρ ≥ ρ2: 接受, 扩大';
        otherwise
            text = '';
    end
end


%% ===== 5. P3 乘子 =====

function print_multipliers(Report, show_all)
% PRINT_MULTIPLIERS 打印 P3 的乘子：罚项类的 |λ|/w，以及信赖域界的生效个数。
%
% 数学形式 (详见 evaluate_p3_multipliers):
%   罚项类约束里松弛的系数为 +1，目标里的松弛罚项是 w·|ν|，所以最优时 |λ| ≤ w。
%   |λ|/w < 1 表示这一类没顶到罚权（罚权再加大解也不变），等于 1 表示松弛在起作用。
%   信赖域界生效指该变量的信赖域界乘子大于容差。
%
% 代码形式:
%   默认两行：罚项类（动力学、衔接、终端倾角、终端远地点）各自的最大 |λ|/w，
%   比值达到 0.999 记 *；信赖域界生效个数和生效最多的通道。
%   展开时另列所有约束类的 max|λ| 和位置，以及信赖域各通道的生效数。

    capped_ratio = 0.999;
    fprintf('\nP3 乘子 (|λ|/w < 1: 没顶到罚权, * 为顶到):\n');
    if ~Report.evaluated
        fprintf('  NOT_AVAILABLE (%s)\n', Report.reason);
        return;
    end

    is_penalty = isfinite([Report.classes.weight]);
    PenaltyClasses = Report.classes(is_penalty);
    parts = cell(1, numel(PenaltyClasses));
    for k = 1:numel(PenaltyClasses)
        if PenaltyClasses(k).ratio >= capped_ratio
            mark = '*';
        else
            mark = '';
        end
        parts{k} = sprintf('%s %.3f%s', PenaltyClasses(k).label, ...
            PenaltyClasses(k).ratio, mark);
    end
    fprintf('  |λ|/w  %s\n', strjoin(parts, ' | '));

    active_total = sum(Report.trust_active_count);
    if active_total > 0
        [top_count, top] = max(Report.trust_active_count);
        fprintf('  信赖域界: 生效 %d 个 | 最多的通道 %s (%d 个)\n', ...
            active_total, Report.trust_channel_names{top}, top_count);
    else
        fprintf('  信赖域界: 生效 0 个\n');
    end

    if ~show_all
        return;
    end
    % 展开 (a): 所有约束类的 max|λ|、罚权、比值和最大值所在位置
    widths = [14, 10, 8, 8, 18];
    print_table_row({'约束类', 'max|λ|', '罚权 w', '|λ|/w', '位置'}, ...
        widths, 4);
    for k = 1:numel(Report.classes)
        Class = Report.classes(k);
        if isfinite(Class.weight)
            weight_text = sprintf('%g', Class.weight);
            ratio_text = sprintf('%.3f', Class.ratio);
        else
            weight_text = '-';
            ratio_text = '-';
        end
        print_table_row({Class.label, format_short(Class.max_abs), ...
            weight_text, ratio_text, Class.location}, widths, 4);
    end
    % 展开 (b): 信赖域各通道的生效数
    widths = [8, 8];
    print_table_row({'通道', '生效数'}, widths, 4);
    for c = 1:numel(Report.trust_channel_names)
        print_table_row({Report.trust_channel_names{c}, ...
            sprintf('%d', Report.trust_active_count(c))}, widths, 4);
    end
end


%% ===== 6. P2 可行性检查 =====

function print_p2_feasibility(P2Feasibility, Solution, ConstData, ...
        show_all, config)
% PRINT_P2_FEASIBILITY 打印 P2 可行性检查：逐区间的梯形动力学，以及与真空段积分的对照。
%
% 分两组。逐区间的梯形动力学：动力学违反量。与真空段积分的对照：衔接违反量、
% 终端违反量，以及终端映射的余项（积分得到的终端量减 P3 的终端量，只报告，
% 不计入对 P2 可行）。动力学和衔接两项另给 Σ|g| 和乘罚权后的罚项，与罚函数对照。

    fprintf('\nP2 可行性检查:\n');
    DynamicsReport = P2Feasibility.dynamics_report;
    JunctionReport = P2Feasibility.junction_report;

    fprintf('  逐区间的梯形动力学（节点值代入原动力学）:\n');
    fprintf('  动力学违反量 %s | 最大比值 %.3e | Σ|g| %.6e | 罚项 %.6e\n', ...
        status_to_text(DynamicsReport.success), DynamicsReport.max_ratio, ...
        DynamicsReport.sum_abs, ...
        config.objective.weight_dyn_slack * DynamicsReport.sum_abs);
    print_metric_group('动力学违反量', DynamicsReport.metrics, ...
        Solution, ConstData, show_all, show_all);
    if show_all
        print_worst_dynamics_intervals(DynamicsReport);
    end

    fprintf('  与真空段积分的对照（从节点值出发积分；余项为积分值减 P3 值）:\n');
    fprintf('  衔接违反量 %s | 最大比值 %.3e | Σ|g| %.6e | 罚项 %.6e\n', ...
        status_to_text(JunctionReport.success), JunctionReport.max_ratio, ...
        JunctionReport.sum_abs, ...
        config.objective.weight_point_slack * JunctionReport.sum_abs);
    print_metric_group('衔接违反量', JunctionReport.metrics, ...
        Solution, ConstData, show_all, false);
    print_metric_group('终端违反量', P2Feasibility.terminal_report.metrics, ...
        Solution, ConstData, show_all, false);
    print_metric_group('终端映射的余项（只报告）', ...
        P2Feasibility.terminal_remainder_report.metrics, ...
        Solution, ConstData, show_all, false);
end


function print_worst_dynamics_intervals(DynamicsReport)
% PRINT_WORST_DYNAMICS_INTERVALS 列出相对容差最大的那个通道上动力学违反量最大的 3 个区间。

    [~, s] = max([DynamicsReport.metrics.ratio]);
    % 该通道的物理换算系数与单位直接取自报告（evaluate_dynamics_violation）
    scale = DynamicsReport.scale(s);
    unit = DynamicsReport.metrics(s).unit;
    [values, order] = sort(DynamicsReport.interval_values(:, s), 'descend');
    count = min(3, numel(order));
    parts = cell(1, count);
    for k = 1:count
        parts{k} = sprintf('节点%d %.3g', ...
            DynamicsReport.interval_node(order(k)), values(k) * scale);
    end
    fprintf('    %s 最差 %d 个区间: %s (%s)\n', ...
        DynamicsReport.metrics(s).name, count, ...
        strjoin(parts, ' | '), unit);
end


%% ===== 7. 约束对照 =====

function print_constraint_comparison(P2Feasibility, TrapezoidCheck)
% PRINT_CONSTRAINT_COMPARISON 对照 P2 节点值与梯形递推的路径和终端约束。
%
% P2 节点值列读优化节点上的报告（路径约束的节点最大值、终端违反量），
% 梯形递推列读 TrapezoidCheck；两列结论不一致时在同一行并列，不合并。
% 状态列为“P2 节点值|梯形递推”。

    NodeMetrics = {P2Feasibility.path_report.metrics(1), ...
        P2Feasibility.path_report.metrics(2), ...
        P2Feasibility.path_report.metrics(3), ...
        P2Feasibility.terminal_report.metrics(1), ...
        P2Feasibility.terminal_report.metrics(2)};
    names = {'动压 q', '热流 Qdot', '过载 n', '终端远地点违反量', ...
        '终端倾角违反量'};
    trapezoid_ok = TrapezoidCheck.evaluated && TrapezoidCheck.success;
    fprintf('\n约束对照:\n');
    if ~trapezoid_ok
        fprintf('  梯形递推未评价 (%s)\n', TrapezoidCheck.failure_reason);
        TrapezoidMetrics = NodeMetrics;
    else
        TrapezoidMetrics = {TrapezoidCheck.path_report.metrics(1), ...
            TrapezoidCheck.path_report.metrics(2), ...
            TrapezoidCheck.path_report.metrics(3), ...
            TrapezoidCheck.terminal_report.metrics(1), ...
            TrapezoidCheck.terminal_report.metrics(2)};
    end
    widths = [14, 11, 11, 11, 7, 13];
    print_table_row({'名称', 'P2 节点值', '梯形递推', '上限/容差', '单位', ...
        '状态'}, widths);
    for k = 1:numel(NodeMetrics)
        NodeMetric = NodeMetrics{k};
        [node_value, limit] = read_node_value_and_limit(NodeMetric);
        if trapezoid_ok
            [integrated_value, ~] = read_node_value_and_limit(TrapezoidMetrics{k});
            integrated_text = format_number(integrated_value);
            integrated_status = status_to_text(TrapezoidMetrics{k}.satisfied);
        else
            integrated_text = '-';
            integrated_status = 'SKIPPED';
        end
        print_table_row({names{k}, format_number(node_value), ...
            integrated_text, format_number(limit), ...
            display_unit(NodeMetric.unit), ...
            [status_to_text(NodeMetric.satisfied), '|', ...
            integrated_status]}, widths);
    end
end


%% ===== 8. 物理量 =====

function print_physical_quantities(Solution, SubproblemDiag, TrapezoidCheck, ...
        Reference, ConstData, show_all)
% PRINT_PHYSICAL_QUANTITIES 打印本轮关键物理量（三行，展开时加脉冲表和每圈表）。
%
% 默认三类各一行：总脉冲与终端倾角（读 P2 可行性检查的重算值）、各段飞行时间
% t_f（优化变量，附参考值与本轮变化）、梯形递推完成情况。展开时另列逐次脉冲，
% 以及每圈的飞行时间（含参考值）、最低高度、路径峰值（优化节点）。
% 罚函数 J 与 P3 目标 L 的分项对照已并入第 4 块，这里不再重复。

    fprintf('\n物理量:\n');
    fprintf('  总脉冲 Σ|P| %.2f m/s | 终端倾角 %.2f deg (目标 %.2f deg)\n', ...
        SubproblemDiag.p2_feasibility.performance_report.value, ...
        SubproblemDiag.p2_feasibility.terminal_report.metrics(2).actual_value, ...
        rad2deg(ConstData.i_aim));
    % t_f 是优化变量：各段值、总值与相对本轮参考的总变化（物理秒）
    tf_display = Solution.t_f * ConstData.TU;
    tf_total_change = sum(Solution.t_f - Reference.t_f) * ConstData.TU;
    fprintf('  t_f (s): %s | 总 %.1f | 较参考 %+.1f\n', ...
        strjoin(arrayfun(@(x) sprintf('%.1f', x), tf_display, ...
        'UniformOutput', false), ' '), ...
        sum(tf_display), tf_total_change);
    % 梯形递推只提供终端、路径和总脉冲，不再回放各圈远地点
    if TrapezoidCheck.evaluated && TrapezoidCheck.success
        fprintf('  梯形递推: 完成 | 最大单步残差 %.2e | 最长牛顿迭代 %d\n', ...
            TrapezoidCheck.recursion_report.max_step_residual, ...
            TrapezoidCheck.recursion_report.max_newton_iterations);
        fprintf('  梯形递推总脉冲: %.2f m/s | 路径 %s | 递推值与节点值最大差 %s\n', ...
            TrapezoidCheck.performance_report.value, ...
            status_to_text(TrapezoidCheck.path_report.success), ...
            describe_trapezoid_deviation(TrapezoidCheck.deviation_report));
    else
        fprintf('  梯形递推: 未完成 (%s)\n', TrapezoidCheck.failure_reason);
        if TrapezoidCheck.recursion_report.evaluated
            Recursion = TrapezoidCheck.recursion_report;
            fprintf(['  已完成区间 %d | 最后递推节点 %d | 失败区间 %d' ...
                ' (试探残差 %.2e) | 后续未评价\n'], ...
                Recursion.num_completed_intervals, Recursion.last_completed_node, ...
                Recursion.failing_interval, Recursion.failure_step_residual);
        end
    end
    if show_all
        print_pulse_table(SubproblemDiag.p2_feasibility.performance_report.components ...
            / ConstData.VU, ConstData);
        print_circle_table(Solution, Reference.t_f, ...
            SubproblemDiag.p2_feasibility.path_report, ...
            Reference.PointsBounds, ConstData);
    end
    fprintf('  目标远地点 ra (km): %.0f\n', ...
        ConstData.R_aaim * ConstData.LU / 1e3);
end


function text = describe_trapezoid_deviation(Deviations)
% DESCRIBE_TRAPEZOID_DEVIATION 给出递推值与节点值之差最大的物理通道。

    [value, index] = max([Deviations.value]);
    text = sprintf('%.3g %s (%s)', value, Deviations(index).unit, ...
        Deviations(index).name);
end


function print_pulse_table(P, ConstData)
% PRINT_PULSE_TABLE 一行列出各次脉冲（m/s，带符号）。

    num_pulses = numel(P);
    headers = [{'脉冲'}, arrayfun(@(k) sprintf('P%d', k), 1:num_pulses, ...
        'UniformOutput', false), {'单位'}];
    values = [{'优化解'}, arrayfun(@(p) sprintf('%.2f', p * ConstData.VU), ...
        P(:)', 'UniformOutput', false), {'m/s'}];
    widths = [6, 7 * ones(1, num_pulses), 5];
    print_table_row(headers, widths, 4);
    print_table_row(values, widths, 4);
end


function print_circle_table(Solution, reference_t_f, PathReport, ...
        PointsBounds, ConstData)
% PRINT_CIRCLE_TABLE 每圈一行显示节点路径峰值、飞行时间及最低高度。
%
% 峰值从 PathReport.node_values 取各圈节点的最大值，最低高度从优化节点
% 半径取最小值；两者均只读已保存的数据，不重新求值。梯形递推仅在末圈
% 提供终端约束报告，不能把旧 RK4 回放的逐圈远地点数据补进本表。

    widths = [3, 10, 11, 11, 9, 9, 8];
    print_table_row({'圈', '飞行时间 s', '参考 t_f s', '最低高度 km', ...
        '动压峰值', '热流峰值', '过载峰值'}, widths, 4);
    for cir = 1:numel(PointsBounds)
        nodes = PointsBounds(cir).begin:PointsBounds(cir).end;
        peaks = max(PathReport.node_values(nodes, :), [], 1);
        min_altitude = (min(Solution.state(nodes, 1)) - ConstData.RM) ...
            * ConstData.LU / 1e3;
        print_table_row({sprintf('%d', cir), ...
            sprintf('%.1f', Solution.t_f(cir) * ConstData.TU), ...
            sprintf('%.1f', reference_t_f(cir) * ConstData.TU), ...
            sprintf('%.1f', min_altitude), sprintf('%.0f', peaks(1)), ...
            sprintf('%.1f', peaks(2)), sprintf('%.2f', peaks(3))}, widths, 4);
    end
    fprintf('    峰值单位 N/m^2、W/cm^2、- ；均为优化节点值\n');
end


%% ===== 9. 收敛 =====

function print_convergence(IterationRecord, PointsBounds, ConstData, show_all)
% PRINT_CONVERGENCE 打印收敛的三项：驻点、对 P2 可行、步长，停止依据的那一项后加 *。
%
% 数学形式:
%   驻点: 驻点度量的上界 (r_max/r)ΔL 不超过 ε；
%   对 P2 可行: 候选解的 P2 可行性检查通过（max_ratio 为最大违反量/容差）；
%   步长: 相邻解的最大差小于步长检查阈值（归一化量，t_f 不进判据）。
%   “收敛”指三项都满足；本项目实际的停止依据只有步长（见 stop_basis），
%   其余两项只报告。驻点度量衡量的是本轮参考点（候选解相对它的预测下降），
%   不是候选解本身。
%
% 代码形式:
%   三项结论取自本轮 IterationRecord.stop（stationary、feasible、step_converged），
%   数值取自 trust.evaluation（驻点度量的上界）和 subproblem（违反比、解差）。
%   各项之间用 ' | ' 连接，超过 78 个显示列在项之间换行。
%   展开时列原步长检查的各通道归一化差、物理差和最大差所在位置。

    SubproblemDiag = IterationRecord.subproblem;
    Stop = IterationRecord.stop;
    Evaluation = IterationRecord.trust.evaluation;
    ConvergenceReport = SubproblemDiag.convergence_report;
    P2Feasibility = SubproblemDiag.p2_feasibility;

    % 驻点: 只看驻点度量的上界
    bound = Evaluation.stationarity_bound;
    if isfinite(bound)
        stationary_text = sprintf('驻点 %s (上界 %.1e %s ε %.0e)', ...
            logical_to_text(Stop.stationary), bound, ...
            compare_to_text(Stop.stationary), ...
            Evaluation.stationarity_tolerance);
    else
        stationary_text = sprintf('驻点 %s (上界未算)', ...
            logical_to_text(Stop.stationary));
    end
    feasible_text = sprintf('对 P2 可行 %s (最大违反量/容差 %.2e)', ...
        logical_to_text(Stop.feasible), P2Feasibility.max_ratio);
    step_text = sprintf('步长 %s (%.1e %s %s %.0e)', ...
        logical_to_text(Stop.step_converged), ConvergenceReport.max_value, ...
        ConvergenceReport.max_name, compare_to_text(Stop.step_converged), ...
        ConvergenceReport.tolerance);

    % 停止依据的那一项后加 *
    if ismember('stationary', Stop.stop_basis)
        stationary_text = [stationary_text ' *'];
    end
    if ismember('feasible', Stop.stop_basis)
        feasible_text = [feasible_text ' *'];
    end
    if ismember('step', Stop.stop_basis)
        step_text = [step_text ' *'];
    end
    all_converged = Stop.stationary && Stop.feasible && Stop.step_converged;
    fprintf('\n');
    print_joined_pieces({sprintf('收敛: %s', logical_to_text(all_converged)), ...
        stationary_text, feasible_text, step_text, '(* 停止依据)'}, 78);

    if ~show_all
        return;
    end
    print_convergence_channels(ConvergenceReport, PointsBounds, ConstData, ...
        IterationRecord);
end


function text = compare_to_text(satisfied)
% COMPARE_TO_TEXT 判据满足时写 ≤，否则写 >（判据是“量 ≤ 阈值”）。

    if satisfied
        text = '≤';
    else
        text = '>';
    end
end


function print_convergence_channels(ConvergenceReport, PointsBounds, ...
        ConstData, IterationRecord)
% PRINT_CONVERGENCE_CHANNELS 展开：相邻解差在各通道的归一化值、物理值和位置。
%
% 判据在归一化单位下混合比较各通道（state 含 r、V 和角度），所以先按判据原样
% 显示归一化值。t_f 是决策变量但不在判据内，作为显示通道单列并附物理差（s）。
% 展开表把 state 拆成 5 个状态、t_f 按圈拆开，给出物理单位和最大差所在的节点、
% 圈或脉冲序号；判据不变。旧记录若没有 t_f_channel，从同轮解和参考补出显示值。

    channel_text = arrayfun(@(M) sprintf('%s %.2e', M.name, M.difference), ...
        ConvergenceReport.metrics, 'UniformOutput', false);
    TfChannel = read_tf_channel(ConvergenceReport, IterationRecord);
    fprintf('  各通道 (归一化): %s | t_f %.2e (%.2f s)\n', ...
        strjoin(channel_text(:)', ' | '), TfChannel.difference, ...
        TfChannel.difference * ConstData.TU);

    % 每行：通道名、指标、物理单位换算系数、单位、位置类型
    Metrics = ConvergenceReport.metrics;
    Channels = ConvergenceReport.state_channels;
    pick = @(name) Metrics(strcmp({Metrics.name}, name));
    row_specs = {
        'u1',    pick('u1'),  1,                  '-',   'node';
        'u2',    pick('u2'),  1,                  '-',   'node';
        'r',     Channels(1), ConstData.LU / 1e3, 'km',  'node';
        'V',     Channels(2), ConstData.VU,       'm/s', 'node';
        'gamma', Channels(3), 180 / pi,           'deg', 'node';
        'phi',   Channels(4), 180 / pi,           'deg', 'node';
        'psi',   Channels(5), 180 / pi,           'deg', 'node';
        'P',     pick('P'),   ConstData.VU,       'm/s', 'pulse';
    };
    widths = [6, 10, 10, 5, 12];
    print_table_row({'通道', '归一化差', '物理差', '单位', '位置'}, widths, 4);
    for k = 1:size(row_specs, 1)
        Metric = row_specs{k, 2};
        if strcmp(row_specs{k, 5}, 'pulse')
            location = sprintf('第 %d 次', Metric.max_index);
        else
            cir = locate_node(Metric.max_index, PointsBounds);
            location = sprintf('圈%d 节点%d', cir, Metric.max_index);
        end
        print_table_row({row_specs{k, 1}, format_short(Metric.difference), ...
            sprintf('%.4g', Metric.difference * row_specs{k, 3}), ...
            row_specs{k, 4}, location}, widths, 4);
    end
    % t_f 按圈拆开（不在判据内，附物理差与所在圈）
    print_table_row({'t_f', format_short(TfChannel.difference), ...
        sprintf('%.4g', TfChannel.difference * ConstData.TU), 's', ...
        sprintf('圈%d', TfChannel.max_index)}, widths, 4);
end


function TfChannel = read_tf_channel(ConvergenceReport, IterationRecord)
% READ_TF_CHANNEL 读取已有的 t_f 显示通道，兼容没有该字段的旧迭代记录。
% 仅补齐显示用的最大差及所在圈，不修改 ConvergenceReport 或判据。

    if isfield(ConvergenceReport, 't_f_channel') ...
            && ~isempty(ConvergenceReport.t_f_channel)
        TfChannel = ConvergenceReport.t_f_channel;
        return;
    end
    [difference, max_index] = max(abs(IterationRecord.solution.t_f ...
        - IterationRecord.reference_before.t_f));
    TfChannel = struct('name', 't_f', 'difference', difference, ...
        'max_index', max_index, 'unit', 'normalized', 'active', true);
end


%% ===== 10. 本轮结果 =====

function print_iteration_key_results(IterationRecord)
% PRINT_ITERATION_KEY_RESULTS 打印候选解的决策、停止状态和累计接受次数，停止时附停止说明。

    TrustResult = IterationRecord.trust;
    fprintf('\n本轮结果: 候选解 %s (%s)\n', ...
        decision_to_text(TrustResult), TrustResult.reason);
    fprintf('  停止: %s (%s) | 累计接受 %d\n', ...
        logical_to_text(IterationRecord.stop.stop), ...
        IterationRecord.stop.reason, IterationRecord.num_accepted_after);
    if ~isempty(IterationRecord.stop.detail)
        print_wrapped(IterationRecord.stop.detail, 36);
    end
end


function text = decision_to_text(TrustResult)
% DECISION_TO_TEXT 候选解决策词：NO_CANDIDATE / ACCEPTED / REJECTED。

    if ~TrustResult.candidate_available
        text = 'NO_CANDIDATE';
    elseif TrustResult.accept_candidate
        text = 'ACCEPTED';
    else
        text = 'REJECTED';
    end
end


%% ===== 单位换算与定位 =====

function [node_value, limit] = read_node_value_and_limit(Metric)
% READ_NODE_VALUE_AND_LIMIT 取 P2 节点值一侧的数值和上限：路径约束取节点最大值和上限，终端违反量取违反量和容差。

    if isfield(Metric, 'limit')
        node_value = Metric.max_value;
        limit = Metric.limit;
    else
        node_value = Metric.value;
        limit = Metric.tolerance;
    end
end


function Row = convert_metric_to_display(Metric)
% CONVERT_METRIC_TO_DISPLAY 把一条检查指标换成显示用的名称、物理单位数值和位置。
%
% P2 可行性检查的动力学违反量、衔接违反量、终端违反量和终端映射的余项在报告里已存
% 物理单位数值，直接显示。其余单位为 '1' 的量（松弛）保持归一化值，单位显示为
% “归一化”。报告里存的仍是原单位值。
% 位置：有 max_cir/max_node 时写“圈c 节点n”，有 max_point 时写“初始/内点 c”。

    name = Metric.name;
    unit = display_unit(Metric.unit);
    if strcmp(Metric.unit, '1')
        unit = '归一化';
    end

    Row.name = name;
    Row.value = Metric.value;
    Row.tolerance = Metric.tolerance;
    Row.unit = unit;
    Row.node = NaN;
    Row.location = '-';
    if isfield(Metric, 'max_cir') && isfinite(Metric.max_cir)
        Row.node = Metric.max_node;
        Row.location = sprintf('圈%d 节点%d', Metric.max_cir, Metric.max_node);
    elseif isfield(Metric, 'max_point') && isfinite(Metric.max_point)
        if Metric.max_point == 1
            Row.location = '初始';
        else
            Row.location = sprintf('内点 %d', Metric.max_point - 1);
        end
    end
end


function [cir, position, count] = locate_node(node, PointsBounds)
% LOCATE_NODE 找出节点所在的圈、它在该圈中的序号和该圈节点数。

    cir = find([PointsBounds.begin] <= node & [PointsBounds.end] >= node, 1);
    position = node - PointsBounds(cir).begin + 1;
    count = PointsBounds(cir).end - PointsBounds(cir).begin + 1;
end


function text = format_altitude(Solution, node, ConstData)
% FORMAT_ALTITUDE 节点高度 (km)，节点号无效时显示 '-'。

    if ~isfinite(node)
        text = '-';
        return;
    end
    text = sprintf('%.1f', ...
        (Solution.state(node, 1) - ConstData.RM) * ConstData.LU / 1e3);
end


function unit = display_unit(unit)
% DISPLAY_UNIT 无量纲单位 '1' 显示为 '-'。

    if strcmp(unit, '1')
        unit = '-';
    end
end


%% ===== 排版工具 =====

function print_table_row(cells, widths, indent)
% PRINT_TABLE_ROW 按终端显示宽度打印一行表格：首列左对齐，其余列右对齐。
% indent 为行首空格数，默认 2。

    if nargin < 3
        indent = 2;
    end
    parts = cell(1, numel(cells));
    parts{1} = pad_text(cells{1}, widths(1));
    for c = 2:numel(cells)
        parts{c} = pad_text(cells{c}, widths(c), 'right');
    end
    fprintf('%s%s\n', blanks(indent), strjoin(parts, ' '));
end


function text = pad_text(text, width, align)
% PAD_TEXT 用空格把文本补到指定显示宽度（中文等全角字符算两格）。

    if nargin < 3
        align = 'left';
    end
    num_spaces = max(width - display_width(text), 0);
    if strcmp(align, 'right')
        text = [blanks(num_spaces), text];
    else
        text = [text, blanks(num_spaces)];
    end
end


function width = display_width(text)
% DISPLAY_WIDTH 计算文本在终端中的显示宽度：U+2E80 及以上的字符（中日韩文字、全角符号）算两格。

    codes = double(char(text));
    width = numel(codes) + sum(codes >= 11904);
end


function print_wrapped(text, line_width)
% PRINT_WRAPPED 把长文本按固定列数折行打印，每行缩进 4 格。

    for start = 1:line_width:numel(text)
        stop = min(start + line_width - 1, numel(text));
        fprintf('    %s\n', text(start:stop));
    end
end


function print_joined_pieces(pieces, max_width)
% PRINT_JOINED_PIECES 把若干短句用 ' | ' 连成行，超过 max_width 个显示列就在句间换行（续行缩进两格）。

    line_text = pieces{1};
    for k = 2:numel(pieces)
        joined = [line_text ' | ' pieces{k}];
        if display_width(joined) > max_width
            fprintf('%s\n', line_text);
            line_text = ['  ' pieces{k}];
        else
            line_text = joined;
        end
    end
    fprintf('%s\n', line_text);
end


function text = format_number(value)
% FORMAT_NUMBER 表格数值统一用 %.4e，非有限值显示为 NaN/Inf。

    text = sprintf('%.4e', value);
end


function text = format_short(value)
% FORMAT_SHORT 较短的 %.2e，用于系数量级和小表。

    text = sprintf('%.2e', value);
end


function text = format_long(value)
% FORMAT_LONG 6 位有效数字的 %.5e，用于 ΔL、D、ΔJ 及其三部分等要细看的量。

    text = sprintf('%.5e', value);
end


function text = format_integer(value)
% FORMAT_INTEGER 整数列，NaN 显示为 '-'。

    if isfinite(value)
        text = sprintf('%d', value);
    else
        text = '-';
    end
end


function text = status_to_text(satisfied)
% STATUS_TO_TEXT 将布尔检查结果转为状态词。

    if satisfied
        text = 'PASS';
    else
        text = 'FAIL';
    end
end


function text = logical_to_text(value)
% LOGICAL_TO_TEXT 将布尔值转为是/否文本。

    if value
        text = '是';
    else
        text = '否';
    end
end
