function finish_history_axes(ax, iters, y_label, config)
% FINISH_HISTORY_AXES 横轴为迭代序号的分块收尾: 横轴范围与刻度、轴标签。
%
% 输入:
%   ax      - 已画好曲线的坐标轴
%   iters   - 画出的迭代序号（含第 0 次时包含 0）
%   y_label - 纵轴标签
%   config  - 读取 config.plot.font_size
%
% 图例不在这里放：整扇窗的分块画完后由 finish_tile_window 放一个共用图例，只收
% 有 DisplayName 的对象，参考线要在画的时候起名字，不起名字的不进图例。

    xlim(ax, [min(iters) - 0.5, max(iters) + 0.5]);
    if numel(iters) <= 20
        xticks(ax, iters);
    end
    style_plot_axes(ax, '迭代序号', y_label, config);
end
