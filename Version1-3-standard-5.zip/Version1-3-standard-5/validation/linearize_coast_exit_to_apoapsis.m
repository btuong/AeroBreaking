function c_x = linearize_coast_exit_to_apoapsis(x_c5N, ConstData)
% LINEARIZE_COAST_EXIT_TO_APOAPSIS 中心差分计算终态对末圈出口状态的偏导。
%
% 数学形式:
%   对真空映射 [x_ff; i_ff] = Φ_f(y)（y = [V, γ, φ, ψ]^T 为末圈出口状态，出口
%   半径固定为 R_atm；x_ff 为最终远地点 ECF 球坐标 5 分量，i_ff 为终端倾角 rad），
%   在 ȳ 处求中心差分偏导：
%       Φ_f,y = ∂Φ_f/∂y ∈ R^(6×4)
%   差分步长: V 取 1e-6/VU，γ、φ、ψ 取 0.00025°（均为单侧步长）。
%
% 代码形式:
%   c_x 为 4×6，按出口分量存放（行 = V, γ, φ, ψ；列 = x_ff 的 5 分量与 i_ff），
%   即 Φ_f,y 的转置：c_x(j, i) = Φ_f,y(i, j)。
%
% 输入:
%   x_c5N - 1x6 末圈出口状态 [R_atm, V, gamma, phi, psi, 0]（首分量固定不扰动）
%
% 输出:
%   c_x - 4x6 矩阵，第 1~4 行依次为终态 6 分量（5 状态 + 倾角）对出口
%         V/gamma/phi/psi 的偏导（Φ_f,y 的转置）

    delta_V = 1e-6 / ConstData.VU;
    delta_gamma = deg2rad(0.00025);
    delta_phi = deg2rad(0.00025);
    delta_psi = deg2rad(0.00025);

    x21 = x_c5N; x22 = x_c5N;
    x21(2) = x21(2) - delta_V; x22(2) = x22(2) + delta_V;
    x31 = x_c5N; x32 = x_c5N;
    x31(3) = x31(3) - delta_gamma; x32(3) = x32(3) + delta_gamma;
    x41 = x_c5N; x42 = x_c5N;
    x41(4) = x41(4) - delta_phi; x42(4) = x42(4) + delta_phi;
    x51 = x_c5N; x52 = x_c5N;
    x51(5) = x51(5) - delta_psi; x52(5) = x52(5) + delta_psi;

    c_V = (evaluate_coast_exit_to_apoapsis(x22, ConstData) ...
        - evaluate_coast_exit_to_apoapsis(x21, ConstData)) / (2 * delta_V);
    c_gamma = (evaluate_coast_exit_to_apoapsis(x32, ConstData) ...
        - evaluate_coast_exit_to_apoapsis(x31, ConstData)) / (2 * delta_gamma);
    c_phi = (evaluate_coast_exit_to_apoapsis(x42, ConstData) ...
        - evaluate_coast_exit_to_apoapsis(x41, ConstData)) / (2 * delta_phi);
    c_psi = (evaluate_coast_exit_to_apoapsis(x52, ConstData) ...
        - evaluate_coast_exit_to_apoapsis(x51, ConstData)) / (2 * delta_psi);

    c_x = [c_V; c_gamma; c_phi; c_psi];
end
