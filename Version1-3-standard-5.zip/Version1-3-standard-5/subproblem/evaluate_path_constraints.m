function PathConstraintReport = evaluate_path_constraints( ...
        CurrentSolution, ConstData, config)
% EVALUATE_PATH_CONSTRAINTS 在每个优化节点用原非线性函数检查动压、热流、过载是否超限。
%
% 数学形式:
%   g_j(x_i) ≤ g_j,max,  i = 1..N,  j ∈ {动压 q, 热流 Q̇, 过载 n}
%   g_j 为原非线性路径函数；x_i 为本轮优化解第 i 个节点的 (r, V)，
%   不是参考值。g_j,max 为 ConstData.q_max、Qdot_max、N_max。
%
% P3 里的路径约束是线性化后的形式：线性化式满足，只说明线性化式在节点上
% 成立，不说明原约束成立，所以要在节点上重新求值。节点之间是否超限只有
% 连续积分检查能看到，不在这里插值补点。
%
% 本函数依次完成：
%   1. 在每个优化节点用原非线性函数算出动压、热流、过载。
%   2. 每类约束取最大值及所在节点，与上限比较。
%   3. 汇总超限的约束名与最大超限比例。
%
% PathConstraintReport.success 只表示节点处原约束满足，不表示松弛为零、
% 递推轨迹满足或候选解被接受。
% PathConstraintReport.node_values 为 N x 3 的逐节点原函数值（列依次为
% q, Q̇, n，与 metrics 同序、同单位），逐轮图直接读它，不在绘图里重算。

    %% 1. 在每个优化节点用原非线性函数算出动压、热流、过载
    num_nodes = size(CurrentSolution.state, 1);
    path_values = zeros(num_nodes, 3);   % 列依次为 q, Q̇, n
    for i = 1:num_nodes
        r = CurrentSolution.state(i, 1);
        V = CurrentSolution.state(i, 2);
        path_values(i, 1) = linearize_dynamic_pressure(ConstData, r, V);
        path_values(i, 2) = linearize_heat_flux(ConstData, r, V);
        path_values(i, 3) = linearize_load_factor(ConstData, r, V);
    end

    %% 2. 每类约束取最大值及所在节点，与上限比较
    tolerance = config.validation.path_constraint_tolerance;
    Metrics(1) = create_path_metric('dynamic_pressure', 'N/m^2', ...
        path_values(:, 1), ConstData.q_max, tolerance);
    Metrics(2) = create_path_metric('heat_flux', 'W/cm^2', ...
        path_values(:, 2), ConstData.Qdot_max, tolerance);
    Metrics(3) = create_path_metric('load_factor', '1', ...
        path_values(:, 3), ConstData.N_max, tolerance);

    %% 3. 汇总超限的约束名与最大超限比例
    PathConstraintReport.success = all([Metrics.satisfied]);
    PathConstraintReport.evaluated = true;
    PathConstraintReport.metrics = Metrics;
    PathConstraintReport.node_values = path_values;
    PathConstraintReport.failed_names = {Metrics(~[Metrics.satisfied]).name};
    [PathConstraintReport.max_ratio, max_index] = max([Metrics.ratio]);
    PathConstraintReport.max_name = Metrics(max_index).name;
end


function Metric = create_path_metric(name, unit, values, limit, tolerance)
% CREATE_PATH_METRIC 创建单类路径约束指标：节点上最大值、上限和比值。

    [max_value, max_node] = max(values);
    Metric.name = name;
    Metric.unit = unit;
    Metric.max_value = max_value;
    Metric.limit = limit;
    Metric.ratio = max_value / limit;
    Metric.max_node = max_node;
    Metric.tolerance = tolerance;   % 相对容差：ratio ≤ 1 + tolerance
    Metric.active = true;
    Metric.evaluated = true;
    Metric.satisfied = isfinite(max_value) && Metric.ratio <= 1 + tolerance;
end
