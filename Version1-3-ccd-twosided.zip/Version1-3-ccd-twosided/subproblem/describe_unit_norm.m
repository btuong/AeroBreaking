function UnitNorm = describe_unit_norm(config)
% DESCRIBE_UNIT_NORM 按 config.unit_norm 返回单位范数约束 ‖u_i‖=1 的处理方式与参数。
%
% 数学形式:
%   'regularized'（默认）  ‖u_i‖_2 ≤ 1 + 附加项 Γ（控制正则，由 describe_control_regularizer 给出）
%   'twosided'             文章 [15] 双侧共用松弛 CCD：
%                          ‖u_i‖_2 ≤ 1 + s_a1（凸侧 SOC）
%                          −2·ū_i^T·u_i − s_a2 ≤ −(1 + ‖ū_i‖_2^2)（凹侧内逼近）
%                          0 ≤ s_a1, s_a2 ≤ s_max，目标加 P·(s_a1 + s_a2)
%
% 代码形式:
%   config 无 unit_norm 字段或为空时按 'regularized' 处理；未知 mode 抛错
%   SCP:UnknownUnitNormMode；'twosided' 下要求 twosided_penalty_weight 与
%   twosided_slack_max 为有限正实数，否则抛错 SCP:InvalidUnitNormConfig。
%   返回字段：mode、is_twosided、penalty_weight、slack_max、keep_control_bounds、
%   term_name、term_label、term_kind。

    mode = 'regularized';
    unit_norm_config = struct();
    if nargin >= 1 && isstruct(config) && isfield(config, 'unit_norm') ...
            && ~isempty(config.unit_norm)
        unit_norm_config = config.unit_norm;
        if isfield(unit_norm_config, 'mode') && ~isempty(unit_norm_config.mode)
            mode = char(string(unit_norm_config.mode));
        end
    end

    switch mode
        case 'regularized'
            if nargin >= 1 && isstruct(config) && isfield(config, 'objective')
                term_kind = describe_control_regularizer(config).kind;
            else
                term_kind = 'extra_nonconvex';
            end
            UnitNorm = struct( ...
                'mode', 'regularized', ...
                'is_twosided', false, ...
                'penalty_weight', 0, ...
                'slack_max', 0, ...
                'keep_control_bounds', false, ...
                'term_name', 'control_reg', ...
                'term_label', '控制正则项', ...
                'term_kind', term_kind);
        case 'twosided'
            if ~isfield(unit_norm_config, 'twosided_penalty_weight')
                penalty_weight = 100;
            else
                penalty_weight = unit_norm_config.twosided_penalty_weight;
            end
            if ~isfield(unit_norm_config, 'twosided_slack_max')
                slack_max = 2;
            else
                slack_max = unit_norm_config.twosided_slack_max;
            end
            if ~is_positive_finite_real(penalty_weight) ...
                    || ~is_positive_finite_real(slack_max)
                error('SCP:InvalidUnitNormConfig', ...
                    'twosided 模式下 twosided_penalty_weight 与 twosided_slack_max 必须为有限正实数。');
            end
            keep_control_bounds = false;
            if isfield(unit_norm_config, 'twosided_keep_control_bounds') ...
                    && ~isempty(unit_norm_config.twosided_keep_control_bounds)
                keep_control_bounds = logical( ...
                    unit_norm_config.twosided_keep_control_bounds);
            end
            UnitNorm = struct( ...
                'mode', 'twosided', ...
                'is_twosided', true, ...
                'penalty_weight', double(penalty_weight), ...
                'slack_max', double(slack_max), ...
                'keep_control_bounds', keep_control_bounds, ...
                'term_name', 'unit_norm_penalty', ...
                'term_label', '单位范数罚项', ...
                'term_kind', 'inequality_penalty');
        otherwise
            error('SCP:UnknownUnitNormMode', ...
                '未知的单位范数处理模式 unit_norm.mode = ''%s''，可选 regularized、twosided。', ...
                mode);
    end
end


function valid = is_positive_finite_real(value)
% IS_POSITIVE_FINITE_REAL 检查标量是否为有限正实数。

    valid = isnumeric(value) && isreal(value) && isscalar(value) ...
        && isfinite(value) && value > 0;
end
