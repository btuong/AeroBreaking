function ControlReport = create_empty_control_report(reason)
% CREATE_EMPTY_CONTROL_REPORT 创建字段齐全的“未评价”控制量报告。
%
% 字段与 evaluate_control_report 的输出一致：逐节点量为空数组，汇总量为 NaN；
% evaluated = false，reason 写明原因（如 'solver_failed'、'not_attempted'）。

    ControlReport.evaluated = false;
    ControlReport.reason = reason;
    ControlReport.dual_available = false;     % 对偶分解相关字段是否有值
    ControlReport.dual_reason = reason;
    ControlReport.num_nodes = 0;
    ControlReport.num_circuits = 0;
    ControlReport.tightness_tolerance = NaN;  % 无损凸化紧性容差

    % 节点信息（N x 1）
    ControlReport.node = [];
    ControlReport.cir = [];
    ControlReport.tau = [];
    ControlReport.omega = [];                 % 本版本实际用的梯形积分权

    % 控制量与紧性（N x 1）
    ControlReport.u1 = [];
    ControlReport.u2 = [];
    ControlReport.u_norm = [];
    ControlReport.tight_gap = [];             % 1 - ‖u‖
    ControlReport.sigma_deg = [];             % atan2d(u2, u1)

    % 目标向量 c 在 u1、u2 两列的值（N x 2）
    ControlReport.c_reg = [];

    % u 列驻点条件的对偶分解（N x 2，列为 u1、u2）
    ControlReport.s_reg = [];
    ControlReport.s_dyn = [];
    ControlReport.s_rate = [];
    ControlReport.s_inner = [];
    ControlReport.lambda_inner = [];
    ControlReport.s_bound = [];
    ControlReport.s_total = [];
    ControlReport.s_cone = [];
    ControlReport.cone_dual_leading = [];
    ControlReport.stationarity_residual = [];
    ControlReport.s_main = [];                % s_dyn + s_rate + s_bound

    % twosided 模式单位范数共用松弛（regularized 为 NaN / false）
    ControlReport.unit_norm_slack = [NaN; NaN];
    ControlReport.slack_capped = [false; false];

    % 由分解导出的分析量（N x 1）
    ControlReport.s_reg_norm = [];
    ControlReport.s_main_norm = [];
    ControlReport.reg_ratio = [];             % ‖s_reg‖ / ‖s_main‖
    ControlReport.sigma_main_deg = [];        % 只听主问题时 u 指向的方向
    ControlReport.sigma_shift_deg = [];       % σ - σ_main，规约到 (-180, 180]
    ControlReport.gamma_node = [];            % c_reg(:,1).*u1 + c_reg(:,2).*u2

    % 紧性余量、抵消和弦上平坦（N x 1，弦切向量为 N x 2）
    ControlReport.tightness_margin = [];
    ControlReport.cone_complementarity = [];
    ControlReport.complementarity_bound = [];
    ControlReport.radial_main = [];
    ControlReport.radial_regularizer = [];
    ControlReport.cancellation_cosine = [];
    ControlReport.cancellation_strength = [];
    ControlReport.cancellation_candidate = [];
    ControlReport.chord_active = [];
    ControlReport.chord_rank = [];
    ControlReport.chord_tangent = [];
    ControlReport.chord_reg_component = [];
    ControlReport.chord_flatness = [];
    ControlReport.chord_flat = [];

    % 逐圈汇总（num_circuits x 1 结构体数组）和全程汇总
    ControlReport.summary_circuits = repmat(create_empty_control_summary(), 0, 1);
    ControlReport.summary_total = create_empty_control_summary();
end

