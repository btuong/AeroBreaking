function x_out = transform_rv2state(r, v)
% TRANSFORM_RV2STATE 将 ECF 直角坐标 rv 矢量转换到 ECF 球坐标状态。
%
% 输出 x_out 为 6 元素 [r, V, gamma, phi, psi, theta]，
% psi=0 时速度指向北方（北向为基准）。

    r1 = norm(r);
    V1 = norm(v);
    if r(1) >= 0 && r(2) > 0
        sita1 = atan(r(2) ./ r(1));
    elseif r(1) >= 0 && r(2) <= 0
        sita1 = 2 * pi + atan(r(2) ./ r(1));
    else
        sita1 = pi + atan(r(2) ./ r(1));
    end
    phi1 = atan(r(3) ./ norm(r(1:2)));

    R2phi = [cos(phi1), 0, -sin(phi1);
        0, 1, 0;
        sin(phi1), 0, cos(phi1)];
    R3sita = [cos(sita1), sin(sita1), 0;
        -sin(sita1), cos(sita1), 0;
        0, 0, 1];
    v_fly = R2phi' * R3sita * v;
    if v_fly(2) > 0
        psi1 = pi / 2 - atan(v_fly(3) ./ v_fly(2));
    elseif v_fly(2) < 0
        psi1 = -pi / 2 - atan(v_fly(3) ./ v_fly(2));
    else
        psi1 = 0;
    end
    gamma1 = atan(v_fly(1) ./ norm(v_fly(2:3)));

    x_out = [r1, V1, gamma1, phi1, psi1, sita1];
end
