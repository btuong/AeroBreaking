function Cases = list_compare_cases()
% LIST_COMPARE_CASES 列出双侧共用松弛 CCD 对比实验的全部 12 个工况。
%
% 工况分三组（均使用 config.unit_norm.mode = 'twosided'，s_max = 2）:
%   1. 主罚权扫描（7 档）: P = 1e-3, 1e-2, 3e-2, 1e-1, 1e0, 1e1, 1e2，上限 50 轮
%   2. 箱形边界对照（1 档）: twosidedkeep_P1e-1（保留 ±1 边界），上限 50 轮
%   3. 初值与速率约束专项对照（4 档）: 上限 10 轮，检验圆内初值、零初值与速率约束开关
% 入口脚本与分析函数共用本函数，保证工况名、参数和顺序一致。
%
% 输出 Cases（1 x 12 结构体数组）:
%   name                      - 工况名
%   type                      - 固定为 'twosided'
%   max_iter                  - 最大 SCP 迭代轮数（50 或 10）
%   w                         - 控制正则系数（twosided 下为 NaN）
%   p                         - 双侧共用松弛罚权 P（str2double 精确解析）
%   slack_max                 - 共用松弛安全上界 s_max（固定为 2）
%   keep_control_bounds       - 是否保留 u1、u2 的 ±1 箱形边界
%   enable_control_continuity - 是否启用相邻节点 u1 速率约束
%   init_control_mode         - 初始控制调整模式：'default'、'scale_0p3' 或 'zero'

    case_specs = {
        'twosided_P1e-3',          50, '1e-3', false, true,  'default';
        'twosided_P1e-2',          50, '1e-2', false, true,  'default';
        'twosided_P3e-2',          50, '3e-2', false, true,  'default';
        'twosided_P1e-1',          50, '1e-1', false, true,  'default';
        'twosided_P1e0',           50, '1e0',  false, true,  'default';
        'twosided_P1e1',           50, '1e1',  false, true,  'default';
        'twosided_P1e2',           50, '1e2',  false, true,  'default';
        'twosidedkeep_P1e-1',      50, '1e-1', true,  true,  'default';
        'twosided_init0p3_P1e-1',  10, '1e-1', false, true,  'scale_0p3';
        'twosided_init0_P1e-1',    10, '1e-1', false, true,  'zero';
        'twosided_init0_nr_P1e-1', 10, '1e-1', false, false, 'zero';
        'twosided_init0_P1e2',     10, '1e2',  false, true,  'zero';
    };

    case_list = cell(1, size(case_specs, 1));
    for k = 1:size(case_specs, 1)
        case_list{k} = struct( ...
            'name', case_specs{k, 1}, ...
            'type', 'twosided', ...
            'max_iter', case_specs{k, 2}, ...
            'w', NaN, ...
            'p', str2double(case_specs{k, 3}), ...
            'slack_max', 2, ...
            'keep_control_bounds', case_specs{k, 4}, ...
            'enable_control_continuity', case_specs{k, 5}, ...
            'init_control_mode', case_specs{k, 6});
    end
    Cases = [case_list{:}];
end
