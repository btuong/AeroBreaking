function [Result, FinalizedRun, SaveReport, RunInfo] = run_converge_case(config, plateau)
% RUN_CONVERGE_CASE 按给定配置完整跑一次 SCP，并按总脉冲平台判据停止，不改全局状态。
%
% 流程与 SCP.m 相同，只去掉 clc/clear/close 和路径管理，由调用方（入口脚本）负责路径；
% 另在主循环里加一步总脉冲平台判断。平台判据（本实验的“收敛”）：
%   最近 plateau.window 个被接受轮的总脉冲极差 ≤ plateau.tolerance，且这些轮都对 P2 可行
%   （取 P2 可行性检查的 feasible，即各通道最大违反量都在各自容差内）。
% 平台成立时，在 RunState 上写入停止标记（stop_reason = 'performance_plateau'）后结束循环，
% 之后的收尾、结果映射和保存都沿用主代码。步长停止由调用方把 config.iter.tolerance
% 设为 0 关掉（步长判据是 max_value < tolerance，恒不成立）。
% 其余停止原因（P3 失败、拒绝且半径在下限、达到上限）仍由主代码给出。
%
% 输入:
%   config  - 完整配置（scp_config_default 的返回值加覆盖项）
%   plateau - 平台判据：window（被接受轮数）、tolerance（总脉冲极差上限，m/s）
%
% 输出:
%   Result       - 对外稳定结果（build_scp_result）
%   FinalizedRun - 冻结的运行对象
%   SaveReport   - 保存报告（save_scp_result）
%   RunInfo      - 本实验的运行信息:
%       plateau_reached     是否因平台停止
%       plateau_start_iter  平台起始轮（最后 window 个被接受轮的第 1 轮），未成立为 NaN
%       plateau_mean_impulse 该窗口内总脉冲均值 (m/s)，未成立为 NaN
%       plateau_range       该窗口内总脉冲极差 (m/s)，未成立为 NaN
%       iter_seconds        各轮用时 (s)（含 P3 求解、检查和后处理），num_attempted x 1
%
% 本函数依次完成：
%   1. 初始化问题数据。
%   2. 生成初始参考轨迹。
%   3. 准备迭代数据结构。
%   4. SCP 主迭代循环（含总脉冲平台判断）。
%   5. 整理最终结果并保存。

    %% 1. 初始化问题数据
    [ConstData, InitialState] = initialize_problem(config);

    %% 2. 生成初始参考轨迹
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, config);

    %% 3. 准备迭代数据结构
    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);
    if config.output.print_pre_iteration
        print_initial_summary(ConstData, InitialReference, InitialPropagation);
    end
    if config.plot.enable_initial
        plot_initial_reference(ConstData, InitialPropagation, config);
    end

    %% 4. SCP 主迭代循环（含总脉冲平台判断）
    accepted_iter = zeros(0, 1);        % 被接受轮的轮号
    accepted_impulse = zeros(0, 1);     % 被接受轮的总脉冲 (m/s)
    accepted_feasible = false(0, 1);    % 被接受轮是否对 P2 可行
    iter_seconds = nan(config.iter.max_scp_iter, 1);
    Plateau = create_plateau_result();
    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        iter_timer = tic;

        % 1 构建、求解本轮 P3，并做步长检查、P3 解检查与 P2 可行性检查
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);

        % 2 决定候选解是否接受、下一轮信赖域多大
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);

        % 3 更新下一轮参考和信赖域，判断是否停止，并记录本轮
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);

        % 4 被接受轮记下总脉冲与 P2 可行性，判断总脉冲是否进入平台
        if TrustResult.accept_candidate
            accepted_iter(end + 1, 1) = iter;
            accepted_impulse(end + 1, 1) = ...
                IterationRecord.subproblem.p2_feasibility.performance_report.value;
            accepted_feasible(end + 1, 1) = ...
                logical(TrustResult.accepted_p2_feasibility.feasible);
            Plateau = detect_performance_plateau( ...
                accepted_iter, accepted_impulse, accepted_feasible, plateau);
        end
        % 主代码已因 P3 失败等原因停止时不改停止原因；只有达到上限同时成立时以平台为准
        if Plateau.reached && (~RunState.stop ...
                || strcmp(RunState.stop_reason, 'max_iterations'))
            RunState = mark_plateau_stop(RunState, Plateau, plateau);
        end

        % 5 只读后处理：对被接受解做隐式梯形递推、逐轮打印与绘图
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);
        iter_seconds(iter) = toc(iter_timer);

        % 6 停止检查
        if RunState.stop
            break;
        end
    end

    %% 5. 整理最终结果并保存
    FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory);
    Result = build_scp_result(FinalizedRun);
    SaveReport = save_scp_result(FinalizedRun, ConstData, config);
    RunInfo = build_run_info(Plateau, strcmp(RunState.stop_reason, ...
        'performance_plateau'), iter_seconds(1:FinalizedRun.num_attempted));
end


function Plateau = create_plateau_result()
% CREATE_PLATEAU_RESULT 创建“平台尚未成立”的判断结果。

    Plateau = struct('reached', false, 'start_iter', NaN, ...
        'mean_impulse', NaN, 'range', NaN);
end


function Plateau = detect_performance_plateau( ...
        accepted_iter, accepted_impulse, accepted_feasible, plateau)
% DETECT_PERFORMANCE_PLATEAU 判断最近 window 个被接受轮的总脉冲是否进入平台。
%
% 平台 = 最近 window 个被接受轮的总脉冲极差 ≤ tolerance，且它们都对 P2 可行。
% 被接受轮不足 window 个时不成立。start_iter 为窗口第 1 个被接受轮的轮号。

    Plateau = create_plateau_result();
    window = plateau.window;
    if numel(accepted_iter) < window
        return;
    end
    recent = numel(accepted_iter) - window + 1:numel(accepted_iter);
    window_impulse = accepted_impulse(recent);
    window_range = max(window_impulse) - min(window_impulse);
    if window_range <= plateau.tolerance && all(accepted_feasible(recent))
        Plateau.reached = true;
        Plateau.start_iter = accepted_iter(recent(1));
        Plateau.mean_impulse = mean(window_impulse);
        Plateau.range = window_range;
    end
end


function RunState = mark_plateau_stop(RunState, Plateau, plateau)
% MARK_PLATEAU_STOP 在 RunState 上写入平台停止标记（只写停止三项，不动参考和信赖域）。

    RunState.stop = true;
    RunState.stop_reason = 'performance_plateau';
    RunState.stop_detail = sprintf( ...
        '最近 %d 个被接受轮（自第 %d 轮起）总脉冲极差 %.2e ≤ %g m/s 且对 P2 可行', ...
        plateau.window, Plateau.start_iter, Plateau.range, plateau.tolerance);
end


function RunInfo = build_run_info(Plateau, stopped_by_plateau, iter_seconds)
% BUILD_RUN_INFO 整理本实验的运行信息；只有因平台停止时才记平台起始轮等量。

    RunInfo.plateau_reached = stopped_by_plateau;
    if stopped_by_plateau
        RunInfo.plateau_start_iter = Plateau.start_iter;
        RunInfo.plateau_mean_impulse = Plateau.mean_impulse;
        RunInfo.plateau_range = Plateau.range;
    else
        RunInfo.plateau_start_iter = NaN;
        RunInfo.plateau_mean_impulse = NaN;
        RunInfo.plateau_range = NaN;
    end
    RunInfo.iter_seconds = iter_seconds(:);
end
