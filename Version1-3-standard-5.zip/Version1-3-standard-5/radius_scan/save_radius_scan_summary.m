function SaveReport = save_radius_scan_summary(Summary, scan, version_root, fig)
% SAVE_RADIUS_SCAN_SUMMARY 按扫描设置里的保存开关保存多轮汇总: 汇总表、汇总图。
%
% 输入:
%   Summary      - build_radius_scan_summary 的输出
%   scan         - 扫描设置，读 save_summary、save_figure
%   version_root - 版本根目录
%   fig          - 汇总图的句柄，没画图时传空
%
% 写出，一个开关管一个文件:
%   scan.save_summary results/radius_scan_summary.txt  汇总表（print_radius_scan_summary 的输出）
%   scan.save_figure  pictures/半径扫描-多轮汇总.png
% 保存失败只记进 SaveReport，不中断。SaveReport 的字段同 save_radius_scan。

    SaveReport.files = cell(0, 2);
    SaveReport.success = false;
    SaveReport.error_message = '';
    try
        if scan.save_summary
            output_directory = fullfile(version_root, 'results');
            if ~isfolder(output_directory)
                mkdir(output_directory);
            end
            text_path = fullfile(output_directory, 'radius_scan_summary.txt');
            summary_text = evalc('print_radius_scan_summary(Summary)');
            file_id = fopen(text_path, 'w', 'n', 'UTF-8');
            if file_id < 0
                error('SCP:OpenRadiusScanFileFailed', ...
                    '无法打开扫描汇总文件：%s。', text_path);
            end
            cleanup = onCleanup(@() fclose(file_id));
            fprintf(file_id, '%s', summary_text);
            clear cleanup   % 先关文件，再记路径
            SaveReport.files(end + 1, :) = {'扫描汇总表', text_path};
        end
        if scan.save_figure && ~isempty(fig)
            figure_path = fullfile(version_root, 'pictures', [fig.Name '.png']);
            save_plot_figure(fig, figure_path);
            SaveReport.files(end + 1, :) = {'扫描汇总图', figure_path};
        end
        SaveReport.success = true;
    catch exception
        SaveReport.error_message = exception.message;
    end
end
