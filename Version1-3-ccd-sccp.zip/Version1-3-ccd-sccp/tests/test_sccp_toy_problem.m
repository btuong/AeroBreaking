function tests = test_sccp_toy_problem
% TEST_SCCP_TOY_PROBLEM 用独立玩具 SOCP 核验 SCCP 的转角上界、乘子和零初值钉扎行为。

    tests = functiontests(localfunctions);
end


function test_toy_proposition_c1_common_angle_cap(testCase)
% TEST_TOY_PROPOSITION_C1_COMMON_ANGLE_CAP 10 节点（2 个 D 节点 + 8 个不同 q_i 外推节点）的共用转角与乘子和。

    rng(42, 'twister');
    N = 10;
    C_eta = 0.5;
    eta_max = 1000;

    theta_ref = 2 * pi * rand(N, 1) - pi;
    u_ref = [cos(theta_ref), sin(theta_ref)];

    q = zeros(N, 1);
    q(3:N) = [0.1; 0.3; 0.8; 1.5; 2.5; 4.0; 6.5; 10.0];
    delta_theta = zeros(N, 1);
    delta_theta(3:N) = deg2rad(linspace(110, 160, 8)).';
    theta_d = theta_ref + delta_theta;
    d = [cos(theta_d), sin(theta_d)];

    [SolverResult, VariableIndex, inner_rows] = solve_toy_sccp_problem( ...
        u_ref, q, d, C_eta, eta_max);
    verifyTrue(testCase, SolverResult.success);

    primal = SolverResult.primal(:);
    u1 = primal(VariableIndex.u1);
    u2 = primal(VariableIndex.u2);
    eta = primal(VariableIndex.eta);

    verifyGreaterThan(testCase, eta, 1e-4);
    verifyLessThan(testCase, eta, eta_max);

    alpha_deg = acosd(1 - eta / (2 * N));
    for i = 3:N
        u_i = [u1(i); u2(i)];
        d_i = d(i, :).';
        u_ref_i = u_ref(i, :).';
        aligned_with_d = acos(max(min(dot(u_i, d_i) / norm(u_i), 1), -1)) < deg2rad(1e-2);
        if ~aligned_with_d
            turn_deg = acosd(max(min(dot(u_i, u_ref_i), 1), -1));
            verifyEqual(testCase, turn_deg, alpha_deg, 'AbsTol', 1e-3);
        end
    end

    % 乘子：约束写成 -2*u_ref'*u - (1/N)*eta <= -2，故 -y_i/N 之和等于 C_eta
    y_inner = SolverResult.dual.y(inner_rows);
    verifyEqual(testCase, sum(-y_inner / N), C_eta, 'AbsTol', 1e-6);
end


function test_toy_zero_init_pins_d_node(testCase)
% TEST_TOY_ZERO_INIT_PINS_D_NODE 从 ū_i = (0, 0) 出发时 η 被钉在 N，D 节点停在原点。

    N = 10;
    C_eta = 0.5;
    eta_max = 1000;

    u_ref = zeros(N, 2);
    q = zeros(N, 1);
    q(3:N) = linspace(0.5, 5.0, 8).';
    angles = linspace(0, pi, 8).';
    d = zeros(N, 2);
    d(3:N, :) = [cos(angles), sin(angles)];

    [SolverResult, VariableIndex, ~] = solve_toy_sccp_problem( ...
        u_ref, q, d, C_eta, eta_max);
    verifyTrue(testCase, SolverResult.success);

    primal = SolverResult.primal(:);
    u1 = primal(VariableIndex.u1);
    u2 = primal(VariableIndex.u2);
    eta = primal(VariableIndex.eta);

    verifyEqual(testCase, eta, N, 'AbsTol', 1e-7);
    for i = 1:2
        verifyLessThanOrEqual(testCase, hypot(u1(i), u2(i)), 1e-6);
    end
end


function [SolverResult, VariableIndex, inner_rows] = solve_toy_sccp_problem( ...
        u_ref, q, d, C_eta, eta_max)
% SOLVE_TOY_SCCP_PROBLEM 构造并调用 solve_convex_subproblem 求解玩具 SCCP 子问题。
%
% 数学形式:
%   min_{u, η}  Σ_(i=1..N) (−q_i·d_iᵀ·u_i) + C_η·η
%   s.t.        ‖u_i‖_2 ≤ 1                                （control_disk 锥）
%               −2·ū_iᵀ·u_i − (1/N)·η ≤ −(1 + ‖ū_i‖_2²)    （unit_norm_inner）
%               u_i ∈ [−1, 1]^2,  η ∈ [0, η_max]

    N = size(u_ref, 1);
    VariableIndex.u1 = (1:N).';
    VariableIndex.u2 = N + (1:N).';
    VariableIndex.eta = 2 * N + 1;
    num_variables = 2 * N + 1;

    objective = zeros(num_variables, 1);
    objective(VariableIndex.u1) = -q(:) .* d(:, 1);
    objective(VariableIndex.u2) = -q(:) .* d(:, 2);
    objective(VariableIndex.eta) = C_eta;

    nodes = (1:N).';
    row_index = [nodes; nodes; nodes];
    column_index = [ ...
        VariableIndex.u1; VariableIndex.u2; repmat(VariableIndex.eta, N, 1)];
    values = [ ...
        -2 * u_ref(:, 1); -2 * u_ref(:, 2); repmat(-1 / N, N, 1)];
    LinearConstraints.matrix = sparse( ...
        row_index, column_index, values, N, num_variables);
    LinearConstraints.lower = -inf(N, 1);
    LinearConstraints.upper = -(1 + sum(u_ref.^2, 2));
    inner_rows = (1:N).';
    LinearConstraints.row_groups.unit_norm_inner = inner_rows;

    VariableBounds.lower = [-ones(2 * N, 1); 0];
    VariableBounds.upper = [ones(2 * N, 1); eta_max];

    cone_rows = (1:3 * N).';
    cone_cols = reshape([VariableIndex.u1.'; VariableIndex.u2.'], [], 1);
    cone_map_rows = reshape([3 * (0:N - 1) + 2; 3 * (0:N - 1) + 3], [], 1);
    ConicConstraints.mapping = sparse( ...
        cone_map_rows, cone_cols, ones(2 * N, 1), 3 * N, num_variables);
    ConicConstraints.offset = repmat([1; 0; 0], N, 1);
    cones = repmat(struct( ...
        'name', 'control_disk', 'type', 'quadratic', 'dimension', 3, ...
        'rows', [], 'tightness_role', 'none', 'index', 0), N, 1);
    for i = 1:N
        cones(i).rows = cone_rows(3 * (i - 1) + (1:3));
        cones(i).index = i;
    end
    ConicConstraints.cones = cones;

    config = scp_config_default();
    config.solver.log_level = 0;
    SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ConicConstraints, ...
        config, 0);
end
