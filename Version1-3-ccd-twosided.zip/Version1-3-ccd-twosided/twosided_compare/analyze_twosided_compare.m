function [Summary, Groups, Check] = analyze_twosided_compare( ...
        results_root, pictures_root, delta, window)
% ANALYZE_TWOSIDED_COMPARE 汇总双侧共用松弛 CCD 对比实验：读存档、算指标、写表与作图。
%
% 只读 twosided_compare/results/ 下 12 个 twosided 工况与 ../Version1-3-standard-5/
% ccd_compare/results/ 下 5 个只读基线（校验 version_root == 'Version1-3-standard-5'），
% 不重跑 SCP。节点分组取 none 末轮的 q_i = ‖s_main,i‖/ω_i（q_i < 1e-6 为 D，其余为 E）。
%
% 输入（均可省略）:
%   results_root  - twosided 工况结果目录，默认 <本文件夹>/results
%   pictures_root - 图片导出目录，默认 <本文件夹>/pictures
%   delta         - 差值稳定阈值 (m/s)，默认 0.1
%   window        - 差值稳定窗口轮数，默认 5
%
% 输出:
%   Summary - 1 x 17 结构体数组（12 个 twosided 工况 + 5 个基线）
%   Groups  - 共用节点分组（D/E）
%   Check   - 基线校验与自检数值
%
% 本函数依次完成：
%   1. 补路径并确定目录和参数。
%   2. 读取 12 个 twosided 工况与 5 个只读基线的结果。
%   3. 按 none 工况末轮确定共用 D/E 节点分组。
%   4. 逐工况计算指标（含 E/D 偏差扩散、对偶门槛、转角与零初值指标）。
%   5. 补充相对 none 与 normgap_w1e-4 的差值及稳定性。
%   6. 执行基线校验与自检。
%   7. 写入汇总文本与轻量 MAT。
%   8. 绘制并导出对比图。

    %% 1. 补路径并确定目录和参数
    compare_root = fileparts(mfilename('fullpath'));
    version_root = fileparts(compare_root);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));
    addpath(fullfile(version_root, 'subproblem'), fullfile(version_root, 'output'), ...
        compare_root);
    if nargin < 1 || isempty(results_root)
        results_root = fullfile(compare_root, 'results');
    end
    if nargin < 2 || isempty(pictures_root)
        pictures_root = fullfile(compare_root, 'pictures');
    end
    if nargin < 3 || isempty(delta)
        delta = 0.1;
    end
    if nargin < 4 || isempty(window)
        window = 5;
    end
    Options = struct( ...
        'delta', delta, ...
        'window', window, ...
        'reference_case', 'normgap_w1e-4', ...
        'baseline_root', fullfile(fileparts(version_root), ...
            'Version1-3-standard-5', 'ccd_compare', 'results'));

    %% 2. 读取 12 个 twosided 工况与 5 个只读基线的结果
    CaseData = load_all_case_data(results_root, Options.baseline_root);

    %% 3. 按 none 工况末轮确定共用 D/E 节点分组
    Groups = determine_node_groups(CaseData);

    %% 4. 逐工况计算指标（含 E/D 偏差扩散、对偶门槛、转角与零初值指标）
    Summary = compute_all_indicators(CaseData, Groups, Options);

    %% 5. 补充相对 none 与 normgap_w1e-4 的差值及稳定性
    Summary = add_difference_indicators(Summary, Groups, Options);

    %% 6. 执行基线校验与自检
    Check = check_run(Summary, CaseData, Groups);

    %% 7. 写入汇总文本与轻量 MAT
    write_compare_text(fullfile(results_root, '对比汇总.txt'), ...
        Summary, Groups, Check, Options);
    save(fullfile(results_root, '对比汇总.mat'), ...
        'Summary', 'Groups', 'Check', 'Options');

    %% 8. 绘制并导出对比图
    plot_compare_figures(Summary, Groups, Options, pictures_root);
end


%% ===== 读取结果与校验 =====

function CaseData = load_all_case_data(results_root, baseline_root)
% LOAD_ALL_CASE_DATA 读取 12 个 twosided 工况和 5 个只读基线的结果并校验存档身份。

    TwosidedCases = list_compare_cases();
    BaselineSpecs = {
        'none',          'none',     NaN;
        'norm_w1e-4',    'norm',     str2double('1e-4');
        'normgap_w1e-3', 'norm_gap', str2double('1e-3');
        'normgap_w1e-4', 'norm_gap', str2double('1e-4');
        'normgap_w1e-5', 'norm_gap', str2double('1e-5');
    };

    data_list = cell(1, numel(TwosidedCases) + size(BaselineSpecs, 1));
    cursor = 0;
    for k = 1:numel(TwosidedCases)
        cursor = cursor + 1;
        Case = TwosidedCases(k);
        data_list{cursor} = load_single_case(Case, results_root, false, ...
            'Version1-3-ccd-twosided', 'twosided');
    end
    for k = 1:size(BaselineSpecs, 1)
        cursor = cursor + 1;
        Case = struct( ...
            'name', BaselineSpecs{k, 1}, ...
            'type', BaselineSpecs{k, 2}, ...
            'max_iter', 50, ...
            'w', BaselineSpecs{k, 3}, ...
            'p', NaN, ...
            'slack_max', 0, ...
            'keep_control_bounds', false, ...
            'enable_control_continuity', true, ...
            'init_control_mode', 'default');
        data_list{cursor} = load_single_case(Case, baseline_root, true, ...
            'Version1-3-standard-5', 'regularized');
    end
    CaseData = [data_list{:}];
end


function Data = load_single_case( ...
        Case, folder_root, is_baseline, expected_version, expected_mode)
% LOAD_SINGLE_CASE 读取单个工况的 case_metrics.mat 与 scp_run_control.mat 并校验来源。

    Data = struct( ...
        'name', Case.name, ...
        'type', Case.type, ...
        'is_baseline', logical(is_baseline), ...
        'max_iter', Case.max_iter, ...
        'w', Case.w, ...
        'p', Case.p, ...
        'keep', logical(Case.keep_control_bounds), ...
        'enable_continuity', logical(Case.enable_control_continuity), ...
        'init_mode', Case.init_control_mode, ...
        'version_root', '', ...
        'unit_norm_mode', '', ...
        'state', 'missing', ...
        'Metrics', [], ...
        'attempts', [], ...
        'error_message', '');

    case_dir = fullfile(folder_root, Case.name);
    metrics_path = fullfile(case_dir, 'case_metrics.mat');
    control_path = fullfile(case_dir, 'scp_run_control.mat');
    error_path = fullfile(case_dir, 'case_error.txt');

    if isfile(metrics_path) && isfile(control_path)
        Loaded = load(metrics_path);
        Control = load(control_path);
        Export = Control.ControlExport;
        if ~strcmp(Export.version_root, expected_version)
            error('TwosidedCompare:VersionMismatch', ...
                '工况 %s 的存档 version_root=%s，预期 %s。', ...
                Case.name, Export.version_root, expected_version);
        end
        if ~strcmp(Export.unit_norm_mode, expected_mode)
            error('TwosidedCompare:ModeMismatch', ...
                '工况 %s 的存档 unit_norm_mode=%s，预期 %s。', ...
                Case.name, Export.unit_norm_mode, expected_mode);
        end
        Data.version_root = Export.version_root;
        Data.unit_norm_mode = Export.unit_norm_mode;
        Data.Metrics = Loaded.Metrics;
        attempts = Export.attempts;
        if isempty(attempts)
            solved = false(0, 1);
        else
            solved = arrayfun(@(a) logical(a.control_report.evaluated), attempts);
        end
        Data.attempts = attempts(solved);
        if Loaded.Metrics.num_accepted > 0
            Data.state = 'ok';
        else
            Data.state = 'no_solution';
        end
    elseif isfile(error_path)
        Data.state = 'failed';
        Data.error_message = strtrim(fileread(error_path));
    end
end


function Groups = determine_node_groups(CaseData)
% DETERMINE_NODE_GROUPS 由 none 末轮的 q_i = ‖s_main,i‖/ω_i 划分 D（< 1e-6）与 E。

    Groups = struct('available', false, 'N', NaN, 'tau', [], 'cir', [], ...
        'q', [], 'D', [], 'E', [], 'num_D', NaN, 'num_E', NaN, 'threshold', 1e-6);
    none_index = find(strcmp({CaseData.name}, 'none') ...
        & strcmp({CaseData.state}, 'ok'), 1);
    if isempty(none_index)
        return;
    end
    Report = pick_final_report(CaseData(none_index));
    Groups.N = Report.num_nodes;
    Groups.tau = Report.tau;
    Groups.cir = Report.cir;
    if ~Report.dual_available
        Groups.D = false(Groups.N, 1);
        Groups.E = true(Groups.N, 1);
        Groups.num_D = 0;
        Groups.num_E = Groups.N;
        return;
    end
    Groups.available = true;
    Groups.q = Report.s_main_norm ./ Report.omega;
    Groups.D = Groups.q < Groups.threshold;
    Groups.E = ~Groups.D;
    Groups.num_D = sum(Groups.D);
    Groups.num_E = sum(Groups.E);
end


function Report = pick_final_report(Data)
% PICK_FINAL_REPORT 取出最后一次被接受尝试的控制量报告。

    accepted = [Data.attempts.accepted];
    Report = Data.attempts(find(accepted, 1, 'last')).control_report;
end


%% ===== 逐工况指标 =====

function Summary = compute_all_indicators(CaseData, Groups, Options)
% COMPUTE_ALL_INDICATORS 逐工况汇总指标并按 max_rounds 统一序列长度。

    max_rounds = max(arrayfun(@count_attempted, CaseData));
    if isempty(max_rounds) || max_rounds < 1
        max_rounds = 1;
    end
    none_index = find(strcmp({CaseData.name}, 'none') ...
        & strcmp({CaseData.state}, 'ok'), 1);
    none_sigma = [];
    if ~isempty(none_index)
        none_sigma = pick_final_report(CaseData(none_index)).sigma_deg;
    end
    summary_list = cell(1, numel(CaseData));
    for c = 1:numel(CaseData)
        summary_list{c} = compute_case_indicators(CaseData(c), Groups, ...
            none_sigma, max_rounds, Options);
    end
    Summary = [summary_list{:}];
end


function count = count_attempted(Data)
% COUNT_ATTEMPTED 返回一个工况的尝试轮数，缺失时为 0。

    if isempty(Data.Metrics) || ~isfield(Data.Metrics, 'num_attempted')
        count = 0;
    else
        count = Data.Metrics.num_attempted;
    end
end


function Indicator = compute_case_indicators( ...
        Data, Groups, none_sigma, max_rounds, Options)
% COMPUTE_CASE_INDICATORS 计算单个工况的末轮、E/D 扩散、对偶门槛、转角与零初值指标。

    Indicator = create_empty_indicator(Data, max_rounds);
    if ~strcmp(Data.state, 'ok')
        return;
    end
    Attempts = Data.attempts;
    Metrics = Data.Metrics;
    E = Groups.E;
    D = Groups.D;
    final_position = find([Attempts.accepted], 1, 'last');
    Report = Attempts(final_position).control_report;
    final_iter = Attempts(final_position).iter;
    window = Options.window;

    %% 基本运行状态与序列
    Indicator.num_attempted = Metrics.num_attempted;
    Indicator.num_accepted = Metrics.num_accepted;
    Indicator.final_iter = final_iter;
    Indicator.stop_reason = Metrics.stop_reason;
    Indicator.first_status = read_first_status(Metrics);
    Indicator.plateau_start = Metrics.plateau_start_iter;
    Indicator.elapsed_seconds = Metrics.elapsed_seconds;
    Indicator.mean_round_seconds = mean(Metrics.iter_seconds, 'omitnan');

    round_index = (1:numel(Metrics.accepted)).';
    Indicator.impulse_series = place_series(Metrics.total_impulse_m_s, round_index, max_rounds);
    Indicator.gap_series = place_series(Metrics.max_tight_gap, round_index, max_rounds);
    Indicator.inward_series = place_series(Metrics.max_inward_gap, round_index, max_rounds);
    Indicator.outward_series = place_series(Metrics.max_outward_gap, round_index, max_rounds);
    Indicator.rho_series = place_series(Metrics.rho, round_index, max_rounds);
    Indicator.turn_median_series = place_series(Metrics.turn_median_deg, round_index, max_rounds);
    Indicator.turn_p95_series = place_series( ...
        get_metric_or_nan(Metrics, 'turn_p95_deg', numel(round_index)), round_index, max_rounds);
    Indicator.s_a1_series = place_series( ...
        get_metric_or_nan(Metrics, 's_a1', numel(round_index)), round_index, max_rounds);
    Indicator.s_a2_series = place_series( ...
        get_metric_or_nan(Metrics, 's_a2', numel(round_index)), round_index, max_rounds);
    Indicator.alpha_cap_series = place_series( ...
        get_metric_or_nan(Metrics, 'alpha_cap_deg', numel(round_index)), round_index, max_rounds);
    Indicator.sum_kappa_over_P_series = place_series( ...
        get_metric_or_nan(Metrics, 'sum_kappa_over_P', numel(round_index)), round_index, max_rounds);
    Indicator.sum_y_inner_over_P_series = place_series( ...
        get_metric_or_nan(Metrics, 'sum_y_inner_over_P', numel(round_index)), round_index, max_rounds);
    Indicator.sum_s_main_norm_series = place_series( ...
        get_metric_or_nan(Metrics, 'sum_s_main_norm', numel(round_index)), round_index, max_rounds);
    Indicator.circle_error_series = place_series( ...
        Metrics.circle_error, round_index, max_rounds);

    %% 由控制报告补齐逐轮 E/D 节点统计与留存角统计
    Indicator = fill_attempt_node_series(Indicator, Attempts, Groups, max_rounds);

    %% 末轮总脉冲段
    series = Indicator.impulse_series;
    range_index = max(1, final_iter - window + 1):final_iter;
    Indicator.impulse_final = series(final_iter);
    Indicator.impulse_mean_last = mean(series(range_index), 'omitnan');
    Indicator.impulse_range_last = max(series(range_index), [], 'omitnan') ...
        - min(series(range_index), [], 'omitnan');
    if final_iter > 10
        Indicator.impulse_decrease_last10 = ...
            (series(final_iter - 10) - series(final_iter)) / 10;
    end

    %% 全局紧性、松弛与触界
    Indicator.s_a1_final = Indicator.s_a1_series(final_iter);
    Indicator.s_a2_final = Indicator.s_a2_series(final_iter);
    Indicator.s_a1_max_all = max(Indicator.s_a1_series, [], 'omitnan');
    Indicator.s_a2_max_all = max(Indicator.s_a2_series, [], 'omitnan');
    Indicator.alpha_cap_final = Indicator.alpha_cap_series(final_iter);
    Indicator.gap_final = Metrics.max_tight_gap(final_iter);
    Indicator.gap_max_all = max(Metrics.max_tight_gap, [], 'omitnan');
    Indicator.inward_final = Metrics.max_inward_gap(final_iter);
    Indicator.outward_final = Metrics.max_outward_gap(final_iter);
    Indicator.num_untight_final = Metrics.num_untight(final_iter);
    Indicator.num_untight_1e3_final = sum(abs(Report.tight_gap) > 1e-3);
    Indicator.num_capped_max = max(Metrics.num_slack_capped, [], 'omitnan');
    Indicator.num_capped_rounds = sum(Metrics.num_slack_capped > 0, 'omitnan');
    if isnan(Indicator.num_capped_max)
        Indicator.num_capped_max = 0;
    end
    if Report.dual_available
        Indicator.num_bound_active_final = sum(vecnorm(Report.s_bound, 2, 2) > 1e-6);
    end
    if ~Data.is_baseline && ~Data.keep
        u_bound = 1 + 2;   % ±(1 + s_max)，s_max = 2
    else
        u_bound = 1;
    end
    at_bound = max(abs(Report.u1), abs(Report.u2)) >= u_bound - 1e-6;
    Indicator.num_box_touch_final = sum(at_bound);

    %% 末轮 E vs D 偏差扩散统计
    if Groups.available
        u_norm = Report.u_norm(:);
        in_gap = max(1 - u_norm, 0);
        out_gap = max(u_norm - 1, 0);

        Indicator.num_E_in_1e6 = sum(in_gap(E) > 1e-6);
        Indicator.num_E_in_1e3 = sum(in_gap(E) > 1e-3);
        Indicator.max_E_in = max(in_gap(E));

        Indicator.num_E_out_1e6 = sum(out_gap(E) > 1e-6);
        Indicator.num_E_out_1e3 = sum(out_gap(E) > 1e-3);
        Indicator.max_E_out = max(out_gap(E));

        Indicator.num_D_in_1e6 = sum(in_gap(D) > 1e-6);
        Indicator.num_D_in_1e3 = sum(in_gap(D) > 1e-3);
        Indicator.max_D_in = max(in_gap(D));

        Indicator.num_D_out_1e6 = sum(out_gap(D) > 1e-6);
        Indicator.num_D_out_1e3 = sum(out_gap(D) > 1e-3);
        Indicator.max_D_out = max(out_gap(D));

        Indicator.max_E_in_all = max(Indicator.E_in_series, [], 'omitnan');
        Indicator.max_E_out_all = max(Indicator.E_out_series, [], 'omitnan');
        Indicator.max_D_in_all = max(Indicator.D_in_series, [], 'omitnan');
        Indicator.max_D_out_all = max(Indicator.D_out_series, [], 'omitnan');
    end

    %% 命题 C2 对偶门槛与转角冻结
    if Report.dual_available
        Indicator.sum_s_main_norm_final = sum(Report.s_main_norm, 'omitnan');
    else
        Indicator.sum_s_main_norm_final = Indicator.sum_s_main_norm_series(final_iter);
    end
    Indicator.sum_kappa_over_P_final = Indicator.sum_kappa_over_P_series(final_iter);
    Indicator.sum_y_inner_over_P_final = Indicator.sum_y_inner_over_P_series(final_iter);
    Indicator.turn_median_final = Indicator.turn_median_series(final_iter);
    Indicator.turn_p95_final = Indicator.turn_p95_series(final_iter);
    if numel(Indicator.turn_median_series) >= 10
        Indicator.turn_median_r10 = Indicator.turn_median_series(10);
        Indicator.turn_p95_r10 = Indicator.turn_p95_series(10);
        Indicator.alpha_cap_r10 = Indicator.alpha_cap_series(10);
        Indicator.s_a1_r10 = Indicator.s_a1_series(10);
        Indicator.s_a2_r10 = Indicator.s_a2_series(10);
    end

    %% 圆约束组预测误差账
    Indicator.circle_predicted_final = Metrics.circle_predicted(final_iter);
    Indicator.circle_actual_final = Metrics.circle_actual(final_iter);
    Indicator.circle_error_final = Metrics.circle_error(final_iter);
    Indicator.circle_error_min = min(Metrics.circle_error, [], 'omitnan');
    Indicator.circle_error_max = max(Metrics.circle_error, [], 'omitnan');
    Indicator.circle_error_absmax = max(abs(Metrics.circle_error), [], 'omitnan');
    Indicator.circle_error_pos_count = sum(Metrics.circle_error > 0, 'omitnan');
    Indicator.circle_error_gt1e8_count = sum(Metrics.circle_error > 1e-8, 'omitnan');
    Indicator.circle_error_gt1e6_count = sum(Metrics.circle_error > 1e-6, 'omitnan');

    %% 末轮 σ 偏差
    Indicator.final_sigma = Report.sigma_deg;
    if ~isempty(none_sigma) && Groups.available
        deviation = abs(wrap_angle_deg(Indicator.final_sigma - none_sigma));
        Indicator.sigma_dev_E_median = median(deviation(E));
        Indicator.sigma_dev_D_median = median(deviation(D));
    end

    %% 自检统计
    Indicator.min_u_norm_all = min(arrayfun( ...
        @(a) min(a.control_report.u_norm), Attempts));
    Indicator.stationarity_max = max(arrayfun( ...
        @(a) max(abs(a.control_report.stationarity_residual), [], 'all'), Attempts));
    s_inner_2p = get_metric_or_nan(Metrics, 'sum_s_inner_over_2P', numel(round_index));
    y_inner_p = get_metric_or_nan(Metrics, 'sum_y_inner_over_P', numel(round_index));
    valid_pair = isfinite(s_inner_2p) & isfinite(y_inner_p);
    if any(valid_pair)
        % 仅在全体控制量非零轮严格相等（圆外/圆上轮均成立，zero-init 首轮除外）
        if ~strcmp(Data.init_mode, 'zero')
            Indicator.s_inner_consistency_max = max(abs(s_inner_2p(valid_pair) - y_inner_p(valid_pair)));
        elseif numel(valid_pair) > 1 && any(valid_pair(2:end))
            sub_valid = valid_pair;
            sub_valid(1) = false;
            if any(sub_valid) && Data.enable_continuity
                Indicator.s_inner_consistency_max = max(abs(s_inner_2p(sub_valid) - y_inner_p(sub_valid)));
            end
        end
    end
end


function Indicator = fill_attempt_node_series(Indicator, Attempts, Groups, max_rounds)
% FILL_ATTEMPT_NODE_SERIES 从逐次尝试的 control_report 计算 E/D 分组序列与 45±15 度留存统计。

    if ~Groups.available || isempty(Attempts)
        return;
    end
    E = Groups.E;
    D = Groups.D;
    stayed_E = true(Groups.num_E, 1);
    stayed_D = true(Groups.num_D, 1);

    for k = 1:numel(Attempts)
        iter = Attempts(k).iter;
        R = Attempts(k).control_report;
        u_norm = R.u_norm(:);
        in_gap = max(1 - u_norm, 0);
        out_gap = max(u_norm - 1, 0);

        Indicator.D_min_u_norm_series(iter) = min(u_norm(D));
        Indicator.D_max_u_norm_series(iter) = max(u_norm(D));
        Indicator.E_min_u_norm_series(iter) = min(u_norm(E));
        Indicator.E_max_u_norm_series(iter) = max(u_norm(E));
        Indicator.E_max_gap_series(iter) = max(abs(R.tight_gap(E)));
        Indicator.D_max_gap_series(iter) = max(abs(R.tight_gap(D)));
        Indicator.E_in_series(iter) = max(in_gap(E));
        Indicator.E_out_series(iter) = max(out_gap(E));
        Indicator.D_in_series(iter) = max(in_gap(D));
        Indicator.D_out_series(iter) = max(out_gap(D));

        % 基线在无 s_inner/dual 扩展时的补齐
        if isnan(Indicator.sum_s_main_norm_series(iter)) && R.dual_available
            Indicator.sum_s_main_norm_series(iter) = sum(R.s_main_norm, 'omitnan');
        end

        % σ 留在 45° ± 15° 内且控制非退化的节点统计
        in_band = abs(wrap_angle_deg(R.sigma_deg(:) - 45)) <= 15 & u_norm > 1e-9;
        stayed_E = stayed_E & in_band(E);
        stayed_D = stayed_D & in_band(D);
        if iter == 10
            Indicator.num_E_45pm15_r10 = sum(in_band(E));
            Indicator.num_D_45pm15_r10 = sum(in_band(D));
        end
        if Attempts(k).accepted
            Indicator.num_E_45pm15_final = sum(in_band(E));
            Indicator.num_D_45pm15_final = sum(in_band(D));
        end
    end
    Indicator.num_E_45pm15_all = sum(stayed_E);
    Indicator.num_D_45pm15_all = sum(stayed_D);
end


function status = read_first_status(Metrics)
% READ_FIRST_STATUS 读取首轮求解器状态，兼容未记录 first_status 的基线存档。

    if isfield(Metrics, 'first_status')
        status = Metrics.first_status;
    elseif Metrics.num_attempted >= 1 && Metrics.candidate_available(1)
        status = 'OPTIMAL';
    else
        status = '-';
    end
end


function values = get_metric_or_nan(Metrics, field_name, expected_len)
% GET_METRIC_OR_NAN 从 Metrics 读取字段，缺失时返回等长 NaN 列。

    if isfield(Metrics, field_name)
        values = Metrics.(field_name);
    else
        values = nan(expected_len, 1);
    end
end


function Indicator = create_empty_indicator(Data, max_rounds)
% CREATE_EMPTY_INDICATOR 创建字段齐全的空指标结构体（避免跨工况字段不一致）。

    Indicator = struct();
    Indicator.name = Data.name;
    Indicator.type = Data.type;
    Indicator.is_baseline = Data.is_baseline;
    Indicator.mode = 'twosided';
    if Data.is_baseline
        Indicator.mode = 'regularized';
    end
    Indicator.max_iter = Data.max_iter;
    Indicator.w = Data.w;
    Indicator.p = Data.p;
    Indicator.keep = Data.keep;
    Indicator.enable_continuity = Data.enable_continuity;
    Indicator.init_mode = Data.init_mode;
    Indicator.version_root = Data.version_root;
    Indicator.state = Data.state;
    Indicator.error_message = Data.error_message;
    Indicator.first_status = '-';
    Indicator.num_attempted = NaN;
    Indicator.num_accepted = NaN;
    Indicator.final_iter = NaN;
    Indicator.stop_reason = '-';
    Indicator.plateau_start = NaN;
    Indicator.elapsed_seconds = NaN;
    Indicator.mean_round_seconds = NaN;

    series_fields = {'impulse_series', 'gap_series', 'inward_series', ...
        'outward_series', 'rho_series', 'turn_median_series', ...
        'turn_p95_series', 's_a1_series', 's_a2_series', 'alpha_cap_series', ...
        'sum_kappa_over_P_series', 'sum_y_inner_over_P_series', ...
        'sum_s_main_norm_series', 'circle_error_series', ...
        'D_min_u_norm_series', 'D_max_u_norm_series', ...
        'E_min_u_norm_series', 'E_max_u_norm_series', ...
        'E_max_gap_series', 'D_max_gap_series', ...
        'E_in_series', 'E_out_series', 'D_in_series', 'D_out_series', 'd_series'};
    for k = 1:numel(series_fields)
        Indicator.(series_fields{k}) = nan(max_rounds, 1);
    end

    scalar_fields = {'impulse_final', 'impulse_mean_last', 'impulse_range_last', ...
        'impulse_decrease_last10', 's_a1_final', 's_a2_final', ...
        's_a1_max_all', 's_a2_max_all', 'alpha_cap_final', ...
        'gap_final', 'gap_max_all', 'inward_final', 'outward_final', ...
        'num_untight_final', 'num_untight_1e3_final', 'num_capped_max', ...
        'num_capped_rounds', 'num_bound_active_final', 'num_box_touch_final', ...
        'num_E_in_1e6', 'num_E_in_1e3', 'max_E_in', ...
        'num_E_out_1e6', 'num_E_out_1e3', 'max_E_out', ...
        'num_D_in_1e6', 'num_D_in_1e3', 'max_D_in', ...
        'num_D_out_1e6', 'num_D_out_1e3', 'max_D_out', ...
        'max_E_in_all', 'max_E_out_all', 'max_D_in_all', 'max_D_out_all', ...
        'sum_s_main_norm_final', 'sum_kappa_over_P_final', ...
        'sum_y_inner_over_P_final', 'turn_median_final', 'turn_p95_final', ...
        'turn_median_r10', 'turn_p95_r10', 'alpha_cap_r10', 's_a1_r10', 's_a2_r10', ...
        'num_E_45pm15_r10', 'num_D_45pm15_r10', ...
        'num_E_45pm15_final', 'num_D_45pm15_final', ...
        'num_E_45pm15_all', 'num_D_45pm15_all', ...
        'circle_predicted_final', 'circle_actual_final', 'circle_error_final', ...
        'circle_error_min', 'circle_error_max', 'circle_error_absmax', ...
        'circle_error_pos_count', 'circle_error_gt1e8_count', 'circle_error_gt1e6_count', ...
        'sigma_dev_E_median', 'sigma_dev_D_median', 'sigma_ref_E_median', ...
        'd_final', 'd_mean_last', 'd_range_last', 'd_stable', 'd_stable_round', ...
        'd_ref_final', 'min_u_norm_all', 'stationarity_max', ...
        's_inner_consistency_max'};
    for k = 1:numel(scalar_fields)
        Indicator.(scalar_fields{k}) = NaN;
    end
    Indicator.final_sigma = [];
end


function series = place_series(values, iters, max_rounds)
% PLACE_SERIES 把逐轮向量按轮号填入长度为 max_rounds 的列向量。

    series = nan(max_rounds, 1);
    series(iters) = values(:);
end


%% ===== 差值与稳定性 =====

function Summary = add_difference_indicators(Summary, Groups, Options)
% ADD_DIFFERENCE_INDICATORS 计算相对 none 与 normgap_w1e-4 的总脉冲差及稳定性。

    ItemList = arrayfun(@(S) S, Summary, 'UniformOutput', false);
    names = {Summary.name};
    none_index = find(strcmp(names, 'none') & strcmp({Summary.state}, 'ok'), 1);
    ref_index = find(strcmp(names, Options.reference_case) ...
        & strcmp({Summary.state}, 'ok'), 1);

    for c = 1:numel(ItemList)
        if ~strcmp(Summary(c).state, 'ok')
            continue;
        end
        S = Summary(c);
        if ~isempty(none_index)
            S = fill_difference(S, ...
                S.impulse_series - Summary(none_index).impulse_series, Options);
        end
        if ~S.is_baseline && ~isempty(ref_index)
            diff_ref = S.impulse_series - Summary(ref_index).impulse_series;
            S.d_ref_final = diff_ref(S.final_iter);
        end
        ItemList{c} = S;
    end
    Summary = [ItemList{:}];

    if ~isempty(ref_index) && Groups.available
        ref_sigma = Summary(ref_index).final_sigma;
        for c = 1:numel(Summary)
            if Summary(c).is_baseline || ~strcmp(Summary(c).state, 'ok')
                continue;
            end
            dev = abs(wrap_angle_deg(Summary(c).final_sigma - ref_sigma));
            Summary(c).sigma_ref_E_median = median(dev(Groups.E));
        end
    end
end


function S = fill_difference(S, difference, Options)
% FILL_DIFFERENCE 计算差值序列的末轮值、末窗口极差与稳定轮。

    final_iter = S.final_iter;
    range_index = max(1, final_iter - Options.window + 1):final_iter;
    last_values = difference(range_index);
    S.d_series = difference;
    S.d_final = difference(final_iter);
    S.d_mean_last = mean(last_values, 'omitnan');
    S.d_range_last = max(last_values, [], 'omitnan') ...
        - min(last_values, [], 'omitnan');
    S.d_stable = double(S.d_range_last <= Options.delta);
    within = abs(difference(1:final_iter) - difference(final_iter)) <= Options.delta;
    last_outside = find(~within & ~isnan(difference(1:final_iter)), 1, 'last');
    if isempty(last_outside)
        S.d_stable_round = 1;
    else
        S.d_stable_round = last_outside + 1;
    end
end


%% ===== 基线校验与自检 =====

function Check = check_run(Summary, CaseData, Groups)
% CHECK_RUN 汇总基线版本校验与全部 twosided 工况的残差、u 范数及预测误差自检。

    is_base = [CaseData.is_baseline];
    Base = CaseData(is_base);
    Check.baseline_names = {Base.name};
    Check.baseline_versions = {Base.version_root};
    Check.baseline_states = {Base.state};
    Check.baseline_all_verified = all(strcmp({Base.state}, 'ok')) ...
        && all(strcmp({Base.version_root}, 'Version1-3-standard-5'));
    Check.num_D = Groups.num_D;
    Check.num_E = Groups.num_E;

    is_two = ~[Summary.is_baseline] & strcmp({Summary.state}, 'ok');
    Two = Summary(is_two);
    Check.twosided_num_cases = numel(Two);
    Check.twosided_total_rounds = sum([Two.num_attempted]);
    Check.twosided_stationarity_max = max([Two.stationarity_max]);
    Check.twosided_min_u_norm = min([Two.min_u_norm_all]);
    Check.twosided_circle_error_min = min([Two.circle_error_min]);
    Check.twosided_circle_error_max = max([Two.circle_error_max]);
    Check.twosided_circle_error_absmax = max([Two.circle_error_absmax]);
    Check.twosided_circle_error_pos_count = sum([Two.circle_error_pos_count]);
    Check.twosided_circle_error_gt1e8_count = sum([Two.circle_error_gt1e8_count]);
    Check.twosided_circle_error_gt1e6_count = sum([Two.circle_error_gt1e6_count]);
    Check.twosided_s_inner_consistency_max = max([Two.s_inner_consistency_max], [], 'omitnan');
end


%% ===== 汇总文本 =====

function write_compare_text(text_path, Summary, Groups, Check, Options)
% WRITE_COMPARE_TEXT 写七节汇总文本到 results/对比汇总.txt。

    file_id = fopen(text_path, 'w', 'n', 'UTF-8');
    cleanup = onCleanup(@() fclose(file_id));
    write_run_list(file_id, Summary);
    write_self_check(file_id, Check, Options);
    write_final_and_spread_tables(file_id, Summary, Groups);
    write_c2_and_freezing_tables(file_id, Summary, Groups);
    write_circle_error_table(file_id, Summary);
    write_zero_init_tables(file_id, Summary);
    write_round_series(file_id, Summary);
    fprintf(file_id, '\n（δ = %g m/s，window = %d；共用节点分组来自 none 末轮: |D| = %g，|E| = %g）\n', ...
        Options.delta, Options.window, Groups.num_D, Groups.num_E);
end


function write_run_list(file_id, Summary)
% WRITE_RUN_LIST 第 1 节：运行清单（12 个 twosided + 5 个只读基线）。

    fprintf(file_id, '=== 1 运行清单（12 个 twosided + 5 个只读基线） ===\n');
    headers = {'工况', '来源/模式', 'P 或 w', '保边界', '速率', '初值', ...
        '首轮', '轮数', '接受', '停止原因', '用时(s)', '末轮脉冲(m/s)'};
    rows = cell(numel(Summary), 12);
    for c = 1:numel(Summary)
        S = Summary(c);
        if ~S.is_baseline
            coeff = format_coeff('P', S.p);
            src_mode = 'twosided';
        elseif isnan(S.w)
            coeff = '-';
            src_mode = 'baseline/reg';
        else
            coeff = format_coeff('w', S.w);
            src_mode = 'baseline/reg';
        end
        rows(c, :) = {S.name, src_mode, coeff, yes_no_text(S.keep), ...
            yes_no_text(S.enable_continuity), S.init_mode, ...
            S.first_status, format_value(S.num_attempted, '%d'), ...
            format_value(S.num_accepted, '%d'), S.stop_reason, ...
            format_value(S.elapsed_seconds, '%.1f'), ...
            format_value(S.impulse_final, '%.4f')};
    end
    write_table(file_id, headers, rows);
end


function write_self_check(file_id, Check, Options)
% WRITE_SELF_CHECK 第 2 节：只读基线校验与 twosided 全部轮次自检。

    fprintf(file_id, '\n=== 2 基线校验与自检 ===\n');
    fprintf(file_id, '基线目录: %s\n', Options.baseline_root);
    fprintf(file_id, '基线 version_root == ''Version1-3-standard-5'' 校验: %s\n', ...
        yes_no_text(Check.baseline_all_verified));
    headers = {'基线工况', '存档 version_root', '状态'};
    rows = cell(numel(Check.baseline_names), 3);
    for k = 1:numel(Check.baseline_names)
        rows(k, :) = {Check.baseline_names{k}, ...
            char_or_dash(Check.baseline_versions{k}), Check.baseline_states{k}};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n共用节点分组（none 末轮 q_i = ‖s_main,i‖/ω_i < 1e-6）: |D| = %g, |E| = %g\n', ...
        Check.num_D, Check.num_E);
    fprintf(file_id, 'twosided 有效工况数 = %d，总尝试轮次 = %d\n', ...
        Check.twosided_num_cases, Check.twosided_total_rounds);
    fprintf(file_id, '全部 twosided 轮次最大驻点残差 max|s_total - s_cone| = %.3e\n', ...
        Check.twosided_stationarity_max);
    fprintf(file_id, '全部 twosided 轮次 min(‖u‖) = %.6f\n', Check.twosided_min_u_norm);
    fprintf(file_id, ['全部 twosided 轮次圆约束组预测误差 D_unit: 最小 = %+.3e, ' ...
        '最大 = %+.3e, max|D| = %.3e\n'], ...
        Check.twosided_circle_error_min, Check.twosided_circle_error_max, ...
        Check.twosided_circle_error_absmax);
    fprintf(file_id, '  其中 D_unit > 0 轮次 = %d, > 1e-8 轮次 = %d, > 1e-6 轮次 = %d\n', ...
        Check.twosided_circle_error_pos_count, ...
        Check.twosided_circle_error_gt1e8_count, ...
        Check.twosided_circle_error_gt1e6_count);
    fprintf(file_id, '对偶一致性检验 max|‖s_inner‖/(2‖ū‖) - (-y_i)| / P（非零参考） = %.3e\n', ...
        Check.twosided_s_inner_consistency_max);
end


function write_final_and_spread_tables(file_id, Summary, Groups)
% WRITE_FINAL_AND_SPREAD_TABLES 第 3 节：末轮总脉冲、全局紧性及 E vs D 两侧扩散表。

    fprintf(file_id, '\n=== 3 末轮表与两侧偏差扩散（|E| = %g, |D| = %g） ===\n', ...
        Groups.num_E, Groups.num_D);

    fprintf(file_id, '(3a) 总脉冲与相对 none 同轮差值 d:\n');
    headers = {'工况', '末轮脉冲', '末5均值', '末10降幅/轮', '末5极差', ...
        'd 末轮', 'd 末5极差', '稳定轮', '稳定'};
    rows = cell(numel(Summary), 9);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.impulse_final, '%.4f'), ...
            format_value(S.impulse_mean_last, '%.4f'), ...
            format_value(S.impulse_decrease_last10, '%.4f'), ...
            format_value(S.impulse_range_last, '%.4f'), ...
            format_value_plus(S.d_final), format_value_plus(S.d_range_last), ...
            format_value(S.d_stable_round, '%d'), stable_text(S.d_stable)};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(3b) 全局共用松弛、紧性与触界:\n');
    headers = {'工况', '末轮 s_a1', '末轮 s_a2', '全程 max s_a1', '全程 max s_a2', ...
        '末轮 max|1-‖u‖|', '全程 max|1-‖u‖|', '末轮不紧(>1e-6)', ...
        '末轮不紧(>1e-3)', '触上界轮', '触箱边界', '边界乘子'};
    rows = cell(numel(Summary), 12);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value(S.s_a1_final, '%.3e'), ...
            format_value(S.s_a2_final, '%.3e'), ...
            format_value(S.s_a1_max_all, '%.3e'), ...
            format_value(S.s_a2_max_all, '%.3e'), ...
            format_value(S.gap_final, '%.3e'), ...
            format_value(S.gap_max_all, '%.3e'), ...
            format_value(S.num_untight_final, '%d'), ...
            format_value(S.num_untight_1e3_final, '%d'), ...
            format_value(S.num_capped_rounds, '%d'), ...
            format_value(S.num_box_touch_final, '%d'), ...
            format_value(S.num_bound_active_final, '%d')};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(3c) 末轮 E 节点 vs D 节点在圆内/圆外的不紧节点数与最大偏离:\n');
    headers = {'工况', 'E内(>1e-6)', 'E内(>1e-3)', 'E内最大', ...
        'E外(>1e-6)', 'E外(>1e-3)', 'E外最大', ...
        'D内(>1e-6)', 'D内(>1e-3)', 'D内最大', ...
        'D外(>1e-6)', 'D外(>1e-3)', 'D外最大'};
    rows = cell(numel(Summary), 13);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, ...
            format_value(S.num_E_in_1e6, '%d'), format_value(S.num_E_in_1e3, '%d'), ...
            format_value(S.max_E_in, '%.3e'), ...
            format_value(S.num_E_out_1e6, '%d'), format_value(S.num_E_out_1e3, '%d'), ...
            format_value(S.max_E_out, '%.3e'), ...
            format_value(S.num_D_in_1e6, '%d'), format_value(S.num_D_in_1e3, '%d'), ...
            format_value(S.max_D_in, '%.3e'), ...
            format_value(S.num_D_out_1e6, '%d'), format_value(S.num_D_out_1e3, '%d'), ...
            format_value(S.max_D_out, '%.3e')};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(3d) 全程各轮 E/D 最大向内与向外偏离:\n');
    headers = {'工况', '全程E内最大', '全程E外最大', '全程D内最大', '全程D外最大'};
    rows = cell(numel(Summary), 5);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, ...
            format_value(S.max_E_in_all, '%.3e'), format_value(S.max_E_out_all, '%.3e'), ...
            format_value(S.max_D_in_all, '%.3e'), format_value(S.max_D_out_all, '%.3e')};
    end
    write_table(file_id, headers, rows);
end


function write_c2_and_freezing_tables(file_id, Summary, Groups)
% WRITE_C2_AND_FREEZING_TABLES 第 4 节：命题 C2 对偶门槛与大 P 转角冻结表。

    fprintf(file_id, '\n=== 4 命题 C2 对偶门槛与转角冻结 ===\n');
    main_mask = is_main_scan_or_ref(Summary);
    Main = Summary(main_mask);

    fprintf(file_id, '(4a) 末轮命题 C2 对偶门槛核验:\n');
    headers = {'工况', 'P', 'Σ‖s_main‖', 'Σκ̂/P', 'Σ(-y_i)/P', ...
        's_a1', 's_a2', '理论α_末(deg)'};
    rows = cell(numel(Main), 8);
    for k = 1:numel(Main)
        S = Main(k);
        rows(k, :) = {S.name, format_value(S.p, '%.0e'), ...
            format_value(S.sum_s_main_norm_final, '%.4e'), ...
            format_value(S.sum_kappa_over_P_final, '%.4f'), ...
            format_value(S.sum_y_inner_over_P_final, '%.4f'), ...
            format_value(S.s_a1_final, '%.3e'), ...
            format_value(S.s_a2_final, '%.3e'), ...
            format_value(S.alpha_cap_final, '%.3f')};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(4b) 第 10 轮与第 50 轮（末轮）转角冻结对照（|E|=%g, |D|=%g）:\n', ...
        Groups.num_E, Groups.num_D);
    headers = {'工况', 'α_10', '转角中位_10', '转角95%_10', ...
        'α_末', '转角中位_末', '转角95%_末', ...
        'E留45±15(10/末/全)', 'D留45±15(10/末/全)', '|Δσ|E_相对none'};
    rows = cell(numel(Main), 10);
    for k = 1:numel(Main)
        S = Main(k);
        e_stay = sprintf('%s/%s/%s', ...
            format_value(S.num_E_45pm15_r10, '%d'), ...
            format_value(S.num_E_45pm15_final, '%d'), ...
            format_value(S.num_E_45pm15_all, '%d'));
        d_stay = sprintf('%s/%s/%s', ...
            format_value(S.num_D_45pm15_r10, '%d'), ...
            format_value(S.num_D_45pm15_final, '%d'), ...
            format_value(S.num_D_45pm15_all, '%d'));
        rows(k, :) = {S.name, ...
            format_value(S.alpha_cap_r10, '%.3f'), ...
            format_value(S.turn_median_r10, '%.3f'), ...
            format_value(S.turn_p95_r10, '%.3f'), ...
            format_value(S.alpha_cap_final, '%.3f'), ...
            format_value(S.turn_median_final, '%.3f'), ...
            format_value(S.turn_p95_final, '%.3f'), ...
            e_stay, d_stay, format_value(S.sigma_dev_E_median, '%.3f')};
    end
    write_table(file_id, headers, rows);
end


function write_circle_error_table(file_id, Summary)
% WRITE_CIRCLE_ERROR_TABLE 第 5 节：圆约束组预测下降、真实下降与预测误差表。

    fprintf(file_id, '\n=== 5 圆约束组预测误差（ΔL_unit、ΔJ_unit、D_unit） ===\n');
    headers = {'工况', 'ΔL 末轮', 'ΔJ 末轮', 'D 末轮', '全程 min D', ...
        '全程 max D', '全程 max|D|', 'D>0轮', 'D>1e-8轮', 'D>1e-6轮'};
    rows = cell(numel(Summary), 10);
    for c = 1:numel(Summary)
        S = Summary(c);
        rows(c, :) = {S.name, format_value_plus(S.circle_predicted_final), ...
            format_value_plus(S.circle_actual_final), ...
            format_value_plus(S.circle_error_final), ...
            format_value_plus(S.circle_error_min), ...
            format_value_plus(S.circle_error_max), ...
            format_value(S.circle_error_absmax, '%.3e'), ...
            format_value(S.circle_error_pos_count, '%d'), ...
            format_value(S.circle_error_gt1e8_count, '%d'), ...
            format_value(S.circle_error_gt1e6_count, '%d')};
    end
    write_table(file_id, headers, rows);
end


function write_zero_init_tables(file_id, Summary)
% WRITE_ZERO_INIT_TABLES 第 6 节：圆内/零初值专项表（第 1、2、5、10 轮及 1~10 轮明细）。

    fprintf(file_id, '\n=== 6 圆内与零初值专项对照（第 1、2、5、10 轮） ===\n');
    target_names = {'twosided_init0p3_P1e-1', 'twosided_init0_P1e-1', ...
        'twosided_init0_nr_P1e-1', 'twosided_init0_P1e2', ...
        'twosided_P1e-1', 'twosided_P1e2'};
    target_rounds = [1, 2, 5, 10];
    headers = {'工况', '轮次', '总脉冲(m/s)', 's_a1', 's_a2', ...
        'D min‖u‖', 'D max‖u‖', 'E max|1-‖u‖|', 'Σκ̂/P', 'Σ(-y_i)/P'};
    rows = {};
    for k = 1:numel(target_names)
        idx = find(strcmp({Summary.name}, target_names{k}), 1);
        if isempty(idx) || ~strcmp(Summary(idx).state, 'ok')
            continue;
        end
        S = Summary(idx);
        for r = target_rounds
            if r > S.num_attempted
                continue;
            end
            rows(end + 1, :) = {S.name, sprintf('%d', r), ... %#ok<AGROW>
                format_value(S.impulse_series(r), '%.4f'), ...
                format_value(S.s_a1_series(r), '%.3e'), ...
                format_value(S.s_a2_series(r), '%.3e'), ...
                format_value(S.D_min_u_norm_series(r), '%.6f'), ...
                format_value(S.D_max_u_norm_series(r), '%.6f'), ...
                format_value(S.E_max_gap_series(r), '%.3e'), ...
                format_value(S.sum_kappa_over_P_series(r), '%.4f'), ...
                format_value(S.sum_y_inner_over_P_series(r), '%.4f')};
        end
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n初值专项 1~10 轮逐轮明细（s_a2 与 D min‖u‖）:\n');
    init_names = target_names(1:4);
    round_headers = [{'工况', '指标'}, arrayfun(@(r) sprintf('轮%d', r), 1:10, ...
        'UniformOutput', false)];
    detail_rows = {};
    for k = 1:numel(init_names)
        idx = find(strcmp({Summary.name}, init_names{k}), 1);
        if isempty(idx) || ~strcmp(Summary(idx).state, 'ok')
            continue;
        end
        S = Summary(idx);
        detail_rows(end + 1, :) = [{S.name, 's_a2'}, ... %#ok<AGROW>
            arrayfun(@(r) format_value(S.s_a2_series(r), '%.3e'), 1:10, 'UniformOutput', false)];
        detail_rows(end + 1, :) = [{S.name, 'D min‖u‖'}, ... %#ok<AGROW>
            arrayfun(@(r) format_value(S.D_min_u_norm_series(r), '%.4f'), 1:10, 'UniformOutput', false)];
        detail_rows(end + 1, :) = [{S.name, 'E max|gap|'}, ... %#ok<AGROW>
            arrayfun(@(r) format_value(S.E_max_gap_series(r), '%.2e'), 1:10, 'UniformOutput', false)];
    end
    write_table(file_id, round_headers, detail_rows);
end


function write_round_series(file_id, Summary)
% WRITE_ROUND_SERIES 第 7 节：各工况逐轮总脉冲、s_a1、s_a2 与 max|1-‖u‖| 序列。

    fprintf(file_id, '\n=== 7 逐轮序列 ===\n');
    series_specs = {
        'impulse_series', '各轮总脉冲 (m/s)', '%.3f';
        's_a1_series',    '各轮 s_a1（凸侧松弛）', '%.1e';
        's_a2_series',    '各轮 s_a2（凹侧松弛）', '%.1e';
        'gap_series',     '各轮 max|1-‖u‖|', '%.1e'};
    num_rounds = numel(Summary(1).impulse_series);
    headers = [{'工况'}, arrayfun(@(k) sprintf('轮%d', k), 1:num_rounds, ...
        'UniformOutput', false)];
    for s = 1:size(series_specs, 1)
        fprintf(file_id, '\n%s:\n', series_specs{s, 2});
        rows = cell(numel(Summary), num_rounds + 1);
        for c = 1:numel(Summary)
            values = Summary(c).(series_specs{s, 1});
            rows{c, 1} = Summary(c).name;
            for k = 1:num_rounds
                rows{c, k + 1} = format_value(values(k), series_specs{s, 3});
            end
        end
        write_table(file_id, headers, rows);
    end
end


function mask = is_main_scan_or_ref(Summary)
% IS_MAIN_SCAN_OR_REF 选出主扫描工况（default 初值，50 轮）及 none / normgap_w1e-4 对照。

    names = {Summary.name};
    mask = (~[Summary.is_baseline] & strcmp({Summary.init_mode}, 'default')) ...
        | strcmp(names, 'none') | strcmp(names, 'normgap_w1e-4');
end


%% ===== 文本格式工具 =====

function text = format_coeff(symbol, val)
% FORMAT_COEFF 按固定科学计数格式写系数（如 P=3.0e-02）。

    text = sprintf('%s=%.1e', symbol, val);
end


function text = stable_text(flag)
% STABLE_TEXT 稳定标志转中文。

    if isnan(flag)
        text = '-';
    elseif flag > 0
        text = '是';
    else
        text = '否';
    end
end


function text = yes_no_text(value)
% YES_NO_TEXT 逻辑量转“是”“否”。

    if value
        text = '是';
    else
        text = '否';
    end
end


function text = format_value(value, spec)
% FORMAT_VALUE 格式化单个数值，NaN 写为 '-'。

    if isnan(value)
        text = '-';
    elseif isinf(value)
        text = 'Inf';
    else
        text = sprintf(spec, value);
    end
end


function text = format_value_plus(value)
% FORMAT_VALUE_PLUS 带符号科学计数，NaN 写为 '-'。

    text = format_value(value, '%+.3e');
end


function text = char_or_dash(value)
% CHAR_OR_DASH 空字符串写为 '-'。

    if isempty(value)
        text = '-';
    else
        text = value;
    end
end


function write_table(file_id, headers, rows)
% WRITE_TABLE 按终端显示宽度对齐写表：首列左对齐，其余列右对齐，列间空两格。

    if isempty(rows)
        return;
    end
    all_rows = [headers; rows];
    num_columns = size(all_rows, 2);
    widths = zeros(1, num_columns);
    for c = 1:num_columns
        widths(c) = max(cellfun(@display_width, all_rows(:, c)));
    end
    for r = 1:size(all_rows, 1)
        parts = cell(1, num_columns);
        for c = 1:num_columns
            padding = blanks(widths(c) - display_width(all_rows{r, c}));
            if c == 1
                parts{c} = [all_rows{r, c}, padding];
            else
                parts{c} = [padding, all_rows{r, c}];
            end
        end
        fprintf(file_id, '%s\n', strjoin(parts, '  '));
    end
end


function width = display_width(text)
% DISPLAY_WIDTH 计算显示宽度（全角字符占两格，其余占一格）。

    width = sum(1 + (double(text) >= 11904));
end


%% ===== 绘图 =====

function plot_compare_figures(Summary, Groups, Options, pictures_root)
% PLOT_COMPARE_FIGURES 绘制并导出对比实验的七张 PNG 图（字号 16，底部共用图例）。
%
% 本函数依次完成：
%   1. 确保图片输出目录存在。
%   2. 绘制主扫描各轮总脉冲对比图。
%   3. 绘制相对 none 总脉冲差值 d 对比图。
%   4. 绘制双侧松弛与单位范数紧性随轮次及随 P 扩散图。
%   5. 绘制命题 C2 对偶门槛与转角冻结随 P 变化图。
%   6. 绘制零初值对照指标与末轮 σ 叠画图。

    %% 1. 确保图片输出目录存在
    if ~isfolder(pictures_root)
        mkdir(pictures_root);
    end

    %% 2. 绘制主扫描各轮总脉冲对比图
    plot_round_impulse_figure(Summary, pictures_root);

    %% 3. 绘制相对 none 总脉冲差值 d 对比图
    plot_difference_rounds_figure(Summary, Options, pictures_root);

    %% 4. 绘制双侧松弛与单位范数紧性随轮次及随 P 扩散图
    plot_slack_rounds_figure(Summary, pictures_root);
    plot_spread_vs_p_figure(Summary, pictures_root);

    %% 5. 绘制命题 C2 对偶门槛与转角冻结随 P 变化图
    plot_dual_threshold_figure(Summary, pictures_root);

    %% 6. 绘制零初值对照指标与末轮 σ 叠画图
    plot_zero_init_figure(Summary, pictures_root);
    plot_final_sigma_figure(Summary, Groups, pictures_root);
end


function plot_round_impulse_figure(Summary, pictures_root)
% PLOT_ROUND_IMPULSE_FIGURE 对比-各轮总脉冲：三块共用纵轴（基线、twosided P<=0.1、P>=1）。

    font_size = 16;
    fig = new_figure('对比-各轮总脉冲');
    layout = create_tile_layout(fig, 3);
    main_mask = is_main_scan_or_ref(Summary) ...
        | strcmp({Summary.name}, 'normgap_w1e-3') ...
        | strcmp({Summary.name}, 'normgap_w1e-5');
    limits = padded_limits(cellfun(@(S) S.impulse_series, ...
        num2cell(Summary(main_mask)), 'UniformOutput', false));
    tile_axes = gobjects(1, 3);
    for g = 1:3
        [group_name, label] = tile_group(g);
        ax = nexttile(layout);
        tile_axes(g) = ax;
        hold(ax, 'on');
        draw_case_series(ax, Summary, 'impulse_series', ...
            group_members(Summary, group_name), g > 1);
        ylim(ax, limits);
        style_axes(ax, ['总脉冲 (m/s)，' label], '迭代轮次', font_size);
    end
    finish_compare_window(layout, tile_axes, '主扫描各轮总脉冲对比', {}, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-各轮总脉冲.png'));
end


function plot_difference_rounds_figure(Summary, Options, pictures_root)
% PLOT_DIFFERENCE_ROUNDS_FIGURE 对比-相对none差值：2x2 分块展示基线与 twosided 各档差值 d。

    font_size = 16;
    fig = new_figure('对比-相对none差值');
    layout = create_tile_layout(fig, 4);
    reg_mask = group_members(Summary, 'regularized') & ~strcmp({Summary.type}, 'none');
    zoom_vals = cellfun(@(S) S.d_series, num2cell(Summary(reg_mask)), 'UniformOutput', false);
    zoom_limits = padded_limits([vertcat(zoom_vals{:}); Options.delta; -Options.delta]);
    main_mask = is_main_scan_or_ref(Summary) & ~strcmp({Summary.type}, 'none');
    all_vals = cellfun(@(S) S.d_series, num2cell(Summary(main_mask)), 'UniformOutput', false);
    all_limits = padded_limits([vertcat(all_vals{:}); Options.delta; -Options.delta]);

    groups = {'regularized', 'regularized', 'twosided_small', 'twosided_large'};
    labels = {'regularized（放大）', 'regularized（同尺度）', 'twosided，P ≤ 0.1', 'twosided，P ≥ 1'};
    tile_limits = {zoom_limits, all_limits, all_limits, all_limits};
    tile_axes = gobjects(1, 4);
    for t = 1:4
        ax = nexttile(layout);
        tile_axes(t) = ax;
        hold(ax, 'on');
        yline(ax, 0, 'k-', 'LineWidth', 1.0, 'HandleVisibility', 'off');
        yline(ax, Options.delta, '--', 'Color', [0.45 0.45 0.45], ...
            'LineWidth', 1.2, 'DisplayName', sprintf('±δ (%g m/s)', Options.delta));
        yline(ax, -Options.delta, '--', 'Color', [0.45 0.45 0.45], ...
            'LineWidth', 1.2, 'HandleVisibility', 'off');
        members = group_members(Summary, groups{t}) & ~strcmp({Summary.type}, 'none');
        draw_case_series(ax, Summary, 'd_series', members, t == 2);
        ylim(ax, tile_limits{t});
        x_label = '';
        if t >= 3
            x_label = '迭代轮次';
        end
        style_axes(ax, ['d (m/s)，' labels{t}], x_label, font_size);
    end
    finish_compare_window(layout, tile_axes, '相对 none 同轮总脉冲差值 d', {}, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-相对none差值.png'));
end


function plot_slack_rounds_figure(Summary, pictures_root)
% PLOT_SLACK_ROUNDS_FIGURE 对比-双侧松弛与紧性随轮次：2x3 展示 s_a1、s_a2 与 max|1-‖u‖| 随轮次变化。

    font_size = 16;
    floor_val = 1e-12;
    fig = new_figure('对比-双侧松弛与紧性随轮次');
    layout = create_tile_layout(fig, 6);
    tile_axes = gobjects(1, 6);

    small_members = group_members(Summary, 'twosided_small') & ~strcmp({Summary.type}, 'none');
    large_members = group_members(Summary, 'twosided_large') & ~strcmp({Summary.type}, 'none');
    fields = {'s_a1_series', 's_a2_series', 'gap_series'};
    y_prefixes = {'s_{a1}', 's_{a2}', 'max|1-‖u‖|'};

    for col = 1:3
        ax_top = nexttile(layout, col);
        tile_axes(col) = ax_top;
        hold(ax_top, 'on');
        draw_case_series(ax_top, Summary, fields{col}, small_members, false, floor_val);
        set(ax_top, 'YScale', 'log');
        style_axes(ax_top, [y_prefixes{col} '，P ≤ 0.1'], '', font_size);

        ax_bot = nexttile(layout, 3 + col);
        tile_axes(3 + col) = ax_bot;
        hold(ax_bot, 'on');
        draw_case_series(ax_bot, Summary, fields{col}, large_members, false, floor_val);
        set(ax_bot, 'YScale', 'log');
        style_axes(ax_bot, [y_prefixes{col} '，P ≥ 1'], '迭代轮次', font_size);
    end

    finish_compare_window(layout, tile_axes, '双侧松弛与紧性随轮次变化', ...
        {'对数纵轴零值画在 1e-12'}, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-双侧松弛与紧性随轮次.png'));
end


function plot_spread_vs_p_figure(Summary, pictures_root)
% PLOT_SPREAD_VS_P_FIGURE 对比-偏差扩散随P：末轮松弛量、E/D 最大偏离及不紧节点数随 P 变化。

    font_size = 16;
    floor_val = 1e-12;
    fig = new_figure('对比-偏差扩散随P');
    layout = create_tile_layout(fig, 2);
    tile_axes = gobjects(1, 2);

    scan_mask = ~[Summary.is_baseline] & strcmp({Summary.init_mode}, 'default') ...
        & ~[Summary.keep] & strcmp({Summary.state}, 'ok');
    Scan = Summary(scan_mask);
    [~, order] = sort([Scan.p]);
    Scan = Scan(order);
    p_vals = [Scan.p];

    ax1 = nexttile(layout, 1);
    tile_axes(1) = ax1;
    hold(ax1, 'on');
    plot(ax1, p_vals, max([Scan.s_a1_final], floor_val), '-o', ...
        'Color', [0.00 0.45 0.74], 'MarkerFaceColor', [0.00 0.45 0.74], ...
        'LineWidth', 1.8, 'DisplayName', 's_{a1}');
    plot(ax1, p_vals, max([Scan.s_a2_final], floor_val), '-d', ...
        'Color', [0.85 0.33 0.10], 'MarkerFaceColor', [0.85 0.33 0.10], ...
        'LineWidth', 1.8, 'DisplayName', 's_{a2}');
    plot(ax1, p_vals, max([Scan.max_E_out], floor_val), '--^', ...
        'Color', [0.47 0.67 0.19], 'MarkerFaceColor', [0.47 0.67 0.19], ...
        'LineWidth', 1.5, 'DisplayName', 'E 圆外最大偏离');
    plot(ax1, p_vals, max([Scan.max_D_in], floor_val), ':s', ...
        'Color', [0.49 0.18 0.56], 'MarkerFaceColor', [0.49 0.18 0.56], ...
        'LineWidth', 1.5, 'DisplayName', 'D 圆内最大偏离');
    set(ax1, 'XScale', 'log', 'YScale', 'log');
    style_axes(ax1, '末轮松弛与最大偏离', '罚权 P', font_size);

    ax2 = nexttile(layout, 2);
    tile_axes(2) = ax2;
    hold(ax2, 'on');
    plot(ax2, p_vals, [Scan.num_E_out_1e6], '-o', ...
        'Color', [0.47 0.67 0.19], 'MarkerFaceColor', [0.47 0.67 0.19], ...
        'LineWidth', 1.6, 'DisplayName', 'E 圆外不紧数');
    plot(ax2, p_vals, [Scan.num_E_in_1e6], '-d', ...
        'Color', [0.00 0.60 0.50], 'MarkerFaceColor', [0.00 0.60 0.50], ...
        'LineWidth', 1.6, 'DisplayName', 'E 圆内不紧数');
    plot(ax2, p_vals, [Scan.num_D_out_1e6] + [Scan.num_D_in_1e6], '-^', ...
        'Color', [0.49 0.18 0.56], 'MarkerFaceColor', [0.49 0.18 0.56], ...
        'LineWidth', 1.6, 'DisplayName', 'D 不紧数');
    set(ax2, 'XScale', 'log');
    ylim(ax2, [-20, 620]);
    style_axes(ax2, '末轮不紧节点数 (>1e-6)', '罚权 P', font_size);

    finish_compare_window(layout, tile_axes, '末轮松弛与 E/D 偏差扩散随 P 变化', ...
        {'左图零值画在 1e-12'}, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-偏差扩散随P.png'));
end


function plot_dual_threshold_figure(Summary, pictures_root)
% PLOT_DUAL_THRESHOLD_FIGURE 对比-对偶门槛随P：命题 C2 门槛比、需求总和与转角冻结随 P 变化。

    font_size = 16;
    fig = new_figure('对比-对偶门槛随P');
    layout = create_tile_layout(fig, 3);
    tile_axes = gobjects(1, 3);

    scan_mask = ~[Summary.is_baseline] & strcmp({Summary.init_mode}, 'default') ...
        & ~[Summary.keep] & strcmp({Summary.state}, 'ok');
    Scan = Summary(scan_mask);
    [~, order] = sort([Scan.p]);
    Scan = Scan(order);
    p_vals = [Scan.p];
    keep_idx = find(strcmp({Summary.name}, 'twosidedkeep_P1e-1') ...
        & strcmp({Summary.state}, 'ok'), 1);

    %% 分块 1: 对偶总和比 Σκ̂_i/P 与 Σ(-y_i)/P 随 P
    ax = nexttile(layout, 1);
    tile_axes(1) = ax;
    hold(ax, 'on');
    plot(ax, p_vals, [Scan.sum_kappa_over_P_final], '-o', ...
        'Color', [0.00 0.45 0.74], 'MarkerFaceColor', [0.00 0.45 0.74], ...
        'LineWidth', 1.8, 'DisplayName', 'Σκ̂_i / P');
    plot(ax, p_vals, [Scan.sum_y_inner_over_P_final], '-d', ...
        'Color', [0.85 0.33 0.10], 'MarkerFaceColor', [0.85 0.33 0.10], ...
        'LineWidth', 1.8, 'DisplayName', 'Σ(-y_i) / P');
    if ~isempty(keep_idx)
        Sk = Summary(keep_idx);
        plot(ax, Sk.p, Sk.sum_kappa_over_P_final, 'o', 'Color', [0.00 0.45 0.74], ...
            'MarkerFaceColor', 'none', 'MarkerSize', 10, 'LineWidth', 1.6, ...
            'DisplayName', '保边界 Σκ̂_i/P');
        plot(ax, Sk.p, Sk.sum_y_inner_over_P_final, 'd', 'Color', [0.85 0.33 0.10], ...
            'MarkerFaceColor', 'none', 'MarkerSize', 10, 'LineWidth', 1.6, ...
            'DisplayName', '保边界 Σ(-y_i)/P');
    end
    yline(ax, 1.0, '--', 'Color', [0.25 0.25 0.25], 'LineWidth', 1.4, ...
        'DisplayName', '门槛上限 1');
    set(ax, 'XScale', 'log');
    ylim(ax, [0, 1.15]);
    style_axes(ax, '对偶总和比（命题 C2）', '罚权 P', font_size);

    %% 分块 2: 末轮 Σκ̂_i、Σ(-y_i) 与 Σ‖s_main‖ 随 P
    ax = nexttile(layout, 2);
    tile_axes(2) = ax;
    hold(ax, 'on');
    plot(ax, p_vals, max(p_vals .* [Scan.sum_kappa_over_P_final], 1e-12), '-o', ...
        'Color', [0.00 0.45 0.74], 'MarkerFaceColor', [0.00 0.45 0.74], ...
        'LineWidth', 1.8, 'DisplayName', 'Σκ̂_i');
    plot(ax, p_vals, max(p_vals .* [Scan.sum_y_inner_over_P_final], 1e-12), '-d', ...
        'Color', [0.85 0.33 0.10], 'MarkerFaceColor', [0.85 0.33 0.10], ...
        'LineWidth', 1.8, 'DisplayName', 'Σ(-y_i)');
    plot(ax, p_vals, max([Scan.sum_s_main_norm_final], 1e-12), '-^', ...
        'Color', [0.47 0.67 0.19], 'MarkerFaceColor', [0.47 0.67 0.19], ...
        'LineWidth', 1.8, 'DisplayName', 'Σ‖s_{main}‖');
    set(ax, 'XScale', 'log', 'YScale', 'log');
    style_axes(ax, '末轮乘子与需求总和', '罚权 P', font_size);

    %% 分块 3: 第 10 轮转角中位数与理论帽半角上限 α_10 随 P
    ax = nexttile(layout, 3);
    tile_axes(3) = ax;
    hold(ax, 'on');
    plot(ax, p_vals, max([Scan.turn_median_r10], 1e-6), '-o', ...
        'Color', [0.49 0.18 0.56], 'MarkerFaceColor', [0.49 0.18 0.56], ...
        'LineWidth', 1.8, 'DisplayName', '第 10 轮转角中位');
    plot(ax, p_vals, max([Scan.turn_median_final], 1e-6), '-s', ...
        'Color', [0.00 0.60 0.50], 'MarkerFaceColor', [0.00 0.60 0.50], ...
        'LineWidth', 1.6, 'DisplayName', '末轮转角中位');
    plot(ax, p_vals, max([Scan.alpha_cap_r10], 1e-6), '--^', ...
        'Color', [0.25 0.25 0.25], 'MarkerFaceColor', [0.25 0.25 0.25], ...
        'LineWidth', 1.4, 'DisplayName', '理论上限 α_{10}');
    set(ax, 'XScale', 'log', 'YScale', 'log');
    style_axes(ax, '节点转角 (deg)', '罚权 P', font_size);

    finish_compare_window(layout, tile_axes, '命题 C2 对偶门槛与转角冻结随 P 变化', {}, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-对偶门槛随P.png'));
end


function plot_zero_init_figure(Summary, pictures_root)
% PLOT_ZERO_INIT_FIGURE 对比-零初值对照：对比圆内 0.3、零初值、无速率零初值与 P=100 零初值前 10 轮指标。

    font_size = 16;
    floor_val = 1e-12;
    fig = new_figure('对比-零初值对照');
    layout = create_tile_layout(fig, 4);
    tile_axes = gobjects(1, 4);

    init_names = {'twosided_init0p3_P1e-1', 'twosided_init0_P1e-1', ...
        'twosided_init0_nr_P1e-1', 'twosided_init0_P1e2'};
    colors = [0.00 0.45 0.74; 0.30 0.70 0.35; 0.85 0.33 0.10; 0.49 0.18 0.56];
    markers = {'o', 's', '^', 'd'};
    labels = {'0.3 初值, P=0.1', '零初值, P=0.1', '零初值无速率, P=0.1', '零初值, P=100'};
    rounds = 1:10;

    specs = {
        'impulse_series',      '总脉冲 (m/s)',      false;
        's_a2_series',         '凹侧共用松弛 s_{a2}', true;
        'D_min_u_norm_series', 'D 节点 min‖u‖',      false;
        'E_max_gap_series',    'E 节点 max|1-‖u‖|',  true};

    for t = 1:4
        ax = nexttile(layout, t);
        tile_axes(t) = ax;
        hold(ax, 'on');
        if strcmp(specs{t, 1}, 's_a2_series')
            yline(ax, 1.0, '--', 'Color', [0.35 0.35 0.35], 'LineWidth', 1.2, ...
                'HandleVisibility', 'off');
        end
        for k = 1:numel(init_names)
            idx = find(strcmp({Summary.name}, init_names{k}) ...
                & strcmp({Summary.state}, 'ok'), 1);
            if isempty(idx)
                continue;
            end
            vals = Summary(idx).(specs{t, 1})(rounds);
            if specs{t, 3}
                has_val = ~isnan(vals);
                vals(has_val) = max(vals(has_val), floor_val);
            end
            plot(ax, rounds, vals, '-', 'Color', colors(k, :), ...
                'Marker', markers{k}, 'MarkerFaceColor', colors(k, :), ...
                'MarkerSize', 7, 'LineWidth', 1.6, 'DisplayName', labels{k});
        end
        if specs{t, 3}
            set(ax, 'YScale', 'log');
        elseif strcmp(specs{t, 1}, 'D_min_u_norm_series')
            ylim(ax, [-0.05, 1.15]);
        end
        x_label = '';
        if t >= 3
            x_label = '迭代轮次';
        end
        style_axes(ax, specs{t, 2}, x_label, font_size);
    end
    finish_compare_window(layout, tile_axes, '圆内与零初值前 10 轮轨迹对照', {}, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-零初值对照.png'));
end


function plot_final_sigma_figure(Summary, Groups, pictures_root)
% PLOT_FINAL_SIGMA_FIGURE 对比-末轮σ：按 5 圈叠画 none、normgap_w1e-4、twosided_P1e-1 与 P=100。

    if ~Groups.available
        return;
    end
    font_size = 16;
    names = {'none', 'normgap_w1e-4', 'twosided_P1e-1', 'twosided_P1e2'};
    y_limits = [-190, 190];
    num_cir = max(Groups.cir);
    fig = new_figure('对比-末轮σ');
    layout = create_tile_layout(fig, num_cir);
    tile_axes = gobjects(1, num_cir);

    for cir = 1:num_cir
        ax = nexttile(layout, cir);
        tile_axes(cir) = ax;
        hold(ax, 'on');
        in_cir = Groups.cir == cir;
        ylim(ax, y_limits);
        if any(Groups.D & in_cir)
            intervals = build_group_intervals(Groups.tau(in_cir), Groups.D(in_cir));
            for k = 1:size(intervals, 1)
                patch(ax, ...
                    [intervals(k, 1); intervals(k, 2); intervals(k, 2); intervals(k, 1)], ...
                    [y_limits(1); y_limits(1); y_limits(2); y_limits(2)], ...
                    [0.85 0.85 0.85], 'EdgeColor', 'none', 'FaceAlpha', 0.5, ...
                    'DisplayName', 'D 节点');
            end
        end
        for k = 1:numel(names)
            idx = find(strcmp({Summary.name}, names{k}) & strcmp({Summary.state}, 'ok'), 1);
            if isempty(idx)
                continue;
            end
            Style = case_style(Summary(idx));
            plot(ax, Groups.tau(in_cir), Summary(idx).final_sigma(in_cir), ...
                Style.line, 'Color', Style.color, 'LineWidth', 1.6, ...
                'DisplayName', Style.label);
        end
        x_label = '';
        if cir >= 3
            x_label = '圈内 τ';
        end
        style_axes(ax, sprintf('σ (deg)，第 %d 圈', cir), x_label, font_size);
    end
    finish_compare_window(layout, tile_axes, '末轮倾侧角 σ 分圈叠画', {}, font_size);
    finish_figure(fig, fullfile(pictures_root, '对比-末轮σ.png'));
end


function finish_compare_window(layout, tile_axes, title_text, notes, font_size)
% FINISH_COMPARE_WINDOW 汇总各分块唯一图例项放到底部，并设置整窗总标题。

    unique_names = {};
    handles = gobjects(1, 0);
    for a = 1:numel(tile_axes)
        children = flipud(get(tile_axes(a), 'Children'));
        for m = 1:numel(children)
            if ~isprop(children(m), 'DisplayName')
                continue;
            end
            vis = get(children(m), 'HandleVisibility');
            if strcmp(vis, 'off')
                continue;
            end
            name = get(children(m), 'DisplayName');
            if isempty(name) || any(strcmp(unique_names, name))
                continue;
            end
            unique_names{end + 1} = name; %#ok<AGROW>
            handles(end + 1) = children(m); %#ok<AGROW>
        end
    end
    if ~isempty(handles)
        num_cols = min(numel(handles), 5);
        legend_handle = legend(tile_axes(end), handles, unique_names, ...
            'Orientation', 'horizontal', 'NumColumns', num_cols, ...
            'FontSize', font_size, 'Interpreter', 'none');
        legend_handle.Layout.Tile = 'south';
    end
    if isempty(notes)
        title(layout, title_text, 'FontSize', font_size);
    else
        title(layout, [{title_text}, notes], 'FontSize', font_size);
    end
end


%% ===== 绘图通用工具 =====

function draw_case_series(ax, Summary, field, members, skip_none, floor_value)
% DRAW_CASE_SERIES 按工况固定样式画出逐轮序列，带标记以便区分。

    if nargin < 6
        floor_value = [];
    end
    for c = find(members)
        S = Summary(c);
        values = S.(field);
        if all(isnan(values))
            continue;
        end
        if ~isempty(floor_value)
            has_value = ~isnan(values);
            values(has_value) = max(values(has_value), floor_value);
        end
        Style = case_style(S);
        marker_idx = 1:5:numel(values);
        if strcmp(Style.marker, 'none')
            marker_idx = [];
        end
        args = {'Color', Style.color, 'LineWidth', 1.6, ...
            'Marker', Style.marker, 'MarkerSize', 6, ...
            'MarkerFaceColor', marker_face(Style), ...
            'DisplayName', Style.label};
        if ~isempty(marker_idx)
            args = [args, {'MarkerIndices', marker_idx}]; %#ok<AGROW>
        end
        h = plot(ax, 1:numel(values), values, Style.line, args{:});
        if skip_none && strcmp(S.type, 'none')
            set(h, 'HandleVisibility', 'off');
        end
        if isfield(S, 'plateau_start') && ~isnan(S.plateau_start)
            xline(ax, S.plateau_start, ':', 'Color', Style.color, ...
                'HandleVisibility', 'off');
        end
    end
end


function members = group_members(Summary, group_name)
% GROUP_MEMBERS 返回指定绘图分组在 Summary 中的逻辑掩码。

    types = {Summary.type};
    p = [Summary.p];
    is_ok = strcmp({Summary.state}, 'ok');
    is_main_two = ~[Summary.is_baseline] & strcmp({Summary.init_mode}, 'default');
    switch group_name
        case 'regularized'
            members = is_ok & (strcmp(types, 'none') | strcmp(types, 'norm_gap'));
        case 'twosided_small'
            members = is_ok & (strcmp(types, 'none') | (is_main_two & p <= 0.1 + 1e-12));
        case 'twosided_large'
            members = is_ok & (strcmp(types, 'none') | (is_main_two & p >= 1 - 1e-12));
        otherwise
            error('TwosidedCompare:UnknownGroup', '未知绘图分组 %s。', group_name);
    end
end


function [group_name, label] = tile_group(g)
% TILE_GROUP 返回第 g 个分块组的名称和纵轴后缀说明。

    groups = {'regularized', 'twosided_small', 'twosided_large'};
    labels = {'regularized', 'twosided，P ≤ 0.1', 'twosided，P ≥ 1'};
    group_name = groups{g};
    label = labels{g};
end


function Style = case_style(S)
% CASE_STYLE 为每个工况分配固定颜色、标记与线型，保证跨图一致且支持 P=3e-2。

    if strcmp(S.type, 'none')
        Style = struct('color', [0.35 0.35 0.35], 'marker', 'none', ...
            'line', '--', 'filled', false, 'label', 'none');
        return;
    end
    if strcmp(S.type, 'norm_gap')
        markers = {'d', 'o', 's'};
        index = find(abs([1e-3, 1e-4, 1e-5] - S.w) < 1e-12, 1);
        Style = struct('color', [0.80 0.47 0.65], 'marker', markers{index}, ...
            'line', '-', 'filled', true, 'label', sprintf('w=%.0e', S.w));
        return;
    end
    p_levels = [1e-3, 1e-2, 3e-2, 1e-1, 1e0, 1e1, 1e2];
    p_labels = {'P=1e-3', 'P=1e-2', 'P=3e-2', 'P=1e-1', 'P=1', 'P=10', 'P=100'};
    colors = [
        0.13, 0.30, 0.55;
        0.13, 0.55, 0.63;
        0.00, 0.60, 0.50;
        0.30, 0.70, 0.35;
        0.90, 0.65, 0.10;
        0.95, 0.45, 0.10;
        0.75, 0.15, 0.15];
    markers = {'o', 's', 'p', '^', 'd', 'v', '>'};
    [~, index] = min(abs(log10(p_levels) - log10(S.p)));
    Style = struct('color', colors(index, :), 'marker', markers{index}, ...
        'line', '-', 'filled', true, 'label', p_labels{index});
    if S.keep
        Style.line = ':';
        Style.filled = false;
        Style.label = [Style.label '（保边界）'];
    end
end


function face = marker_face(Style)
% MARKER_FACE 返回标记填充颜色（实心用曲线颜色，空心为 none）。

    if Style.filled
        face = Style.color;
    else
        face = 'none';
    end
end


function limits = padded_limits(values)
% PADDED_LIMITS 计算有限数值上下留 5% 边距的范围。

    if iscell(values)
        values = vertcat(values{:});
    end
    values = values(isfinite(values));
    if isempty(values)
        limits = [0, 1];
        return;
    end
    span = max(values) - min(values);
    if span == 0
        span = max(1, abs(values(1)));
    end
    limits = [min(values) - 0.05 * span, max(values) + 0.05 * span];
end


function intervals = build_group_intervals(tau, mask)
% BUILD_GROUP_INTERVALS 将圈内连续掩码节点合并为 τ 底纹区间 [起点, 终点]。

    intervals = zeros(0, 2);
    if isempty(tau) || ~any(mask)
        return;
    end
    tau = tau(:);
    mask = logical(mask(:));
    midpoint = (tau(1:end - 1) + tau(2:end)) / 2;
    lower_edge = [tau(1) - (midpoint(1) - tau(1)); midpoint(:)];
    upper_edge = [midpoint(:); tau(end) + (tau(end) - midpoint(end))];
    change = diff([false; mask; false]);
    start_index = find(change == 1);
    stop_index = find(change == -1) - 1;
    intervals = [lower_edge(start_index), upper_edge(stop_index)];
end


function fig = new_figure(name)
% NEW_FIGURE 创建不显示且使用默认窗口尺寸的图窗。

    fig = figure('Name', name, 'NumberTitle', 'off', 'Visible', 'off');
end


function style_axes(ax, y_label, x_label, font_size)
% STYLE_AXES 统一坐标轴字号、网格与标签。

    set(ax, 'FontSize', font_size, 'Box', 'on');
    grid(ax, 'on');
    ylabel(ax, y_label, 'FontSize', font_size);
    if ~isempty(x_label)
        xlabel(ax, x_label, 'FontSize', font_size);
    end
end


function finish_figure(fig, png_path)
% FINISH_FIGURE 导出高分辨率 PNG 后关闭图窗。

    save_plot_figure(fig, png_path);
    close(fig);
end
