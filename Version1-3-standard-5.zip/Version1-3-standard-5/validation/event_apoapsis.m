function [position, isterminal, direction] = event_apoapsis(~, y)
% EVENT_APOAPSIS ode45 事件：ECI 状态到达瞬时远地点（r·v 穿越零）。

    position = y(1:3).' * y(4:6);
    isterminal = 1;
    direction = 0;
end
