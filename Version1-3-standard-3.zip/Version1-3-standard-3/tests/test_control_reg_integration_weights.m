function tests = test_control_reg_integration_weights
% TEST_CONTROL_REG_INTEGRATION_WEIGHTS 核验控制正则项是否使用逐节点积分权。

    tests = functiontests(localfunctions);
end


function test_default_preserves_weighted_objective_and_offset(testCase)
% 默认分支若丢掉梯形权或改变常数偏置，下列手算系数会失败。

    [VariableIndex, Reference] = make_objective_fixture();
    config = scp_config_default();
    config.objective.control_reg_type = 'norm_gap';
    config.objective.weight_control_reg = 0.2;

    [objective, objective_offset] = build_objective( ...
        VariableIndex, Reference, [], config);

    verifyTrue(testCase, config.objective.control_reg_use_integration_weights);
    verifyEqual(testCase, objective(VariableIndex.u1), ...
        -0.2 * [0.25; 0.5; 0.25], 'AbsTol', 1e-14);
    verifyEqual(testCase, objective(VariableIndex.u2), ...
        zeros(3, 1), 'AbsTol', 1e-14);
    verifyEqual(testCase, objective_offset, 0.2, 'AbsTol', 1e-14);
end


function test_disabled_switch_removes_weights_from_all_regularizers(testCase)
% 关闭后若任何正则方式仍乘梯形权，其目标系数会不等于手算的 w。

    [VariableIndex, Reference] = make_objective_fixture();
    config = scp_config_default();
    config.objective.control_reg_use_integration_weights = false;
    config.objective.weight_control_reg = 0.2;
    types = {'sum', 'u1', 'u2', 'norm', 'norm_gap'};
    for k = 1:numel(types)
        config.objective.control_reg_type = types{k};
        [objective, objective_offset] = build_objective( ...
            VariableIndex, Reference, [], config);
        switch types{k}
            case 'sum'
                expected_u1 = 0.2 * ones(3, 1);
                expected_u2 = 0.2 * ones(3, 1);
                expected_offset = 0;
            case 'u1'
                expected_u1 = 0.2 * ones(3, 1);
                expected_u2 = zeros(3, 1);
                expected_offset = 0;
            case 'u2'
                expected_u1 = zeros(3, 1);
                expected_u2 = 0.2 * ones(3, 1);
                expected_offset = 0;
            case {'norm', 'norm_gap'}
                expected_u1 = -0.2 * ones(3, 1);
                expected_u2 = zeros(3, 1);
                expected_offset = 0;
        end
        if strcmp(types{k}, 'norm_gap')
            expected_offset = 0.6;
        end
        verifyEqual(testCase, objective(VariableIndex.u1), expected_u1, ...
            'AbsTol', 1e-14);
        verifyEqual(testCase, objective(VariableIndex.u2), expected_u2, ...
            'AbsTol', 1e-14);
        verifyEqual(testCase, objective_offset, expected_offset, 'AbsTol', 1e-14);
    end
end


function test_penalty_function_uses_same_node_weights_as_objective(testCase)
% 罚函数若未同步去权，线性正则值和参考处 L(0)=J 的对应会被破坏。

    Point.tau = [0; 0.5; 1];
    Point.PointsBounds = struct('begin', 1, 'end', 3);
    Point.control.u1 = [0.6; 0.8; 0.6];
    Point.control.u2 = zeros(3, 1);
    P2Feasibility.terminal_report.metrics = struct( ...
        'normalized_violation', {0, 0});
    P2Feasibility.performance_report.normalized_value = 0;
    P2Feasibility.performance_report.components = zeros(6, 1);
    P2Feasibility.junction_report.sum_abs = 0;
    P2Feasibility.dynamics_report.sum_abs = 0;
    ConstData.VU = 1;
    config = scp_config_default();
    config.objective.control_reg_type = 'norm_gap';
    config.objective.weight_control_reg = 0.2;
    config.objective.weight_inclination = 0;
    config.objective.weight_apoapsis = 0;
    config.objective.weight_impulse = 0;
    config.objective.weight_point_slack = 0;
    config.objective.weight_dyn_slack = 0;

    Weighted = evaluate_penalty_function(Point, P2Feasibility, ConstData, config);
    config.objective.control_reg_use_integration_weights = false;
    Unweighted = evaluate_penalty_function(Point, P2Feasibility, ConstData, config);
    weighted_term = Weighted.terms(strcmp({Weighted.terms.name}, 'control_reg'));
    unweighted_term = Unweighted.terms(strcmp({Unweighted.terms.name}, 'control_reg'));
    verifyEqual(testCase, weighted_term.value, 0.06, 'AbsTol', 1e-14);
    verifyEqual(testCase, unweighted_term.value, 0.2, 'AbsTol', 1e-14);

    config.objective.control_reg_type = 'sum';
    UnweightedLinear = evaluate_penalty_function( ...
        Point, P2Feasibility, ConstData, config);
    config.objective.control_reg_use_integration_weights = true;
    WeightedLinear = evaluate_penalty_function( ...
        Point, P2Feasibility, ConstData, config);
    weighted_linear_term = WeightedLinear.terms( ...
        strcmp({WeightedLinear.terms.name}, 'control_reg'));
    unweighted_linear_term = UnweightedLinear.terms( ...
        strcmp({UnweightedLinear.terms.name}, 'control_reg'));
    verifyEqual(testCase, weighted_linear_term.value, 0.14, 'AbsTol', 1e-14);
    verifyEqual(testCase, unweighted_linear_term.value, 0.4, 'AbsTol', 1e-14);
end


function [VariableIndex, Reference] = make_objective_fixture()
% MAKE_OBJECTIVE_FIXTURE 三个控制节点及手算梯形权 [0.25, 0.5, 0.25]。

    VariableIndex.t_if = 1;
    VariableIndex.t_raf = 2;
    VariableIndex.t_P = 3:8;
    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    next_index = 9;
    for k = 1:numel(state_names)
        VariableIndex.(['t_poi_slack_' state_names{k}]) = ...
            next_index:(next_index + 4);
        next_index = next_index + 5;
    end
    for k = 1:numel(state_names)
        VariableIndex.(['t_dyn_slack_' state_names{k}]) = ...
            next_index:(next_index + 1);
        next_index = next_index + 2;
    end
    VariableIndex.u1 = next_index:(next_index + 2);
    VariableIndex.u2 = (next_index + 3):(next_index + 5);
    Reference.N = 3;
    Reference.tau = [0; 0.5; 1];
    Reference.PointsBounds = struct('begin', 1, 'end', 3);
    Reference.control.u1 = ones(3, 1);
    Reference.control.u2 = zeros(3, 1);
end
