%% SCP.m — 气动辅助降轨多圈大气跳跃 SCP 求解入口
%
% 5 次大气跳跃 + 6 次切向脉冲，从双曲线接近轨道降到 6678 km、
% 倾角 86 度圆轨道。大气段 ECF 球坐标状态，控制为倾侧角分解
% u=(cos(sigma), sin(sigma))，单位范数约束 ‖u‖=1 在 P3 中按 config.unit_norm.mode
% 处理：regularized（无损凸化，默认）或 ccd_lu（Lu 2020 原文凹凸分解）；真空段映射 ode45 + 中心差分线性化；
% 凸子问题 P3 为线性 + 二阶锥规划，MOSEK 求解。逐轮分列 P3 解检查、
% P2 可行性检查及被接受解的梯形递推检查；罚函数 J 与 P2 可行性检查共用求值。
% 逐轮输出迭代分析（预测下降、预测误差、真实下降的组成，ρ、门槛、半径、K 估计、驻点度量的上界）
% 和 P3 乘子（只报告，不参与决策）；运行结束按 config.output.save 的开关保存简略文件、
% 详细文件、半径扫描用的 MAT（半径扫描见同目录的 SCP_radius_scan.m）和控制量 u 的导出文件。
%
% 主流程：
%   [环境准备] → [配置覆盖] → [初始化和初始参考]
%     → [SCP 主迭代循环] → [整理最终结果并输出]
%
% 算法定义见 docs/algorithm_knowledge_base/气动辅助降轨算法知识库.md。

%% ── 环境准备 ──
% 入口拥有工作区清理与路径管理；restore_scp_path 在清空工作区或入口重跑时恢复路径
clc; clear; close all;
tic;
version_root = fileparts(mfilename('fullpath'));
previous_path = path;
restore_scp_path = onCleanup(@() path(previous_path));
modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
    'trust_region', 'validation', 'iteration', 'output', 'tests'};
for k = 1:numel(modules)
    addpath(fullfile(version_root, modules{k}));
end
rehash;   % 重新扫描路径，让新增或替换的 .m 文件立即可见

%% ── 配置覆盖 ──
% 先加载默认配置，再覆盖项目特定参数
config = scp_config_default();

    % ===== 迭代控制 =====
    config.iter.max_scp_iter = 10;   % 被拒绝的尝试也计数

    config.objective.control_reg_type = 'norm';   % norm sum
    config.objective.weight_control_reg = 1e-4;
    config.unit_norm.mode = 'regularized';   % regularized（无损凸化，默认） ccd_lu（Lu 2020 原文凹凸分解）

%% ── 初始化 ──
% ConstData:    归一化物理常数、尺度、目标轨道与固定初始 ECI 状态 rv00
% InitialState: 初始状态诊断（标称入口点、24h 反向积分结果与轨道根数）
[ConstData, InitialState] = initialize_problem(config);

%% ── 初始参考轨迹 ──
% 逐圈近地点速度梯度 + 二分打靶生成 M 圈参考；网格为 ODE 原生节点拼接
[InitialReference, InitialPropagation] = ...
    generate_initial_reference(ConstData, InitialState, config);

%% ── 准备迭代数据结构 ──
% 初始参考不是第零轮接受解；空接受解、初始信赖域状态与诊断历史在此初始化
[RunState, DiagnosticsHistory] = initialize_scp_run( ...
    InitialReference, InitialPropagation, config);
if config.output.print_pre_iteration
    print_initial_summary(ConstData, InitialReference, InitialPropagation);
end
if config.plot.enable_initial
    plot_initial_reference(ConstData, InitialPropagation, config);
end

%% ══════════════════════════════════════════════════════
%%  SCP 主迭代循环
%% ══════════════════════════════════════════════════════
for iter = 1:config.iter.max_scp_iter
    if RunState.stop
        break;
    end

    % 1 构建、求解本轮凸子问题 P3^k，并做步长检查、P3 解检查与 P2 可行性检查
    [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
        RunState.current_reference, RunState.trust_region, ...
        ConstData, config, iter);

    % 2 按 ρ = 真实下降/预测下降 决定候选解是否接受、下一轮信赖域多大
    TrustResult = update_trust_region( ...
        CurrentSolution, SubproblemDiag, RunState.current_reference, ...
        RunState.trust_region, ConstData, config, iter);

    % 3 更新下一轮参考和信赖域，判断是否停止，并记录本轮
    [RunState, IterationRecord] = advance_scp_iteration( ...
        RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
        ConstData, config, iter);

    % 4 只读后处理：对被接受解做隐式梯形递推、逐轮打印与绘图
    DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
        RunState, IterationRecord, ConstData, config);

    % 5 停止检查
    if RunState.stop
        break;
    end
end

%% ══════════════════════════════════════════════════════
%%  整理最终结果并输出
%% ══════════════════════════════════════════════════════
% FinalizedRun 固定最后接受的解；绘图、公开 Result 和保存都只读它
FinalizedRun = finalize_scp_run(RunState, DiagnosticsHistory);
PlotReport = plot_scp_result(FinalizedRun, ConstData, config);
Result = build_scp_result(FinalizedRun);
if config.output.print_summary
    print_scp_summary(FinalizedRun, ConstData);
end
% 按 config.output.save 的开关保存: 简略文件、详细文件、扫描用 MAT、全量 MAT、控制量文件、控制量 MAT
SaveReport = save_scp_result(FinalizedRun, ConstData, config);

%% ── 运行报告 ──
print_save_report(SaveReport);
if ~PlotReport.success
    fprintf('警告: 最终图部分绘制失败: %s\n', ...
        strjoin(PlotReport.failed_groups, ', '));
end
fprintf('\n代码运行时间: %.2f 秒\n', toc);
