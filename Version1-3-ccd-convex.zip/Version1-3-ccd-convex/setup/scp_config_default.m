function config = scp_config_default()
% SCP_CONFIG_DEFAULT 返回气动辅助降轨 SCP 求解的默认超参数。

    %% ===== 场景参数 =====
    config.scenario.total_cir = 5;    % 大气穿越圈数 M

    %% ===== 罚权、性能指标与附加项的系数 =====
    % P3 的目标 L = w_i*|i_f-i_aim| + w_ra*|ra_f-ra_aim| + w_P*Σ|P_k|
    %         + w_poi*Σt_poi + w_dyn*Σt_dyn + L_reg，L_reg 为附加项 Γ 在 P3 中的形式，按
    %         control_reg_type 取（u_i = (u1_i, u2_i)）:
    %   'norm'     Γ = −w_reg*Σω_i*‖u_i‖，P3 中取参考控制处的线性化 −w_reg*Σω_i*ē_i^T*u_i（ē_i = ū_i/‖ū_i‖）
    %   'norm_gap' Γ = w_reg*Σω_i*(1 − ‖u_i‖)，P3 中线性化为 w_reg*Σω_i*(1 − ē_i^T*u_i)（含 cfix 偏置）
    %   'sum'  Γ = w_reg*Σω_i*(u1_i + u2_i)
    %   'u1'   Γ = w_reg*Σω_i*u1_i
    %   'u2'   Γ = w_reg*Σω_i*u2_i
    %   'none' Γ = 0（忽略 w_reg）
    % 以上各式为 control_reg_use_integration_weights = true 的默认形式，ω_i 为按圈梯形权；
    % 开关为 false 时各式去掉 Σ 中的 ω_i，仅保留总系数 w_reg。
    config.objective.weight_inclination = 1.5;    % 终端倾角罚权 w_i
    config.objective.weight_apoapsis = 1.5;       % 终端远地点罚权 w_ra
    config.objective.weight_impulse = 0.1;        % 性能指标（总脉冲）的系数 w_P

    config.objective.weight_point_slack = 240;    % 衔接罚权 w_poi
    config.objective.weight_dyn_slack = 240;      % 动力学罚权 w_dyn
    config.objective.weight_control_reg = 1e-5;   % 附加项（控制正则）的系数 w_reg
    config.objective.control_reg_type = 'norm';   % 控制正则方式：'sum'、'u1'、'u2'、'norm'、'none'
    config.objective.control_reg_use_integration_weights = true;  % 控制正则是否使用逐节点积分权 ω_i

    %% ===== 单位范数约束的处理方式 =====
    config.unit_norm.mode = 'regularized';                  % 'regularized'（默认）或 'ccd_lu'
    config.unit_norm.ccd_penalty_weight = 1e-2;             % p：ε_i 的罚权（不乘 ω_i，原文 Eq. (40)/(74)），只在 'ccd_lu' 下使用
    config.unit_norm.ccd_slack_max = 1;                     % ε 上界（安全上界；触到时报告 WARN）
    config.unit_norm.ccd_keep_control_bounds = false;       % false 时 u1、u2 边界放宽到 ±(1 + ε 上界)
    config.unit_norm.ccd_normalize_initial_control = true;  % true 时对非零初始参考控制做 u_i ← u_i/‖u_i‖_2；零向量保持 0

    %% ===== 迭代控制 =====
    config.iter.max_scp_iter = 5;                 % 最大 SCP 迭代次数
    config.iter.tolerance = 1e-2;                 % 相邻迭代解最大差收敛阈值（步长，本项目的停止依据）
    config.iter.stationarity_tolerance = 1e-4;    % 驻点度量的上界的阈值 ε（L 的口径，只报告，不进停止）
    config.iter.subproblem_failure_policy = 'stop';  % P3 求解失败即停止

    %% ===== 信赖域参数 =====
    % 'ratio' 按 ρ = 真实下降/预测下降 接受或拒绝候选解并缩放半径；
    % 'fixed' 半径固定、P3 成功即接受（仍计算并打印 ρ，只看不用）
    config.trust_region.method = 'fixed';

    % 基准半径（归一化单位，P 除外）；实际半径 = 倍数 r × 基准半径（代码里叫 scale）
    % 只加在被线性化的量上：控制 u 仿射进入动力学，不加；P5 虽只进入
    % 线性入轨等式，但无界时求解器数值停滞（首轮即失败），一并加
    config.trust_region.r = 0.25;                 % 径向距离 (LU)
    config.trust_region.V = 0.1;                  % 速度 (VU)
    config.trust_region.gamma = deg2rad(5);       % 航迹角 (rad)
    config.trust_region.phi = deg2rad(7);         % 纬度 (rad)
    config.trust_region.psi = deg2rad(7);         % 航向角 (rad)
    config.trust_region.P = 20;                   % 脉冲 P0~P5 (m/s，装配时除以 VU)

    % 半径 r（基准半径的倍数）及其更新规则（method = 'ratio' 时使用）
    config.trust_region.initial_scale = 1;        % 初始半径 r0
    config.trust_region.min_scale = 1 / 16;       % r 下限；拒绝且已在下限时停止
    config.trust_region.max_scale = 4;            % r 上限 r_max
    config.trust_region.scale_factor = 2;         % 缩小时 r/α，扩大时 α·r
    config.trust_region.accept_ratio = 0;         % ρ0：ρ < ρ0 拒绝候选解
    config.trust_region.shrink_ratio = 0.25;      % ρ1：ρ < ρ1 缩小半径
    config.trust_region.expand_ratio = 0.75;      % ρ2：ρ ≥ ρ2 扩大半径
    config.trust_region.min_predicted_reduction = 1e-6;  % ΔL 不超过此值时不算 ρ（P3 目标 L 口径）
    config.trust_region.boundary_tolerance = 0.99; % 步长达到半径的此比例记为贴边界（只报告）
    config.trust_region.slack_zero_ratio = 1e-6;       % 松弛罚项 ≤ 参考处罚项的此倍数时记为“松弛为零”（只报告）
    config.trust_region.active_dual_tolerance = 1e-9;  % 信赖域乘子大于此值才算该界生效（只报告）

    config.trust_region.consecutive_u = 0.1;      % 相邻节点 u1 差值上限

    %% ===== 约束开关 =====
    config.constraints.enable_control_continuity = true;  % 相邻节点 u1 速率约束；仅诊断时关闭

    %% ===== 变量边界 =====
    config.bounds.min_r = 35;                     % 最小地心距 (LU)
    config.bounds.min_gamma = -1;                 % 航迹角下界 (rad)
    config.bounds.max_gamma = 1;                  % 航迹角上界 (rad)
    config.bounds.min_psi = -1;                   % 航向角下界 (rad)
    config.bounds.max_psi = 1;                    % 航向角上界 (rad)
    config.bounds.min_u1 = -1;                    % 控制分量下界
    config.bounds.max_u1 = 1;
    config.bounds.min_u2 = -1;
    config.bounds.max_u2 = 1;
    config.bounds.tolerance_r_atm = 1e-4;         % 大气入口/出口半径钉扎容差 (LU)

    %% ===== 求解器 =====
    config.solver.name = 'mosek';
    config.solver.log_level = 10;                 % MOSEK 日志级别；0 时日志为空，数据警告无从得知
    config.solver.echo_log = false;               % 是否把截下的 MOSEK 日志打印到终端
    config.solver.accept_near_optimal = true;     % 接受 NEAR_OPTIMAL 状态
    config.solver.tol_dfeas = 1e-14;              % 对偶可行性
    config.solver.tol_infeas = 1e-14;             % 不可行性
    config.solver.tol_pfeas = 1e-14;              % 原问题可行性
    config.solver.tol_rel_gap = 1e-14;            % 相对对偶间隙
    % 锥容差 1e-8（相对间隙 1e-10）。锥容差 1e-12 时，控制正则
    % −w_reg·Σω‖u‖ 在 w_reg = 1e-2、1e-4、1e-5、1e-6、0 下首轮 P3 内点法数值停滞
    % （TRM_STALL→UNKNOWN，2026-11-15），只有 1e-3 能解；w_reg = 1e-3 时两种容差的
    % 总脉冲相差 2e-5 m/s
    config.solver.co_tol_rel_gap = 1e-10;         % 锥相对间隙
    config.solver.co_tol_pfeas = 1e-8;
    config.solver.co_tol_dfeas = 1e-8;
    config.solver.co_tol_infeas = 1e-14;

    % 数值健康检查阈值（只报告，不作接受门槛；装配坐标/归一化单位）
    config.solver.numerics.max_abs_coefficient = 1e6;        % 系数绝对值上限（MOSEK 自身在 1e10 报警）
    config.solver.numerics.max_row_span = 1e8;               % 行内最大/最小非零系数之比上限
    config.solver.numerics.tiny_relative_coefficient = 1e-10; % 低于所在行最大系数此倍数计为小系数
    config.solver.numerics.max_abs_bound = 1e6;              % 有限上下界绝对值上限
    config.solver.numerics.max_constraint_residual = 1e-7;   % 原始矩阵行/变量边界残差上限
    config.solver.numerics.max_solution_norm = 1e4;          % 原始解、对偶解 ‖·‖∞ 上限
    config.solver.numerics.residual_reference = 1e-9;        % 数值健康图横参考线：求解器精度量级（只画图）

    %% ===== 验证阈值 =====
    config.validation.max_dyn_slack = 1e-3;       % 动力学松弛阈值
    config.validation.max_point_slack = 1e-3;     % 端点松弛阈值
    config.validation.conic_feasibility_tolerance = 1e-6;  % 锥可行性残差上限
    config.validation.conic_tightness_tolerance = 1e-6;    % 上图紧性差值上限
    config.validation.lossless_tightness_tolerance = 1e-3; % 无损凸化紧性差值 |1-‖u‖| 上限（control_disk）
    config.validation.chord_active_tolerance = 1e-8;   % 速率约束距边界的活动判据（只报告）
    config.validation.chord_flatness_tolerance = 0.05; % 弦向正则分量/正则范数 ≤ 此值记为弦向平坦
    % P2 可行性检查：各通道用最大物理违反量判定，阈值与 Version1-4-1 相同
    config.validation.dynamics_tolerance = struct( ...
        'r', 0.1829, 'V', 0.1829, 'gamma', 0.0572957795130823, ...
        'phi', 0.0572957795130823, 'psi', 0.0572957795130823);
    config.validation.junction_tolerance = config.validation.dynamics_tolerance;
    config.validation.terminal_tolerance = struct( ...
        'apoapsis', 10, ...                                % 终端远地点违反量阈值 (km)
        'inclination', 0.1);                               % 终端倾角违反量阈值 (deg)
    config.validation.path_constraint_tolerance = 1e-3;    % 节点处路径约束相对容差：峰值/上限 ≤ 1+tol
    config.validation.enable_trapezoid_check = true;       % 被接受解的梯形递推（只诊断）
    config.validation.trapezoid_step_tolerance = 1e-10;    % 单区间隐式残差（求解坐标）
    config.validation.trapezoid_max_newton_iter = 20;      % 单区间牛顿迭代上限

    %% ===== 绘图 =====
    % 画哪些图
    config.plot.enable_initial = false;           % 迭代前：初始参考轨迹图
    config.plot.enable_iteration = true;          % 迭代中：逐轮图（4 扇窗：状态量、控制量、违反量与松弛、路径约束量；横轴时间）
    config.plot.enable_final = false;              % 结束后：全程图（10 扇窗：状态量、控制量叠加；P3 性能指标、附加项与目标、P3 关键约束与松弛、罚函数 J、预测下降与预测误差（总量、分三部分）、半径与步长、余项与驻点度量、半径平面）
    config.plot.overlay_max_rounds = 6;           % 全程状态量、控制量叠画最多画几轮（第一轮、最后接受解，中间均匀取）；Inf 每轮都画
    % 逐轮图的可选窗（enable_iteration = true 时才画）
    config.plot.enable_numerics_iteration = true;       % 数值健康（行内跨度 - 相对残差）
    config.plot.enable_trust_region_iteration = false;  % 步长与信赖域（逐节点 |候选解-参考|/半径）
    config.plot.enable_multiplier_iteration = false;    % 乘子（逐区间 |λ|/w）
    config.plot.iteration_figure_mode = 'reuse';  % 'reuse' 每轮清空同一组窗口重画；'accumulate' 每轮新开一组
    % 所有图通用
    config.plot.visibility = 'on';                % 图窗可见性，'off' 时只建窗不显示
    config.plot.save_figures = false;              % 导出 PNG：初始图与全程图按窗口名存 pictures/；逐轮图存 pictures/iterations/iterNN/
    config.plot.font_size = 16;                   % 全部绘图文字统一字号

    %% ===== 终端输出 =====
    % 打印哪几段
    config.output.print_pre_iteration = true;     % 迭代前：初始参考摘要
    config.output.print_iteration = true;         % 迭代中：逐轮日志
    config.output.print_summary = true;           % 结束后：运行摘要和各轮概况表
    % 逐轮日志每块默认只打结论（FAIL/WARN 行照常展开）；下面设为 true 的块打出全部
    % 明细和定位信息。这组开关只管终端，不影响保存的文件
    config.output.detail.numerics = false;        % 数值检查：残差表、MOSEK 原文、系数块、最差行
    config.output.detail.p3_checks = false;       % P3 解检查：松弛、锥重构与无损紧性
    config.output.detail.analysis = false;        % 迭代分析：分项表、子项表、各通道步长/半径、余项按阶逐通道表
    config.output.detail.multipliers = false;     % P3 乘子：各约束类 max|λ| 表、信赖域各通道生效数表
    config.output.detail.p2_feasibility = false;  % P2 可行性检查：动力学违反量与衔接违反量
    config.output.detail.physics = false;         % 物理量：逐次脉冲、每圈飞行时间/最低高度/峰值
    config.output.detail.convergence = true;      % 收敛：步长（相邻解差）的各状态通道、脉冲的物理差和所在位置
    config.output.detail.all = false;             % true 时以上七块全部展开

    %% ===== 保存文件 =====
    % 一个开关对应一个文件，每次运行覆盖；六个都关就什么都不存
    config.output.save.brief_text = true;         % <前缀>_brief.txt：简略，运行结论和各轮概况表
    config.output.save.detail_text = true;        % <前缀>_detail.txt：详细，运行结论加每一轮分析要用的全部量（各块固定全部展开）
    config.output.save.scan_mat = true;           % <前缀>_scan.mat：每轮的参考点和半径，SCP_radius_scan.m 读它
    config.output.save.full_mat = false;          % <前缀>_full.mat：全部运行数据 Result 和 FinalizedRun（几十 MB）
    config.output.save.control_text = true;       % <前缀>_control.txt：控制量 u 的结果导出（逐次尝试汇总、最后接受轮的逐圈汇总和逐节点表）
    config.output.save.control_mat = false;        % <前缀>_control.mat：控制量 u 的小 MAT，顶层 ControlExport（每次尝试的控制量报告）
    config.output.save.directory = 'results';     % 保存目录（相对版本根）
    config.output.save.filename_prefix = 'scp_run';  % 文件名前缀

end
