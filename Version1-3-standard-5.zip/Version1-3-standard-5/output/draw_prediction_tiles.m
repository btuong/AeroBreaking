function draw_prediction_tiles(fig, HistorySeries, config)
% DRAW_PREDICTION_TILES 画预测下降与预测误差的总量: ΔL 与 ΔJ，ΔL、门槛与 D，下降比 ρ。
%
% 输入:
%   fig            - 目标图窗
%   HistorySeries  - plot_scp_result 整理好的迭代序列，各轮 plot_data 含 trust_region
%   config         - 读取 config.plot.font_size 与 config.trust_region 阈值
%
% 三个分块（横轴为迭代序号，对数纵轴的分块负值按绝对值画并用向下三角标出）:
%   1. ΔL 与 ΔJ: 预测下降和真实下降（ΔJ = ΔL − D，为负时画 ▼）。
%   2. ΔL、门槛、D: ΔL（实线）、门槛 (1−ρ1)ΔL（虚线，用 ΔL 的颜色）、D（实线），
%      D 在门槛以下就接受。
%   3. 下降比 ρ: ρ（实线），ρ0、ρ1、ρ2（虚线）；纵轴限在 [−1, 1.5]，超出的点画在边上
%      用三角标出；ρ 没算出的轮留空。
% 性能指标、附加项、罚项三部分和罚项在另一扇窗（draw_prediction_part_tiles）。
% 标记约定与其他全程图一致: 接受实心、拒绝空心、P3 失败红叉，含义写在标题下面一行；
% ΔL、D、ΔJ 颜色和标记形状各不相同（build_analysis_palette），整扇窗只在底部放一个
% 共用图例（finish_tile_window）；不在图上加文字标注。

    iters = HistorySeries.iter;
    status = HistorySeries.status;
    TrustData = collect_trust_series(HistorySeries);
    pick = @(field) [TrustData.(field)];
    Palette = build_analysis_palette();
    series = @(name, field, key) build_log_series(name, pick(field), ...
        Palette.(key), false, Palette.marker.(key), Palette.width.normal);

    layout = create_tile_layout(fig, 3);
    tile_axes = gobjects(1, 3);
    for j = 1:3
        tile_axes(j) = nexttile(layout);
    end
    notes = {describe_status_marks(status)};

    notes = [notes, draw_log_history_tile(tile_axes(1), iters, status, ...
        [series('ΔL', 'predicted_reduction', 'predicted_reduction'), ...
        series('ΔJ', 'actual_reduction', 'actual_reduction')], ...
        'ΔL 与 ΔJ', config)];
    notes = [notes, draw_log_history_tile(tile_axes(2), iters, status, ...
        [series('ΔL', 'predicted_reduction', 'predicted_reduction'), ...
        build_log_series('门槛', pick('threshold'), ...
            Palette.predicted_reduction, true, 'none', Palette.width.bound), ...
        series('D', 'prediction_error', 'prediction_error')], ...
        'ΔL、门槛 (1-ρ1)ΔL、D', config)];
    notes = [notes, draw_ratio_tile(tile_axes(3), iters, status, TrustData, ...
        Palette.single, config)];

    finish_tile_window(layout, tile_axes, '预测下降与预测误差', notes, config);
end


function notes = draw_ratio_tile(ax, iters, status, TrustData, color, config)
% DRAW_RATIO_TILE 画 ρ: 实线 ρ，虚线 ρ0、ρ1、ρ2；纵轴限在 [-1, 1.5]，超出的点画在边上。
%
% 返回要写在窗口标题下面的说明行（三角的含义、ρ 没算出的轮次和原因）。

    notes = {};
    hold(ax, 'on');
    lower_limit = -1;
    upper_limit = 1.5;

    ratio = nan(size(iters));
    available = [TrustData.ratio_available];
    ratio(available) = [TrustData(available).ratio];
    % 超出范围的值夹到边上；不能用 max/min 夹取，它们会把 NaN（没算出的轮）当缺失值丢掉
    clipped = ratio;
    clipped(ratio > upper_limit) = upper_limit;
    clipped(ratio < lower_limit) = lower_limit;
    plot(ax, iters, clipped, '-', 'Color', color, 'LineWidth', 1.5, ...
        'DisplayName', 'ρ', 'Tag', 'series');
    in_range = ratio >= lower_limit & ratio <= upper_limit;
    marked = ratio;
    marked(~in_range) = NaN;
    mark_history_status(ax, iters, status, marked, color);

    % 超出范围的点画在上、下边沿，三角朝外
    above = ratio > upper_limit;
    below = ratio < lower_limit;
    plot(ax, iters(above), repmat(upper_limit, 1, nnz(above)), '^', ...
        'Color', color, 'MarkerFaceColor', color, 'MarkerSize', 8, ...
        'HandleVisibility', 'off');
    plot(ax, iters(below), repmat(lower_limit, 1, nnz(below)), 'v', ...
        'Color', color, 'MarkerFaceColor', color, 'MarkerSize', 8, ...
        'HandleVisibility', 'off');
    if any(above) || any(below)
        notes{end + 1} = '▲▼ ρ 超出纵轴范围（画在边上）';
    end

    draw_ratio_thresholds(ax, config);
    ylim(ax, [lower_limit - 0.05, upper_limit + 0.05]);

    % 评价过但 ρ 没算出的轮（如 ΔL 过小）留空，在标题下面列出轮次和原因
    unavailable = [TrustData.ratio_unavailable];
    if any(unavailable)
        notes{end + 1} = ['ρ 未算：' compose_unavailable_text(iters(unavailable), ...
            {TrustData(unavailable).unavailable_reason})];
    end
    mark_failed_rounds(ax, iters, status);
    finish_history_axes(ax, iters, '下降比 ρ', config);
end


function text_out = compose_unavailable_text(unavailable_iters, reasons)
% COMPOSE_UNAVAILABLE_TEXT 汇总 ρ 没算出的轮次和原因，写在标题下面。

    unique_reasons = unique(reasons, 'stable');
    parts = cell(1, numel(unique_reasons));
    for j = 1:numel(unique_reasons)
        selected = unavailable_iters(strcmp(reasons, unique_reasons{j}));
        parts{j} = sprintf('第 %s 轮(%s)', ...
            strjoin(string(selected), ','), describe_unavailable( ...
            unique_reasons{j}));
    end
    text_out = strjoin(parts, '、');
end


function label = describe_unavailable(reason)
% DESCRIBE_UNAVAILABLE 把评价原因翻译成短语。

    switch reason
        case 'small_predicted_reduction'
            label = 'ΔL 过小';
        case 'nonfinite_penalty_function'
            label = '罚函数非有限';
        case 'subproblem_failed'
            label = 'P3 失败';
        otherwise
            label = reason;
    end
end
