function RecursionReport = check_trapezoid_recursion(TrapezoidSolution, config)
% CHECK_TRAPEZOID_RECURSION 区分已完成梯形步、失败区间与未评价尾段。

    completed = isfinite(TrapezoidSolution.step_residual);
    RecursionReport.success = TrapezoidSolution.success;
    RecursionReport.evaluated = true;
    RecursionReport.failure_reason = TrapezoidSolution.failure_reason;
    RecursionReport.last_completed_node = TrapezoidSolution.last_completed_node;
    RecursionReport.failing_interval = TrapezoidSolution.failing_interval;
    RecursionReport.failure_step_residual = TrapezoidSolution.failure_step_residual;
    RecursionReport.failure_newton_iterations = ...
        TrapezoidSolution.failure_newton_iterations;
    RecursionReport.num_completed_intervals = sum(completed);
    if ~any(completed)
        RecursionReport.max_step_residual = NaN;
        RecursionReport.max_newton_iterations = NaN;
    else
        RecursionReport.max_step_residual = ...
            max(TrapezoidSolution.step_residual(completed));
        RecursionReport.max_newton_iterations = ...
            max(TrapezoidSolution.newton_iterations(completed));
    end
    RecursionReport.tolerance = config.validation.trapezoid_step_tolerance;
end
