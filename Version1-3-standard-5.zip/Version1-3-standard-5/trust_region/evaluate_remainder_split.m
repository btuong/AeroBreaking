function RemainderSplit = evaluate_remainder_split( ...
        CurrentSolution, CurrentReference, CandidateCheck, ConstData, config)
% EVALUATE_REMAINDER_SPLIT 把候选解处的动力学余项按随半径变化的阶拆成四部分（只报告）。
%
% 数学形式:
%   记参考点的节点量 x̄、ū、所在圈时长 t̄，候选解的 x*、u*、t*，Δx = x* − x̄，
%   Δt = t* − t̄。f 为 evaluate_atmospheric_dynamics 的前 5 个分量，对 u 仿射；
%   P3 线性化的是 F = t_f·f。每个节点算四次 f:
%       f00 = f(x̄, ū)   f10 = f(x*, ū)   f01 = f(x̄, u*)   f11 = f(x*, u*)
%   节点余项 R = t*·f11 − [t̄·f00 + J_x·Δx + t̄·(f01 − f00) + Δt·f00]
%   精确等于四部分之和:
%       状态×状态  t̄·(f10 − f00) − J_x·Δx                  随半径二次
%       状态×控制  t̄·[(f11 − f10) − (f01 − f00)]           随半径一次
%       状态×时长  Δt·(f11 − f01)                          随半径一次
%       控制×时长  Δt·(f01 − f00)                          与半径无关
%   J_x·Δx 的第 s 个分量 = Σ_v coeffs{s}.(v)·Δx_v，v 取 r, V, γ, φ, ψ，
%   coeffs 由 linearize_atmospheric_dynamics 给出（系数已乘 t̄）。分类的依据是
%   本项目的信赖域只加在状态和脉冲上，u 和 t_f 不受限制。
%   第 c 圈区间 i（Δτ = τ(i+1) − τ(i)）的余项是 −(Δτ/2)·(R_i + R_(i+1))，
%   四部分各自同样处理；它等于候选解处的动力学违反量加上动力学松弛，即
%   DynamicsReport.values + CurrentSolution.dyn_slack。
%
% 代码形式:
%   区间顺序与 DynamicsReport.values、dyn_slack 的行一致（按圈、按区间）。
%   输出 weighted 为 1 x 4，每部分 w·Σ|·|（全部区间、全部通道，w 为动力学罚权）；
%   weighted_channel 为 4 x 5，按通道 r, V, γ, φ, ψ 分开；total = w·Σ|区间余项|；
%   closure = max|区间余项 − 四部分之和|，应在 1e-9 量级或更小。
%   四部分的加权和相加不小于 total（绝对值的三角不等式），这是正常的。
%   只拆动力学；衔接和终端的余项不拆。
%
% 本函数依次完成：
%   1. 逐节点算四次 f 和线性化系数，得到节点余项的四部分。
%   2. 把节点余项按梯形公式合成区间余项。
%   3. 加权汇总，并和候选解处的区间余项核对。

    RemainderSplit = create_empty_remainder_split();
    PointsBounds = CurrentReference.PointsBounds;
    num_nodes = CurrentReference.N;
    num_parts = 4;

    %% 1. 逐节点算四次 f 和线性化系数，得到节点余项的四部分
    node_cir = zeros(num_nodes, 1);
    for cir = 1:numel(PointsBounds)
        node_cir(PointsBounds(cir).begin:PointsBounds(cir).end) = cir;
    end
    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    node_parts = zeros(num_nodes, 5, num_parts);
    for i = 1:num_nodes
        cir = node_cir(i);
        x_ref = CurrentReference.state(i, :)';
        x_new = CurrentSolution.state(i, :)';
        u_ref = [CurrentReference.control.u1(i), CurrentReference.control.u2(i)];
        u_new = [CurrentSolution.control.u1(i), CurrentSolution.control.u2(i)];
        t_ref = CurrentReference.t_f(cir);
        t_new = CurrentSolution.t_f(cir);

        f00 = evaluate_dynamics_pair(i, x_ref, u_ref, ConstData);
        f10 = evaluate_dynamics_pair(i, x_new, u_ref, ConstData);
        f01 = evaluate_dynamics_pair(i, x_ref, u_new, ConstData);
        f11 = evaluate_dynamics_pair(i, x_new, u_new, ConstData);

        % J_x·Δx：线性化系数已乘 t̄，第 s 个状态对各状态变量的偏导求和
        coeffs = linearize_atmospheric_dynamics(ConstData, x_ref', ...
            struct('u1', u_ref(1), 'u2', u_ref(2)), t_ref);
        jacobian_step = zeros(5, 1);
        for s = 1:5
            for v = 1:5
                jacobian_step(s) = jacobian_step(s) ...
                    + coeffs{s}.(state_names{v}) * (x_new(v) - x_ref(v));
            end
        end

        time_step = t_new - t_ref;
        node_parts(i, :, 1) = (t_ref * (f10 - f00) - jacobian_step)';
        node_parts(i, :, 2) = (t_ref * ((f11 - f10) - (f01 - f00)))';
        node_parts(i, :, 3) = (time_step * (f11 - f01))';
        node_parts(i, :, 4) = (time_step * (f01 - f00))';
    end

    %% 2. 把节点余项按梯形公式合成区间余项
    num_intervals = num_nodes - numel(PointsBounds);
    interval_parts = zeros(num_intervals, 5, num_parts);
    row = 0;
    for cir = 1:numel(PointsBounds)
        for i = PointsBounds(cir).begin:(PointsBounds(cir).end - 1)
            row = row + 1;
            delta_tau = CurrentReference.tau(i + 1) - CurrentReference.tau(i);
            for p = 1:num_parts
                interval_parts(row, :, p) = -(delta_tau / 2) ...
                    * (node_parts(i, :, p) + node_parts(i + 1, :, p));
            end
        end
    end

    %% 3. 加权汇总，并和候选解处的区间余项核对
    weight = config.objective.weight_dyn_slack;
    interval_total = CandidateCheck.dynamics_report.values ...
        + CurrentSolution.dyn_slack;
    for p = 1:num_parts
        RemainderSplit.weighted_channel(p, :) = ...
            weight * sum(abs(interval_parts(:, :, p)), 1);
    end
    RemainderSplit.weighted = sum(RemainderSplit.weighted_channel, 2)';
    RemainderSplit.total = weight * sum(abs(interval_total), 'all');
    RemainderSplit.closure = max(abs(interval_total - sum(interval_parts, 3)), ...
        [], 'all');
    RemainderSplit.evaluated = true;
end


function f = evaluate_dynamics_pair(node, x, u, ConstData)
% EVALUATE_DYNAMICS_PAIR 在节点处用原非线性动力学算 f 的前 5 个分量（5 x 1）。
% x 为 5 x 1 状态，u 为 [u1, u2]。

    dxdt = evaluate_atmospheric_dynamics(node, x, u(1), u(2), ConstData);
    f = dxdt(1:5);
end
