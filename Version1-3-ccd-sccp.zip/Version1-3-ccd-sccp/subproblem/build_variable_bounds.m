function VariableBounds = build_variable_bounds( ...
        VariableIndex, CurrentReference, TrustRegionState, ...
        ConstData, config)
% BUILD_VARIABLE_BOUNDS 构建 M 圈大气跳跃 P3 的决策变量上下界。
%
% 本函数依次叠加（取交而非覆盖）:
%   1. 控制量硬边界 u1, u2 ∈ [-1, 1]
%   2. 状态量硬边界：r >= min_r；gamma/psi 物理边界
%   3. 大气入口/出口节点 r 钉扎在 R_atm ± tolerance_r_atm
%   4. 信赖域：r/V/gamma/phi/psi/P 以参考为中心 ± 倍数 r × 基准半径
%      （r 由 update_trust_region 按 ρ 更新；P 半径以 m/s 配置，此处除以
%      VU 转为归一化单位）。控制 u 仿射进入动力学，不加信赖域；
%      P5 虽只进入线性入轨等式，但无界时目标沿其增大方向单调获益，
%      求解器数值停滞（首轮即失败），故与 P0~P4 一并加信赖域
%   5. 绝对值上图与非负松弛下界 0（t_P, t_if, t_raf, t_poi_*, t_dyn_*）；
%      'sccp' 模式下另加单位范数共用松弛 η ∈ [0, sccp_slack_max]
%
% 注：t_f、xff、xff_i 及 poi/dyn 松弛本身无边界。
%
% 输出 VariableBounds:
%   lower, upper  - 叠加后的最终上下界（交给求解器）
%   trust_lower, trust_upper - 只含信赖域的界，num_variables x 1；
%                   不受信赖域约束的变量为 NaN。P3 乘子报告靠它判断
%                   某个变量的信赖域界有没有生效（有效界等于信赖域界）
%   trust_base    - 每个变量的基准半径 b_j（归一化单位，没乘倍数 r；
%                   P 通道是 config.trust_region.P / VU），不受约束的为 NaN
%   trust_channel - 每个变量所属通道：1~6 依次为 r、V、gamma、phi、psi、P，
%                   不受信赖域约束的为 0
%   trust_node    - 状态通道变量所在节点号，P 通道为脉冲序号（1~6），其余为 0
%
% 本函数依次完成：
%   1. 控制量硬边界。
%   2. 状态量硬边界。
%   3. 大气入口/出口半径钉扎。
%   4. 信赖域（同时另存只含信赖域的界）。
%   5. 绝对值上图与非负松弛下界。
%   6. 检查最终边界。

    bounds = config.bounds;
    PointsBounds = CurrentReference.PointsBounds;

    num_variables = max(collect_index_values(VariableIndex));
    lower = -inf(num_variables, 1);
    upper = inf(num_variables, 1);

    r_k = CurrentReference.state(:, 1);
    V_k = CurrentReference.state(:, 2);
    gamma_k = CurrentReference.state(:, 3);
    phi_k = CurrentReference.state(:, 4);
    psi_k = CurrentReference.state(:, 5);
    P_k = CurrentReference.control.P;

    %% 1. 控制量硬边界
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.u1, bounds.min_u1, bounds.max_u1);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.u2, bounds.min_u2, bounds.max_u2);

    %% 2. 状态量硬边界
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.r, bounds.min_r, inf);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.gamma, ...
        bounds.min_gamma, bounds.max_gamma);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.psi, bounds.min_psi, bounds.max_psi);

    %% 3. 大气入口/出口半径钉扎
    for i = 1:5
        [lower, upper] = intersect_variable_bounds( ...
            lower, upper, VariableIndex.r(PointsBounds(i).begin), ...
            ConstData.R_atm - bounds.tolerance_r_atm, ...
            ConstData.R_atm + bounds.tolerance_r_atm);
        [lower, upper] = intersect_variable_bounds( ...
            lower, upper, VariableIndex.r(PointsBounds(i).end), ...
            ConstData.R_atm - bounds.tolerance_r_atm, ...
            ConstData.R_atm + bounds.tolerance_r_atm);
    end

    %% 4. 信赖域
    % 本轮实际半径 = 倍数 r × 基准半径
    radius = scale_trust_region_radius(TrustRegionState);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.r, r_k - radius.r, r_k + radius.r);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.V, V_k - radius.V, V_k + radius.V);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.gamma, ...
        gamma_k - radius.gamma, gamma_k + radius.gamma);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.phi, ...
        phi_k - radius.phi, phi_k + radius.phi);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.psi, ...
        psi_k - radius.psi, psi_k + radius.psi);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.P, ...
        P_k - radius.P / ConstData.VU, ...
        P_k + radius.P / ConstData.VU);
    % 另存一份只含信赖域的界，P3 乘子报告用它判断信赖域界有没有生效
    TrustBounds = record_trust_bounds(VariableIndex, CurrentReference, ...
        radius, TrustRegionState.base, ConstData, num_variables);

    %% 5. 绝对值上图与非负松弛下界
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.t_P, 0, inf);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.t_if, 0, inf);
    [lower, upper] = intersect_variable_bounds( ...
        lower, upper, VariableIndex.t_raf, 0, inf);

    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    for s = 1:numel(state_names)
        [lower, upper] = intersect_variable_bounds( ...
            lower, upper, ...
            VariableIndex.(['t_poi_slack_' state_names{s}]), 0, inf);
    end
    for s = 1:numel(state_names)
        [lower, upper] = intersect_variable_bounds( ...
            lower, upper, ...
            VariableIndex.(['t_dyn_slack_' state_names{s}]), 0, inf);
    end
    UnitNorm = describe_unit_norm(config);
    if UnitNorm.is_sccp
        [lower, upper] = intersect_variable_bounds( ...
            lower, upper, VariableIndex.unit_norm_slack, ...
            0, UnitNorm.slack_max);
    end

    %% 6. 检查最终边界
    validate_variable_bounds(lower, upper, num_variables);

    VariableBounds.lower = lower;
    VariableBounds.upper = upper;
    VariableBounds.trust_lower = TrustBounds.lower;
    VariableBounds.trust_upper = TrustBounds.upper;
    VariableBounds.trust_base = TrustBounds.base_radius;
    VariableBounds.trust_channel = TrustBounds.channel;
    VariableBounds.trust_node = TrustBounds.node;
end


function TrustBounds = record_trust_bounds( ...
        VariableIndex, CurrentReference, radius, base, ConstData, num_variables)
% RECORD_TRUST_BOUNDS 另存只含信赖域的界、基准半径、所属通道和节点号。
%
% 界的算法与第 4 步完全相同（参考值 ± 本轮实际半径，P 除以 VU），所以信赖域界
% 就是最终界时两者逐位相等。base 是倍数 r 之前的基准半径，P 同样除以 VU。

    state_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    TrustBounds.lower = nan(num_variables, 1);
    TrustBounds.upper = nan(num_variables, 1);
    TrustBounds.base_radius = nan(num_variables, 1);
    TrustBounds.channel = zeros(num_variables, 1);
    TrustBounds.node = zeros(num_variables, 1);

    for c = 1:numel(state_names)
        name = state_names{c};
        index = VariableIndex.(name);
        center = CurrentReference.state(:, c);
        TrustBounds.lower(index) = center - radius.(name);
        TrustBounds.upper(index) = center + radius.(name);
        TrustBounds.base_radius(index) = base.(name);
        TrustBounds.channel(index) = c;
        TrustBounds.node(index) = 1:numel(index);
    end

    index = VariableIndex.P;
    center = CurrentReference.control.P;
    TrustBounds.lower(index) = center - radius.P / ConstData.VU;
    TrustBounds.upper(index) = center + radius.P / ConstData.VU;
    TrustBounds.base_radius(index) = base.P / ConstData.VU;
    TrustBounds.channel(index) = 6;
    TrustBounds.node(index) = 1:numel(index);
end


function [lower, upper] = intersect_variable_bounds( ...
        lower, upper, indices, new_lower, new_upper)
% INTERSECT_VARIABLE_BOUNDS 将新边界与指定变量已有边界取交集。

    indices = indices(:);
    new_lower = expand_bound_value(new_lower, numel(indices));
    new_upper = expand_bound_value(new_upper, numel(indices));

    lower(indices) = max(lower(indices), new_lower);
    upper(indices) = min(upper(indices), new_upper);
end


function bound_value = expand_bound_value(bound_value, num_elements)
% EXPAND_BOUND_VALUE 将标量边界扩展为与索引数等长的向量。

    if isscalar(bound_value)
        bound_value = repmat(bound_value, num_elements, 1);
    else
        bound_value = bound_value(:);
    end
end


function validate_variable_bounds(lower, upper, num_variables)
% VALIDATE_VARIABLE_BOUNDS 检查变量边界的维数、数值和交集。

    if numel(lower) ~= num_variables || numel(upper) ~= num_variables
        error('SCP:InvalidVariableBoundSize', ...
            '变量边界长度必须等于决策变量总数。');
    end
    if any(isnan(lower) | isnan(upper))
        error('SCP:InvalidVariableBoundValue', ...
            '变量边界包含 NaN。');
    end
    invalid_index = find(lower > upper, 1);
    if ~isempty(invalid_index)
        error('SCP:EmptyVariableBoundIntersection', ...
            '变量 %d 的下界 %.6e 大于上界 %.6e。', ...
            invalid_index, lower(invalid_index), upper(invalid_index));
    end
end
