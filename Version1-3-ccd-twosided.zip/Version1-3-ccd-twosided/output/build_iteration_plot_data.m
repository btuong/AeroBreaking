function PlotData = build_iteration_plot_data(IterationRecord, ConstData)
% BUILD_ITERATION_PLOT_DATA 把一轮迭代记录整理成通用绘图数据（项目适配层）。
%
% 画哪些量、单位换算、时间拼接都在本函数决定；plot_scp_iteration、
% plot_scp_result 和各 draw_* 只认本函数的输出，不读 IterationRecord 的其他字段。
%
% 本函数只取值、换单位、拼时间，不调用动力学、映射等原函数。路径约束逐节点值读
% p2_feasibility.path_report.node_values，关键约束实际值和目标值读
% p2_feasibility.terminal_report.metrics 的 actual_value 与 target_value，
% 最大松弛读 p3_check.slack_report.metrics，动力学违反量与衔接违反量读 P2 可行性检查
% （候选解）和 Evaluation.reference_check（参考），P3 乘子读
% p3_check.multiplier_report，步长比例、预测下降和预测误差读 trust.evaluation。
%
% 叫法：P3 是凸子问题，P2 是离散后的非线性规划；罚函数 J 在 P2 上用原非线性函数
% 求值，L 是 P3 的目标。
%
% 时间轴只包含 5 次大气飞行段：每圈内时间为 tau * t_f * TU，圈与圈首尾相接，
% 圈间真空飞行不占时间轴。圈与圈之间在曲线里插一个 NaN，避免状态跳变连成斜线。
%
% 输出 PlotData（P3 失败轮只有 iter、status、has_path_constraints、
% trust_region、penalty、numerics 有内容）:
%   iter, status, has_path_constraints - 迭代序号、'accepted'/'rejected'/'failed'、是否有路径约束
%   segment_times  - 圈分界时刻 (s)，1 x 4
%   states         - 逐轮状态分块数组，横轴为时间
%   state_history  - 全程状态分块：states 加各圈 t_f，t_f 画在圈段中点
%   controls       - 控制分块数组，横轴为时间
%   violations     - 违反量与松弛分块（5 个状态通道 + 衔接点），横轴为区间中点时刻，
%                    每块三条曲线：参考处的违反量、松弛、候选解处的违反量，对数纵轴
%   step_trust     - 步长与信赖域分块（r、V、γ、φ、ψ、P），逐节点步长/(r·b)，
%                    参考线 1，信赖域界生效的节点另加标记（可选窗）
%   multipliers    - 乘子分块（5 个状态通道 + 衔接点），|λ|/w，参考线 1（可选窗）
%   path           - 路径约束分块数组，横轴为时间
%   p3_objective   - 指标项数组: 总脉冲 Σ|P| 与 P5（P3 解，同一分块）、附加项
%                    （控制正则项）、P3 目标 L 总值
%   key_constraints - 指标项数组，终端远地点半径和倾角，参考线为目标值
%   max_slack      - 指标项数组，各松弛通道最大绝对值，参考线为容差
%   penalty        - 罚函数 J 的分项: names、labels、candidate、reference（1 x 6）、
%                    candidate_total、reference_total，evaluated 为 false 时无数据
%   trust_region   - 本轮预测与半径数据: ρ、ΔL、D、ΔJ 的三部分、门槛、罚项与松弛罚项、
%                    r 前后值与动作、步长/半径、K 估计、余项按阶、驻点度量的上界、
%                    参考点序号、不可用原因（任何状态轮都有）
%   numerics       - 数值健康数据：A 的逐行跨度与相对残差、所属块、两条参考线、
%                    MOSEK 响应与警告（P3 失败轮也有，残差为空）
%
% 本函数依次完成：
%   1. 判断本轮状态，整理信赖域数据、罚函数分项和数值健康数据（P3 失败轮也整理）。
%   2. 拼接物理时间轴。
%   3. 整理状态量和控制量。
%   4. 整理违反量与松弛、步长与信赖域、乘子和路径约束量。
%   5. 整理 P3 性能指标、附加项与目标、终端约束和最大松弛。

    %% 1. 判断本轮状态，整理信赖域数据、罚函数分项和数值健康数据（P3 失败轮也整理）
    PlotData.iter = IterationRecord.iter;
    PlotData.has_path_constraints = true;   % 热流、过载、动压
    PlotData.segment_times = [];
    PlotData.states = struct([]);
    PlotData.state_history = struct([]);
    PlotData.controls = struct([]);
    PlotData.violations = struct([]);
    PlotData.step_trust = struct([]);
    PlotData.multipliers = struct([]);
    PlotData.path = struct([]);
    PlotData.p3_objective = struct([]);
    PlotData.key_constraints = struct([]);
    PlotData.max_slack = struct([]);
    PlotData.penalty = build_penalty_data(IterationRecord.trust.evaluation);
    PlotData.trust_region = build_trust_region_data(IterationRecord);
    PlotData.numerics = build_numerics_data(IterationRecord.subproblem);
    if isempty(IterationRecord.solution)
        % P3 失败没有解，只留状态
        PlotData.status = 'failed';
        return;
    end
    if IterationRecord.trust.accept_candidate
        PlotData.status = 'accepted';
    else
        PlotData.status = 'rejected';
    end
    Solution = IterationRecord.solution;
    Subproblem = IterationRecord.subproblem;
    Evaluation = IterationRecord.trust.evaluation;
    PointsBounds = IterationRecord.reference_before.PointsBounds;

    %% 2. 拼接物理时间轴
    % node_time 为 N x 1 各节点时刻 (s)；pass_end_time 为各圈结束时刻 (s)
    [node_time, pass_end_time] = compute_node_time(Solution, PointsBounds, ConstData);
    PlotData.segment_times = pass_end_time(1:end - 1);
    % 画曲线时按下面三组下标取值：圈间插 NaN；动力学违反量按区间起点节点取时刻
    [node_pos, interval_pos, interval_node] = compute_plot_positions(PointsBounds);
    time_axis = take_with_breaks(node_time, node_pos);
    % 区间中点时刻：区间起点和终点节点时刻的平均，圈间的 NaN 位保持 NaN
    interval_time = nan(numel(interval_node), 1);
    is_interval = ~isnan(interval_node);
    interval_time(is_interval) = 0.5 * (node_time(interval_node(is_interval)) ...
        + node_time(interval_node(is_interval) + 1));
    % 衔接点画在各圈入口节点时刻（第 1 点是初始点，其余是圈间内点）
    point_time = node_time([PointsBounds.begin]);

    %% 3. 整理状态量和控制量
    LU_km = ConstData.LU / 1e3;
    VU_km = ConstData.VU / 1e3;
    state_values = {
        'r', 'r (km)',    Solution.state(:, 1) * LU_km;
        'V', 'V (km/s)',  Solution.state(:, 2) * VU_km;
        'γ', 'γ (deg)',   rad2deg(Solution.state(:, 3));
        'φ', 'φ (deg)',   rad2deg(Solution.state(:, 4));
        'ψ', 'ψ (deg)',   rad2deg(Solution.state(:, 5));
    };
    PlotData.states = build_line_tiles(state_values, node_pos, time_axis);

    % t_f 是每圈一个标量，只追加到全程状态图；逐轮状态图保持五个分块
    pass_start_time = [0, pass_end_time(1:end - 1)];
    pass_mid_time = (pass_start_time + pass_end_time) / 2;
    tf_tile = build_plot_tile('t_f', 't_f (s)', ...
        build_plot_curve('t_f', pass_mid_time, ...
            Solution.t_f * ConstData.TU, 'marker'));
    PlotData.state_history = [PlotData.states, tf_tile];

    % 控制：P3 里的原始变量 u1、u2，以及它们换成的倾侧角 sigma 和模长 ||u||
    u1 = Solution.control.u1;
    u2 = Solution.control.u2;
    sigma_deg = transform_u2sigma(u2, u1);
    control_values = {
        'u₁',  'u₁',       u1;
        'u₂',  'u₂',       u2;
        '‖u‖', '‖u‖',      hypot(u1, u2);
        'σ',   'σ (deg)',  sigma_deg(:);
    };
    PlotData.controls = build_line_tiles(control_values, node_pos, time_axis);

    % 脉冲是离散量：P(1)..P(5) 画在各圈入口时刻，P(6) 画在最后一圈结束时刻
    pulse_time = [node_time([PointsBounds.begin]); pass_end_time(end)];
    pulse_tile = build_plot_tile('P', 'P (m/s)', ...
        build_plot_curve('P', pulse_time, ...
            Solution.control.P * ConstData.VU, 'marker'));
    PlotData.controls = [PlotData.controls, pulse_tile];

    %% 4. 整理违反量与松弛、步长与信赖域、乘子和路径约束量
    PlotData.violations = build_violation_tiles(Evaluation, Subproblem, Solution, ...
        interval_time, interval_pos, point_time);
    PlotData.step_trust = build_step_tiles(Evaluation, ...
        Subproblem.p3_check.multiplier_report, node_time, node_pos, ...
        time_axis, pulse_time);
    PlotData.multipliers = build_multiplier_tiles( ...
        Subproblem.p3_check.multiplier_report, interval_time, interval_pos, ...
        point_time);

    % 路径约束逐节点值由 evaluate_path_constraints 算好
    PathReport = Subproblem.p2_feasibility.path_report;
    path_tiles = cell(1, numel(PathReport.metrics));
    for j = 1:numel(PathReport.metrics)
        Metric = PathReport.metrics(j);
        name = describe_metric(Metric.name);
        path_tiles{j} = build_plot_tile(name, ...
            format_axis_label(name, Metric.unit), ...
            build_plot_curve('节点值', time_axis, ...
                take_with_breaks(PathReport.node_values(:, j), node_pos), 'line'), ...
            Metric.limit, '上限');
    end
    PlotData.path = [path_tiles{:}];

    %% 5. 整理 P3 性能指标、附加项与目标、终端约束和最大松弛
    % 性能指标取 P3 解本身: 总脉冲 Σ|P| 与最大的一项 P5（P(6)），同一分块；
    % 总脉冲是总量画粗线，P5 是其中一项画细线
    pulses = abs(Solution.control.P(:)) * ConstData.VU;
    ObjectiveTerms = Subproblem.objective_terms;
    control_reg = ObjectiveTerms.terms(strcmp({ObjectiveTerms.terms.name}, ...
        'control_reg'));
    if isempty(control_reg)
        extra_value = 0;
    else
        extra_value = control_reg.value;
    end
    objective_items = { ...
        build_history_item('总脉冲 Σ|P|', '性能指标', '脉冲 (m/s)', ...
            sum(pulses), NaN, '', 'bold'), ...
        build_history_item('P5', '性能指标', '脉冲 (m/s)', pulses(end), ...
            NaN, ''), ...
        build_history_item('附加项（控制正则项）', '附加项（控制正则项）', ...
            '附加项（控制正则项）', extra_value, NaN, ''), ...
        build_history_item('P3 目标 L', 'P3 目标 L', 'P3 目标 L', ...
            ObjectiveTerms.total, NaN, '')};
    PlotData.p3_objective = [objective_items{:}];

    % 关键约束：终端远地点半径和倾角，参考线为目标值（读 P2 可行性检查的重算值）
    PenaltyMetrics = Subproblem.p2_feasibility.terminal_report.metrics;
    key_items = cell(1, numel(PenaltyMetrics));
    for j = 1:numel(PenaltyMetrics)
        Metric = PenaltyMetrics(j);
        label = describe_metric(Metric.name);
        key_items{j} = build_history_item(label, label, ...
            format_axis_label(label, Metric.unit), ...
            Metric.actual_value, Metric.target_value, '目标');
    end
    PlotData.key_constraints = [key_items{:}];

    % 最大松弛：同类松弛（各状态通道）画在同一分块，参考线为容差
    SlackMetrics = Subproblem.p3_check.slack_report.metrics;
    slack_items = cell(1, numel(SlackMetrics));
    for j = 1:numel(SlackMetrics)
        Metric = SlackMetrics(j);
        % 名称 dyn_slack_r 拆成类别 dyn_slack（作分块）和通道 r（作图例）
        group = describe_metric(regexprep(Metric.name, '_[^_]+$', ''));
        channel = describe_metric(regexp(Metric.name, '[^_]+$', 'match', 'once'));
        slack_items{j} = build_history_item([group ' ' channel], group, ...
            ['最大' group ' |ν|'], Metric.value, ...
            Metric.tolerance, '容差');
    end
    PlotData.max_slack = [slack_items{:}];
end


function Tiles = build_violation_tiles(Evaluation, Subproblem, Solution, ...
        interval_time, interval_pos, point_time)
% BUILD_VIOLATION_TILES 违反量与松弛分块: 每个状态通道一块，再加衔接点一块。
%
% 数学形式:
%   每个区间三个量: 参考处的违反量 |g(z^k)|、松弛 |ν|、候选解处的违反量
%   |g(z^k+d^k)|。松弛 ν 把 P3 里线性化后的等式补平，候选解处违反量等于松弛
%   与余项之和（余项为单个函数在候选解处的原函数值减线性化值）；三者对照能看出
%   违反量是被修掉了、还是被松弛吃掉了。衔接点同理，三个量按 Σ|g| 画（归一化单位）。
%
% 代码形式:
%   参考处取 Evaluation.reference_check，候选解处取 Subproblem.p2_feasibility，
%   松弛取候选解的 dyn_slack 与 point_slack。动力学违反量按通道换成物理
%   单位（km、m/s、deg），横轴为区间中点时刻；全部纵轴为对数，零值由绘图函数
%   统一画在下限处。参考处检查缺失时参考曲线整条为 NaN。

    DynamicsReport = Subproblem.p2_feasibility.dynamics_report;
    JunctionReport = Subproblem.p2_feasibility.junction_report;
    ReferenceCheck = Evaluation.reference_check;
    has_reference = ~isempty(ReferenceCheck);

    channel_names = {'r', 'V', 'γ', 'φ', 'ψ'};
    scales = DynamicsReport.scale;
    tile_list = cell(1, numel(channel_names) + 1);
    for s = 1:numel(channel_names)
        candidate_dynamics = abs(DynamicsReport.values(:, s)) * scales(s);
        slack = abs(Solution.dyn_slack(:, s)) * scales(s);
        reference_dynamics = nan(size(candidate_dynamics));
        if has_reference
            reference_dynamics = abs(ReferenceCheck.dynamics_report.values(:, s)) ...
                * scales(s);
        end
        curves = [ ...
            build_plot_curve('参考处的违反量', interval_time, ...
                take_with_breaks(reference_dynamics, interval_pos), 'thin'), ...
            build_plot_curve('松弛', interval_time, ...
                take_with_breaks(slack, interval_pos), 'dashed'), ...
            build_plot_curve('候选解处的违反量', interval_time, ...
                take_with_breaks(candidate_dynamics, interval_pos), 'line')];
        tile_list{s} = build_plot_tile(channel_names{s}, ...
            sprintf('%s 违反量 (%s)', channel_names{s}, ...
            DynamicsReport.metrics(s).unit), curves, NaN, '', true);
    end

    % 衔接点: 5 个点，线型和颜色与各通道分块一致（共用图例），每个点另加标记
    candidate_junction = sum(abs(JunctionReport.values), 2);
    slack_junction = sum(abs(Solution.point_slack), 2);
    reference_junction = nan(size(candidate_junction));
    if has_reference
        reference_junction = sum(abs(ReferenceCheck.junction_report.values), 2);
    end
    curves = [ ...
        build_plot_curve('参考处的违反量', point_time, ...
            reference_junction, 'thin_marker'), ...
        build_plot_curve('松弛', point_time, slack_junction, ...
            'dashed_marker'), ...
        build_plot_curve('候选解处的违反量', point_time, ...
            candidate_junction, 'line_marker')];
    tile_list{end} = build_plot_tile('衔接点', ...
        '衔接违反量 Σ|g| (归一化)', curves, NaN, '', true);
    Tiles = [tile_list{:}];
end


function Tiles = build_step_tiles(Evaluation, MultiplierReport, node_time, ...
        node_pos, time_axis, pulse_time)
% BUILD_STEP_TILES 步长与信赖域分块: r、V、γ、φ、ψ 各一块，再加脉冲 P 一块。
%
% 逐节点画 |候选解 − 参考| / (r·b)（Evaluation.step_ratio_node），参考线为 1，
% 即信赖域边界；信赖域界生效的节点（乘子大于容差，见 evaluate_p3_multipliers）
% 另用标记点出。乘子不可用时只画步长比例。P 的 6 个脉冲画成标记。

    channel_names = {'r', 'V', 'γ', 'φ', 'ψ'};
    has_multipliers = MultiplierReport.evaluated;
    tile_list = cell(1, numel(channel_names) + 1);
    for s = 1:numel(channel_names)
        ratio = Evaluation.step_ratio_node(:, s);
        curves = build_plot_curve('|候选解-参考| / (r·b)', time_axis, ...
            take_with_breaks(ratio, node_pos), 'line');
        if has_multipliers
            active = MultiplierReport.trust_active_node(:, s);
            if any(active)
                curves = [curves, build_plot_curve('信赖域界生效', ...
                    node_time(active), ratio(active), 'marker')]; %#ok<AGROW>
            end
        end
        tile_list{s} = build_plot_tile(channel_names{s}, ...
            [channel_names{s} ' 步长 / 半径'], curves, 1, '信赖域边界');
    end

    pulse_ratio = Evaluation.step_ratio_pulse(:);
    curves = build_plot_curve('|候选解-参考| / (r·b)', pulse_time, ...
        pulse_ratio, 'marker');
    if has_multipliers
        active = MultiplierReport.trust_active_pulse(:);
        if any(active)
            curves = [curves, build_plot_curve('信赖域界生效', ...
                pulse_time(active), pulse_ratio(active), 'marker_cross')];
        end
    end
    tile_list{end} = build_plot_tile('P', 'P 步长 / 半径', curves, 1, ...
        '信赖域边界');
    Tiles = [tile_list{:}];
end


function Tiles = build_multiplier_tiles(MultiplierReport, interval_time, ...
        interval_pos, point_time)
% BUILD_MULTIPLIER_TILES 乘子分块: 每个状态通道一块逐区间 |λ|/w_dyn，再加衔接点一块。
%
% |λ|/w 等于 1 表示这一行的罚权被顶满（松弛在起作用），小于 1 表示没顶到。
% 衔接点一块里五个通道各一条曲线（标记），|λ|/w_poi。乘子不可用时返回空，
% 绘图函数写明没有数据。

    Tiles = struct([]);
    if ~MultiplierReport.evaluated
        return;
    end
    channel_names = {'r', 'V', 'γ', 'φ', 'ψ'};
    tile_list = cell(1, numel(channel_names) + 1);
    for s = 1:numel(channel_names)
        tile_list{s} = build_plot_tile(channel_names{s}, ...
            [channel_names{s} ' |λ|/w_dyn'], ...
            build_plot_curve('|λ|/w_dyn', interval_time, ...
                take_with_breaks(MultiplierReport.dynamics_ratio(:, s), ...
                interval_pos), 'line'), 1, '罚权 w');
    end
    junction_curves = cell(1, numel(channel_names));
    for s = 1:numel(channel_names)
        junction_curves{s} = build_plot_curve(channel_names{s}, point_time, ...
            MultiplierReport.junction_ratio(:, s), 'marker');
    end
    tile_list{end} = build_plot_tile('衔接点', '衔接 |λ|/w_poi', ...
        [junction_curves{:}], 1, '罚权 w');
    Tiles = [tile_list{:}];
end


function Penalty = build_penalty_data(Evaluation)
% BUILD_PENALTY_DATA 罚函数 J 的分项: 候选解处和参考处各一份，供全程罚函数图用。
%
% 全程图画候选解处的值，第 0 次迭代画初始参考，所以两份都存。未评价
% （P3 失败）时 evaluated 为 false，其余为空，不拿其他轮的数据填。

    Penalty.evaluated = false;
    Penalty.names = {};
    Penalty.labels = {};
    Penalty.candidate = [];
    Penalty.reference = [];
    Penalty.candidate_total = NaN;
    Penalty.reference_total = NaN;
    if ~Evaluation.evaluated || isempty(Evaluation.candidate) ...
            || isempty(Evaluation.reference)
        return;
    end
    Penalty.evaluated = true;
    Penalty.names = {Evaluation.candidate.terms.name};
    Penalty.labels = arrayfun(@(t) describe_penalty_term(t.name), ...
        Evaluation.candidate.terms, 'UniformOutput', false);
    Penalty.candidate = [Evaluation.candidate.terms.value];
    Penalty.reference = [Evaluation.reference.terms.value];
    Penalty.candidate_total = Evaluation.candidate.total;
    Penalty.reference_total = Evaluation.reference.total;
end


function TrustRegion = build_trust_region_data(IterationRecord)
% BUILD_TRUST_REGION_DATA 整理本轮预测与半径数据，供全程的预测下降、半径与判据、半径平面三扇窗拼序列。
%
% 只读 IterationRecord 已存的评价和更新记录，不重新计算。ρ 不可用或 P3 失败时
% ratio 为 NaN、unavailable_reason 记明原因（不补零）；失败轮半径保持不变，
% r 前后值照常保留，其余量均为 NaN。
%
% 字段（K 估计、余项按阶只在评价过的轮有值）:
%   predicted_reduction、cost_predicted、extra_predicted、penalty_predicted
%                                                       - ΔL 及其性能指标、附加项、罚项三部分
%   prediction_error、cost_error、extra_error、penalty_error
%                                                       - D 及其三部分
%   actual_reduction、cost_actual、extra_actual、penalty_actual
%                                                       - ΔJ 及其三部分
%   reference_penalty、candidate_penalty、slack_penalty - 参考处的罚项、候选解处的罚项、松弛罚项
%   threshold                                           - 门槛 (1−ρ1)ΔL
%   step_ratio_channels                                  - 1 x 6，通道 r, V, γ, φ, ψ, P 的步长/半径
%   curvature_estimate                                   - K 估计 D/‖d‖²
%   remainder_second、remainder_first、remainder_zero    - 动力学余项按阶：二次、一次
%                                                          （状态×控制 + 状态×时长）、与半径无关
%   stationarity_bound                                    - 驻点度量的上界 (r_max/r)ΔL
%   reference_index                                      - 同一参考点上的求解此值相同

    Trust = IterationRecord.trust;
    Evaluation = Trust.evaluation;
    Update = Trust.trust_region_update;
    Split = Evaluation.remainder_split;
    TrustRegion.evaluated = Evaluation.evaluated;
    TrustRegion.accept_candidate = Trust.accept_candidate;
    TrustRegion.reference_index = IterationRecord.num_accepted_after ...
        - double(Trust.accept_candidate);
    TrustRegion.ratio = Evaluation.ratio;
    TrustRegion.ratio_available = Evaluation.ratio_available;
    TrustRegion.ratio_unavailable = ~Evaluation.ratio_available ...
        && Evaluation.evaluated;
    TrustRegion.unavailable_reason = Evaluation.reason;
    TrustRegion.predicted_reduction = Evaluation.predicted_reduction;   % ΔL
    TrustRegion.cost_predicted = Evaluation.group.cost.predicted;
    TrustRegion.extra_predicted = Evaluation.group.extra.predicted;
    TrustRegion.penalty_predicted = Evaluation.group.penalty.predicted;
    TrustRegion.actual_reduction = Evaluation.actual_reduction;         % ΔJ
    TrustRegion.cost_actual = Evaluation.group.cost.actual;
    TrustRegion.extra_actual = Evaluation.group.extra.actual;
    TrustRegion.penalty_actual = Evaluation.group.penalty.actual;
    TrustRegion.prediction_error = Evaluation.prediction_error;         % D
    TrustRegion.cost_error = Evaluation.group.cost.error;
    TrustRegion.extra_error = Evaluation.group.extra.error;
    TrustRegion.penalty_error = Evaluation.group.penalty.error;
    TrustRegion.reference_penalty = Evaluation.group.penalty.reference;
    TrustRegion.candidate_penalty = Evaluation.group.penalty.candidate;
    TrustRegion.slack_penalty = Evaluation.slack_penalty;
    TrustRegion.threshold = Evaluation.threshold;
    TrustRegion.step_ratio = Evaluation.step_ratio;
    TrustRegion.step_ratio_channel = Evaluation.step_ratio_channel;
    TrustRegion.step_ratio_channels = Evaluation.step_ratio_channels;
    TrustRegion.on_boundary = Evaluation.on_boundary;
    TrustRegion.curvature_estimate = Evaluation.curvature_estimate;
    TrustRegion.remainder_second = Split.weighted(1);
    TrustRegion.remainder_first = Split.weighted(2) + Split.weighted(3);
    TrustRegion.remainder_zero = Split.weighted(4);
    TrustRegion.stationarity_bound = Evaluation.stationarity_bound;
    TrustRegion.stationarity_tolerance = Evaluation.stationarity_tolerance;
    TrustRegion.scale_before = Update.scale_before;
    TrustRegion.scale_after = Update.scale_after;
    TrustRegion.requested_action = Update.requested_action;
    TrustRegion.applied_action = Update.applied_action;
end


function [node_time, pass_end_time] = compute_node_time(Solution, PointsBounds, ConstData)
% COMPUTE_NODE_TIME 各节点物理时刻 (s)：圈内 tau * t_f * TU，圈与圈首尾相接。
%
% node_time 为 N x 1；pass_end_time 为 1 x 圈数，各圈结束时刻。

    node_time = zeros(Solution.N, 1);
    pass_end_time = zeros(1, numel(PointsBounds));
    offset = 0;
    for cir = 1:numel(PointsBounds)
        rows = PointsBounds(cir).begin:PointsBounds(cir).end;
        node_time(rows) = offset + Solution.tau(rows) * Solution.t_f(cir) * ConstData.TU;
        offset = node_time(rows(end));
        pass_end_time(cir) = offset;
    end
end


function [node_pos, interval_pos, interval_node] = compute_plot_positions(PointsBounds)
% COMPUTE_PLOT_POSITIONS 生成取值下标：每圈之间插一个 NaN 位，曲线在圈间断开。
%
% node_pos      - 按节点取值的下标
% interval_pos  - 动力学松弛（每个区间一行）按区间序号取值的下标
% interval_node - 与 interval_pos 对应、取区间起点节点时刻的节点下标

    num_passes = numel(PointsBounds);
    total_nodes = PointsBounds(end).end;
    node_pos = nan(1, total_nodes + num_passes - 1);
    interval_pos = nan(1, total_nodes - 1);
    interval_node = nan(1, total_nodes - 1);
    node_cursor = 0;
    interval_cursor = 0;
    interval_count = 0;
    for cir = 1:num_passes
        rows = PointsBounds(cir).begin:PointsBounds(cir).end;
        num_intervals = numel(rows) - 1;
        if cir > 1
            node_cursor = node_cursor + 1;
            interval_cursor = interval_cursor + 1;
        end
        node_pos(node_cursor + (1:numel(rows))) = rows;
        node_cursor = node_cursor + numel(rows);
        interval_pos(interval_cursor + (1:num_intervals)) = ...
            interval_count + (1:num_intervals);
        interval_node(interval_cursor + (1:num_intervals)) = rows(1:end - 1);
        interval_cursor = interval_cursor + num_intervals;
        interval_count = interval_count + num_intervals;
    end
end


function values = take_with_breaks(source, positions)
% TAKE_WITH_BREAKS 按下标取值，下标为 NaN 的位置给 NaN。

    values = nan(numel(positions), 1);
    valid = ~isnan(positions);
    values(valid) = source(positions(valid));
end


function Tiles = build_line_tiles(specs, node_pos, time_axis)
% BUILD_LINE_TILES 按“标题、纵轴标签、各节点取值”清单生成单曲线分块。

    % 先放进元胞再一次拼成结构体数组，避免逐个下标赋值时的类型问题
    tile_list = cell(1, size(specs, 1));
    for j = 1:size(specs, 1)
        tile_list{j} = build_plot_tile(specs{j, 1}, specs{j, 2}, ...
            build_plot_curve(specs{j, 1}, time_axis, ...
                take_with_breaks(specs{j, 3}, node_pos), 'line'));
    end
    Tiles = [tile_list{:}];
end


function label = format_axis_label(name, unit)
% FORMAT_AXIS_LABEL 纵轴标签写成“名称 (单位)”；无量纲量只写名称。

    if isempty(unit) || any(strcmp(unit, {'1', '-'}))
        label = name;
    else
        label = sprintf('%s (%s)', name, unit);
    end
end


function label = describe_metric(name)
% DESCRIBE_METRIC 检查报告里的英文指标名、通道名对应的图上名称。
% 有明确数学符号的状态只用符号；路径约束、终端约束等写“中文 + 符号”。

    names = {
        'dynamic_pressure',               '动压 q';
        'heat_flux',                      '热流 Q̇';
        'load_factor',                    '过载 n';
        'terminal_apoapsis_violation',    '终端远地点半径 rₐ';
        'terminal_inclination_violation', '终端倾角 i';
        'dyn_slack',                      '动力学松弛';
        'point_slack',                    '衔接松弛';
        'r',                              'r';
        'V',                              'V';
        'gamma',                          'γ';
        'phi',                            'φ';
        'psi',                            'ψ';
    };
    row = find(strcmp(names(:, 1), name), 1);
    if isempty(row)
        label = name;
    else
        label = names{row, 2};
    end
end




function Numerics = build_numerics_data(Subproblem)
% BUILD_NUMERICS_DATA 整理数值健康图的数据：A 的逐行跨度与相对残差。
%
% 跨度取自求解前的系数扫描，相对残差取自原始矩阵残差检查，两者按行号对应。
% P3 失败时没有返回解，relative 为空。参考线取自系数扫描记下的阈值配置。

    LinearRows = Subproblem.coefficient_report.linear_rows;
    Numerics.span = LinearRows.span;
    Numerics.block = LinearRows.block;
    Numerics.block_names = LinearRows.block_names;
    Numerics.relative = [];
    if Subproblem.success
        Numerics.relative = ...
            Subproblem.p3_check.solver_feasibility_report.linear_rows.relative;
    end

    Thresholds = Subproblem.coefficient_report.thresholds;
    Numerics.span_reference = NaN;
    Numerics.residual_reference = NaN;
    if isfield(Thresholds, 'max_row_span')
        Numerics.span_reference = Thresholds.max_row_span;
    end
    if isfield(Thresholds, 'residual_reference')
        Numerics.residual_reference = Thresholds.residual_reference;
    end

    % 标题用的求解器信息：响应名（缺失时用响应码）和警告编号
    MosekReport = Subproblem.solver.mosek_report;
    response_text = MosekReport.response_name;
    if isempty(response_text)
        response_text = sprintf('响应码 %g', Subproblem.solver.response_code);
    end
    if isempty(MosekReport.warning_codes)
        warning_text = '无警告';
    else
        warning_text = ['警告 ' strjoin(arrayfun(@num2str, ...
            MosekReport.warning_codes, 'UniformOutput', false), ', ')];
    end
    Numerics.solver_text = sprintf('MOSEK %s，%s', response_text, warning_text);
end
