function plot_scp_iteration(IterationRecord, ConstData, config)
% PLOT_SCP_ITERATION 画本轮优化解的状态量、控制量、违反量与松弛、路径约束量，以及可选的步长与信赖域、乘子和数值健康图。
%
% 默认四扇窗横轴为物理时间: 状态量、控制量、违反量与松弛、路径约束量。
% 可选窗由配置控制: 步长与信赖域（config.plot.enable_trust_region_iteration）、
% 乘子（config.plot.enable_multiplier_iteration）、数值健康
% （config.plot.enable_numerics_iteration，A 逐行的“行内跨度 - 相对残差”散点图）。
% 图窗累计还是复用由 config.plot.iteration_figure_mode 决定: 'reuse'（默认）
% 每轮清空同一组窗口重画，'accumulate' 每轮新开一组。与场景有关的取值全部在
% build_iteration_plot_data 里，本函数不随场景改动。
% config.plot.save_figures 为 true 时，本轮每扇窗画完即导出 PNG 到
% pictures/iterations/iterNN/（NN 为两位迭代序号），reuse 模式下也逐轮各存一份。
% 被拒绝的轮候选解存在，照常画；P3 失败轮各窗只写一行说明。
%
% 本函数依次完成:
%   1. 把本轮记录整理成绘图数据。
%   2. 画优化解状态量。
%   3. 画优化解控制量。
%   4. 画违反量与松弛。
%   5. 画路径约束量。
%   6. 画步长与信赖域（可选）。
%   7. 画乘子（可选）。
%   8. 画数值健康图（可选）。

    %% 1. 把本轮记录整理成绘图数据
    PlotData = build_iteration_plot_data(IterationRecord, ConstData);
    title_suffix = build_iteration_title_suffix(PlotData);

    %% 2. 画优化解状态量
    % P3 失败时各窗只写一行失败说明，不留上一轮的曲线
    fig = open_iteration_figure('state', '状态量', PlotData.iter, config);
    draw_time_tiles(fig, PlotData.states, PlotData.segment_times, ...
        ['状态量 ' title_suffix], config);
    save_iteration_figure(fig, '状态量', PlotData.iter, config);

    %% 3. 画优化解控制量
    fig = open_iteration_figure('control', '控制量', PlotData.iter, config);
    draw_time_tiles(fig, PlotData.controls, PlotData.segment_times, ...
        ['控制量 ' title_suffix], config);
    save_iteration_figure(fig, '控制量', PlotData.iter, config);

    %% 4. 画违反量与松弛
    % 每个状态通道一块，三条曲线: 参考处的违反量、松弛、候选解处的违反量；零值画在下限
    fig = open_iteration_figure('violation', '违反量与松弛', PlotData.iter, config);
    draw_time_tiles(fig, PlotData.violations, PlotData.segment_times, ...
        ['违反量与松弛 ' title_suffix], config);
    save_iteration_figure(fig, '违反量与松弛', PlotData.iter, config);

    %% 5. 画路径约束量
    % 问题没有路径约束时不开这扇窗
    if PlotData.has_path_constraints
        fig = open_iteration_figure('path', '路径约束量', PlotData.iter, config);
        draw_time_tiles(fig, PlotData.path, PlotData.segment_times, ...
            ['路径约束量 ' title_suffix], config);
        save_iteration_figure(fig, '路径约束量', PlotData.iter, config);
    end

    %% 6. 画步长与信赖域（可选）
    % 逐节点的 |候选解 - 参考| / (r·b)，参考线 1 即信赖域边界，界生效的节点加标记
    if config.plot.enable_trust_region_iteration
        fig = open_iteration_figure('step', '步长与信赖域', PlotData.iter, config);
        draw_time_tiles(fig, PlotData.step_trust, PlotData.segment_times, ...
            ['步长与信赖域 ' title_suffix], config);
        save_iteration_figure(fig, '步长与信赖域', PlotData.iter, config);
    end

    %% 7. 画乘子（可选）
    % 逐区间的 |λ|/w_dyn 和衔接点的 |λ|/w_poi，参考线 1 即罚权
    if config.plot.enable_multiplier_iteration
        fig = open_iteration_figure('multiplier', '乘子', PlotData.iter, config);
        draw_time_tiles(fig, PlotData.multipliers, PlotData.segment_times, ...
            ['乘子 ' title_suffix], config);
        save_iteration_figure(fig, '乘子', PlotData.iter, config);
    end

    %% 8. 画数值健康图（可选）
    % P3 失败时没有残差，窗里写明失败和 MOSEK 响应
    if config.plot.enable_numerics_iteration
        fig = open_iteration_figure('numerics', '数值健康', PlotData.iter, config);
        draw_numerics_scatter(fig, PlotData.numerics, ...
            ['数值健康 ' title_suffix '  ' PlotData.numerics.solver_text], config);
        save_iteration_figure(fig, '数值健康', PlotData.iter, config);
    end
end


function save_iteration_figure(fig, name, iter, config)
% SAVE_ITERATION_FIGURE save_figures 打开时把本轮该扇窗导出到按轮次分的目录。
% 导出失败只告警，不影响后续窗口与求解。

    if ~config.plot.save_figures
        return;
    end
    folder = fullfile('pictures', 'iterations', sprintf('iter%02d', iter));
    try
        save_plot_figure(fig, fullfile(folder, name));
    catch exception
        warning('SCP:IterationFigureExportFailed', ...
            '第 %d 轮%s图导出失败：%s', iter, name, exception.message);
    end
end


function title_suffix = build_iteration_title_suffix(PlotData)
% BUILD_ITERATION_TITLE_SUFFIX 生成窗口标题后缀，如“第 3 轮（接受）”。

    switch PlotData.status
        case 'accepted'
            status_text = '接受';
        case 'rejected'
            status_text = '拒绝';
        otherwise
            status_text = 'P3 失败';
    end
    title_suffix = sprintf('第 %d 轮（%s）', PlotData.iter, status_text);
end


function fig = open_iteration_figure(key, name, iter, config)
% OPEN_ITERATION_FIGURE 按图窗模式取得本轮要画的窗口。
%
% 'reuse'：按固定 Tag 找已有窗口，找到就清空，找不到就新建。
% 'accumulate'：每轮新建，窗口名带迭代序号。
% 句柄不跨轮传递，也不存进任何运行对象。

    tag = ['scp_iteration_' key];
    switch config.plot.iteration_figure_mode
        case 'reuse'
            fig = findobj(groot, 'Type', 'figure', 'Tag', tag);
            if isempty(fig)
                fig = figure('Name', ['迭代-' name], 'NumberTitle', 'off', ...
                    'Tag', tag, 'Visible', config.plot.visibility);
            else
                fig = fig(1);
                clf(fig);
            end
        case 'accumulate'
            fig = figure('Name', sprintf('迭代 %d-%s', iter, name), ...
                'NumberTitle', 'off', 'Tag', tag, ...
                'Visible', config.plot.visibility);
        otherwise
            error('SCP:InvalidIterationFigureMode', ...
                'config.plot.iteration_figure_mode 只能是 reuse 或 accumulate。');
    end
end
