function Summary = summarize_control_report(ControlReport, node_mask)
% SUMMARIZE_CONTROL_REPORT 对 node_mask 选出的节点汇总控制量报告。
%
% 逐圈汇总传某一圈的节点掩码，全程汇总传全部节点。只读 ControlReport 的逐节点量，
% 不重新求值；对偶分解不可用时对偶相关量为 NaN（统计量也是 NaN）。
%
% 输出 Summary 字段:
%   num_nodes          - 节点数
%   sum_omega          - Σω
%   gamma_sum          - Γ 小计 Σ gamma_node
%   max_abs_tight_gap  - max|1-‖u‖|
%   num_untight        - |1-‖u‖| 大于 ControlReport.tightness_tolerance 的节点数
%   sigma_mean/min/max - σ 的均值、最小、最大 (deg)，均值是算术平均
%   fraction_neg135    - σ 落在 -135° ± 15° 的节点比例（角差按 360° 规约）
%   fraction_pos45     - σ 落在 +45° ± 15° 的节点比例
%   reg_ratio_median/max, num_reg_ratio_gt1 - reg_ratio 的中位数、最大值、大于 1 的节点数
%   shift_abs_median/max - |σ_shift| 的中位数、最大值 (deg)
%   residual_max_abs   - max|stationarity_residual|

    Summary = create_empty_control_summary();
    node_mask = logical(node_mask(:));
    Summary.num_nodes = sum(node_mask);
    if Summary.num_nodes == 0
        return;
    end

    sigma = ControlReport.sigma_deg(node_mask);
    tight_gap = ControlReport.tight_gap(node_mask);
    reg_ratio = ControlReport.reg_ratio(node_mask);
    shift_abs = abs(ControlReport.sigma_shift_deg(node_mask));
    residual = abs(ControlReport.stationarity_residual(node_mask, :));

    Summary.sum_omega = sum(ControlReport.omega(node_mask));
    Summary.gamma_sum = sum(ControlReport.gamma_node(node_mask));
    Summary.max_abs_tight_gap = max(abs(tight_gap));
    Summary.num_untight = sum(abs(tight_gap) > ControlReport.tightness_tolerance);
    Summary.sigma_mean = mean(sigma);
    Summary.sigma_min = min(sigma);
    Summary.sigma_max = max(sigma);
    Summary.fraction_neg135 = mean(abs(wrap_angle_deg(sigma + 135)) <= 15);
    Summary.fraction_pos45 = mean(abs(wrap_angle_deg(sigma - 45)) <= 15);

    % 对偶相关量：没有有限值时统计量保持 NaN，不用 0 代替
    Summary.reg_ratio_median = compute_finite_statistic(@median, reg_ratio);
    Summary.reg_ratio_max = compute_finite_statistic(@max, reg_ratio);
    if any(~isnan(reg_ratio))
        Summary.num_reg_ratio_gt1 = sum(reg_ratio > 1);
    end
    Summary.shift_abs_median = compute_finite_statistic(@median, shift_abs);
    Summary.shift_abs_max = compute_finite_statistic(@max, shift_abs);
    Summary.residual_max_abs = compute_finite_statistic(@max, residual(:));
end


function value = compute_finite_statistic(statistic, values)
% COMPUTE_FINITE_STATISTIC 对非 NaN 的元素求统计量；没有可用元素时返回 NaN。

    values = values(~isnan(values));
    if isempty(values)
        value = NaN;
    else
        value = statistic(values);
    end
end

