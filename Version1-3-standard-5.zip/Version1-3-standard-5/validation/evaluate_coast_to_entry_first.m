function x_in_atm = evaluate_coast_to_entry_first(rv0, P0, ConstData)
% EVALUATE_COAST_TO_ENTRY_FIRST 真空映射：初始点施加 P0 后积分到首次进入大气层。
%
% 输入:
%   rv0 - 1x6 ECI 初始状态 [r, v]（ConstData.rv00）
%   P0  - 初始脉冲（VU）
%
% 输出:
%   x_in_atm - 1x5 第一圈大气入口的 ECF 球坐标状态
%
% 时间链口径：ECF 转换取 gast=0（z 轴旋转对称下与真实转角等价）。

    R_atm = ConstData.R_atm;
    mu = ConstData.mu;
    we = ConstData.we;
    RM = ConstData.RM;
    TU = ConstData.TU;
    J2 = ConstData.J2;

    r0 = rv0(1:3);
    v0 = rv0(4:6);
    v1 = v0 + v0 / norm(v0) * P0;

    opts = odeset('Events', @(t, y) event_atmosphere_entry_rv(t, y, R_atm), ...
        'RelTol', 1e-12, 'AbsTol', 1e-12);
    [~, rv_trans_in] = ode45( ...
        @(t, x) evaluate_vacuum_dynamics(mu, J2, RM, x), ...
        [0, 3000000 / TU], [r0, v1], opts);
    [r_in_atm, v_in_atm] = transform_eci2ecf(0, we, ...
        rv_trans_in(end, 1:3)', rv_trans_in(end, 4:6)');
    x_in_atm = transform_rv2state(r_in_atm, v_in_atm);
    x_in_atm = x_in_atm(1:5);
end
