function TrapezoidSolution = propagate_trapezoid_solution( ...
        AcceptedSolution, ConstData, config)
% PROPAGATE_TRAPEZOID_SOLUTION 从第一圈入口按梯形隐式格式递推整条节点轨迹。
%
% 数学形式:
%   x_(i+1) = x_i + (Δτ_i/2)·t_f,c·[f(x_i,u_i)+f(x_(i+1),u_(i+1))]。
%   x_i 始终取上一步递推值，节点值只作牛顿初值。圈间用原真空映射 G_c
%   作用于递推出口，P_c 取优化解；五维状态的单位与优化变量相同。
%
% 代码形式:
%   保留优化解的控制、时间和网格；state 只在已递推节点填值，未计算节点
%   和区间的 state、step_residual、newton_iterations 均为 NaN。
%   node_deviation 为已递推值减优化节点值，未递推节点保持 NaN。
%   last_completed_node 为最后完成的全局节点号，failing_interval 为失败
%   区间在全部大气区间中的顺序号；失败区间的牛顿残差另存 failure_step_residual。
%   P3 的终端变量 xff、i 和末次脉冲不当作递推值，递推成功后再按原映射重算。
%
% 本函数依次完成：
%   1. 从初始真空映射得到第一圈入口。
%   2. 逐圈、逐区间用牛顿法解隐式梯形方程并衔接下一圈。
%   3. 记录逐步的牛顿残差、递推值与节点值之差和失败状态。

    %% 1. 从初始真空映射得到第一圈入口
    TrapezoidSolution = AcceptedSolution;
    TrapezoidSolution.state = nan(size(AcceptedSolution.state));
    TrapezoidSolution.xff = nan(size(AcceptedSolution.xff));
    TrapezoidSolution.i = NaN;
    TrapezoidSolution.control.P(end) = NaN;
    TrapezoidSolution.state(1, :) = evaluate_coast_to_entry_first( ...
        ConstData.rv00, AcceptedSolution.control.P(1), ConstData);
    interval_count = AcceptedSolution.N - numel(AcceptedSolution.PointsBounds);
    TrapezoidSolution.step_residual = nan(interval_count, 1);
    TrapezoidSolution.newton_iterations = nan(interval_count, 1);
    TrapezoidSolution.last_completed_node = 1;
    TrapezoidSolution.failing_interval = NaN;
    TrapezoidSolution.failure_step_residual = NaN;
    TrapezoidSolution.failure_newton_iterations = NaN;
    TrapezoidSolution.success = false;
    TrapezoidSolution.method = 'trapezoid';
    TrapezoidSolution.failure_reason = '';
    TrapezoidSolution.evaluated = true;

    %% 2. 逐圈、逐区间用牛顿法解隐式梯形方程并衔接下一圈
    row = 0;
    for cir = 1:numel(AcceptedSolution.PointsBounds)
        for i = AcceptedSolution.PointsBounds(cir).begin:( ...
                AcceptedSolution.PointsBounds(cir).end - 1)
            row = row + 1;
            dtau = AcceptedSolution.tau(i + 1) - AcceptedSolution.tau(i);
            step_size = dtau * AcceptedSolution.t_f(cir);
            [next_state, residual, iterations, success] = solve_trapezoid_step( ...
                TrapezoidSolution.state(i, :), AcceptedSolution.state(i + 1, :), ...
                AcceptedSolution.control.u1(i:i + 1), ...
                AcceptedSolution.control.u2(i:i + 1), step_size, ...
                i, ConstData, config.validation);
            if ~success
                % 失败区间只记录牛顿尝试，不把试探值冒充已递推状态或已完成步。
                TrapezoidSolution.failing_interval = row;
                TrapezoidSolution.failure_step_residual = residual;
                TrapezoidSolution.failure_newton_iterations = iterations;
                TrapezoidSolution.failure_reason = 'newton_not_converged';
                TrapezoidSolution.node_deviation = ...
                    TrapezoidSolution.state - AcceptedSolution.state;
                return;
            end
            TrapezoidSolution.step_residual(row) = residual;
            TrapezoidSolution.newton_iterations(row) = iterations;
            TrapezoidSolution.state(i + 1, :) = next_state;
            TrapezoidSolution.last_completed_node = i + 1;
        end
        if cir < numel(AcceptedSolution.PointsBounds)
            exit_state = [ConstData.R_atm, ...
                TrapezoidSolution.state(AcceptedSolution.PointsBounds(cir).end, 2:5), 0];
            next_node = AcceptedSolution.PointsBounds(cir + 1).begin;
            TrapezoidSolution.state(next_node, :) = evaluate_coast_pass_to_entry( ...
                exit_state, AcceptedSolution.control.P(cir + 1), ConstData);
            TrapezoidSolution.last_completed_node = next_node;
        end
    end

    %% 3. 记录逐步的牛顿残差、递推值与节点值之差和失败状态
    TrapezoidSolution.node_deviation = ...
        TrapezoidSolution.state - AcceptedSolution.state;
    TrapezoidSolution.success = true;
end


function [next_state, residual_norm, iterations, success] = solve_trapezoid_step( ...
        previous_state, initial_guess, u1, u2, step_size, node, ConstData, Validation)
% SOLVE_TRAPEZOID_STEP 用解析状态雅可比求解一个五维隐式梯形步。
%
% 牛顿迭代中残差或雅可比出现 NaN/Inf 时直接按未收敛返回，不再解线性方程
% （否则 MATLAB 会打印“矩阵为奇异值…RCOND = NaN”警告）。

    next_state = initial_guess(:)';
    previous_state = previous_state(:)';
    f_previous = evaluate_atmospheric_dynamics( ...
        node, previous_state, u1(1), u2(1), ConstData);
    residual_norm = Inf;
    success = false;
    for iterations = 0:Validation.trapezoid_max_newton_iter
        f_next = evaluate_atmospheric_dynamics( ...
            node + 1, next_state', u1(2), u2(2), ConstData);
        residual = next_state - previous_state ...
            - step_size / 2 * (f_previous(1:5) + f_next(1:5))';
        residual_norm = max(abs(residual));
        if any(~isfinite(residual))
            % 试探点上动力学算不出有限值（max 会忽略 NaN，所以单独判）：
            % 此处的雅可比也不是有限值，再解线性方程只会报 RCOND = NaN
            residual_norm = NaN;
            break;
        end
        if residual_norm <= Validation.trapezoid_step_tolerance
            success = true;
            return;
        end
        if iterations == Validation.trapezoid_max_newton_iter ...
                || any(~isfinite(next_state), 'all')
            break;
        end
        Jacobian = compute_state_jacobian(next_state', u1(2), u2(2), ConstData);
        system_matrix = eye(5) - step_size / 2 * Jacobian;
        if any(~isfinite(system_matrix), 'all')
            break;    % 雅可比含 NaN/Inf：牛顿步无意义，按未收敛处理
        end
        correction = system_matrix \ residual';
        next_state = next_state - correction';
    end
end


function Jacobian = compute_state_jacobian(state, u1, u2, ConstData)
% COMPUTE_STATE_JACOBIAN 复用线性化用的解析偏导，取t_f=1得到原动力学对状态的雅可比。

    r = state(1);
    V = state(2);
    gamma = state(3);
    phi = state(4);
    psi = state(5);
    [~, dr_V, dr_gamma] = linearize_coefficient_drdtau(V, gamma, 1);
    [~, dV_r, dV_V, dV_gamma, dV_phi, dV_psi] = ...
        linearize_coefficient_dVdtau(ConstData, r, V, gamma, phi, psi, 1);
    [~, dg_r, dg_V, dg_gamma, dg_phi, dg_psi] = ...
        linearize_coefficient_dgammadtau(ConstData, r, V, gamma, phi, psi, u1, 1);
    [~, dp_r, dp_V, dp_gamma, dp_psi] = ...
        linearize_coefficient_dphidtau(r, V, gamma, psi, 1);
    [~, ds_r, ds_V, ds_gamma, ds_phi, ds_psi] = ...
        linearize_coefficient_dpsidtau(ConstData, r, V, gamma, phi, psi, u2, 1);
    Jacobian = [ ...
        0, dr_V, dr_gamma, 0, 0; ...
        dV_r, dV_V, dV_gamma, dV_phi, dV_psi; ...
        dg_r, dg_V, dg_gamma, dg_phi, dg_psi; ...
        dp_r, dp_V, dp_gamma, 0, dp_psi; ...
        ds_r, ds_V, ds_gamma, ds_phi, ds_psi];
end
