# Version1-3-standard-3 正则方式长迭代对比

自 `Version1-3-standard-2` 复制（2026-11-16，只复制模块、`SCP.m`、README、知识库；代码与 standard-2 相同，主代码没有改动，`SCP.m` 行为不变）。本版本做一次实验调整：阶段2 的控制正则对比只跑 10 轮，阶段3-1 把同样 21 个工况（sum、u1、u2、norm × w ∈ {1e-2…1e-6}，加 none）迭代到 50 轮，比较相对 none 的总脉冲差随轮次的变化。

实验放在版本目录的 `regularizer_converge/`：入口 `SCP_regularizer_converge.m`，单工况运行 `run_converge_case.m`（流程同 `SCP.m`，每轮加总脉冲平台判断，平台停止直接向 RunState 写停止三项，仅此实验用），指标提取 `extract_converge_metrics.m`，汇总作图 `analyze_regularizer_converge.m`。配置取 `scp_config_default()`，覆盖迭代上限 50、`config.iter.tolerance = 0`（关步长停止）；停止由在线平台判据（最近 5 个被接受轮总脉冲极差 ≤ 0.1 m/s 且 P2 可行）和上限给出。主判据为相对 none 的同轮总脉冲差 d 的稳定（最后 5 轮极差 ≤ 0.1 m/s），原因是试点中绝对总脉冲在 50 轮内不出平台。

数据与结果见 [阶段报告](../Version1-3-standard-3/docs/算法改进_阶段3-1_正则方式长迭代对比.md)，方案与运行方法见 `Version1-3-standard-3/regularizer_converge/README.md`。

2026-11-23 补充第一、二类不紧的诊断：控制报告增加逐节点余量、互补积、抵消和弦向几何量；`tightness_diagnosis/` 对8个代表工况做固定参考的有/无速率约束 A/B。`norm_gap` 目标常数偏置实现已纳入当前源码。默认 `SCP.m` 沿用本次诊断前的入口覆盖（10轮、norm、w_reg=1e-4），速率约束和迭代规则不变；只读诊断不改原21工况数据。阶段报告记录七个聚焦测试及代表工况的观测。

2026-11-24 增加控制正则积分权开关 `control_reg_use_integration_weights`，默认 true；关闭时仅控制正则改为 w_reg·Σ(·)_i。8工况各10轮的对照入口、结果和运行说明在 `regularizer_converge/`，未覆盖原21工况存档；10项聚焦测试通过，默认开启回归逐位一致。数据见阶段报告。
