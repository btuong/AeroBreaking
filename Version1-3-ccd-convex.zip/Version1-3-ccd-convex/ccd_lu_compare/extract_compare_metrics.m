function Metrics = extract_compare_metrics( ...
        Result, RunInfo, case_name, Case, elapsed_seconds)
% EXTRACT_COMPARE_METRICS 从单次工况运行结果提取逐轮与汇总指标，保存为轻量 MAT。
%
% 输入:
%   Result          - run_compare_case 返回的 Result
%   RunInfo         - run_compare_case 返回的运行信息
%   case_name       - 工况名
%   Case            - list_compare_cases 的单条工况配置
%   elapsed_seconds - 工况运行用时 (s)
%
% 输出 Metrics（逐轮字段均为 K x 1，K 为尝试次数；无候选解轮记 NaN）:
%   mode、p、keep_control_bounds、normalize_init、init_control_mode
%   first_status、first_term_code、first_problem_status、first_response_code、first_response_name
%   num_attempted、num_accepted、final_index、status、stop_reason
%   total_impulse_m_s、apoapsis_km、inclination_deg、max_ratio、feasible
%   J、C、Gamma、Theta、delta_L、delta_J、rho
%   max_inward_gap、max_outward_gap、max_tight_gap、max_eps
%   num_untight（>1e-6）、num_untight_1e3（>1e-3）、num_slack_capped、num_bound_active
%   turn_median_deg、circle_predicted、circle_actual、circle_error
%   min_u_norm、max_u_norm、stationarity_max

    History = Result.history;
    K = numel(History);

    Metrics.case_name = case_name;
    Metrics.type = Case.type;
    Metrics.group = Case.group;
    Metrics.w = NaN;
    Metrics.mode = 'ccd_lu';
    Metrics.p = Case.p;
    Metrics.keep_control_bounds = logical(Case.keep_control_bounds);
    Metrics.normalize_init = logical(Case.normalize_init);
    Metrics.init_control_mode = Case.init_control_mode;
    Metrics.elapsed_seconds = elapsed_seconds;

    Metrics.status = Result.status;
    Metrics.stop_reason_raw = Result.stop_reason;
    if strcmp(Result.stop_reason, 'max_iterations')
        Metrics.stop_reason = 'max_iter';
    else
        Metrics.stop_reason = Result.stop_reason;
    end
    Metrics.stop_detail = Result.stop_detail;
    Metrics.num_attempted = Result.num_attempted;
    Metrics.num_accepted = Result.num_accepted;
    if Result.has_accepted_solution
        Metrics.final_index = Result.final_iteration.iter;
    else
        Metrics.final_index = NaN;
    end

    % 记录第 1 轮求解器状态，覆盖 INFEASIBLE 等无解工况
    [first_status, first_term_code, first_problem_status, ...
        first_response_code, first_response_name] = extract_first_solver_info(History);
    Metrics.first_status = first_status;
    Metrics.first_term_code = first_term_code;
    Metrics.first_problem_status = first_problem_status;
    Metrics.first_response_code = first_response_code;
    Metrics.first_response_name = first_response_name;

    Metrics.plateau_start_iter = RunInfo.plateau_start_iter;
    Metrics.plateau_mean_impulse = RunInfo.plateau_mean_impulse;
    Metrics.plateau_range = RunInfo.plateau_range;
    Metrics.iter_seconds = RunInfo.iter_seconds;

    Metrics.accepted = false(K, 1);
    Metrics.candidate_available = false(K, 1);
    Metrics.feasible = false(K, 1);
    Metrics.convex_error_flag = false(K, 1);
    Metrics.convex_error_names = {};
    Metrics.solver_status = repmat({''}, K, 1);
    names = {'total_impulse_m_s', 'apoapsis_km', 'inclination_deg', 'max_ratio', ...
        'J', 'C', 'Gamma', 'Theta', 'delta_L', 'delta_J', 'rho', ...
        'delta_L_gamma', 'delta_J_gamma', 'error_gamma', 'step_max', ...
        'max_tight_gap', 'num_untight', 'num_untight_1e3', 'turn_median_deg', ...
        'max_inward_gap', 'max_outward_gap', 'num_slack_capped', ...
        'num_bound_active', 'circle_predicted', 'circle_actual', ...
        'circle_error', 'max_eps', 'min_u_norm', 'max_u_norm', 'stationarity_max'};
    for n = 1:numel(names)
        Metrics.(names{n}) = nan(K, 1);
    end

    % 转角相对上一接受解；首轮取 Result.initial_reference.control
    previous_control = Result.initial_reference.control;
    if Metrics.normalize_init
        previous_control = normalize_nonzero_control(previous_control);
    end

    for k = 1:K
        Record = History(k);
        if isfield(Record.subproblem, 'solver') && isfield(Record.subproblem.solver, 'status')
            Metrics.solver_status{k} = char(string(Record.subproblem.solver.status));
        end
        Metrics.candidate_available(k) = logical(Record.trust.candidate_available);
        Metrics.accepted(k) = Metrics.candidate_available(k) ...
            && logical(Record.trust.accept_candidate);
        if ~Metrics.candidate_available(k)
            continue;
        end

        P2Feasibility = Record.subproblem.p2_feasibility;
        Metrics.total_impulse_m_s(k) = P2Feasibility.performance_report.value;
        Metrics.apoapsis_km(k) = P2Feasibility.terminal_report.metrics(1).actual_value;
        Metrics.inclination_deg(k) = P2Feasibility.terminal_report.metrics(2).actual_value;
        Metrics.max_ratio(k) = P2Feasibility.max_ratio;
        Metrics.feasible(k) = logical(P2Feasibility.feasible);
        Metrics.step_max(k) = Record.subproblem.convergence_report.max_value;

        ControlReport = Record.subproblem.control_report;
        if ControlReport.evaluated
            Metrics.max_tight_gap(k) = max(abs(ControlReport.tight_gap));
            Metrics.num_untight(k) = sum(abs(ControlReport.tight_gap) > 1e-6);
            Metrics.num_untight_1e3(k) = sum(abs(ControlReport.tight_gap) > 1e-3);
            Metrics.max_inward_gap(k) = ControlReport.summary_total.max_inward_gap;
            Metrics.max_outward_gap(k) = ControlReport.summary_total.max_outward_gap;
            Metrics.num_slack_capped(k) = ControlReport.summary_total.num_slack_capped;
            Metrics.min_u_norm(k) = min(ControlReport.u_norm);
            Metrics.max_u_norm(k) = max(ControlReport.u_norm);
            if any(~isnan(ControlReport.unit_norm_slack))
                Metrics.max_eps(k) = max(ControlReport.unit_norm_slack);
            end
            if ControlReport.dual_available
                Metrics.num_bound_active(k) = ...
                    sum(vecnorm(ControlReport.s_bound, 2, 2) > 1e-6);
                Metrics.stationarity_max(k) = ...
                    max(abs(ControlReport.stationarity_residual), [], 'all');
            end
        end

        Control = Record.solution.control;
        turn_deg = abs(wrap_angle_deg( ...
            atan2d(Control.u2(:), Control.u1(:)) ...
            - atan2d(previous_control.u2(:), previous_control.u1(:))));
        Metrics.turn_median_deg(k) = median(turn_deg);
        if Metrics.accepted(k)
            previous_control = Control;
        end

        Evaluation = Record.trust.evaluation;
        if ~Evaluation.evaluated
            continue;
        end
        Metrics.J(k) = Evaluation.candidate.total;
        Metrics.C(k) = Evaluation.group.cost.candidate;
        Metrics.Gamma(k) = Evaluation.group.extra.candidate;
        Metrics.Theta(k) = Evaluation.group.penalty.candidate;
        Metrics.delta_L(k) = Evaluation.predicted_reduction;
        Metrics.delta_J(k) = Evaluation.actual_reduction;
        Metrics.rho(k) = Evaluation.ratio;
        Metrics.delta_L_gamma(k) = Evaluation.group.extra.predicted;
        Metrics.delta_J_gamma(k) = Evaluation.group.extra.actual;
        Metrics.error_gamma(k) = Evaluation.group.extra.error;
        Metrics.convex_error_flag(k) = Evaluation.convex_error_flag;
        Metrics.convex_error_names = union(Metrics.convex_error_names, ...
            Evaluation.convex_error_names);

        circle_index = find(strcmp(Evaluation.term_names, 'unit_norm_penalty'), 1);
        if ~isempty(circle_index)
            Metrics.circle_predicted(k) = ...
                Evaluation.term_predicted_reduction(circle_index);
            Metrics.circle_actual(k) = ...
                Evaluation.term_actual_reduction(circle_index);
            Metrics.circle_error(k) = Evaluation.term_prediction_error(circle_index);
        end
    end
end


function [first_status, first_term_code, first_problem_status, ...
        first_response_code, first_response_name] = extract_first_solver_info(History)
% EXTRACT_FIRST_SOLVER_INFO 提取第 1 轮求解器的状态与终止码字段。

    first_status = 'not_attempted';
    first_term_code = '';
    first_problem_status = '';
    first_response_code = NaN;
    first_response_name = '';
    if isempty(History) || ~isfield(History(1), 'subproblem') ...
            || ~isfield(History(1).subproblem, 'solver')
        return;
    end
    Solver1 = History(1).subproblem.solver;
    if isfield(Solver1, 'status')
        first_status = char(string(Solver1.status));
    end
    if isfield(Solver1, 'problem_status')
        first_problem_status = char(string(Solver1.problem_status));
    end
    if isfield(Solver1, 'termination_code')
        first_term_code = char(string(Solver1.termination_code));
    else
        first_term_code = first_problem_status;
    end
    if isfield(Solver1, 'response_code')
        first_response_code = Solver1.response_code;
    end
    if isfield(Solver1, 'mosek_report') && isfield(Solver1.mosek_report, 'response_name')
        first_response_name = char(string(Solver1.mosek_report.response_name));
    end
end


function Control = normalize_nonzero_control(Control)
% NORMALIZE_NONZERO_CONTROL 仅对非零节点归一化控制向量，与 initialize_scp_run 一致。

    u1 = Control.u1(:);
    u2 = Control.u2(:);
    norm_u = hypot(u1, u2);
    nonzero = norm_u >= 1e-12;
    u1(nonzero) = u1(nonzero) ./ norm_u(nonzero);
    u2(nonzero) = u2(nonzero) ./ norm_u(nonzero);
    Control.u1 = u1;
    Control.u2 = u2;
end
