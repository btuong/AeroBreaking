function [Summary, Groups, Check, SwitchTests] = analyze_ccd_lu_compare( ...
        results_root, pictures_root, delta, window)
% ANALYZE_CCD_LU_COMPARE 汇总文献 [20] 原文凹凸分解（ccd_lu）对比实验：联合只读 standard-5 存档，检验开关①③④。
%
% 只读加载本实验 12 个 ccd_lu 工况的 case_metrics.mat 与 scp_run_control.mat，并只读引用
% ../Version1-3-standard-5/ccd_compare/results/ 下 5 个基线工况（none、norm_w1e-4、
% normgap_w1e-3..5）与 7 个加权范数 CCD 工况（ccd_p1e-3..1e2、ccdkeep_p1e0），加载时
% 严格校验存档的 version_root 与单位范数模式。
%
% 输入（均可省略）:
%   results_root  - ccd_lu 实验结果目录，默认 <本文件夹>/results
%   pictures_root - 图片输出目录，默认 <本文件夹>/pictures
%   delta         - 差值稳定阈值 δ (m/s)，默认 0.1
%   window        - 末段窗口长度（轮），默认 5
%
% 输出:
%   Summary     - 1 x 24 结构体数组（12 个 ccd_lu + 5 个基线 + 7 个 standard-5 CCD）
%   Groups      - 节点分组与网格粗细/需求密度划分（基于 standard-5/none 末轮）
%   Check       - 版本校验与 ccd_lu 全部可行轮自检
%   SwitchTests - 开关①（E vs D）、开关④（粗细单元失紧与等总权惯性）、开关③（平方下界与衰减）、
%                 初值专项（第 1–10 轮）的全部汇总数据
%   同时写 results/对比汇总.txt、results/对比汇总.mat 与 pictures/ 下对比图。
%
% 本函数依次完成：
%   1. 补路径并确定目录与参数。
%   2. 只读加载 12 个 ccd_lu 工况与 12 个 standard-5 存档并校验版本。
%   3. 按 standard-5 none 末轮划分 E/D 节点组与网格粗细/需求密度子组。
%   4. 计算全部工况的常规末轮指标、E/D 紧性分组与相对基线差值。
%   5. 检验开关①、开关④、开关③与初值专项并自检。
%   6. 写对比汇总文本与 MAT 文件。
%   7. 绘制全部对比图并导出 PNG。

    %% 1. 补路径并确定目录与参数
    compare_root = fileparts(mfilename('fullpath'));
    version_root = fileparts(compare_root);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));
    addpath(fullfile(version_root, 'subproblem'), ...
        fullfile(version_root, 'output'), compare_root);

    if nargin < 1 || isempty(results_root)
        results_root = fullfile(compare_root, 'results');
    end
    if nargin < 2 || isempty(pictures_root)
        pictures_root = fullfile(compare_root, 'pictures');
    end
    if nargin < 3 || isempty(delta)
        delta = 0.1;
    end
    if nargin < 4 || isempty(window)
        window = 5;
    end

    standard5_root = fullfile(fileparts(version_root), ...
        'Version1-3-standard-5', 'ccd_compare', 'results');
    Options = struct( ...
        'delta', delta, ...
        'window', window, ...
        'reference_ccd', 'normgap_w1e-4', ...
        'results_root', results_root, ...
        'standard5_root', standard5_root);

    %% 2. 只读加载 12 个 ccd_lu 工况与 12 个 standard-5 存档并校验版本
    [CaseData, ArchiveChecks] = load_all_compare_data( ...
        results_root, standard5_root);

    %% 3. 按 standard-5 none 末轮划分 E/D 节点组与网格粗细/需求密度子组
    Groups = determine_node_groups(CaseData);

    %% 4. 计算全部工况的常规末轮指标、E/D 紧性分组与相对基线差值
    Summary = compute_all_indicators(CaseData, Groups, Options);
    Summary = add_difference_indicators(Summary, Groups, Options);

    %% 5. 检验开关①、开关④、开关③与初值专项并自检
    Check = run_self_checks(Summary, CaseData, ArchiveChecks);
    SwitchTests = build_switch_tests(CaseData, Summary, Groups, Options);

    %% 6. 写对比汇总文本与 MAT 文件
    if ~isfolder(results_root)
        mkdir(results_root);
    end
    write_compare_summary_text(fullfile(results_root, '对比汇总.txt'), ...
        Summary, Groups, Check, SwitchTests, Options);
    save(fullfile(results_root, '对比汇总.mat'), ...
        'Summary', 'Groups', 'Check', 'SwitchTests', 'Options');

    %% 7. 绘制全部对比图并导出 PNG
    plot_compare_figures(Summary, CaseData, Groups, SwitchTests, ...
        Options, pictures_root);
end


%% ===== 数据加载与版本校验 =====

function [CaseData, ArchiveChecks] = load_all_compare_data( ...
        results_root, standard5_root)
% LOAD_ALL_COMPARE_DATA 加载 12 个 ccd_lu 工况与 12 个 standard-5 存档并校验版本。

    CcdLuCases = list_compare_cases();
    Standard5Specs = list_standard5_archive_specs();

    data_list = cell(1, numel(CcdLuCases) + numel(Standard5Specs));
    archive_checks = cell(1, numel(Standard5Specs));

    for k = 1:numel(CcdLuCases)
        Case = CcdLuCases(k);
        data_list{k} = load_single_case( ...
            Case.name, 'ccd_lu', Case.type, Case.group, NaN, Case.p, ...
            Case.max_iter, Case.keep_control_bounds, Case.normalize_init, ...
            Case.init_control_mode, results_root, ...
            'Version1-3-ccd-convex', 'ccd_lu');
    end

    offset = numel(CcdLuCases);
    for k = 1:numel(Standard5Specs)
        Spec = Standard5Specs(k);
        [Data, CheckItem] = load_single_case( ...
            Spec.name, 'standard-5', Spec.type, Spec.group, Spec.w, Spec.p, ...
            50, Spec.keep, true, 'default', standard5_root, ...
            'Version1-3-standard-5', Spec.expected_mode);
        data_list{offset + k} = Data;
        archive_checks{k} = CheckItem;
    end

    CaseData = [data_list{:}];
    ArchiveChecks = [archive_checks{:}];
end


function Specs = list_standard5_archive_specs()
% LIST_STANDARD5_ARCHIVE_SPECS 列出只读引用的 12 个 standard-5 存档工况规格。

    entries = {
        'none',          'none',     'baseline',     NaN,   NaN,   false, 'regularized'; ...
        'norm_w1e-4',    'norm',     'baseline',     1e-4,  NaN,   false, 'regularized'; ...
        'normgap_w1e-3', 'norm_gap', 'baseline',     1e-3,  NaN,   false, 'regularized'; ...
        'normgap_w1e-4', 'norm_gap', 'baseline',     1e-4,  NaN,   false, 'regularized'; ...
        'normgap_w1e-5', 'norm_gap', 'baseline',     1e-5,  NaN,   false, 'regularized'; ...
        'ccd_p1e-3',     'ccd',      'std5_ccd',     NaN,   1e-3,  false, 'ccd'; ...
        'ccd_p1e-2',     'ccd',      'std5_ccd',     NaN,   1e-2,  false, 'ccd'; ...
        'ccd_p1e-1',     'ccd',      'std5_ccd',     NaN,   1e-1,  false, 'ccd'; ...
        'ccd_p1e0',      'ccd',      'std5_ccd',     NaN,   1e0,   false, 'ccd'; ...
        'ccd_p1e1',      'ccd',      'std5_ccd',     NaN,   1e1,   false, 'ccd'; ...
        'ccd_p1e2',      'ccd',      'std5_ccd',     NaN,   1e2,   false, 'ccd'; ...
        'ccdkeep_p1e0',  'ccd',      'std5_ccdkeep', NaN,   1e0,   true,  'ccd' ...
    };
    spec_list = cell(1, size(entries, 1));
    for k = 1:size(entries, 1)
        spec_list{k} = struct( ...
            'name', entries{k, 1}, ...
            'type', entries{k, 2}, ...
            'group', entries{k, 3}, ...
            'w', entries{k, 4}, ...
            'p', entries{k, 5}, ...
            'keep', entries{k, 6}, ...
            'expected_mode', entries{k, 7});
    end
    Specs = [spec_list{:}];
end


function [Data, ArchiveCheck] = load_single_case( ...
        name, source, type_name, group_name, w, p, max_iter, keep, ...
        normalize_init, init_control_mode, root_dir, ...
        expected_version_root, expected_unit_norm_mode)
% LOAD_SINGLE_CASE 读取单个工况的 case_metrics.mat 与 scp_run_control.mat 并校验版本。

    Data = struct( ...
        'name', name, 'source', source, 'type', type_name, 'group', group_name, ...
        'w', w, 'p', p, 'max_iter', max_iter, 'keep', logical(keep), ...
        'normalize_init', logical(normalize_init), ...
        'init_control_mode', init_control_mode, ...
        'state', 'missing', 'Metrics', [], 'all_attempts', [], ...
        'attempts', [], 'error_message', '');
    ArchiveCheck = struct( ...
        'name', name, 'found', false, 'version_root', '', ...
        'unit_norm_mode', '', 'version_ok', false, 'mode_ok', false);

    case_dir = fullfile(root_dir, name);
    metrics_path = fullfile(case_dir, 'case_metrics.mat');
    control_path = fullfile(case_dir, 'scp_run_control.mat');
    error_path = fullfile(case_dir, 'case_error.txt');

    if isfile(metrics_path) && isfile(control_path)
        Loaded = load(metrics_path);
        Control = load(control_path);
        Export = Control.ControlExport;

        ArchiveCheck.found = true;
        ArchiveCheck.version_root = char(string(Export.version_root));
        ArchiveCheck.unit_norm_mode = char(string(Export.unit_norm_mode));
        ArchiveCheck.version_ok = strcmp(ArchiveCheck.version_root, expected_version_root);
        ArchiveCheck.mode_ok = strcmp(ArchiveCheck.unit_norm_mode, expected_unit_norm_mode);

        if ~ArchiveCheck.version_ok
            error('CCDLuCompare:ArchiveVersionMismatch', ...
                '工况 %s 存档 version_root 应为 %s，实际为 %s。', ...
                name, expected_version_root, ArchiveCheck.version_root);
        end
        if ~ArchiveCheck.mode_ok
            error('CCDLuCompare:ArchiveModeMismatch', ...
                '工况 %s 存档 unit_norm_mode 应为 %s，实际为 %s。', ...
                name, expected_unit_norm_mode, ArchiveCheck.unit_norm_mode);
        end

        Data.Metrics = Loaded.Metrics;
        attempts = Export.attempts;
        Data.all_attempts = attempts;
        if isempty(attempts)
            solved = false(0, 1);
        else
            solved = arrayfun(@(a) logical(a.control_report.evaluated), attempts);
        end
        Data.attempts = attempts(solved);
        if Loaded.Metrics.num_accepted > 0
            Data.state = 'ok';
        else
            Data.state = 'no_solution';
        end
    elseif isfile(error_path)
        Data.state = 'failed';
        Data.error_message = strtrim(fileread(error_path));
    end
end


%% ===== 节点分组与网格切分 =====

function Groups = determine_node_groups(CaseData)
% DETERMINE_NODE_GROUPS 按 standard-5/none 末轮定义 D/E 节点组与网格粗细/需求密度子组。

    Groups = struct( ...
        'available', false, 'N', NaN, 'tau', [], 'cir', [], 'omega', [], ...
        'q', [], 'D', [], 'E', [], 'num_D', NaN, 'num_E', NaN, ...
        'threshold', 1e-6, ...
        'omega_q25', NaN, 'omega_q50', NaN, 'omega_q75', NaN, ...
        'E_fine', [], 'E_coarse', [], 'E_fine_med', [], 'E_coarse_med', [], ...
        'q_q50', NaN, 'q_q75', NaN, 'Q3', [], 'Q4', [], ...
        'Q3_fine', [], 'Q3_coarse', [], 'Q4_fine', [], 'Q4_coarse', [], ...
        'Q3_fine_med', [], 'Q3_coarse_med', [], ...
        'Q4_fine_med', [], 'Q4_coarse_med', [], ...
        'smain_none_E_max', NaN, 'nu_out_none_E_max', NaN);

    none_idx = find(strcmp({CaseData.name}, 'none') & strcmp({CaseData.state}, 'ok'), 1);
    if isempty(none_idx)
        return;
    end
    Report = pick_final_report(CaseData(none_idx));
    Groups.N = Report.num_nodes;
    Groups.tau = Report.tau(:);
    Groups.cir = Report.cir(:);
    Groups.omega = Report.omega(:);
    if ~Report.dual_available
        return;
    end

    Groups.available = true;
    Groups.q = Report.s_main_norm(:) ./ Groups.omega;
    Groups.D = Groups.q < Groups.threshold;
    Groups.E = ~Groups.D;
    Groups.num_D = sum(Groups.D);
    Groups.num_E = sum(Groups.E);

    % 基于 E 节点的 ω_i 划分粗细单元（四分位 + 中位数两种口径）
    omega_E = Groups.omega(Groups.E);
    omega_qs = compute_percentile_set(omega_E, [25, 50, 75]);
    Groups.omega_q25 = omega_qs(1);
    Groups.omega_q50 = omega_qs(2);
    Groups.omega_q75 = omega_qs(3);
    Groups.E_fine = Groups.E & (Groups.omega <= Groups.omega_q25);
    Groups.E_coarse = Groups.E & (Groups.omega >= Groups.omega_q75);
    Groups.E_fine_med = Groups.E & (Groups.omega <= Groups.omega_q50);
    Groups.E_coarse_med = Groups.E & (Groups.omega > Groups.omega_q50);

    % 基于 E 节点的 q_i 划分中高/高需求密度组 Q3（50-75%）与 Q4（75-100%）
    q_E = Groups.q(Groups.E);
    q_qs = compute_percentile_set(q_E, [50, 75]);
    Groups.q_q50 = q_qs(1);
    Groups.q_q75 = q_qs(2);
    Groups.Q3 = Groups.E & (Groups.q >= Groups.q_q50) & (Groups.q < Groups.q_q75);
    Groups.Q4 = Groups.E & (Groups.q >= Groups.q_q75);

    Groups.Q3_fine = Groups.Q3 & Groups.E_fine;
    Groups.Q3_coarse = Groups.Q3 & Groups.E_coarse;
    Groups.Q4_fine = Groups.Q4 & Groups.E_fine;
    Groups.Q4_coarse = Groups.Q4 & Groups.E_coarse;

    Groups.Q3_fine_med = Groups.Q3 & Groups.E_fine_med;
    Groups.Q3_coarse_med = Groups.Q3 & Groups.E_coarse_med;
    Groups.Q4_fine_med = Groups.Q4 & Groups.E_fine_med;
    Groups.Q4_coarse_med = Groups.Q4 & Groups.E_coarse_med;

    Groups.smain_none_E_max = max(Report.s_main_norm(Groups.E));
    Groups.nu_out_none_E_max = max(max(Report.radial_main(Groups.E), 0));
end


function Report = pick_final_report(Data)
% PICK_FINAL_REPORT 取工况最后被接受尝试的 control_report。

    accepted = [Data.attempts.accepted];
    Report = Data.attempts(find(accepted, 1, 'last')).control_report;
end


function Report = pick_attempt_report(Data, iter_idx)
% PICK_ATTEMPT_REPORT 按迭代轮号取出 control_report，缺失或未求解时返回空。

    Report = [];
    if isempty(Data.attempts)
        return;
    end
    iters = [Data.attempts.iter];
    pos = find(iters == iter_idx, 1);
    if ~isempty(pos)
        Report = Data.attempts(pos).control_report;
    end
end


%% ===== 常规与 E/D 指标计算 =====

function Summary = compute_all_indicators(CaseData, Groups, Options)
% COMPUTE_ALL_INDICATORS 计算全部工况的常规指标与 E/D 紧性分组指标。

    max_rounds = max(arrayfun(@count_attempted, CaseData));
    if isempty(max_rounds) || max_rounds < 1
        max_rounds = 1;
    end
    none_idx = find(strcmp({CaseData.name}, 'none') & strcmp({CaseData.state}, 'ok'), 1);
    none_sigma = [];
    if ~isempty(none_idx)
        none_sigma = pick_final_report(CaseData(none_idx)).sigma_deg;
    end

    summary_list = cell(1, numel(CaseData));
    for c = 1:numel(CaseData)
        summary_list{c} = compute_case_indicators(CaseData(c), Groups, ...
            none_sigma, max_rounds, Options);
    end
    Summary = [summary_list{:}];
end


function count = count_attempted(Data)
% COUNT_ATTEMPTED 返回一个工况的尝试轮数。

    if isempty(Data.Metrics) || ~isfield(Data.Metrics, 'num_attempted')
        count = 0;
    else
        count = Data.Metrics.num_attempted;
    end
end


function Indicator = compute_case_indicators(Data, Groups, none_sigma, ...
        max_rounds, Options)
% COMPUTE_CASE_INDICATORS 计算单个工况的运行清单、末轮表、E/D 紧性与乘子统计。

    Indicator = create_empty_indicator(Data, max_rounds);
    if ~isempty(Data.Metrics)
        M = Data.Metrics;
        Indicator.num_attempted = M.num_attempted;
        Indicator.num_accepted = M.num_accepted;
        Indicator.final_iter = M.final_index;
        Indicator.stop_reason = char_or_dash(M.stop_reason);
        Indicator.stop_detail = char_or_dash(M.stop_detail);
        Indicator.plateau_start = M.plateau_start_iter;
        Indicator.elapsed_seconds = M.elapsed_seconds;
        Indicator.mean_round_seconds = mean(M.iter_seconds, 'omitnan');
        if isfield(M, 'first_status')
            Indicator.first_status = char_or_dash(M.first_status);
        elseif ~isempty(Data.all_attempts) && Data.all_attempts(1).control_report.evaluated
            Indicator.first_status = 'OPTIMAL/NEAR';
        end
        if isfield(M, 'first_term_code')
            Indicator.first_term_code = char_or_dash(M.first_term_code);
        end
        if isfield(M, 'first_problem_status')
            Indicator.first_problem_status = char_or_dash(M.first_problem_status);
        end
    end
    if ~strcmp(Data.state, 'ok')
        return;
    end

    Attempts = Data.attempts;
    Metrics = Data.Metrics;
    final_pos = find([Attempts.accepted], 1, 'last');
    Report = Attempts(final_pos).control_report;
    final_iter = Attempts(final_pos).iter;
    window = Options.window;
    E = Groups.E;
    D = Groups.D;

    % 校验各工况积分权与基准网格一致
    if Groups.available && max(abs(Report.omega(:) - Groups.omega(:))) > 1e-12
        error('CCDLuCompare:OmegaMismatch', ...
            '工况 %s 的积分权与 standard-5/none 基准不一致。', Data.name);
    end

    % 逐轮序列
    n_k = numel(Metrics.accepted);
    Indicator.impulse_series = place_series(Metrics.total_impulse_m_s, (1:n_k)', max_rounds);
    Indicator.gap_series = place_series(Metrics.max_tight_gap, (1:n_k)', max_rounds);
    Indicator.eps_series = place_series(Metrics.max_eps, (1:n_k)', max_rounds);
    Indicator.rho_series = place_series(Metrics.rho, (1:n_k)', max_rounds);
    Indicator.circle_error_series = place_series(Metrics.circle_error, (1:n_k)', max_rounds);

    % 总脉冲段
    series = Indicator.impulse_series;
    range_idx = max(1, final_iter - window + 1):final_iter;
    Indicator.impulse_final = series(final_iter);
    Indicator.impulse_mean_last = mean(series(range_idx), 'omitnan');
    Indicator.impulse_range_last = max(series(range_idx), [], 'omitnan') ...
        - min(series(range_idx), [], 'omitnan');
    if final_iter > 10
        Indicator.impulse_decrease_last10 = (series(final_iter - 10) - series(final_iter)) / 10;
    end

    % 全网紧性与边界
    Indicator.gap_final = Metrics.max_tight_gap(final_iter);
    Indicator.gap_max_all = max(Metrics.max_tight_gap, [], 'omitnan');
    Indicator.inward_final = Metrics.max_inward_gap(final_iter);
    Indicator.outward_final = Metrics.max_outward_gap(final_iter);
    Indicator.eps_final = Metrics.max_eps(final_iter);
    Indicator.eps_max_all = max(Metrics.max_eps, [], 'omitnan');
    Indicator.num_untight_final = Metrics.num_untight(final_iter);
    Indicator.num_untight_1e3_final = sum(abs(Report.tight_gap) > 1e-3);
    Indicator.num_capped_final = Report.summary_total.num_slack_capped;
    Indicator.num_capped_max = max(Metrics.num_slack_capped, [], 'omitnan');
    if isnan(Indicator.num_capped_max)
        Indicator.num_capped_max = 0;
    end
    if Report.dual_available
        Indicator.num_bound_active_final = sum(vecnorm(Report.s_bound, 2, 2) > 1e-6);
    end
    u_bound = resolve_u_bound(Data);
    Indicator.num_box_touch_final = sum(max(abs(Report.u1), abs(Report.u2)) >= u_bound - 1e-6);

    % E vs D 分组（末轮 + 全程）
    if Groups.available
        gap_final_vec = abs(Report.tight_gap);
        eps_final_vec = Report.unit_norm_slack;
        Indicator.E_gap_final = max(gap_final_vec(E));
        Indicator.D_gap_final = max(gap_final_vec(D));
        Indicator.E_untight_1e6_final = sum(gap_final_vec(E) > 1e-6);
        Indicator.E_untight_1e3_final = sum(gap_final_vec(E) > 1e-3);
        Indicator.D_untight_1e6_final = sum(gap_final_vec(D) > 1e-6);
        Indicator.D_untight_1e3_final = sum(gap_final_vec(D) > 1e-3);
        if any(~isnan(eps_final_vec))
            Indicator.E_eps_final = max(eps_final_vec(E));
            Indicator.D_eps_final = max(eps_final_vec(D));
        end

        Indicator.E_gap_max_all = max(arrayfun(@(a) max(abs(a.control_report.tight_gap(E))), Attempts));
        Indicator.D_gap_max_all = max(arrayfun(@(a) max(abs(a.control_report.tight_gap(D))), Attempts));
        Indicator.E_untight_1e6_max = max(arrayfun(@(a) sum(abs(a.control_report.tight_gap(E)) > 1e-6), Attempts));
        Indicator.E_untight_1e3_max = max(arrayfun(@(a) sum(abs(a.control_report.tight_gap(E)) > 1e-3), Attempts));
        Indicator.D_untight_1e6_max = max(arrayfun(@(a) sum(abs(a.control_report.tight_gap(D)) > 1e-6), Attempts));
        Indicator.D_untight_1e3_max = max(arrayfun(@(a) sum(abs(a.control_report.tight_gap(D)) > 1e-3), Attempts));
        if any(~isnan(Report.unit_norm_slack))
            Indicator.E_eps_max_all = max(arrayfun(@(a) max(a.control_report.unit_norm_slack(E)), Attempts));
            Indicator.D_eps_max_all = max(arrayfun(@(a) max(a.control_report.unit_norm_slack(D)), Attempts));
            Indicator.E_capped_max = max(arrayfun(@(a) sum(a.control_report.slack_capped(E)), Attempts));
            Indicator.D_capped_max = max(arrayfun(@(a) sum(a.control_report.slack_capped(D)), Attempts));
        else
            Indicator.E_capped_max = 0;
            Indicator.D_capped_max = 0;
        end

        % 非加权单节点需求（未除以 ω_i）
        if Report.dual_available
            Indicator.smain_E_max_final = max(Report.s_main_norm(E));
            Indicator.nu_out_E_max_final = max(max(Report.radial_main(E), 0));
        end
        smain_all = arrayfun(@(a) max_or_nan(a.control_report.s_main_norm(E), ...
            a.control_report.dual_available), Attempts);
        nuout_all = arrayfun(@(a) max_or_nan(max(a.control_report.radial_main(E), 0), ...
            a.control_report.dual_available), Attempts);
        Indicator.smain_E_max_all = max(smain_all, [], 'omitnan');
        Indicator.nu_out_E_max_all = max(nuout_all, [], 'omitnan');
        R1 = pick_attempt_report(Data, 1);
        if ~isempty(R1) && R1.dual_available
            Indicator.smain_E_max_r1 = max(R1.s_main_norm(E));
            Indicator.nu_out_E_max_r1 = max(max(R1.radial_main(E), 0));
        end
    end

    % 圆约束组逐项账与下降比
    Indicator.circle_predicted_final = Metrics.circle_predicted(final_iter);
    Indicator.circle_actual_final = Metrics.circle_actual(final_iter);
    Indicator.circle_error_final = Metrics.circle_error(final_iter);
    Indicator.circle_error_absmax = max(abs(Metrics.circle_error), [], 'omitnan');
    Indicator.rho_mean_last = mean(Metrics.rho(range_idx), 'omitnan');
    Indicator.delta_L_mean_last = mean(Metrics.delta_L(range_idx), 'omitnan');
    Indicator.delta_J_mean_last = mean(Metrics.rho(range_idx) .* Metrics.delta_L(range_idx), 'omitnan');

    % 乘子统计与 σ 偏差
    if Report.dual_available
        omega = Report.omega;
        Indicator.kappa_stats = describe_values(Report.cone_dual_leading(E) ./ omega(E));
        Indicator.smain_stats = describe_values(Report.s_main_norm(E) ./ omega(E));
        Indicator.smain_raw_stats = describe_values(Report.s_main_norm(E));
        if is_ccd_mode(Data.type)
            Indicator.lambda_inner_stats = describe_values(Report.lambda_inner(E) ./ omega(E));
        end
    end
    Indicator.final_sigma = Report.sigma_deg;
    if ~isempty(none_sigma) && Groups.available
        dev = abs(wrap_angle_deg(Indicator.final_sigma - none_sigma));
        Indicator.sigma_dev_E_median = median(dev(E));
        Indicator.sigma_dev_D_median = median(dev(D));
    end

    % 自检原始量
    Indicator.min_u_norm_all = min(arrayfun(@(a) min(a.control_report.u_norm), Attempts));
    Indicator.max_u_norm_all = max(arrayfun(@(a) max(a.control_report.u_norm), Attempts));
    stat_vals = arrayfun(@(a) max_stationarity(a.control_report), Attempts);
    Indicator.stationarity_max = max(stat_vals, [], 'omitnan');
    Indicator.final_report_ok = Report.evaluated;
end


function val = max_or_nan(values, flag)
% MAX_OR_NAN 标志为真时返回最大值，否则返回 NaN。

    if flag
        val = max(values);
    else
        val = NaN;
    end
end


function val = max_stationarity(Report)
% MAX_STATIONARITY 取单轮最大驻点残差；对偶不可用时返回 NaN。

    if Report.dual_available
        val = max(abs(Report.stationarity_residual), [], 'all');
    else
        val = NaN;
    end
end


function u_bound = resolve_u_bound(Data)
% RESOLVE_U_BOUND 返回工况对应的控制量箱形边界绝对值上限。

    if is_ccd_mode(Data.type) && ~Data.keep
        u_bound = 2;
    else
        u_bound = 1;
    end
end


function tf = is_ccd_mode(type_name)
% IS_CCD_MODE 判断是否属于 CCD 凹凸分解模式（ccd_lu 或 ccd）。

    tf = strcmp(type_name, 'ccd_lu') || strcmp(type_name, 'ccd');
end


function Indicator = create_empty_indicator(Data, max_rounds)
% CREATE_EMPTY_INDICATOR 创建字段齐全的空工况指标结构。

    empty_stats = struct('median', NaN, 'p5', NaN, 'p95', NaN, 'min', NaN, 'max', NaN);
    Indicator = struct( ...
        'name', Data.name, 'source', Data.source, 'type', Data.type, ...
        'group', Data.group, 'w', Data.w, 'p', Data.p, ...
        'max_iter', Data.max_iter, 'keep', Data.keep, ...
        'normalize_init', Data.normalize_init, ...
        'init_control_mode', Data.init_control_mode, ...
        'state', Data.state, 'error_message', Data.error_message, ...
        'num_attempted', NaN, 'num_accepted', NaN, 'final_iter', NaN, ...
        'stop_reason', '-', 'stop_detail', '-', ...
        'first_status', '-', 'first_term_code', '-', 'first_problem_status', '-', ...
        'plateau_start', NaN, 'elapsed_seconds', NaN, 'mean_round_seconds', NaN, ...
        'impulse_series', nan(max_rounds, 1), 'gap_series', nan(max_rounds, 1), ...
        'eps_series', nan(max_rounds, 1), 'rho_series', nan(max_rounds, 1), ...
        'circle_error_series', nan(max_rounds, 1), ...
        'impulse_final', NaN, 'impulse_mean_last', NaN, ...
        'impulse_range_last', NaN, 'impulse_decrease_last10', NaN, ...
        'gap_final', NaN, 'gap_max_all', NaN, ...
        'inward_final', NaN, 'outward_final', NaN, ...
        'eps_final', NaN, 'eps_max_all', NaN, ...
        'num_untight_final', NaN, 'num_untight_1e3_final', NaN, ...
        'num_capped_final', NaN, 'num_capped_max', NaN, ...
        'num_bound_active_final', NaN, 'num_box_touch_final', NaN, ...
        'E_gap_final', NaN, 'E_gap_max_all', NaN, ...
        'D_gap_final', NaN, 'D_gap_max_all', NaN, ...
        'E_eps_final', NaN, 'E_eps_max_all', NaN, ...
        'D_eps_final', NaN, 'D_eps_max_all', NaN, ...
        'E_untight_1e6_final', NaN, 'E_untight_1e3_final', NaN, ...
        'E_untight_1e6_max', NaN, 'E_untight_1e3_max', NaN, ...
        'D_untight_1e6_final', NaN, 'D_untight_1e3_final', NaN, ...
        'D_untight_1e6_max', NaN, 'D_untight_1e3_max', NaN, ...
        'E_capped_max', NaN, 'D_capped_max', NaN, ...
        'smain_E_max_r1', NaN, 'nu_out_E_max_r1', NaN, ...
        'smain_E_max_final', NaN, 'nu_out_E_max_final', NaN, ...
        'smain_E_max_all', NaN, 'nu_out_E_max_all', NaN, ...
        'circle_predicted_final', NaN, 'circle_actual_final', NaN, ...
        'circle_error_final', NaN, 'circle_error_absmax', NaN, ...
        'rho_mean_last', NaN, 'delta_L_mean_last', NaN, 'delta_J_mean_last', NaN, ...
        'kappa_stats', empty_stats, 'smain_stats', empty_stats, ...
        'smain_raw_stats', empty_stats, 'lambda_inner_stats', empty_stats, ...
        'final_sigma', [], 'sigma_dev_E_median', NaN, 'sigma_dev_D_median', NaN, ...
        'sigma_ref_E_median', NaN, 'd_ref_final', NaN, ...
        'd_series', nan(max_rounds, 1), 'd_final', NaN, ...
        'd_mean_last', NaN, 'd_range_last', NaN, ...
        'd_stable', NaN, 'd_stable_round', NaN, ...
        'min_u_norm_all', NaN, 'max_u_norm_all', NaN, ...
        'stationarity_max', NaN, 'final_report_ok', false);
end


function Summary = add_difference_indicators(Summary, Groups, Options)
% ADD_DIFFERENCE_INDICATORS 计算相对 none 与相对 normgap_w1e-4 的总脉冲差及稳定性。

    ItemList = arrayfun(@(S) S, Summary, 'UniformOutput', false);
    names = {Summary.name};
    none_idx = find(strcmp(names, 'none') & strcmp({Summary.state}, 'ok'), 1);
    ref_idx = find(strcmp(names, Options.reference_ccd) & strcmp({Summary.state}, 'ok'), 1);

    for c = 1:numel(ItemList)
        if ~strcmp(Summary(c).state, 'ok')
            continue;
        end
        S = Summary(c);
        if ~isempty(none_idx)
            S = fill_difference(S, S.impulse_series - Summary(none_idx).impulse_series, ...
                '', Options);
        end
        if is_ccd_mode(S.type) && ~isempty(ref_idx)
            diff_ref = S.impulse_series - Summary(ref_idx).impulse_series;
            S.d_ref_final = diff_ref(S.final_iter);
            if Groups.available && ~isempty(Summary(ref_idx).final_sigma)
                dev = abs(wrap_angle_deg(S.final_sigma - Summary(ref_idx).final_sigma));
                S.sigma_ref_E_median = median(dev(Groups.E));
            end
        end
        ItemList{c} = S;
    end
    Summary = [ItemList{:}];
end


function S = fill_difference(S, difference, tag, Options)
% FILL_DIFFERENCE 由差值序列填末轮值、末段极差与稳定轮。

    final_iter = S.final_iter;
    range_idx = max(1, final_iter - Options.window + 1):final_iter;
    last_values = difference(range_idx);
    S.(['d' tag '_series']) = difference;
    S.(['d' tag '_final']) = difference(final_iter);
    S.(['d' tag '_mean_last']) = mean(last_values, 'omitnan');
    S.(['d' tag '_range_last']) = max(last_values, [], 'omitnan') ...
        - min(last_values, [], 'omitnan');
    S.(['d' tag '_stable']) = double(S.(['d' tag '_range_last']) <= Options.delta);
    within = abs(difference(1:final_iter) - difference(final_iter)) <= Options.delta;
    last_outside = find(~within & ~isnan(difference(1:final_iter)), 1, 'last');
    if isempty(last_outside)
        S.(['d' tag '_stable_round']) = 1;
    else
        S.(['d' tag '_stable_round']) = last_outside + 1;
    end
end


%% ===== 自检与开关①③④专项分析 =====

function Check = run_self_checks(Summary, ~, ArchiveChecks)
% RUN_SELF_CHECKS 校验 standard-5 存档版本与全部 ccd_lu 可行轮自检指标。

    Check.archive_checks = ArchiveChecks;
    Check.archive_all_found = all([ArchiveChecks.found]);
    Check.archive_all_version_ok = all([ArchiveChecks.version_ok]);
    Check.archive_all_mode_ok = all([ArchiveChecks.mode_ok]);

    is_ccd_lu = strcmp({Summary.type}, 'ccd_lu') & strcmp({Summary.state}, 'ok');
    LuOk = Summary(is_ccd_lu);
    Check.ccd_lu_num_ok = numel(LuOk);
    Check.ccd_lu_circle_error_max = max([LuOk.circle_error_absmax]);
    Check.ccd_lu_stationarity_max = max([LuOk.stationarity_max]);
    Check.ccd_lu_min_u_norm = min([LuOk.min_u_norm_all]);
    Check.ccd_lu_max_u_norm = max([LuOk.max_u_norm_all]);
end


function SwitchTests = build_switch_tests(CaseData, Summary, Groups, Options)
% BUILD_SWITCH_TESTS 计算开关①、开关④、开关③与初值专项的全部数值结果。

    SwitchTests.switch1 = evaluate_switch1(Summary, Groups);
    SwitchTests.switch4_coarse = evaluate_switch4_coarse(CaseData, Groups);
    SwitchTests.switch4_inertia = evaluate_switch4_inertia(CaseData, Groups);
    SwitchTests.switch3 = evaluate_switch3(CaseData, Summary);
    SwitchTests.init_study = evaluate_init_study(CaseData, Summary, Options);
end


function Switch1 = evaluate_switch1(Summary, Groups)
% EVALUATE_SWITCH1 开关①：统计欠罚档局部 E 节点失紧与 D 节点紧性，对比非加权单节点门槛。

    under_names = {'ccd_lu_p1e-5', 'ccd_lu_p1e-4', 'ccd_lu_peq_1e-1', ...
        'ccd_lu_p1e-3', 'ccd_lu_peq_1e0', 'ccd_lu_p1e-2'};
    rows = cell(1, numel(under_names));
    for k = 1:numel(under_names)
        idx = find(strcmp({Summary.name}, under_names{k}), 1);
        S = Summary(idx);
        rows{k} = struct( ...
            'name', S.name, 'p', S.p, ...
            'E_eps_final', S.E_eps_final, 'E_eps_max_all', S.E_eps_max_all, ...
            'E_untight_1e6_final', S.E_untight_1e6_final, ...
            'E_untight_1e3_final', S.E_untight_1e3_final, ...
            'E_untight_1e6_max', S.E_untight_1e6_max, ...
            'E_untight_1e3_max', S.E_untight_1e3_max, ...
            'D_eps_final', S.D_eps_final, 'D_eps_max_all', S.D_eps_max_all, ...
            'D_gap_final', S.D_gap_final, 'D_gap_max_all', S.D_gap_max_all, ...
            'D_untight_1e6_final', S.D_untight_1e6_final, ...
            'D_untight_1e6_max', S.D_untight_1e6_max, ...
            'smain_E_max_r1', S.smain_E_max_r1, ...
            'nu_out_E_max_r1', S.nu_out_E_max_r1, ...
            'smain_E_max_final', S.smain_E_max_final, ...
            'nu_out_E_max_final', S.nu_out_E_max_final, ...
            'smain_E_max_all', S.smain_E_max_all, ...
            'nu_out_E_max_all', S.nu_out_E_max_all);
    end
    Switch1.under_table = [rows{:}];
    Switch1.none_smain_E_max = Groups.smain_none_E_max;
    Switch1.none_nu_out_E_max = Groups.nu_out_none_E_max;
end


function CoarseResult = evaluate_switch4_coarse(CaseData, Groups)
% EVALUATE_SWITCH4_COARSE 开关④(a)：统计欠罚/临界档失紧节点在粗/细单元上的分布与 ω 中位数比。

    target_names = {'ccd_lu_p1e-5', 'ccd_lu_p1e-4', 'ccd_lu_peq_1e-1', ...
        'ccd_lu_p1e-3', 'ccd_lu_peq_1e0', 'ccd_lu_p1e-2', ...
        'ccd_p1e-3', 'ccd_p1e-2', 'ccd_p1e-1', 'ccd_p1e0'};
    thresholds = [1e-3, 1e-4];
    rows = {};
    omega_E_median = median(Groups.omega(Groups.E));

    for k = 1:numel(target_names)
        idx = find(strcmp({CaseData.name}, target_names{k}), 1);
        Data = CaseData(idx);
        if ~strcmp(Data.state, 'ok')
            continue;
        end
        final_iter = Data.Metrics.final_index;
        [peak_1e4_iter, onset_1e4_iter] = find_representative_untight_rounds( ...
            Data, Groups, 1e-4);
        round_specs = { ...
            'round1', 1; ...
            'onset_1e4', onset_1e4_iter; ...
            'peak_1e4', peak_1e4_iter; ...
            'final', final_iter};
        for r = 1:size(round_specs, 1)
            iter_num = round_specs{r, 2};
            if isnan(iter_num)
                continue;
            end
            Report = pick_attempt_report(Data, iter_num);
            if isempty(Report)
                continue;
            end
            for t = 1:numel(thresholds)
                tol = thresholds(t);
                untight_E = Groups.E & (Report.unit_norm_slack > tol);
                n_total = sum(untight_E);
                n_coarse = sum(untight_E & Groups.E_coarse);
                n_fine = sum(untight_E & Groups.E_fine);
                n_coarse_med = sum(untight_E & Groups.E_coarse_med);
                n_fine_med = sum(untight_E & Groups.E_fine_med);
                if n_total > 0
                    omega_untight_med = median(Groups.omega(untight_E));
                    omega_ratio = omega_untight_med / omega_E_median;
                else
                    omega_untight_med = NaN;
                    omega_ratio = NaN;
                end
                rows{end + 1} = struct( ... %#ok<AGROW>
                    'name', Data.name, 'source', Data.source, 'p', Data.p, ...
                    'checkpoint', round_specs{r, 1}, 'iter', iter_num, ...
                    'threshold', tol, 'n_E_untight', n_total, ...
                    'n_coarse', n_coarse, 'n_coarse_total', sum(Groups.E_coarse), ...
                    'pct_coarse', 100 * n_coarse / sum(Groups.E_coarse), ...
                    'n_fine', n_fine, 'n_fine_total', sum(Groups.E_fine), ...
                    'pct_fine', 100 * n_fine / sum(Groups.E_fine), ...
                    'n_coarse_med', n_coarse_med, ...
                    'pct_coarse_med', 100 * n_coarse_med / sum(Groups.E_coarse_med), ...
                    'n_fine_med', n_fine_med, ...
                    'pct_fine_med', 100 * n_fine_med / sum(Groups.E_fine_med), ...
                    'omega_untight_median', omega_untight_med, ...
                    'omega_E_median', omega_E_median, ...
                    'omega_median_ratio', omega_ratio, ...
                    'omega_untight_values', Groups.omega(untight_E));
            end
        end
    end

    CoarseResult.omega_E_median = omega_E_median;
    CoarseResult.rows = [rows{:}];
end


function [peak_iter, onset_iter] = find_representative_untight_rounds(Data, Groups, tol)
% FIND_REPRESENTATIVE_UNTIGHT_ROUNDS 找到失紧节点数最多和首次出现 ≥ 3 个失紧节点的轮号。

    counts = arrayfun(@(a) sum(Groups.E & (a.control_report.unit_norm_slack > tol)), ...
        Data.attempts);
    iters = [Data.attempts.iter];
    [max_count, pos] = max(counts);
    if max_count > 0
        peak_iter = iters(pos);
    else
        peak_iter = NaN;
    end
    onset_pos = find(counts >= 3, 1, 'first');
    if isempty(onset_pos)
        onset_pos = find(counts >= 1, 1, 'first');
    end
    if isempty(onset_pos)
        onset_iter = NaN;
    else
        onset_iter = iters(onset_pos);
    end
end


function InertiaResult = evaluate_switch4_inertia(CaseData, Groups)
% EVALUATE_SWITCH4_INERTIA 开关④(b)：等总权配对与相近有效权配对在第 10/50 轮的脉冲与细/粗单元倾侧角惯性对比。

    pair_names = { ...
        '等总权 0.5',    'ccd_lu_peq_1e-1', 'ccd_p1e-1'; ...
        '等总权 5.0',    'ccd_lu_peq_1e0',  'ccd_p1e0'; ...
        '相近有效权',    'ccd_lu_p1e-2',    'ccd_p1e0'};
    none_idx = find(strcmp({CaseData.name}, 'none'), 1);
    NoneData = CaseData(none_idx);
    NoneFinalReport = pick_final_report(NoneData);
    none_sigma_final = NoneFinalReport.sigma_deg;
    none_imp_10 = NoneData.Metrics.total_impulse_m_s(10);
    none_imp_50 = NoneData.Metrics.total_impulse_m_s(NoneData.Metrics.final_index);

    unique_cases = unique([pair_names(:, 2); pair_names(:, 3)], 'stable');
    case_rows = cell(1, numel(unique_cases));
    for k = 1:numel(unique_cases)
        case_rows{k} = compute_inertia_case_detail( ...
            CaseData(strcmp({CaseData.name}, unique_cases{k})), ...
            Groups, none_sigma_final, none_imp_10, none_imp_50);
    end

    InertiaResult.pair_specs = pair_names;
    InertiaResult.none_impulse_10 = none_imp_10;
    InertiaResult.none_impulse_50 = none_imp_50;
    InertiaResult.cases = [case_rows{:}];
end


function Detail = compute_inertia_case_detail(Data, Groups, none_sigma_final, ...
        none_imp_10, none_imp_50)
% COMPUTE_INERTIA_CASE_DETAIL 计算单个配对工况在第 10 轮与末轮（第 50 轮）的脉冲及各子组中位 |Δσ|。

    R10 = pick_attempt_report(Data, 10);
    R50 = pick_final_report(Data);
    final_iter = Data.Metrics.final_index;

    imp_10 = Data.Metrics.total_impulse_m_s(10);
    imp_50 = Data.Metrics.total_impulse_m_s(final_iter);

    Detail.name = Data.name;
    Detail.source = Data.source;
    Detail.type = Data.type;
    Detail.p = Data.p;
    Detail.final_iter = final_iter;
    Detail.impulse_10 = imp_10;
    Detail.d_none_10 = imp_10 - none_imp_10;
    Detail.impulse_50 = imp_50;
    Detail.d_none_50 = imp_50 - none_imp_50;

    if strcmp(Data.type, 'ccd_lu')
        Detail.total_weight = Data.p * Groups.N;
        rho_eff = Data.p ./ Groups.omega;
    else
        Detail.total_weight = Data.p * sum(Groups.omega);
        rho_eff = Data.p * ones(Groups.N, 1);
    end
    Detail.eff_weight_E_median = median(rho_eff(Groups.E));
    Detail.eff_weight_fine_median = median(rho_eff(Groups.E_fine));
    Detail.eff_weight_coarse_median = median(rho_eff(Groups.E_coarse));
    Detail.eff_weight_D_median = median(rho_eff(Groups.D));

    subgroup_names = {'E', 'E_fine', 'E_coarse', 'E_fine_med', 'E_coarse_med', ...
        'Q3', 'Q3_fine', 'Q3_coarse', 'Q3_fine_med', 'Q3_coarse_med', ...
        'Q4', 'Q4_fine', 'Q4_coarse', 'Q4_fine_med', 'Q4_coarse_med'};

    dev_r10_none = abs(wrap_angle_deg(R10.sigma_deg - none_sigma_final));
    dev_r50_none = abs(wrap_angle_deg(R50.sigma_deg - none_sigma_final));
    dev_r10_self50 = abs(wrap_angle_deg(R10.sigma_deg - R50.sigma_deg));

    for s = 1:numel(subgroup_names)
        key = subgroup_names{s};
        mask = Groups.(key);
        Detail.r10_vs_none.(key) = median(dev_r10_none(mask));
        Detail.r50_vs_none.(key) = median(dev_r50_none(mask));
        Detail.r10_vs_self50.(key) = median(dev_r10_self50(mask));
    end
end


function Switch3 = evaluate_switch3(CaseData, Summary)
% EVALUATE_SWITCH3 开关③：平方内逼近第 2 轮模长下界检验及第 1–5 轮平方 vs 范数对比。

    lb_names = {'ccd_lu_p1e-5', 'ccd_lu_p1e-4', 'ccd_lu_peq_1e-1', ...
        'ccd_lu_p1e-3', 'ccd_lu_peq_1e0', 'ccd_lu_p1e-2', ...
        'ccd_lu_p1e-1', 'ccd_lu_p1e0', 'ccd_lukeep_p1e-2'};
    lb_rows = cell(1, 0);
    for k = 1:numel(lb_names)
        idx = find(strcmp({CaseData.name}, lb_names{k}), 1);
        Data = CaseData(idx);
        R1 = pick_attempt_report(Data, 1);
        R2 = pick_attempt_report(Data, 2);
        if isempty(R1) || isempty(R2)
            continue;
        end
        u1_norm = R1.u_norm(:);
        u2_norm = R2.u_norm(:);
        lb2 = (1 + u1_norm.^2) ./ (2 * u1_norm);
        diff_all = u2_norm - lb2;

        shift_1e3 = (u1_norm - 1) > 1e-3;
        shift_1e2 = (u1_norm - 1) > 1e-2;
        [max_u1, peak_idx] = max(u1_norm);

        Row = struct( ...
            'name', Data.name, 'p', Data.p, ...
            'max_u1_norm', max_u1, 'max_eps1', max(R1.unit_norm_slack), ...
            'peak_node', peak_idx, ...
            'peak_lb2', lb2(peak_idx), ...
            'peak_u2_norm', u2_norm(peak_idx), ...
            'peak_diff', u2_norm(peak_idx) - lb2(peak_idx), ...
            'all_min_diff', min(diff_all), ...
            'n_shift_1e3', sum(shift_1e3), ...
            'min_u2_shift_1e3', masked_stat(u2_norm, shift_1e3, @min), ...
            'min_lb2_shift_1e3', masked_stat(lb2, shift_1e3, @min), ...
            'max_lb2_shift_1e3', masked_stat(lb2, shift_1e3, @max), ...
            'min_diff_shift_1e3', masked_stat(diff_all, shift_1e3, @min), ...
            'n_shift_1e2', sum(shift_1e2), ...
            'min_u2_shift_1e2', masked_stat(u2_norm, shift_1e2, @min), ...
            'min_lb2_shift_1e2', masked_stat(lb2, shift_1e2, @min), ...
            'max_lb2_shift_1e2', masked_stat(lb2, shift_1e2, @max), ...
            'min_diff_shift_1e2', masked_stat(diff_all, shift_1e2, @min));
        lb_rows{end + 1} = Row; %#ok<AGROW>
    end

    decay_names = {'ccd_lu_peq_1e-1', 'ccd_p1e-1', ...
        'ccd_lu_peq_1e0', 'ccd_p1e0', 'ccd_lu_p1e-2'};
    decay_rows = cell(1, 0);
    for k = 1:numel(decay_names)
        idx = find(strcmp({Summary.name}, decay_names{k}), 1);
        if isempty(idx) || ~strcmp(Summary(idx).state, 'ok')
            continue;
        end
        S = Summary(idx);
        decay_rows{end + 1} = struct( ... %#ok<AGROW>
            'name', S.name, 'source', S.source, 'p', S.p, ...
            'gap_r1_5', S.gap_series(1:5).', ...
            'circle_error_r1_5', S.circle_error_series(1:5).', ...
            'circle_error_absmax', S.circle_error_absmax);
    end

    Switch3.lower_bound = [lb_rows{:}];
    Switch3.decay_r1_5 = [decay_rows{:}];
end


function val = masked_stat(vec, mask, fn)
% MASKED_STAT 在非空逻辑掩码上求统计量，空掩码返回 NaN。

    if any(mask)
        val = fn(vec(mask));
    else
        val = NaN;
    end
end


function InitStudy = evaluate_init_study(CaseData, Summary, ~)
% EVALUATE_INIT_STUDY 整理 3 个初值专项工况第 1–10 轮数据及圆内初值下界验证。

    init_names = {'ccd_lu_init0_p1e-2', 'ccd_lu_init0p3_nonorm_p1e-2', ...
        'ccd_lu_init0p3_nonorm_keep_p1e-2'};
    overview = cell(1, numel(init_names));
    for k = 1:numel(init_names)
        s_idx = find(strcmp({Summary.name}, init_names{k}), 1);
        d_idx = find(strcmp({CaseData.name}, init_names{k}), 1);
        S = Summary(s_idx);
        Data = CaseData(d_idx);
        M = Data.Metrics;

        r1_impulse = NaN;
        r1_delta_L = NaN;
        r1_rho = NaN;
        r1_min_u = NaN;
        r1_max_u = NaN;
        r1_max_eps = NaN;
        r1_capped = NaN;
        r1_box_touch = NaN;
        r1_step_max = NaN;
        if ~isempty(M) && M.num_attempted >= 1 && M.candidate_available(1)
            r1_impulse = M.total_impulse_m_s(1);
            r1_delta_L = M.delta_L(1);
            r1_rho = M.rho(1);
            r1_min_u = M.min_u_norm(1);
            r1_max_u = M.max_u_norm(1);
            r1_max_eps = M.max_eps(1);
            r1_capped = M.num_slack_capped(1);
            r1_step_max = M.step_max(1);
            R1 = pick_attempt_report(Data, 1);
            if ~isempty(R1)
                u_bound = resolve_u_bound(Data);
                r1_box_touch = sum(max(abs(R1.u1), abs(R1.u2)) >= u_bound - 1e-6);
            end
        end

        overview{k} = struct( ...
            'name', S.name, 'init_control_mode', S.init_control_mode, ...
            'normalize_init', S.normalize_init, 'keep', S.keep, ...
            'num_attempted', S.num_attempted, 'num_accepted', S.num_accepted, ...
            'first_status', S.first_status, 'first_term_code', S.first_term_code, ...
            'stop_reason', S.stop_reason, 'stop_detail', S.stop_detail, ...
            'r1_impulse', r1_impulse, 'r1_delta_L', r1_delta_L, 'r1_rho', r1_rho, ...
            'r1_min_u', r1_min_u, 'r1_max_u', r1_max_u, 'r1_max_eps', r1_max_eps, ...
            'r1_capped', r1_capped, 'r1_box_touch', r1_box_touch, ...
            'r1_step_max', r1_step_max);
    end

    % ccd_lu_init0p3_nonorm_p1e-2 的第 1-10 轮逐轮表
    nonorm_idx = find(strcmp({CaseData.name}, 'ccd_lu_init0p3_nonorm_p1e-2'), 1);
    NonormData = CaseData(nonorm_idx);
    M = NonormData.Metrics;
    rounds = cell(M.num_attempted, 1);
    for k = 1:M.num_attempted
        Rk = pick_attempt_report(NonormData, k);
        box_touch = NaN;
        if ~isempty(Rk)
            box_touch = sum(max(abs(Rk.u1), abs(Rk.u2)) >= 2 - 1e-6);
        end
        rounds{k} = struct( ...
            'iter', k, 'status', M.solver_status{k}, ...
            'impulse', M.total_impulse_m_s(k), ...
            'delta_L', M.delta_L(k), 'rho', M.rho(k), ...
            'step_max', M.step_max(k), ...
            'min_u_norm', M.min_u_norm(k), 'max_u_norm', M.max_u_norm(k), ...
            'max_eps', M.max_eps(k), 'num_capped', M.num_slack_capped(k), ...
            'num_box_touch', box_touch, 'feasible', M.feasible(k));
    end

    InitStudy.overview = [overview{:}];
    InitStudy.nonorm_lb_r1 = (1 + 0.3^2) / (2 * 0.3);
    InitStudy.nonorm_rounds = [rounds{:}];
end


%% ===== 汇总文本输出 =====

function write_compare_summary_text(text_path, Summary, Groups, Check, ...
        SwitchTests, Options)
% WRITE_COMPARE_SUMMARY_TEXT 按规格要求写 6 节对比汇总文本。

    file_id = fopen(text_path, 'w', 'n', 'UTF-8');
    cleanup = onCleanup(@() fclose(file_id));

    write_sec1_run_list(file_id, Summary);
    write_sec2_validation_and_self_check(file_id, Check);
    write_sec3_final_and_switch1(file_id, Summary, Groups, SwitchTests.switch1);
    write_sec4_switch4_weighting(file_id, Groups, SwitchTests.switch4_coarse, ...
        SwitchTests.switch4_inertia);
    write_sec5_switch3_square(file_id, SwitchTests.switch3);
    write_sec6_init_study(file_id, SwitchTests.init_study);

    fprintf(file_id, ['\n（δ = %g m/s，window = %d；基准分组来自 standard-5/none 末轮: ' ...
        '|D| = %g，|E| = %g，|E_fine| = %g，|E_coarse| = %g，|Q3| = %g，|Q4| = %g）\n'], ...
        Options.delta, Options.window, Groups.num_D, Groups.num_E, ...
        sum(Groups.E_fine), sum(Groups.E_coarse), sum(Groups.Q3), sum(Groups.Q4));
end


function write_sec1_run_list(file_id, Summary)
% WRITE_SEC1_RUN_LIST 第 1 节：24 个工况运行清单（含不可行工况首轮状态）。

    fprintf(file_id, '=== 1 运行清单 ===\n');
    headers = {'工况', '来源', 'w 或 p', '上限', '尝试', '接受', ...
        '首轮状态', '停止原因', '用时 (s)', '末轮总脉冲 (m/s)'};
    rows = cell(numel(Summary), 10);
    for c = 1:numel(Summary)
        S = Summary(c);
        if is_ccd_mode(S.type)
            coef = sprintf('p=%.4g', S.p);
        elseif isnan(S.w)
            coef = '-';
        else
            coef = sprintf('w=%.0e', S.w);
        end
        rows(c, :) = {S.name, S.source, coef, format_val(S.max_iter, '%d'), ...
            format_val(S.num_attempted, '%d'), format_val(S.num_accepted, '%d'), ...
            S.first_status, S.stop_reason, format_val(S.elapsed_seconds, '%.1f'), ...
            format_val(S.impulse_final, '%.4f')};
    end
    write_table(file_id, headers, rows);

    no_sol = Summary(strcmp({Summary.state}, 'no_solution'));
    if ~isempty(no_sol)
        fprintf(file_id, '\n无接受解（no_solution）工况明细:\n');
        for k = 1:numel(no_sol)
            S = no_sol(k);
            fprintf(file_id, '  %s: first_status=%s, term_code=%s, 尝试=%d, 停止=%s (%s)\n', ...
                S.name, S.first_status, S.first_term_code, S.num_attempted, ...
                S.stop_reason, S.stop_detail);
        end
    end
end


function write_sec2_validation_and_self_check(file_id, Check)
% WRITE_SEC2_VALIDATION_AND_SELF_CHECK 第 2 节：存档版本校验与 ccd_lu 全可行轮自检。

    fprintf(file_id, '\n=== 2 基线校验与自检 ===\n');
    fprintf(file_id, 'standard-5 存档数: %d/%d 齐全 | version_root 全为 Version1-3-standard-5: %s | mode 一致: %s\n', ...
        sum([Check.archive_checks.found]), numel(Check.archive_checks), ...
        yes_no(Check.archive_all_version_ok), yes_no(Check.archive_all_mode_ok));
    fprintf(file_id, 'ccd_lu 有接受解工况数 = %d\n', Check.ccd_lu_num_ok);
    fprintf(file_id, '全部 ccd_lu 可行轮 max|circle_error| = %.3e\n', Check.ccd_lu_circle_error_max);
    fprintf(file_id, '全部 ccd_lu 可行轮驻点残差 max = %.3e\n', Check.ccd_lu_stationarity_max);
    fprintf(file_id, '全部 ccd_lu 可行轮 min(u_norm) = %.12f (1 - min = %.3e)\n', ...
        Check.ccd_lu_min_u_norm, 1 - Check.ccd_lu_min_u_norm);
    fprintf(file_id, '全部 ccd_lu 可行轮 max(u_norm) = %.12f\n', Check.ccd_lu_max_u_norm);
end


function write_sec3_final_and_switch1(file_id, Summary, Groups, Switch1)
% WRITE_SEC3_FINAL_AND_SWITCH1 第 3 节：末轮总脉冲表、E vs D 紧性分组与开关①检验。

    fprintf(file_id, '\n=== 3 末轮表与开关①效果检验 ===\n');
    fprintf(file_id, '(3a) 总脉冲与相对 none 差值 d:\n');
    ok_cases = Summary(strcmp({Summary.state}, 'ok'));
    headers = {'工况', '末轮', '末轮总脉冲', '末5轮均值', '末5轮极差', ...
        'd 末轮', 'd 末5轮极差', '稳定轮', '稳定'};
    rows = cell(numel(ok_cases), 9);
    for c = 1:numel(ok_cases)
        S = ok_cases(c);
        rows(c, :) = {S.name, format_val(S.final_iter, '%d'), ...
            format_val(S.impulse_final, '%.4f'), ...
            format_val(S.impulse_mean_last, '%.4f'), ...
            format_val(S.impulse_range_last, '%.4f'), ...
            format_plus(S.d_final), format_plus(S.d_range_last), ...
            format_val(S.d_stable_round, '%d'), stable_text(S.d_stable)};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(3b) E vs D 分组紧性与触界（末轮 / 全程，|E|=%d，|D|=%d）:\n', ...
        Groups.num_E, Groups.num_D);
    headers = {'工况', 'E末轮maxε', 'E全程maxε', 'E不紧>1e-6(末/全)', ...
        'E不紧>1e-3(末/全)', 'D末轮max|gap|', 'D全程max|gap|', ...
        'D不紧>1e-6(末/全)', '触上界(末/全)', '末轮触箱形'};
    rows = cell(numel(ok_cases), 10);
    for c = 1:numel(ok_cases)
        S = ok_cases(c);
        rows(c, :) = {S.name, ...
            format_val(S.E_eps_final, '%.3e'), format_val(S.E_eps_max_all, '%.3e'), ...
            sprintf('%d/%d', S.E_untight_1e6_final, S.E_untight_1e6_max), ...
            sprintf('%d/%d', S.E_untight_1e3_final, S.E_untight_1e3_max), ...
            format_val(S.D_gap_final, '%.3e'), format_val(S.D_gap_max_all, '%.3e'), ...
            sprintf('%d/%d', S.D_untight_1e6_final, S.D_untight_1e6_max), ...
            sprintf('%s/%d', format_val(S.num_capped_final, '%d'), S.num_capped_max), ...
            format_val(S.num_box_touch_final, '%d')};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(3c) 欠罚档局部 E 节点失紧 vs D 节点紧性与非加权单节点门槛:\n');
    fprintf(file_id, 'none 末轮基准: max_{E}‖s_main‖ = %.3e, max_{E}ν_out^+ = %.3e\n', ...
        Switch1.none_smain_E_max, Switch1.none_nu_out_E_max);
    UT = Switch1.under_table;
    headers = {'工况', 'p', 'E末轮maxε', 'E全程maxε', 'E末轮>1e-3', ...
        'D全程max|gap|', 'D全程>1e-6', '首轮max‖s_main‖', '末轮max‖s_main‖', '全程maxν_out^+'};
    rows = cell(numel(UT), 10);
    for k = 1:numel(UT)
        R = UT(k);
        rows(k, :) = {R.name, format_val(R.p, '%.3e'), ...
            format_val(R.E_eps_final, '%.3e'), format_val(R.E_eps_max_all, '%.3e'), ...
            sprintf('%d', R.E_untight_1e3_final), ...
            format_val(R.D_gap_max_all, '%.3e'), sprintf('%d', R.D_untight_1e6_max), ...
            format_val(R.smain_E_max_r1, '%.3e'), format_val(R.smain_E_max_final, '%.3e'), ...
            format_val(R.nu_out_E_max_all, '%.3e')};
    end
    write_table(file_id, headers, rows);
end


function write_sec4_switch4_weighting(file_id, Groups, Coarse, Inertia)
% WRITE_SEC4_SWITCH4_WEIGHTING 第 4 节：开关④（不加权 vs 加权）粗单元先失紧与等总权惯性/脉冲损失。

    fprintf(file_id, '\n=== 4 开关④专项检验：不加权（ccd_lu）vs 加权（standard-5） ===\n');
    fprintf(file_id, 'E 节点 ω 统计: Q25=%.3e, Q50=%.3e, Q75=%.3e (|E_fine|=%d, |E_coarse|=%d)\n', ...
        Groups.omega_q25, Groups.omega_q50, Groups.omega_q75, ...
        sum(Groups.E_fine), sum(Groups.E_coarse));

    fprintf(file_id, '\n(4a) 粗单元先触及门槛（按 ε_i > tol 统计 E_coarse vs E_fine 失紧比例及 ω 中位数比）:\n');
    headers = {'工况', '检验点', '轮', '阈值', 'E失紧数', ...
        '粗单元(数/%)', '细单元(数/%)', '粗半/细半数', '失紧ω中位/Eω中位'};
    R = Coarse.rows;
    rows = cell(numel(R), 9);
    for k = 1:numel(R)
        item = R(k);
        rows(k, :) = {item.name, item.checkpoint, sprintf('%d', item.iter), ...
            sprintf('%.0e', item.threshold), sprintf('%d', item.n_E_untight), ...
            sprintf('%d/%.1f%%', item.n_coarse, item.pct_coarse), ...
            sprintf('%d/%.1f%%', item.n_fine, item.pct_fine), ...
            sprintf('%d/%d', item.n_coarse_med, item.n_fine_med), ...
            format_val(item.omega_median_ratio, '%.3f')};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(4b) 等总权与相近有效权配对：第 10 轮与末轮（第 50 轮）总脉冲及粗/细单元倾侧角偏差:\n');
    fprintf(file_id, '基准 none: 第 10 轮 %.4f m/s, 第 50 轮 %.4f m/s\n', ...
        Inertia.none_impulse_10, Inertia.none_impulse_50);
    C = Inertia.cases;
    headers = {'工况', '总权', 'E中位p/ω', 'R10脉冲(d)', 'R50脉冲(d)', ...
        'Q3四分位细/粗(R10对50)', 'Q4四分位细/粗(R10对50)', ...
        'Q3中位分细/粗(R10对50)', 'Q4中位分细/粗(R10对50)', ...
        'E四分位细/粗(R10对none)', 'E四分位细/粗(R50对none)'};
    rows = cell(numel(C), 11);
    for k = 1:numel(C)
        d = C(k);
        rows(k, :) = {d.name, sprintf('%.2f', d.total_weight), ...
            sprintf('%.3e', d.eff_weight_E_median), ...
            sprintf('%.4f(%+.2f)', d.impulse_10, d.d_none_10), ...
            sprintf('%.4f(%+.2f)', d.impulse_50, d.d_none_50), ...
            sprintf('%.2f/%.2f', d.r10_vs_self50.Q3_fine, d.r10_vs_self50.Q3_coarse), ...
            sprintf('%.2f/%.2f', d.r10_vs_self50.Q4_fine, d.r10_vs_self50.Q4_coarse), ...
            sprintf('%.2f/%.2f', d.r10_vs_self50.Q3_fine_med, d.r10_vs_self50.Q3_coarse_med), ...
            sprintf('%.2f/%.2f', d.r10_vs_self50.Q4_fine_med, d.r10_vs_self50.Q4_coarse_med), ...
            sprintf('%.2f/%.2f', d.r10_vs_none.E_fine, d.r10_vs_none.E_coarse), ...
            sprintf('%.2f/%.2f', d.r50_vs_none.E_fine, d.r50_vs_none.E_coarse)};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n配对直比（不加权 ccd_lu 减 加权 standard-5）:\n');
    for k = 1:size(Inertia.pair_specs, 1)
        label = Inertia.pair_specs{k, 1};
        Lu = C(strcmp({C.name}, Inertia.pair_specs{k, 2}));
        Wtd = C(strcmp({C.name}, Inertia.pair_specs{k, 3}));
        fprintf(file_id, ['  [%s] %s vs %s: ΔC(R10)=%+.4f m/s, ΔC(R50)=%+.4f m/s | ' ...
            'Q3细/粗(R10对none): %.2f/%.2f vs %.2f/%.2f | Q4细/粗(R10对none): %.2f/%.2f vs %.2f/%.2f\n'], ...
            label, Lu.name, Wtd.name, Lu.impulse_10 - Wtd.impulse_10, ...
            Lu.impulse_50 - Wtd.impulse_50, ...
            Lu.r10_vs_none.Q3_fine, Lu.r10_vs_none.Q3_coarse, ...
            Wtd.r10_vs_none.Q3_fine, Wtd.r10_vs_none.Q3_coarse, ...
            Lu.r10_vs_none.Q4_fine, Lu.r10_vs_none.Q4_coarse, ...
            Wtd.r10_vs_none.Q4_fine, Wtd.r10_vs_none.Q4_coarse);
    end
end


function write_sec5_switch3_square(file_id, Switch3)
% WRITE_SEC5_SWITCH3_SQUARE 第 5 节：开关③平方理论下界验证与前 5 轮衰减对比。

    fprintf(file_id, '\n=== 5 开关③专项检验：平方内逼近 vs 范数内逼近 ===\n');
    fprintf(file_id, '(5a) 第 1 轮偏移节点在第 2 轮的实际模长 vs 平方理论下界 (1+‖u^(1)‖²)/(2‖u^(1)‖):\n');
    LB = Switch3.lower_bound;
    headers = {'工况', 'R1 max‖u‖', '峰值下界lb2', '峰值R2‖u‖', '峰值差', ...
        '偏移>1e-3数', '偏移min‖u2‖', '偏移min_lb2', '偏移max_lb2', '逐点min(u2-lb2)', '全网min(u2-lb2)'};
    rows = cell(numel(LB), 11);
    for k = 1:numel(LB)
        r = LB(k);
        rows(k, :) = {r.name, sprintf('%.6f', r.max_u1_norm), ...
            sprintf('%.6f', r.peak_lb2), sprintf('%.6f', r.peak_u2_norm), ...
            format_plus(r.peak_diff), sprintf('%d', r.n_shift_1e3), ...
            format_val(r.min_u2_shift_1e3, '%.6f'), ...
            format_val(r.min_lb2_shift_1e3, '%.6f'), ...
            format_val(r.max_lb2_shift_1e3, '%.6f'), ...
            format_plus(r.min_diff_shift_1e3), format_plus(r.all_min_diff)};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\n(5b) 第 1–5 轮 max|1-‖u‖| 衰减与圆约束组 circle_error 对比（平方 vs 范数）:\n');
    D = Switch3.decay_r1_5;
    headers = {'工况', '来源', '轮1', '轮2', '轮3', '轮4', '轮5', 'R1~5 max|D|', '全程 max|D|'};
    rows = cell(numel(D), 9);
    for k = 1:numel(D)
        r = D(k);
        rows(k, :) = {r.name, r.source, ...
            format_val(r.gap_r1_5(1), '%.2e'), format_val(r.gap_r1_5(2), '%.2e'), ...
            format_val(r.gap_r1_5(3), '%.2e'), format_val(r.gap_r1_5(4), '%.2e'), ...
            format_val(r.gap_r1_5(5), '%.2e'), ...
            format_val(max(abs(r.circle_error_r1_5), [], 'omitnan'), '%.2e'), ...
            format_val(r.circle_error_absmax, '%.2e')};
    end
    write_table(file_id, headers, rows);
end


function write_sec6_init_study(file_id, InitStudy)
% WRITE_SEC6_INIT_STUDY 第 6 节：初值专项检验（第 1–10 轮）。

    fprintf(file_id, '\n=== 6 初值专项检验（第 1–10 轮） ===\n');
    O = InitStudy.overview;
    headers = {'工况', '初值', '归一化', '保界', '尝试/接受', '首轮状态', ...
        '停止原因', 'R1 ΔL', 'R1 ρ', 'R1 min‖u‖', 'R1 max‖u‖', 'R1 maxε'};
    rows = cell(numel(O), 12);
    for k = 1:numel(O)
        r = O(k);
        rows(k, :) = {r.name, r.init_control_mode, ...
            yes_no(r.normalize_init), yes_no(r.keep), ...
            sprintf('%d/%d', r.num_attempted, r.num_accepted), ...
            r.first_status, r.stop_reason, ...
            format_val(r.r1_delta_L, '%.3e'), format_val(r.r1_rho, '%.4f'), ...
            format_val(r.r1_min_u, '%.6f'), format_val(r.r1_max_u, '%.6f'), ...
            format_val(r.r1_max_eps, '%.3e')};
    end
    write_table(file_id, headers, rows);

    fprintf(file_id, '\nccd_lu_init0p3_nonorm_p1e-2（圆内 0.3 初值理论下界 (1+0.3²)/(2×0.3) = %.6f）第 1–10 轮:\n', ...
        InitStudy.nonorm_lb_r1);
    NR = InitStudy.nonorm_rounds;
    headers = {'轮', '状态', '总脉冲', 'ΔL', 'ρ', '步长max', ...
        'min‖u‖', 'max‖u‖', 'maxε', '触上界', '触箱形', 'P2可行'};
    rows = cell(numel(NR), 12);
    for k = 1:numel(NR)
        r = NR(k);
        rows(k, :) = {sprintf('%d', r.iter), r.status, ...
            format_val(r.impulse, '%.4f'), format_val(r.delta_L, '%.3e'), ...
            format_val(r.rho, '%.4f'), format_val(r.step_max, '%.3e'), ...
            format_val(r.min_u_norm, '%.6f'), format_val(r.max_u_norm, '%.6f'), ...
            format_val(r.max_eps, '%.3e'), format_val(r.num_capped, '%d'), ...
            format_val(r.num_box_touch, '%d'), yes_no(r.feasible)};
    end
    write_table(file_id, headers, rows);
end


%% ===== 绘图（字号 16，底部共用图例） =====

function plot_compare_figures(Summary, CaseData, Groups, SwitchTests, ...
        Options, pictures_root)
% PLOT_COMPARE_FIGURES 生成并导出全部对比图到 pictures/。
%
% 本函数依次完成：
%   1. 确保图片目录存在并构造共用绘图配置。
%   2. 绘制各轮总脉冲对比图。
%   3. 绘制相对 none 总脉冲差值 d 随轮次图。
%   4. 绘制等总权开关④惯性与粗细单元偏差图。
%   5. 绘制欠罚失紧节点 ω_i 分布图。
%   6. 绘制紧性衰减（前 10 轮）与末轮 σ 叠画图。

    %% 1. 确保图片目录存在并构造共用绘图配置
    if ~isfolder(pictures_root)
        mkdir(pictures_root);
    end
    plot_config.plot.font_size = 16;

    %% 2. 绘制各轮总脉冲对比图
    plot_impulse_figure(Summary, plot_config, pictures_root);

    %% 3. 绘制相对 none 总脉冲差值 d 随轮次图
    plot_difference_figure(Summary, Options, plot_config, pictures_root);

    %% 4. 绘制等总权开关④惯性与粗细单元偏差图
    plot_switch4_inertia_figure(SwitchTests.switch4_inertia, ...
        plot_config, pictures_root);

    %% 5. 绘制欠罚失紧节点 ω_i 分布图
    plot_untight_omega_figure(CaseData, Groups, plot_config, pictures_root);

    %% 6. 绘制紧性衰减（前 10 轮）与末轮 σ 叠画图
    plot_tightness_decay_figure(Summary, plot_config, pictures_root);
    plot_final_sigma_figure(Summary, Groups, plot_config, pictures_root);
end


function plot_impulse_figure(Summary, plot_config, pictures_root)
% PLOT_IMPULSE_FIGURE ① 主扫描与等总权配对各轮总脉冲。

    fig = new_hidden_figure('对比-各轮总脉冲');
    tile_groups = { ...
        {'none', 'ccd_lu_p1e-5', 'ccd_lu_p1e-4', 'ccd_lu_p1e-3'}, '主扫描小 p (m/s)'; ...
        {'none', 'ccd_lu_p1e-2', 'ccd_lu_p1e-1', 'ccd_lu_p1e0'}, '主扫描大 p (m/s)'; ...
        {'none', 'ccd_lu_peq_1e-1', 'ccd_p1e-1', 'ccd_lukeep_p1e-2'}, '等总权0.5与保界 (m/s)'; ...
        {'none', 'ccd_lu_peq_1e0', 'ccd_p1e0', 'normgap_w1e-4'}, '等总权5.0与正则 (m/s)'};
    layout = tiledlayout(fig, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    limits = padded_limits(arrayfun(@(S) S.impulse_series, Summary, 'UniformOutput', false));
    tile_axes = gobjects(1, 4);
    for t = 1:4
        ax = nexttile(layout);
        hold(ax, 'on');
        draw_case_curves(ax, Summary, 'impulse_series', tile_groups{t, 1}, 50, []);
        ylim(ax, limits);
        style_plot_axes(ax, '迭代轮次', tile_groups{t, 2}, plot_config);
        tile_axes(t) = ax;
    end
    finish_tile_window(layout, tile_axes, '主扫描与等总权配对各轮总脉冲', {}, plot_config);
    finish_and_save_figure(fig, fullfile(pictures_root, '对比-各轮总脉冲.png'));
end


function plot_difference_figure(Summary, Options, plot_config, pictures_root)
% PLOT_DIFFERENCE_FIGURE ② 相对 none 总脉冲差值 d 随轮次图。

    fig = new_hidden_figure('对比-相对none差值');
    tile_groups = { ...
        {'ccd_lu_p1e-5', 'ccd_lu_p1e-4', 'ccd_lu_p1e-3'}, 'd，主扫描小 p (m/s)'; ...
        {'ccd_lu_p1e-2', 'ccd_lu_p1e-1', 'ccd_lu_p1e0'}, 'd，主扫描大 p (m/s)'; ...
        {'ccd_lu_peq_1e-1', 'ccd_p1e-1', 'ccd_lukeep_p1e-2'}, 'd，等总权0.5与保界 (m/s)'; ...
        {'ccd_lu_peq_1e0', 'ccd_p1e0', 'normgap_w1e-4'}, 'd，等总权5.0与正则 (m/s)'};
    layout = tiledlayout(fig, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    all_names = unique([tile_groups{:, 1}], 'stable');
    all_vals = {};
    for k = 1:numel(all_names)
        idx = find(strcmp({Summary.name}, all_names{k}), 1);
        if ~isempty(idx)
            all_vals{end + 1} = Summary(idx).d_series; %#ok<AGROW>
        end
    end
    limits = padded_limits([vertcat(all_vals{:}); Options.delta; -Options.delta]);
    tile_axes = gobjects(1, 4);
    for t = 1:4
        ax = nexttile(layout);
        hold(ax, 'on');
        yline(ax, 0, 'k-', 'LineWidth', 1.0, 'HandleVisibility', 'off');
        yline(ax, Options.delta, '--', 'Color', [0.4 0.4 0.4], 'LineWidth', 1.2, ...
            'DisplayName', '±0.1 m/s');
        yline(ax, -Options.delta, '--', 'Color', [0.4 0.4 0.4], 'LineWidth', 1.2, ...
            'HandleVisibility', 'off');
        draw_case_curves(ax, Summary, 'd_series', tile_groups{t, 1}, 50, []);
        ylim(ax, limits);
        style_plot_axes(ax, '迭代轮次', tile_groups{t, 2}, plot_config);
        tile_axes(t) = ax;
    end
    finish_tile_window(layout, tile_axes, '相对 none 的同轮总脉冲差值 d', {}, plot_config);
    finish_and_save_figure(fig, fullfile(pictures_root, '对比-相对none差值.png'));
end


function plot_switch4_inertia_figure(Inertia, plot_config, pictures_root)
% PLOT_SWITCH4_INERTIA_FIGURE ③ 等总权对比：第 10/50 轮总脉冲与粗/细单元 |Δσ|。

    fig = new_hidden_figure('对比-等总权开关4惯性与脉冲');
    layout = tiledlayout(fig, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    C = Inertia.cases;
    names_order = {'ccd_lu_peq_1e-1', 'ccd_p1e-1', 'ccd_lu_peq_1e0', ...
        'ccd_p1e0', 'ccd_lu_p1e-2'};
    short_labels = {'lu peq1e-1', 'std5 p1e-1', 'lu peq1e0', 'std5 p1e0', 'lu p1e-2'};
    picked = zeros(1, numel(names_order));
    for k = 1:numel(names_order)
        picked(k) = find(strcmp({C.name}, names_order{k}), 1);
    end
    CP = C(picked);
    x = 1:numel(CP);
    tile_axes = gobjects(1, 4);

    % 分块 1：第 10 轮与第 50 轮总脉冲
    ax = nexttile(layout);
    hold(ax, 'on');
    b1 = bar(ax, x, [[CP.impulse_10].', [CP.impulse_50].']);
    b1(1).DisplayName = '第10轮';
    b1(2).DisplayName = '第50轮';
    yline(ax, Inertia.none_impulse_10, '--', 'Color', [0.35 0.35 0.35], ...
        'LineWidth', 1.2, 'DisplayName', 'none R10');
    yline(ax, Inertia.none_impulse_50, ':', 'Color', [0.15 0.15 0.15], ...
        'LineWidth', 1.4, 'DisplayName', 'none R50');
    set(ax, 'XTick', x, 'XTickLabel', short_labels);
    xtickangle(ax, 15);
    style_plot_axes(ax, '', '总脉冲 (m/s)', plot_config);
    tile_axes(1) = ax;

    % 分块 2：第 10 轮相对各自第 50 轮收敛误差（Q4 细 vs 粗）
    ax = nexttile(layout);
    hold(ax, 'on');
    vals_q4 = [arrayfun(@(s) s.r10_vs_self50.Q4_fine, CP).', ...
        arrayfun(@(s) s.r10_vs_self50.Q4_coarse, CP).'];
    b2 = bar(ax, x, vals_q4);
    b2(1).DisplayName = 'Q4细单元';
    b2(2).DisplayName = 'Q4粗单元';
    set(ax, 'XTick', x, 'XTickLabel', short_labels);
    xtickangle(ax, 15);
    style_plot_axes(ax, '', 'R10对R50 |Δσ| (deg)', plot_config);
    tile_axes(2) = ax;

    % 分块 3：第 10 轮相对各自第 50 轮收敛误差（Q3 细 vs 粗）
    ax = nexttile(layout);
    hold(ax, 'on');
    vals_q3 = [arrayfun(@(s) s.r10_vs_self50.Q3_fine, CP).', ...
        arrayfun(@(s) s.r10_vs_self50.Q3_coarse, CP).'];
    b3 = bar(ax, x, vals_q3);
    b3(1).DisplayName = 'Q3细单元';
    b3(2).DisplayName = 'Q3粗单元';
    set(ax, 'XTick', x, 'XTickLabel', short_labels);
    xtickangle(ax, 15);
    style_plot_axes(ax, '配对工况', 'Q3 R10对R50 |Δσ| (deg)', plot_config);
    tile_axes(3) = ax;

    % 分块 4：第 10 轮相对 none 末轮偏差（E 细 vs 粗）
    ax = nexttile(layout);
    hold(ax, 'on');
    vals_e = [arrayfun(@(s) s.r10_vs_none.E_fine, CP).', ...
        arrayfun(@(s) s.r10_vs_none.E_coarse, CP).'];
    b4 = bar(ax, x, vals_e);
    b4(1).DisplayName = 'E细单元';
    b4(2).DisplayName = 'E粗单元';
    set(ax, 'XTick', x, 'XTickLabel', short_labels);
    xtickangle(ax, 15);
    style_plot_axes(ax, '配对工况', 'R10对none |Δσ| (deg)', plot_config);
    tile_axes(4) = ax;

    finish_tile_window(layout, tile_axes, '等总权与相近有效权对比（开关④）', {}, plot_config);
    finish_and_save_figure(fig, fullfile(pictures_root, '对比-等总权开关4惯性与脉冲.png'));
end


function plot_untight_omega_figure(CaseData, Groups, plot_config, pictures_root)
% PLOT_UNTIGHT_OMEGA_FIGURE ④ 欠罚失紧节点 ω_i 经验分布图（粗单元 vs 细单元）。

    fig = new_hidden_figure('对比-欠罚失紧节点分布');
    layout = tiledlayout(fig, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    panel_specs = { ...
        'ccd_lu_p1e-4',   1e-4, '第1轮 p=1e-4 失紧ω'; ...
        'ccd_lu_peq_1e-1', 1e-4, '第1轮 peq=1e-1 失紧ω'; ...
        'ccd_lu_p1e-3',   1e-4, '第1轮 p=1e-3 失紧ω'; ...
        'ccd_p1e-2',      1e-4, '加权 std5 p=1e-2 失紧ω'};
    omega_E_sorted = sort(Groups.omega(Groups.E));
    cdf_E = (1:numel(omega_E_sorted))' / numel(omega_E_sorted);
    tile_axes = gobjects(1, 4);

    for k = 1:4
        ax = nexttile(layout);
        hold(ax, 'on');
        plot(ax, omega_E_sorted, cdf_E, '--', 'Color', [0.3 0.3 0.3], ...
            'LineWidth', 1.4, 'DisplayName', '全部 E 节点');
        xline(ax, Groups.omega_q50, ':', 'Color', [0.5 0.5 0.5], ...
            'LineWidth', 1.2, 'DisplayName', 'ω_E 中位数');
        idx = find(strcmp({CaseData.name}, panel_specs{k, 1}), 1);
        Data = CaseData(idx);
        R1 = pick_attempt_report(Data, 1);
        if ~isempty(R1)
            mask = Groups.E & (R1.unit_norm_slack > panel_specs{k, 2});
            if any(mask)
                w_vals = sort(Groups.omega(mask));
                plot(ax, w_vals, (1:numel(w_vals))' / numel(w_vals), '-', ...
                    'Color', [0.13 0.40 0.75], 'LineWidth', 1.8, ...
                    'DisplayName', '失紧节点(ε>1e-4)');
            end
        end
        set(ax, 'XScale', 'log');
        ylim(ax, [0, 1.05]);
        style_plot_axes(ax, 'ω_i', '累计概率', plot_config);
        ylabel(ax, panel_specs{k, 3}, 'FontSize', plot_config.plot.font_size);
        tile_axes(k) = ax;
    end
    finish_tile_window(layout, tile_axes, '欠罚失紧节点 ω_i 经验分布（粗单元 vs 细单元）', {}, plot_config);
    finish_and_save_figure(fig, fullfile(pictures_root, '对比-欠罚失紧节点omega分布.png'));
end


function plot_tightness_decay_figure(Summary, plot_config, pictures_root)
% PLOT_TIGHTNESS_DECAY_FIGURE ⑤a max|1-‖u‖| 前 10 轮衰减（平方 vs 范数）。

    fig = new_hidden_figure('对比-紧性衰减前10轮');
    layout = tiledlayout(fig, 1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
    groups = { ...
        {'ccd_lu_peq_1e-1', 'ccd_p1e-1', 'ccd_lu_peq_1e0', 'ccd_p1e0'}, '等总权紧性差'; ...
        {'ccd_lu_p1e-2', 'ccd_lu_p1e-1', 'ccd_lu_p1e0', 'ccd_lu_init0p3_nonorm_p1e-2'}, '平方形式紧性差'};
    tile_axes = gobjects(1, 2);
    for t = 1:2
        ax = nexttile(layout);
        hold(ax, 'on');
        draw_case_curves(ax, Summary, 'gap_series', groups{t, 1}, 10, 1e-12);
        set(ax, 'YScale', 'log');
        style_plot_axes(ax, '迭代轮次', groups{t, 2}, plot_config);
        tile_axes(t) = ax;
    end
    finish_tile_window(layout, tile_axes, '前 10 轮 max|1-‖u‖| 衰减（平方 vs 范数）', {}, plot_config);
    finish_and_save_figure(fig, fullfile(pictures_root, '对比-紧性衰减_前10轮.png'));
end


function plot_final_sigma_figure(Summary, Groups, plot_config, pictures_root)
% PLOT_FINAL_SIGMA_FIGURE ⑤b 末轮 σ 叠画（第 1–5 圈）。

    if ~Groups.available
        return;
    end
    fig = new_hidden_figure('对比-末轮σ');
    num_cir = max(Groups.cir);
    layout = create_tile_layout(fig, num_cir);
    names = {'none', 'normgap_w1e-4', 'ccd_lu_p1e-2', 'ccd_p1e0'};
    y_limits = [-190, 190];
    tile_axes = gobjects(1, num_cir);

    for cir = 1:num_cir
        ax = nexttile(layout);
        hold(ax, 'on');
        in_cir = Groups.cir == cir;
        ylim(ax, y_limits);
        if any(Groups.D & in_cir)
            intervals = build_group_intervals(Groups.tau(in_cir), Groups.D(in_cir));
            for k = 1:size(intervals, 1)
                h_shade = patch(ax, ...
                    [intervals(k, 1); intervals(k, 2); intervals(k, 2); intervals(k, 1)], ...
                    [y_limits(1); y_limits(1); y_limits(2); y_limits(2)], ...
                    [0.85 0.85 0.85], 'EdgeColor', 'none', 'FaceAlpha', 0.5);
                if k == 1
                    h_shade.DisplayName = 'D 节点';
                else
                    h_shade.HandleVisibility = 'off';
                end
            end
        end
        for k = 1:numel(names)
            idx = find(strcmp({Summary.name}, names{k}) & strcmp({Summary.state}, 'ok'), 1);
            if isempty(idx)
                continue;
            end
            Style = resolve_case_style(Summary(idx));
            plot(ax, Groups.tau(in_cir), Summary(idx).final_sigma(in_cir), ...
                Style.line, 'Color', Style.color, 'LineWidth', 1.5, ...
                'DisplayName', Style.label);
        end
        style_plot_axes(ax, '圈内 τ', sprintf('第 %d 圈 σ (deg)', cir), plot_config);
        tile_axes(cir) = ax;
    end
    finish_tile_window(layout, tile_axes, '末轮倾侧角 σ 叠画', {}, plot_config);
    finish_and_save_figure(fig, fullfile(pictures_root, '对比-末轮σ.png'));
end


function draw_case_curves(ax, Summary, field_name, case_names, max_iter, floor_val)
% DRAW_CASE_CURVES 在指定坐标轴绘制一组工况的逐轮序列。

    for k = 1:numel(case_names)
        idx = find(strcmp({Summary.name}, case_names{k}) & strcmp({Summary.state}, 'ok'), 1);
        if isempty(idx)
            continue;
        end
        S = Summary(idx);
        vals = S.(field_name);
        n_plot = min(max_iter, numel(vals));
        vals = vals(1:n_plot);
        if all(isnan(vals))
            continue;
        end
        if ~isempty(floor_val)
            has_val = ~isnan(vals);
            vals(has_val) = max(vals(has_val), floor_val);
        end
        Style = resolve_case_style(S);
        plot(ax, 1:n_plot, vals, Style.line, 'Color', Style.color, ...
            'Marker', Style.marker, 'MarkerSize', 5, 'LineWidth', 1.5, ...
            'DisplayName', Style.label);
    end
end


function Style = resolve_case_style(S)
% RESOLVE_CASE_STYLE 统一映射每个工况的颜色、线型、标记和图例名。

    switch S.name
        case 'none'
            Style = struct('color', [0.35 0.35 0.35], 'line', '--', 'marker', 'none', 'label', 'none');
        case 'normgap_w1e-4'
            Style = struct('color', [0.80 0.47 0.65], 'line', '-', 'marker', 'o', 'label', 'normgap w=1e-4');
        case 'ccd_lu_p1e-5'
            Style = struct('color', [0.10 0.25 0.60], 'line', '-', 'marker', 'o', 'label', 'lu p=1e-5');
        case 'ccd_lu_p1e-4'
            Style = struct('color', [0.13 0.50 0.72], 'line', '-', 'marker', 's', 'label', 'lu p=1e-4');
        case 'ccd_lu_p1e-3'
            Style = struct('color', [0.18 0.65 0.45], 'line', '-', 'marker', '^', 'label', 'lu p=1e-3');
        case 'ccd_lu_p1e-2'
            Style = struct('color', [0.85 0.60 0.10], 'line', '-', 'marker', 'd', 'label', 'lu p=1e-2');
        case 'ccd_lu_p1e-1'
            Style = struct('color', [0.90 0.35 0.10], 'line', '-', 'marker', 'v', 'label', 'lu p=1e-1');
        case 'ccd_lu_p1e0'
            Style = struct('color', [0.70 0.10 0.15], 'line', '-', 'marker', 'p', 'label', 'lu p=1');
        case 'ccd_lu_peq_1e-1'
            Style = struct('color', [0.00 0.45 0.74], 'line', '-', 'marker', 'o', 'label', 'lu peq=0.5/661');
        case 'ccd_lu_peq_1e0'
            Style = struct('color', [0.85 0.33 0.10], 'line', '-', 'marker', 's', 'label', 'lu peq=5/661');
        case 'ccd_p1e-1'
            Style = struct('color', [0.00 0.45 0.74], 'line', ':', 'marker', 'x', 'label', 'std5 p=1e-1');
        case 'ccd_p1e0'
            Style = struct('color', [0.85 0.33 0.10], 'line', ':', 'marker', '+', 'label', 'std5 p=1');
        case 'ccd_lukeep_p1e-2'
            Style = struct('color', [0.50 0.25 0.65], 'line', '-.', 'marker', 'h', 'label', 'lu keep p=1e-2');
        case 'ccd_lu_init0p3_nonorm_p1e-2'
            Style = struct('color', [0.40 0.40 0.10], 'line', '-', 'marker', '*', 'label', 'lu init0.3 nonorm');
        otherwise
            Style = struct('color', [0.2 0.2 0.2], 'line', '-', 'marker', 'none', 'label', S.name);
    end
end


function fig = new_hidden_figure(name)
% NEW_HIDDEN_FIGURE 创建使用 MATLAB 默认尺寸的隐藏图窗。

    fig = figure('Name', name, 'NumberTitle', 'off', 'Visible', 'off');
end


function finish_and_save_figure(fig, png_path)
% FINISH_AND_SAVE_FIGURE 导出高分辨率 PNG 并关闭图窗。

    save_plot_figure(fig, png_path);
    close(fig);
end


%% ===== 通用数值与表格格式化工具 =====

function Stats = describe_values(values)
% DESCRIBE_VALUES 计算一组数的中位数、5%、95% 分位、最小值、最大值。

    values = values(~isnan(values(:)));
    Stats = struct('median', NaN, 'p5', NaN, 'p95', NaN, 'min', NaN, 'max', NaN);
    if isempty(values)
        return;
    end
    Stats.median = median(values);
    qs = compute_percentile_set(values, [5, 95]);
    Stats.p5 = qs(1);
    Stats.p95 = qs(2);
    Stats.min = min(values);
    Stats.max = max(values);
end


function values_out = compute_percentile_set(values, percents)
% COMPUTE_PERCENTILE_SET 计算线性插值分位数。

    values = sort(values(~isnan(values(:))));
    count = numel(values);
    values_out = nan(size(percents));
    if count == 0
        return;
    end
    for k = 1:numel(percents)
        pos = 1 + (count - 1) * percents(k) / 100;
        lo = floor(pos);
        hi = ceil(pos);
        values_out(k) = values(lo) + (pos - lo) * (values(hi) - values(lo));
    end
end


function series = place_series(values, iters, max_rounds)
% PLACE_SERIES 把按轮次排列的向量放进 max_rounds x 1 列。

    series = nan(max_rounds, 1);
    series(iters) = values(:);
end


function intervals = build_group_intervals(tau, mask)
% BUILD_GROUP_INTERVALS 把一圈内连续 mask 节点合并成 τ 区间。

    intervals = zeros(0, 2);
    if isempty(tau) || ~any(mask)
        return;
    end
    tau = tau(:);
    mask = logical(mask(:));
    midpoint = (tau(1:end - 1) + tau(2:end)) / 2;
    lower_edge = [tau(1) - (midpoint(1) - tau(1)); midpoint(:)];
    upper_edge = [midpoint(:); tau(end) + (tau(end) - midpoint(end))];
    change = diff([false; mask; false]);
    start_idx = find(change == 1);
    stop_idx = find(change == -1) - 1;
    intervals = [lower_edge(start_idx), upper_edge(stop_idx)];
end


function limits = padded_limits(values)
% PADDED_LIMITS 计算有限数值上下留 5% 边距的坐标范围。

    if iscell(values)
        values = vertcat(values{:});
    end
    values = values(isfinite(values));
    if isempty(values)
        limits = [0, 1];
        return;
    end
    span = max(values) - min(values);
    if span == 0
        span = max(1, abs(values(1)));
    end
    limits = [min(values) - 0.05 * span, max(values) + 0.05 * span];
end


function text = stable_text(flag)
% STABLE_TEXT 稳定标志转中文。

    if isnan(flag)
        text = '-';
    elseif flag > 0
        text = '是';
    else
        text = '否';
    end
end


function text = yes_no(value)
% YES_NO 逻辑值转中文。

    if value
        text = '是';
    else
        text = '否';
    end
end


function text = format_val(value, spec)
% FORMAT_VAL 格式化标量数值，NaN 显示 '-'。

    if isnan(value)
        text = '-';
    elseif isinf(value)
        text = 'Inf';
    else
        text = sprintf(spec, value);
    end
end


function text = format_plus(value)
% FORMAT_PLUS 带正负号科学计数格式。

    text = format_val(value, '%+.3e');
end


function text = char_or_dash(value)
% CHAR_OR_DASH 空文本返回 '-'。

    if isempty(value)
        text = '-';
    else
        text = char(string(value));
    end
end


function write_table(file_id, headers, rows)
% WRITE_TABLE 按终端显示宽度对齐写表：首列左对齐，其余列右对齐。

    all_rows = [headers; rows];
    num_cols = size(all_rows, 2);
    widths = zeros(1, num_cols);
    for c = 1:num_cols
        widths(c) = max(cellfun(@measure_display_width, all_rows(:, c)));
    end
    for r = 1:size(all_rows, 1)
        parts = cell(1, num_cols);
        for c = 1:num_cols
            pad = blanks(widths(c) - measure_display_width(all_rows{r, c}));
            if c == 1
                parts{c} = [all_rows{r, c}, pad];
            else
                parts{c} = [pad, all_rows{r, c}];
            end
        end
        fprintf(file_id, '%s\n', strjoin(parts, '  '));
    end
end
