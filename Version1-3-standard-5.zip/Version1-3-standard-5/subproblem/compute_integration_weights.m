function weights = compute_integration_weights(tau, PointsBounds)
% COMPUTE_INTEGRATION_WEIGHTS 按圈计算节点的梯形积分权（N x 1）。
%
% 数学形式:
%   第 j 圈占节点 b_j..e_j，圈内 τ 由 0 递增到 1，∫_0^1 y dτ ≈ Σ_(i=b_j..e_j) ω_i·y_i：
%       ω_(b_j) = (τ_(b_j+1) − τ_(b_j))/2
%       ω_i     = (τ_(i+1) − τ_(i−1))/2,   b_j < i < e_j
%       ω_(e_j) = (τ_(e_j) − τ_(e_j−1))/2
%   各权非负，每圈权之和为 τ_(e_j) − τ_(b_j) = 1；圈与圈之间 τ 由 1 回到 0 的跳变
%   不进入任何权。积分变量是各圈的归一化时间 τ，不乘该圈时长 t_f,j。
%
% 代码形式:
%   tau          - N x 1，各圈拼接的归一化时间（每圈内 0~1）
%   PointsBounds - 各圈在拼接节点中的行号，字段 begin/end
%   weights      - N x 1，按拼接节点顺序排列
%   P3 的控制正则项（build_objective）与罚函数（evaluate_penalty_function）共用此权，
%   两边该项完全相同。

    tau = tau(:);
    weights = zeros(numel(tau), 1);

    for cir = 1:numel(PointsBounds)
        nodes = PointsBounds(cir).begin:PointsBounds(cir).end;
        tau_cir = tau(nodes);
        weights_cir = zeros(numel(nodes), 1);
        weights_cir(1) = (tau_cir(2) - tau_cir(1)) / 2;
        weights_cir(2:end-1) = (tau_cir(3:end) - tau_cir(1:end-2)) / 2;
        weights_cir(end) = (tau_cir(end) - tau_cir(end-1)) / 2;
        weights(nodes) = weights_cir;
    end
end
