function diagnose_linear_reg_tightness()
% DIAGNOSE_LINEAR_REG_TIGHTNESS 诊断线性正则项下各节点受力合成与取紧原因（Version1-3-standard-3）。
%
% 与 Version1-3-standard-4 的同名脚本保持完全一致的工况与统计口径：
% 对 sum / u1 / u2 三种线性正则及 w_reg = 1e-3、1e-4 运行 10 轮 SCP（fixed r=1，不覆盖 results/），
% 额外打印 top-5 最不紧节点的 ‖s_rate‖，便于对照 standard-3（含 |Δu1|≤0.1）与 standard-4 的差异。

    tests_dir = fileparts(mfilename('fullpath'));
    version_root = fileparts(tests_dir);
    previous_path = path;
    restore_path = onCleanup(@() path(previous_path));

    modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
        'trust_region', 'validation', 'iteration', 'output', 'tests'};
    for k = 1:numel(modules)
        addpath(fullfile(version_root, modules{k}));
    end
    rehash;

    reg_types = {'sum', 'u1', 'u2'};
    weights = [1e-3, 1e-4];

    fprintf('=== Version1-3-standard-3 线性正则取紧机制诊断（10 轮，fixed r=1，含 |Δu1|<=0.1）===\n\n');

    for it = 1:numel(reg_types)
        for iw = 1:numel(weights)
            reg_type = reg_types{it};
            w_reg = weights(iw);
            run_one_case(reg_type, w_reg);
        end
    end
end


function run_one_case(reg_type, w_reg)
% RUN_ONE_CASE 运行单个线性正则工况并打印节点受力合成统计。

    config = scp_config_default();
    config.iter.max_scp_iter = 10;
    config.iter.tolerance = 0; % 跑满 10 轮便于横向对比
    config.objective.control_reg_type = reg_type;
    config.objective.weight_control_reg = w_reg;

    % 关闭绘图、终端逐轮打印与文件保存，避免污染 results/
    config.plot.enable_initial = false;
    config.plot.enable_iteration = false;
    config.plot.enable_final = false;
    config.output.print_pre_iteration = false;
    config.output.print_iteration = false;
    config.output.print_summary = false;
    config.output.save.brief_text = false;
    config.output.save.detail_text = false;
    config.output.save.scan_mat = false;
    config.output.save.full_mat = false;
    config.output.save.control_text = false;
    config.output.save.control_mat = false;
    config.validation.enable_trapezoid_check = false;

    [ConstData, InitialState] = initialize_problem(config);
    [InitialReference, InitialPropagation] = ...
        generate_initial_reference(ConstData, InitialState, config);
    [RunState, DiagnosticsHistory] = initialize_scp_run( ...
        InitialReference, InitialPropagation, config);

    control_reports = cell(config.iter.max_scp_iter, 1);
    n_iters = 0;
    for iter = 1:config.iter.max_scp_iter
        if RunState.stop
            break;
        end
        [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
            RunState.current_reference, RunState.trust_region, ...
            ConstData, config, iter);
        TrustResult = update_trust_region( ...
            CurrentSolution, SubproblemDiag, RunState.current_reference, ...
            RunState.trust_region, ConstData, config, iter);
        [RunState, IterationRecord] = advance_scp_iteration( ...
            RunState, CurrentSolution, SubproblemDiag, TrustResult, ...
            ConstData, config, iter);
        DiagnosticsHistory(iter) = postprocess_scp_iteration( ...
            RunState, IterationRecord, ConstData, config);
        n_iters = iter;
        control_reports{iter} = SubproblemDiag.control_report;
    end

    % 汇总全部 10 轮的紧性与最接近抵消的节点
    all_iter = [];
    all_node = [];
    all_gap = [];
    all_smain = [];
    all_sreg = [];
    all_srate = [];
    all_stotal = [];
    all_ratio = [];
    all_ang = [];

    for k = 1:n_iters
        CR = control_reports{k};
        if ~CR.evaluated || ~CR.dual_available
            continue;
        end
        s_total_norm = vecnorm(CR.s_total, 2, 2);
        s_rate_norm = vecnorm(CR.s_rate, 2, 2);
        ang_deg = compute_angle_between(-CR.s_main, -CR.s_reg);
        N = CR.num_nodes;
        all_iter = [all_iter; repmat(k, N, 1)]; %#ok<AGROW>
        all_node = [all_node; CR.node(:)]; %#ok<AGROW>
        all_gap = [all_gap; CR.tight_gap(:)]; %#ok<AGROW>
        all_smain = [all_smain; CR.s_main_norm(:)]; %#ok<AGROW>
        all_sreg = [all_sreg; CR.s_reg_norm(:)]; %#ok<AGROW>
        all_srate = [all_srate; s_rate_norm(:)]; %#ok<AGROW>
        all_stotal = [all_stotal; s_total_norm(:)]; %#ok<AGROW>
        all_ratio = [all_ratio; CR.reg_ratio(:)]; %#ok<AGROW>
        all_ang = [all_ang; ang_deg(:)]; %#ok<AGROW>
    end

    % 末轮分析
    CR_last = control_reports{n_iters};
    N = CR_last.num_nodes;
    s_total_last = vecnorm(CR_last.s_total, 2, 2);
    s_rate_last = vecnorm(CR_last.s_rate, 2, 2);
    ang_last = compute_angle_between(-CR_last.s_main, -CR_last.s_reg);
    ratio_last = CR_last.reg_ratio;
    gap_last = CR_last.tight_gap;
    u_vec = [CR_last.u1(:), CR_last.u2(:)];
    reg_radial = sum((-CR_last.s_reg) .* u_vec, 2);

    idx_opp = ang_last > 90;
    idx_inward_u = reg_radial < 0;
    idx_opp_main = idx_opp & (ratio_last < 0.5);
    idx_opp_reg = idx_opp & (ratio_last > 2.0);
    idx_opp_trans = idx_opp & (ratio_last >= 0.5) & (ratio_last <= 2.0);
    idx_cancel_zone = (ang_last > 150) & (ratio_last >= 0.5) & (ratio_last <= 2.0);
    idx_rate_active = s_rate_last > 1e-10;

    fprintf('--------------------------------------------------------------------\n');
    fprintf('工况: %s, w_reg = %.0e | 节点数 N = %d | 全程(10轮) max gap = %.3e\n', ...
        reg_type, w_reg, N, max(all_gap));
    fprintf('  全程 10 轮 (共 %d 节点-轮): gap>1e-6 有 %d 个, gap>1e-3 有 %d 个\n', ...
        numel(all_gap), sum(all_gap > 1e-6), sum(all_gap > 1e-3));
    fprintf('  末轮 (第 %d 轮): max gap = %.3e | gap>1e-6: %d | gap>1e-3: %d | |Δu1|生效节点: %d\n', ...
        n_iters, max(gap_last), sum(gap_last > 1e-6), sum(gap_last > 1e-3), sum(idx_rate_active));
    fprintf('  末轮方向对抗统计:\n');
    fprintf('    - 主需求与 -c 夹角 > 90° 的节点数: %d / %d (%.1f%%)\n', ...
        sum(idx_opp), N, 100 * sum(idx_opp) / N);
    fprintf('    - 最终解 u 落在正则“往圆内拉”半圆的节点数: %d / %d (%.1f%%)\n', ...
        sum(idx_inward_u), N, 100 * sum(idx_inward_u) / N);
    print_band_stats('    [反向 & 主问题主导 ratio<0.5]', idx_opp_main, s_total_last, gap_last, CR_last.sigma_shift_deg);
    print_band_stats('    [反向 & 正则主导   ratio>2.0]', idx_opp_reg, s_total_last, gap_last, CR_last.sigma_shift_deg);
    print_band_stats('    [反向 & 过渡带 0.5<=ratio<=2]', idx_opp_trans, s_total_last, gap_last, CR_last.sigma_shift_deg);
    print_band_stats('    [高危抵消窗 夹角>150°且0.5~2]', idx_cancel_zone, s_total_last, gap_last, CR_last.sigma_shift_deg);

    % 全程 10 轮中 gap 最大的前 5 个节点-轮
    [~, order_gap] = sort(all_gap, 'descend');
    top_k = min(5, numel(order_gap));
    fprintf('  全程 10 轮中 gap 最大的前 %d 个节点:\n', top_k);
    fprintf('    轮  节点     gap      ‖s_main‖    ‖s_reg‖    ‖s_rate‖    ratio   夹角(deg)   ‖s_total‖\n');
    for j = 1:top_k
        idx = order_gap(j);
        fprintf('    %2d  %4d  %.2e   %.2e   %.2e   %.2e  %7.3f    %6.1f    %.2e\n', ...
            all_iter(idx), all_node(idx), all_gap(idx), ...
            all_smain(idx), all_sreg(idx), all_srate(idx), all_ratio(idx), ...
            all_ang(idx), all_stotal(idx));
    end
    fprintf('\n');
end


function ang_deg = compute_angle_between(v1, v2)
% COMPUTE_ANGLE_BETWEEN 计算二维向量逐行夹角（度，[0, 180]）。

    n1 = vecnorm(v1, 2, 2);
    n2 = vecnorm(v2, 2, 2);
    denom = n1 .* n2;
    dot_val = sum(v1 .* v2, 2);
    cos_val = zeros(size(denom));
    valid = denom > 0;
    cos_val(valid) = max(-1, min(1, dot_val(valid) ./ denom(valid)));
    ang_deg = acosd(cos_val);
    ang_deg(~valid) = NaN;
end


function print_band_stats(label, mask, s_total, gap, sigma_shift)
% PRINT_BAND_STATS 打印单个节点分区的数量、‖s_total‖ 最小值、最大 gap 和中位拉偏角。

    cnt = sum(mask);
    if cnt == 0
        fprintf('%s:   0 个\n', label);
        return;
    end
    fprintf('%s: %3d 个 | min‖s_total‖=%.2e | max gap=%.2e | 中位|Δσ|=%.2f°\n', ...
        label, cnt, min(s_total(mask)), max(gap(mask)), median(abs(sigma_shift(mask))));
end
