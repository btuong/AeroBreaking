function Metrics = extract_compare_metrics( ...
        Result, RunInfo, case_name, Case, elapsed_seconds)
% EXTRACT_COMPARE_METRICS 从一个工况的运行结果取出逐轮指标，存成可单独保存的小结构体。
%
% 在阶段3-1 的 extract_converge_metrics 基础上，加单位范数模式的标识和 ccd 的逐轮量。
% 逐轮量取自 Result.history(k)；这一轮没有候选解（P3 失败）时，该轮数值量为 NaN。
%
% 输入:
%   Result          - run_compare_case 返回的 Result
%   RunInfo         - run_compare_case 返回的运行信息（平台起始轮、各轮用时）
%   case_name       - 工况名
%   Case            - list_compare_cases 的一个工况（name、type、w、p、keep_control_bounds）
%   elapsed_seconds - 运行用时 (s)
%
% 输出 Metrics（逐轮字段均为 K x 1，K 为尝试次数）:
%   case_name、type、w、elapsed_seconds     工况信息（同阶段3-1）
%   mode                                    'regularized' 或 'ccd'
%   p、keep_control_bounds                  ccd 的罚权与箱形边界开关（regularized 为 NaN/false）
%   status、stop_reason、stop_reason_raw、stop_detail  运行状态；stop_reason 把主代码的
%                                           'max_iterations' 记为 'max_iter'，其余照旧
%   num_attempted、num_accepted             尝试轮数、接受轮数
%   final_index                             最后被接受的轮号，没有接受解时为 NaN
%   plateau_start_iter                      平台起始轮，未因平台停止时为 NaN
%   plateau_mean_impulse、plateau_range     平台窗口内总脉冲均值与极差 (m/s)
%   iter_seconds                            各轮用时 (s)
%   accepted、candidate_available           逻辑量
%   total_impulse_m_s                       总脉冲 (m/s)
%   apoapsis_km、inclination_deg            终端远地点 (km)、倾角 (deg)
%   max_ratio                               可行违反比
%   feasible                                P2 可行性检查是否通过（各通道违反量都在容差内）
%   J、C、Gamma、Theta                       罚函数及三部分（候选解处）
%   delta_L、rho                            预测下降 ΔL 与下降比 ρ
%   delta_L_gamma、delta_J_gamma、error_gamma  附加项 Γ 的预测下降、真实下降、预测误差
%   step_max                                步长（候选解与参考的相邻解差，归一化单位）
%   max_tight_gap                           max|1-‖u‖|
%   num_untight                             |1-‖u‖| > 1e-6 的节点数
%   turn_median_deg                         各节点相对上一接受解（首轮为初始参考）的转角 |Δσ| 的中位数 (deg)
%   convex_error_flag、convex_error_names   凸项一致性检查是否报警及报警项名
%   max_inward_gap、max_outward_gap         max(1-‖u‖, 0) 与 max(‖u‖-1, 0)（向内/向外的差）
%   num_slack_capped                        ε 触上界 ε_max 的节点数（regularized 恒 0）
%   num_bound_active                        ‖s_bound,i‖ > 1e-12 的节点数（对偶不可用时 NaN）
%   circle_predicted、circle_actual、circle_error
%                                           圆约束组分项（regularized 为 control_reg，ccd 为
%                                           unit_norm_penalty）的预测下降、真实下降、预测误差
%   max_eps                                 max ε（regularized 为 NaN）

    History = Result.history;
    K = numel(History);
    Metrics.case_name = case_name;
    Metrics.type = Case.type;
    Metrics.w = Case.w;
    if strcmp(Case.type, 'ccd')
        Metrics.mode = 'ccd';
        Metrics.p = Case.p;
        circle_name = 'unit_norm_penalty';
    else
        Metrics.mode = 'regularized';
        Metrics.p = NaN;
        circle_name = 'control_reg';
    end
    Metrics.keep_control_bounds = logical(Case.keep_control_bounds);
    Metrics.elapsed_seconds = elapsed_seconds;
    Metrics.status = Result.status;
    Metrics.stop_reason_raw = Result.stop_reason;
    if strcmp(Result.stop_reason, 'max_iterations')
        Metrics.stop_reason = 'max_iter';
    else
        Metrics.stop_reason = Result.stop_reason;
    end
    Metrics.stop_detail = Result.stop_detail;
    Metrics.num_attempted = Result.num_attempted;
    Metrics.num_accepted = Result.num_accepted;
    if Result.has_accepted_solution
        Metrics.final_index = Result.final_iteration.iter;
    else
        Metrics.final_index = NaN;
    end
    Metrics.plateau_start_iter = RunInfo.plateau_start_iter;
    Metrics.plateau_mean_impulse = RunInfo.plateau_mean_impulse;
    Metrics.plateau_range = RunInfo.plateau_range;
    Metrics.iter_seconds = RunInfo.iter_seconds;

    Metrics.accepted = false(K, 1);
    Metrics.candidate_available = false(K, 1);
    Metrics.feasible = false(K, 1);
    Metrics.convex_error_flag = false(K, 1);
    Metrics.convex_error_names = {};
    names = {'total_impulse_m_s', 'apoapsis_km', 'inclination_deg', 'max_ratio', ...
        'J', 'C', 'Gamma', 'Theta', 'delta_L', 'rho', 'delta_L_gamma', ...
        'delta_J_gamma', 'error_gamma', 'step_max', 'max_tight_gap', ...
        'num_untight', 'turn_median_deg', 'max_inward_gap', 'max_outward_gap', ...
        'num_slack_capped', 'num_bound_active', 'circle_predicted', ...
        'circle_actual', 'circle_error', 'max_eps'};
    for n = 1:numel(names)
        Metrics.(names{n}) = nan(K, 1);
    end

    % 转角相对上一接受解；首轮相对初始参考
    previous_control = Result.initial_reference.control;
    for k = 1:K
        Record = History(k);
        Metrics.candidate_available(k) = logical(Record.trust.candidate_available);
        Metrics.accepted(k) = Metrics.candidate_available(k) ...
            && logical(Record.trust.accept_candidate);
        if ~Metrics.candidate_available(k)
            continue;
        end
        P2Feasibility = Record.subproblem.p2_feasibility;
        Metrics.total_impulse_m_s(k) = P2Feasibility.performance_report.value;
        Metrics.apoapsis_km(k) = P2Feasibility.terminal_report.metrics(1).actual_value;
        Metrics.inclination_deg(k) = P2Feasibility.terminal_report.metrics(2).actual_value;
        Metrics.max_ratio(k) = P2Feasibility.max_ratio;
        Metrics.feasible(k) = logical(P2Feasibility.feasible);

        Metrics.step_max(k) = Record.subproblem.convergence_report.max_value;
        ControlReport = Record.subproblem.control_report;
        if ControlReport.evaluated
            Metrics.max_tight_gap(k) = max(abs(ControlReport.tight_gap));
            Metrics.num_untight(k) = sum(abs(ControlReport.tight_gap) > 1e-6);
            Metrics.max_inward_gap(k) = ControlReport.summary_total.max_inward_gap;
            Metrics.max_outward_gap(k) = ControlReport.summary_total.max_outward_gap;
            Metrics.num_slack_capped(k) = ControlReport.summary_total.num_slack_capped;
            if any(~isnan(ControlReport.unit_norm_slack))
                Metrics.max_eps(k) = max(ControlReport.unit_norm_slack);
            end
            if ControlReport.dual_available
                Metrics.num_bound_active(k) = ...
                    sum(vecnorm(ControlReport.s_bound, 2, 2) > 1e-12);
            end
        end
        Control = Record.solution.control;
        turn_deg = abs(wrap_angle_deg( ...
            atan2d(Control.u2(:), Control.u1(:)) ...
            - atan2d(previous_control.u2(:), previous_control.u1(:))));
        Metrics.turn_median_deg(k) = median(turn_deg);
        if Metrics.accepted(k)
            previous_control = Control;
        end

        Evaluation = Record.trust.evaluation;
        if ~Evaluation.evaluated
            continue;
        end
        Metrics.J(k) = Evaluation.candidate.total;
        Metrics.C(k) = Evaluation.group.cost.candidate;
        Metrics.Gamma(k) = Evaluation.group.extra.candidate;
        Metrics.Theta(k) = Evaluation.group.penalty.candidate;
        Metrics.delta_L(k) = Evaluation.predicted_reduction;
        Metrics.rho(k) = Evaluation.ratio;
        Metrics.delta_L_gamma(k) = Evaluation.group.extra.predicted;
        Metrics.delta_J_gamma(k) = Evaluation.group.extra.actual;
        Metrics.error_gamma(k) = Evaluation.group.extra.error;
        Metrics.convex_error_flag(k) = Evaluation.convex_error_flag;
        Metrics.convex_error_names = union(Metrics.convex_error_names, ...
            Evaluation.convex_error_names);
        circle_index = find(strcmp(Evaluation.term_names, circle_name), 1);
        if ~isempty(circle_index)
            Metrics.circle_predicted(k) = ...
                Evaluation.term_predicted_reduction(circle_index);
            Metrics.circle_actual(k) = ...
                Evaluation.term_actual_reduction(circle_index);
            Metrics.circle_error(k) = Evaluation.term_prediction_error(circle_index);
        end
    end
end
