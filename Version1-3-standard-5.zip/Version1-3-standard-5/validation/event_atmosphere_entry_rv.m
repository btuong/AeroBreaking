function [position, isterminal, direction] = event_atmosphere_entry_rv(~, y, r_atm)
% EVENT_ATMOSPHERE_ENTRY_RV ode45 事件：ECI 状态下降穿越大气边界。

    position = norm(y(1:3)) - r_atm;
    isterminal = 1;
    direction = -1;
end
