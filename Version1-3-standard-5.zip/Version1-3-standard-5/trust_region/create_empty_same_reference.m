function SameReference = create_empty_same_reference()
% CREATE_EMPTY_SAME_REFERENCE 创建字段齐全的“同一参考点上没有上一次求解”记录。
%
% 被拒绝后参考点不变、半径变小，相邻两次求解就是 ΔL(r)、D(r) 曲线上的两个点。
% available 为假时其余字段都是 NaN。
% 下降比的阶对 1−ρ 算：ρ 趋于 1，对 ρ 本身取对数比没有意义。余项四部分依次为
% 状态×状态、状态×控制、状态×时长、控制×时长。

    SameReference = struct( ...
        'available', false, ...       % 上一次求解在同一参考点上
        'iter', NaN, ...              % 上一次求解的轮号
        'radius_scale', NaN, ...      % 上一次的半径 r
        'predicted_reduction', NaN, ...   % 上一次的预测下降 ΔL
        'prediction_error', NaN, ...  % 上一次的预测误差 D
        'error_order', NaN, ...       % D 随半径变化的阶 p
        'reduction_order', NaN, ...   % ΔL 随半径变化的阶
        'ratio_gap_order', NaN, ...   % 1−ρ = D/ΔL 随半径变化的阶
        'remainder_weighted', nan(1, 4), ...  % 上一次的动力学余项四部分（加权）
        'remainder_orders', nan(1, 4));       % 四部分各自随半径变化的阶
end
