function print_radius_scan(ScanRound, config)
% PRINT_RADIUS_SCAN 打印一轮参考点的半径扫描: 标题、八张表、结论。
%
% 输入:
%   ScanRound - solve_radius_scan_round 的输出（points 按 r 从大到小，metrics 是评价量）
%   config    - 读取 config.trust_region 的 max_scale、shrink_ratio
%
% 八张表共用 r 列（一行放不下 78 列，所以拆开）；r 后面带 ^ 的行是这一轮运行时实际用的
% 半径 r^k。目标分三部分：性能指标（只含总脉冲）、附加项（控制正则项）、罚项。
% ΔL、D、ΔJ 及其三部分、G、E 用 %.5e，余项四部分 %.4e，多留几位有效数字:
% 罚项部分把 ΔL 撑到 1e1 量级时，性能指标和附加项部分只有它的千分之几。
%   预测        r、状态、ΔL、D、ΔJ、ρ。状态带 * 的是按运行时的容差没解出、放宽容差
%               后才解出的；没解出的半径在表下面列出完整的求解状态和 MOSEK 终止码
%   ΔL 三部分   r、ΔL 的性能指标部分、附加项部分、罚项部分，松弛罚项
%   ΔJ 三部分   r、ΔJ 的性能指标部分、附加项部分、罚项部分
%   分区与修复  r、分区（偏大/合适/偏小）、候选解处的罚项、修复检查的松弛罚项、
%               修得掉与否
%   G 与 E      r、G 和有效下降 E 的性能指标、附加项两份（定义见
%               compute_radius_scan_metrics）
%   余项        r、K 估计、动力学余项的四部分（加权后）
%   阶          r、ΔL、D、1−ρ 和余项四部分各自的阶 = 本行与上一个解出的（更大的）半径
%               之间 ln(X 之比)/ln(r 之比)。下降比的阶对 1−ρ = D/ΔL 算（ρ 趋于 1，对 ρ
%               本身取对数比没有意义），等于 D 的阶减 ΔL 的阶
%   步长        最大步长/半径、六个通道各自的步长/半径、各圈时长的最大相对变化
% 结论: 能维持的最大半径、松弛为零所需的半径（拐点）、两者的先后、本轮实际半径的
% 分区和 ρ、ΔJ(r^k)/max_r ΔJ(r)、G(r^k) 与 E(r^k)（两部分各一行）、阶段度量
% ΔL:性能指标(r_top) 和 ΔL:附加项(r_top)、拐点右边 G 之和是否随 r 不减、性能指标换成
% 总脉冲的系数、检查式 (2.15)、复现自检（r^k 那一行与运行时这一轮的 ΔL、D 是否一致）。

    Points = ScanRound.points;
    Metrics = ScanRound.metrics;
    print_round_header(ScanRound, config);

    %% 预测表
    fprintf('\n');
    widths = [7, 9, 12, 12, 12, 9];
    print_table_row({'r', '状态', 'ΔL', 'D', 'ΔJ', 'ρ'}, widths);
    for k = 1:numel(Points)
        Point = Points(k);
        if ~Point.success
            print_table_row([{format_scale(Point), ...
                shorten_status(Point.solver_status, false)}, ...
                repmat({'-'}, 1, 4)], widths);
            continue;
        end
        if Point.ratio_available
            ratio_text = sprintf('%.4f', Point.ratio);
        else
            ratio_text = '-';
        end
        print_table_row({format_scale(Point), ...
            shorten_status(Point.solver_status, Point.relaxed_tolerance), ...
            sprintf('%.5e', Point.predicted_reduction), ...
            sprintf('%.5e', Point.prediction_error), ...
            sprintf('%.5e', Point.actual_reduction), ratio_text}, widths);
    end
    print_solver_notes(Points);

    %% ΔL 三部分表: 性能指标、附加项、罚项，松弛罚项
    fprintf('\n');
    fprintf('  ΔL 的性能指标部分、附加项部分和罚项部分，松弛罚项:\n');
    widths = [7, 12, 12, 12, 9];
    print_table_row({'r', 'ΔL:性能指标', 'ΔL:附加项', 'ΔL:罚项', '松弛罚项'}, ...
        widths);
    for k = 1:numel(Points)
        Point = Points(k);
        if ~Point.success
            print_table_row([{format_scale(Point)}, repmat({'-'}, 1, 4)], widths);
            continue;
        end
        print_table_row({format_scale(Point), ...
            sprintf('%.5e', Point.cost_predicted), ...
            sprintf('%.5e', Point.extra_predicted), ...
            sprintf('%.5e', Point.penalty_predicted), ...
            sprintf('%.2e', Point.slack_penalty)}, widths);
    end

    %% ΔJ 三部分表: 性能指标、附加项、罚项
    fprintf('\n');
    fprintf('  ΔJ 的性能指标部分、附加项部分和罚项部分:\n');
    widths = [7, 12, 12, 12];
    print_table_row({'r', 'ΔJ:性能指标', 'ΔJ:附加项', 'ΔJ:罚项'}, widths);
    for k = 1:numel(Points)
        Point = Points(k);
        if ~Point.success
            print_table_row([{format_scale(Point)}, repmat({'-'}, 1, 3)], widths);
            continue;
        end
        print_table_row({format_scale(Point), ...
            sprintf('%.5e', Point.cost_actual), ...
            sprintf('%.5e', Point.extra_actual), ...
            sprintf('%.5e', Point.penalty_actual)}, widths);
    end

    %% 分区与修复表: 分区、候选解处的罚项、修复检查
    fprintf('\n');
    if isfinite(ScanRound.repair_radius_scale)
        fprintf(['  分区、候选解处的罚项，修复检查（候选解当参考、r = %.4g ' ...
            '再解 P3）:\n'], ScanRound.repair_radius_scale);
    else
        fprintf('  分区、候选解处的罚项，修复检查没做（scan.repair_check = false）:\n');
    end
    widths = [7, 4, 10, 10, 6];
    print_table_row({'r', '分区', '候选处罚项', '修复松弛', '修得掉'}, widths);
    for k = 1:numel(Points)
        Point = Points(k);
        if ~Point.success
            print_table_row([{format_scale(Point)}, repmat({'-'}, 1, 4)], widths);
            continue;
        end
        [repair_text, repairable_text] = format_repair(Point);
        print_table_row({format_scale(Point), Metrics.zones{k}, ...
            sprintf('%.2e', Point.candidate_penalty), repair_text, ...
            repairable_text}, widths);
    end

    %% G 与 E 表: 性能指标和附加项各一份
    fprintf('\n');
    fprintf('  G = ΔL 的该部分(r) − ΔL 的该部分(拐点)，E 为修复检查后的实测值:\n');
    widths = [7, 12, 12, 12, 12];
    print_table_row({'r', 'G:性能指标', 'G:附加项', 'E:性能指标', 'E:附加项'}, ...
        widths);
    for k = 1:numel(Points)
        Point = Points(k);
        if ~Point.success
            print_table_row([{format_scale(Point)}, repmat({'-'}, 1, 4)], widths);
            continue;
        end
        print_table_row({format_scale(Point), ...
            format_value(Metrics.gain_cost(k), '%.5e'), ...
            format_value(Metrics.gain_extra(k), '%.5e'), ...
            format_value(Metrics.effective_drop_cost(k), '%.5e'), ...
            format_value(Metrics.effective_drop_extra(k), '%.5e')}, widths);
    end

    %% 余项表: K 估计和动力学余项四部分
    fprintf('\n');
    fprintf('  K 估计 D/‖d‖² 和动力学余项的四部分（加权后）:\n');
    widths = [7, 9, 11, 11, 11, 11];
    print_table_row({'r', 'K估计', '状态×状态', '状态×控制', '状态×时长', ...
        '控制×时长'}, widths);
    weighted = collect_remainder_parts(Points);   % K x 4
    for k = 1:numel(Points)
        Point = Points(k);
        if ~Point.success
            print_table_row([{format_scale(Point)}, repmat({'-'}, 1, 5)], widths);
            continue;
        end
        cells = cell(1, 6);
        cells{1} = format_scale(Point);
        cells{2} = sprintf('%.2e', Point.curvature_estimate);
        for p = 1:4
            cells{p + 2} = sprintf('%.4e', weighted(k, p));
        end
        print_table_row(cells, widths);
    end

    %% 阶表: ΔL、D、1−ρ 和余项四部分各自随半径变化的阶
    fprintf('\n');
    fprintf('  与上一个解出的半径之间的阶 ln(X 之比)/ln(r 之比):\n');
    widths = [7, 6, 6, 6, 10, 10, 10, 10];
    print_table_row({'r', 'ΔL', 'D', '1-ρ', '状态×状态', '状态×控制', ...
        '状态×时长', '控制×时长'}, widths);
    reduction = [Points.predicted_reduction]';
    prediction_error = [Points.prediction_error]';
    % 1−ρ = D/ΔL 只在 ΔL 为正时有意义，其余记 NaN
    ratio_gap = nan(size(reduction));
    positive = reduction > 0;
    ratio_gap(positive) = prediction_error(positive) ./ reduction(positive);
    order_values = [reduction, prediction_error, ratio_gap, weighted];   % K x 7
    orders = compute_radius_orders(Points, order_values);
    for k = 1:numel(Points)
        cells = cell(1, 8);
        cells{1} = format_scale(Points(k));
        for c = 1:7
            cells{c + 1} = format_order(orders(k, c));
        end
        print_table_row(cells, widths);
    end

    %% 步长表
    fprintf('\n');
    fprintf('  最大步长/半径、各通道的步长/半径和各圈时长的最大相对变化:\n');
    widths = [7, 7, 7, 7, 7, 7, 7, 7, 9];
    print_table_row({'r', '最大', '通道 r', 'V', 'gamma', 'phi', 'psi', 'P', ...
        '时长变化'}, widths);
    for k = 1:numel(Points)
        Point = Points(k);
        if ~Point.success
            print_table_row([{format_scale(Point)}, repmat({'-'}, 1, 8)], widths);
            continue;
        end
        cells = cell(1, 9);
        cells{1} = format_scale(Point);
        cells{2} = sprintf('%.3f', Point.step_ratio);
        for c = 1:6
            cells{c + 2} = sprintf('%.3f', Point.step_ratio_channels(c));
        end
        cells{9} = sprintf('%.2e', max(abs(Point.time_change)));
        print_table_row(cells, widths);
    end

    %% 结论
    print_round_conclusions(ScanRound);
end


function print_round_header(ScanRound, config)
% PRINT_ROUND_HEADER 打印扫描标题: 轮号、参考处的 J、罚项、性能指标、附加项和总脉冲、r_max、ρ1、本轮实际半径。

    Attempt = ScanRound.attempt;
    if ~Attempt.subproblem_success
        decision_text = 'P3 失败';
    elseif Attempt.accept_candidate
        decision_text = '接受';
    else
        decision_text = '拒绝';
    end
    pieces = { ...
        sprintf('半径扫描: 第 %d 轮参考点', ScanRound.iter), ...
        sprintf('参考处 J %.6e', ScanRound.reference_J), ...
        sprintf('罚项 %.6e', ScanRound.reference_penalty), ...
        sprintf('性能指标 %.6e', ScanRound.reference_cost), ...
        sprintf('附加项 %.6e', ScanRound.reference_extra), ...
        sprintf('总脉冲 %.3f m/s', ScanRound.reference_impulse), ...
        sprintf('r_max %.4g', config.trust_region.max_scale), ...
        sprintf('ρ1 %.2f', config.trust_region.shrink_ratio), ...
        sprintf('本轮实际半径 r^k %.4g（运行时%s）', Attempt.radius_scale, ...
            decision_text)};
    fprintf('\n');
    print_joined_pieces(pieces, 78);
    if numel(ScanRound.same_iters) > 1
        fprintf('  这个参考点同时是第 %s 轮的参考点\n', strjoin(arrayfun( ...
            @num2str, ScanRound.same_iters, 'UniformOutput', false), ', '));
    end
end


function print_round_conclusions(ScanRound)
% PRINT_ROUND_CONCLUSIONS 打印结论行（读 ScanRound.metrics，不重新计算）。

    Points = ScanRound.points;
    Metrics = ScanRound.metrics;
    fprintf('\n');
    fprintf('能维持的最大半径: %s\n', format_radius(Metrics.hold_radius));
    fprintf('松弛为零所需的半径（拐点）: %s\n', format_radius(Metrics.zero_radius));
    fprintf('两者的先后: %s\n', Metrics.order_text);
    if isempty(Metrics.actual_zone)
        zone_text = 'P3 没解出';
    else
        zone_text = Metrics.actual_zone;
    end
    fprintf('本轮实际半径: r^k = %.4g（%s）| ρ(r^k) = %s\n', ...
        Metrics.actual_radius, zone_text, format_value(Metrics.actual_ratio, '%.4f'));
    if isfinite(Metrics.best_index)
        best_text = sprintf('ΔJ 最大在 r = %.4g', ...
            Points(Metrics.best_index).radius_scale);
    else
        best_text = '没有解出的半径';
    end
    fprintf('ΔJ(r^k)/max ΔJ(r) = %s（%s）\n', ...
        format_value(Metrics.actual_share, '%.4f'), best_text);
    fprintf('G:性能指标(r^k) = %s | E:性能指标(r^k) = %s\n', ...
        format_value(Metrics.actual_gain_cost, '%.5e'), ...
        format_value(Metrics.actual_effective_drop_cost, '%.5e'));
    fprintf('G:附加项(r^k) = %s | E:附加项(r^k) = %s\n', ...
        format_value(Metrics.actual_gain_extra, '%.5e'), ...
        format_value(Metrics.actual_effective_drop_extra, '%.5e'));
    fprintf('阶段度量 (r = %.4g): ΔL:性能指标 = %s | ΔL:附加项 = %s\n', ...
        Metrics.stage_radius, format_value(Metrics.stage_cost, '%.5e'), ...
        format_value(Metrics.stage_extra, '%.5e'));
    fprintf('拐点右边 G:性能指标 + G:附加项 随 r 不减: %s\n', Metrics.gain_sum_text);
    fprintf('性能指标换成总脉冲 (m/s) 乘 VU/w_P = %.6g\n', ScanRound.impulse_factor);
    fprintf('检查式 (2.15): %s\n', Metrics.check_text);
    if ~isempty(Metrics.violation_text)
        fprintf('  %s\n', Metrics.violation_text);
    end
    print_replay_line(Metrics);
end


function print_replay_line(Metrics)
% PRINT_REPLAY_LINE 打印复现自检: r^k 那一行是否复现运行时这一轮的 ΔL、D。

    if ~Metrics.replay_available
        fprintf('复现自检: 无可比（运行时 P3 失败或扫描在 r^k 上没解出）\n');
        return;
    end
    if Metrics.replay_ok
        verdict = '复现';
    else
        verdict = 'WARN 对不上';
    end
    fprintf('复现自检: %s | ΔL 相对差 %.1e | D 相对差 %.1e\n', verdict, ...
        Metrics.replay_reduction_gap, Metrics.replay_error_gap);
    fprintf('  ρ 运行时 %s | 扫描 %s\n', format_value(Metrics.run_ratio, '%.4f'), ...
        format_value(Metrics.actual_ratio, '%.4f'));
end


function [repair_text, repairable_text] = format_repair(Point)
% FORMAT_REPAIR 评价表里修复检查两列的文本: 修复后的松弛罚项、修得掉（是/否）。
%
% 没做修复检查时两列都是 '-'；修复用的 P3 没解出时第一列写截短的求解状态、第二列 '否'。

    if ~Point.repair_evaluated
        repair_text = '-';
        repairable_text = '-';
        return;
    end
    if ~Point.repair_success
        repair_text = shorten_status(Point.repair_status, false);
        repairable_text = '否';
        return;
    end
    repair_text = sprintf('%.2e', Point.repair_slack_penalty);
    if Point.repair_relaxed_tolerance
        repair_text = [repair_text '*'];
    end
    if Point.repair_slack_zero
        repairable_text = '是';
    else
        repairable_text = '否';
    end
end


function text = format_value(value, format_spec)
% FORMAT_VALUE 数值的文本；NaN 显示为 '-'。

    if isfinite(value)
        text = sprintf(format_spec, value);
    else
        text = '-';
    end
end


function text = format_radius(radius)
% FORMAT_RADIUS 半径的文本；NaN 表示没有，显示“无”。

    if isfinite(radius)
        text = sprintf('r = %.4g', radius);
    else
        text = '无';
    end
end


function weighted = collect_remainder_parts(Points)
% COLLECT_REMAINDER_PARTS 把各半径的动力学余项四部分（加权后）排成 K x 4；没解出的半径整行为 NaN。

    weighted = nan(numel(Points), 4);
    for k = 1:numel(Points)
        if Points(k).success
            weighted(k, :) = Points(k).remainder_split.weighted;
        end
    end
end


function text = shorten_status(status, relaxed_tolerance)
% SHORTEN_STATUS 求解状态过长时截短，保证表格不超 78 列；放宽容差后解出的末尾加 *。

    if relaxed_tolerance
        max_length = 7;
        mark = '*';
    else
        max_length = 8;
        mark = '';
    end
    if numel(status) > max_length
        text = [status(1:max_length - 1) '~' mark];
    else
        text = [status mark];
    end
end


function print_solver_notes(ScanPoints)
% PRINT_SOLVER_NOTES 预测表下面的求解说明: * 的含义，没解出的半径的完整状态和终止码。

    if any([ScanPoints.relaxed_tolerance])
        fprintf('  * 按运行时的容差没解出，换上 scan.retry_solver 的容差后解出\n');
    end
    failed = find(~[ScanPoints.success]);
    if isempty(failed)
        return;
    end
    fprintf('  没解出的半径（求解状态，MOSEK 终止码）:\n');
    for k = failed
        Point = ScanPoints(k);
        if isempty(Point.response_name)
            fprintf('    r = %.4g: %s\n', Point.radius_scale, Point.solver_status);
        else
            fprintf('    r = %.4g: %s，%s\n', Point.radius_scale, ...
                Point.solver_status, Point.response_name);
        end
    end
end


function orders = compute_radius_orders(ScanPoints, values)
% COMPUTE_RADIUS_ORDERS 相邻两个解出的半径之间各量随 r 变化的阶，记在较小的那个半径上。
%
% values 为 K x M，第 k 行是第 k 个半径上的 M 个量（ScanPoints 按 r 从大到小）。
% 阶 = ln(X_大 / X_小) / ln(r_大 / r_小)。两处的 X 都为正才算，否则为 NaN；
% 第一个解出的半径没有可比的、没解出的半径，整行为 NaN。

    orders = nan(size(values));
    previous = 0;
    for k = 1:numel(ScanPoints)
        if ~ScanPoints(k).success
            continue;
        end
        if previous > 0 && ScanPoints(previous).radius_scale ...
                ~= ScanPoints(k).radius_scale
            radius_log = log(ScanPoints(previous).radius_scale ...
                / ScanPoints(k).radius_scale);
            larger = values(previous, :);
            smaller = values(k, :);
            usable = larger > 0 & smaller > 0;
            orders(k, usable) = log(larger(usable) ./ smaller(usable)) / radius_log;
        end
        previous = k;
    end
end


function text = format_order(order)
% FORMAT_ORDER 阶的文本：保留两位小数，无法定义时显示 '-'。

    if isfinite(order)
        text = sprintf('%.2f', order);
    else
        text = '-';
    end
end


function text = format_scale(Point)
% FORMAT_SCALE 表里 r 列的文本；这一轮运行时实际用的半径 r^k 后面带 ^。

    text = sprintf('%.4g', Point.radius_scale);
    if Point.is_actual_radius
        text = [text '^'];
    end
end


function print_table_row(cells, widths)
% PRINT_TABLE_ROW 按终端显示宽度打印一行表格：首列左对齐，其余列右对齐，缩进两格。

    parts = cell(1, numel(cells));
    for c = 1:numel(cells)
        num_spaces = max(widths(c) - display_width(cells{c}), 0);
        if c == 1
            parts{c} = [cells{c}, blanks(num_spaces)];
        else
            parts{c} = [blanks(num_spaces), cells{c}];
        end
    end
    fprintf('  %s\n', strjoin(parts, ' '));
end


function print_joined_pieces(pieces, max_width)
% PRINT_JOINED_PIECES 把若干短句用 ' | ' 连成行，超过 max_width 个显示列就在句间换行（续行缩进两格）。

    line_text = pieces{1};
    for k = 2:numel(pieces)
        joined = [line_text ' | ' pieces{k}];
        if display_width(joined) > max_width
            fprintf('%s\n', line_text);
            line_text = ['  ' pieces{k}];
        else
            line_text = joined;
        end
    end
    fprintf('%s\n', line_text);
end


function width = display_width(text)
% DISPLAY_WIDTH 计算文本在终端中的显示宽度：U+2E80 及以上的字符算两格。

    codes = double(char(text));
    width = numel(codes) + sum(codes >= 11904);
end
