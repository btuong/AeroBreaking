function Metrics = extract_compare_metrics( ...
        Result, RunInfo, case_name, Case, elapsed_seconds)
% EXTRACT_COMPARE_METRICS 从单次 SCCP 运行结果提取逐轮指标，存成小结构体。
%
% 逐轮量取自 Result.history(k)；该轮未返回候选解（P3 失败）时对应数值记为 NaN。
% 另存初始控制分量 initial_u1、initial_u2（N x 1），供汇总脚本按 D/E 分组统计
% 首轮转角与全程滞留区间。
%
% 输入:
%   Result          - run_compare_case 返回的 Result
%   RunInfo         - run_compare_case 返回的运行信息
%   case_name       - 工况名
%   Case            - list_compare_cases 的单条工况结构体
%   elapsed_seconds - 运行用时 (s)
%
% 输出 Metrics（逐轮字段均为 K x 1，K 为尝试次数）:
%   mode, c_eta, sccp_slack_max, enable_control_continuity, init_control_mode
%   first_status                            - 首轮 SolverResult.status
%   eta, eta_per_node, cap_angle_deg        - 共用松弛、人均松弛、命题 C1 帽半角 (deg)
%   turn_median_deg, turn_p95_deg, turn_max_deg - 相对上一参考的单步转角分布 (deg)
%   max_inward_gap, max_outward_gap         - max(1-‖u‖, 0) 与 max(‖u‖-1, 0)
%   num_untight, num_untight_1e3            - |1-‖u‖| > 1e-6 与 > 1e-3 的节点数
%   circle_predicted, circle_actual, circle_error - unit_norm_penalty 分项账
%   dual_inner_sum_ratio                    - 非零参考处 Σ|y_i| / (N*C_eta)
%   dual_inner_sum_all_ratio                - 全部行 Σ(-y_i) / (N*C_eta)
%   dual_inner_max_abs                      - unit_norm_inner 最大 |y_i|
%   num_stay_pos45                          - 该轮落在 45°±15° 内的有效控制节点数

    History = Result.history;
    K = numel(History);

    %% ===== 1. 工况元信息与停止状态 =====
    Metrics = struct();
    Metrics.case_name = case_name;
    Metrics.type = Case.type;
    Metrics.mode = 'sccp';
    Metrics.c_eta = Case.c_eta;
    Metrics.sccp_slack_max = Case.sccp_slack_max;
    Metrics.enable_control_continuity = logical(Case.enable_control_continuity);
    Metrics.init_control_mode = Case.init_control_mode;
    Metrics.elapsed_seconds = elapsed_seconds;
    Metrics.status = Result.status;
    Metrics.stop_reason_raw = Result.stop_reason;
    if strcmp(Result.stop_reason, 'max_iterations')
        Metrics.stop_reason = 'max_iter';
    else
        Metrics.stop_reason = Result.stop_reason;
    end
    Metrics.stop_detail = Result.stop_detail;
    Metrics.num_attempted = Result.num_attempted;
    Metrics.num_accepted = Result.num_accepted;
    if K >= 1
        Metrics.first_status = History(1).subproblem.solver.status;
    else
        Metrics.first_status = '';
    end
    if Result.has_accepted_solution
        Metrics.final_index = Result.final_iteration.iter;
    else
        Metrics.final_index = NaN;
    end
    Metrics.plateau_start_iter = RunInfo.plateau_start_iter;
    Metrics.plateau_mean_impulse = RunInfo.plateau_mean_impulse;
    Metrics.plateau_range = RunInfo.plateau_range;
    Metrics.iter_seconds = RunInfo.iter_seconds;
    Metrics.initial_u1 = Result.initial_reference.control.u1(:);
    Metrics.initial_u2 = Result.initial_reference.control.u2(:);

    %% ===== 2. 预分配逐轮指标 =====
    Metrics.accepted = false(K, 1);
    Metrics.candidate_available = false(K, 1);
    Metrics.feasible = false(K, 1);
    Metrics.solver_status = repmat({''}, K, 1);
    Metrics.convex_error_flag = false(K, 1);
    Metrics.convex_error_names = {};
    scalar_names = { ...
        'total_impulse_m_s', 'apoapsis_km', 'inclination_deg', 'max_ratio', ...
        'J', 'C', 'Gamma', 'Theta', 'delta_L', 'rho', 'step_max', ...
        'eta', 'eta_per_node', 'cap_angle_deg', ...
        'turn_median_deg', 'turn_p95_deg', 'turn_max_deg', ...
        'max_tight_gap', 'max_inward_gap', 'max_outward_gap', ...
        'min_u_norm', 'max_u_norm', 'num_untight', 'num_untight_1e3', ...
        'num_slack_capped', 'num_bound_active', 'stationarity_max', ...
        'circle_predicted', 'circle_actual', 'circle_error', ...
        'dual_inner_sum_ratio', 'dual_inner_sum_all_ratio', ...
        'dual_inner_max_abs', 'num_stay_pos45'};
    for n = 1:numel(scalar_names)
        Metrics.(scalar_names{n}) = nan(K, 1);
    end

    %% ===== 3. 逐轮提取 =====
    % 转角与对偶计算均相对上一接受解；首轮相对初始参考
    previous_control = Result.initial_reference.control;
    for k = 1:K
        Record = History(k);
        Metrics.solver_status{k} = Record.subproblem.solver.status;
        Metrics.candidate_available(k) = logical(Record.trust.candidate_available);
        Metrics.accepted(k) = Metrics.candidate_available(k) ...
            && logical(Record.trust.accept_candidate);
        if ~Metrics.candidate_available(k)
            continue;
        end

        % P2 可行性与收敛步长
        P2Feasibility = Record.subproblem.p2_feasibility;
        Metrics.total_impulse_m_s(k) = P2Feasibility.performance_report.value;
        Metrics.apoapsis_km(k) = ...
            P2Feasibility.terminal_report.metrics(1).actual_value;
        Metrics.inclination_deg(k) = ...
            P2Feasibility.terminal_report.metrics(2).actual_value;
        Metrics.max_ratio(k) = P2Feasibility.max_ratio;
        Metrics.feasible(k) = logical(P2Feasibility.feasible);
        Metrics.step_max(k) = Record.subproblem.convergence_report.max_value;

        % 控制量报告、紧性、η 与命题 C1 帽半角
        ControlReport = Record.subproblem.control_report;
        prev_u1 = previous_control.u1(:);
        prev_u2 = previous_control.u2(:);
        prev_u_norm = hypot(prev_u1, prev_u2);
        if ControlReport.evaluated
            N_nodes = ControlReport.num_nodes;
            eta_value = max(ControlReport.unit_norm_slack);
            Metrics.eta(k) = eta_value;
            Metrics.eta_per_node(k) = eta_value / N_nodes;
            Metrics.cap_angle_deg(k) = acosd(min(1, max(-1, ...
                1 - Metrics.eta_per_node(k) / 2)));

            Metrics.max_tight_gap(k) = max(abs(ControlReport.tight_gap));
            Metrics.max_inward_gap(k) = ControlReport.summary_total.max_inward_gap;
            Metrics.max_outward_gap(k) = ControlReport.summary_total.max_outward_gap;
            Metrics.min_u_norm(k) = min(ControlReport.u_norm);
            Metrics.max_u_norm(k) = max(ControlReport.u_norm);
            Metrics.num_untight(k) = sum(abs(ControlReport.tight_gap) > 1e-6);
            Metrics.num_untight_1e3(k) = sum(abs(ControlReport.tight_gap) > 1e-3);
            Metrics.num_slack_capped(k) = ...
                ControlReport.summary_total.num_slack_capped;
            Metrics.num_stay_pos45(k) = sum( ...
                ControlReport.u_norm > 1e-9 ...
                & abs(wrap_angle_deg(ControlReport.sigma_deg - 45)) <= 15);

            if ControlReport.dual_available
                Metrics.num_bound_active(k) = ...
                    sum(vecnorm(ControlReport.s_bound, 2, 2) > 1e-6);
                Metrics.stationarity_max(k) = max(abs( ...
                    ControlReport.stationarity_residual), [], 'all');

                % 非零参考节点上由 lambda_inner / (2*‖ū_i‖) 还原 |y_i|，再除以 N*C_eta
                valid_ref = prev_u_norm > 1e-9;
                if any(valid_ref)
                    sum_y = sum(ControlReport.lambda_inner(valid_ref) ...
                        ./ (2 * prev_u_norm(valid_ref)));
                    Metrics.dual_inner_sum_ratio(k) = ...
                        sum_y / (N_nodes * Case.c_eta);
                end
            end

            % 从 P3 乘子报告与求解器原始对偶 y 读取全部 unit_norm_inner 行统计
            [sum_all_ratio, max_abs_dual] = extract_inner_dual_from_p3( ...
                Record.subproblem, N_nodes, Case.c_eta);
            Metrics.dual_inner_sum_all_ratio(k) = sum_all_ratio;
            Metrics.dual_inner_max_abs(k) = max_abs_dual;
        end

        % 相对上一参考的单步转角分布（排除零向量节点）
        Control = Record.solution.control;
        curr_u_norm = hypot(Control.u1(:), Control.u2(:));
        valid_turn = prev_u_norm > 1e-9 & curr_u_norm > 1e-9;
        if any(valid_turn)
            turn_deg = abs(wrap_angle_deg( ...
                atan2d(Control.u2(valid_turn), Control.u1(valid_turn)) ...
                - atan2d(prev_u2(valid_turn), prev_u1(valid_turn))));
            Metrics.turn_median_deg(k) = median(turn_deg);
            Metrics.turn_p95_deg(k) = compute_percentile(turn_deg, 95);
            Metrics.turn_max_deg(k) = max(turn_deg);
        end
        if Metrics.accepted(k)
            previous_control = Control;
        end

        % 候选解评价与圆约束组分项账
        Evaluation = Record.trust.evaluation;
        if ~Evaluation.evaluated
            continue;
        end
        Metrics.J(k) = Evaluation.candidate.total;
        Metrics.C(k) = Evaluation.group.cost.candidate;
        Metrics.Gamma(k) = Evaluation.group.extra.candidate;
        Metrics.Theta(k) = Evaluation.group.penalty.candidate;
        Metrics.delta_L(k) = Evaluation.predicted_reduction;
        Metrics.rho(k) = Evaluation.ratio;
        Metrics.convex_error_flag(k) = Evaluation.convex_error_flag;
        Metrics.convex_error_names = union(Metrics.convex_error_names, ...
            Evaluation.convex_error_names);

        circle_index = find(strcmp(Evaluation.term_names, 'unit_norm_penalty'), 1);
        if ~isempty(circle_index)
            Metrics.circle_predicted(k) = ...
                Evaluation.term_predicted_reduction(circle_index);
            Metrics.circle_actual(k) = ...
                Evaluation.term_actual_reduction(circle_index);
            Metrics.circle_error(k) = Evaluation.term_prediction_error(circle_index);
        end
    end
end


function [sum_all_ratio, max_abs_dual] = extract_inner_dual_from_p3( ...
        SubproblemDiag, N_nodes, c_eta)
% EXTRACT_INNER_DUAL_FROM_P3 从 P3 乘子报告与求解器对偶向量提取内逼近行乘子汇总。

    sum_all_ratio = NaN;
    max_abs_dual = NaN;
    MultiplierReport = SubproblemDiag.p3_check.multiplier_report;
    if MultiplierReport.evaluated
        classes = MultiplierReport.classes;
        inner_idx = find(strcmp({classes.name}, 'unit_norm_inner'), 1);
        if ~isempty(inner_idx)
            max_abs_dual = classes(inner_idx).max_abs;
        end
    end

    LinearRows = SubproblemDiag.p3_check.solver_feasibility_report.linear_rows;
    Dual = SubproblemDiag.solver.dual;
    if ~isempty(Dual.y) && isfield(LinearRows, 'block_names')
        block_id = find(strcmp(LinearRows.block_names, 'unit_norm_inner'), 1);
        if ~isempty(block_id) && numel(Dual.y) == numel(LinearRows.block)
            y_inner = Dual.y(LinearRows.block == block_id);
            sum_all_ratio = sum(-y_inner) / (N_nodes * c_eta);
        end
    end
end


function value = compute_percentile(values, percent)
% COMPUTE_PERCENTILE 用线性插值求有限数值的指定分位点。

    values = sort(values(~isnan(values(:))));
    count = numel(values);
    if count == 0
        value = NaN;
        return;
    end
    position = 1 + (count - 1) * percent / 100;
    lower_index = floor(position);
    upper_index = ceil(position);
    value = values(lower_index) ...
        + (position - lower_index) * (values(upper_index) - values(lower_index));
end
