function [c_x, c_P] = linearize_coast_pass_to_entry(x_ci_N, P1, ConstData)
% LINEARIZE_COAST_PASS_TO_ENTRY 中心差分计算下一圈入口状态对出口状态和脉冲的偏导。
%
% 数学形式:
%   对真空映射 x_in = Φ(y, P)（y = [V, γ, φ, ψ]^T 为出口状态，出口半径固定
%   为 R_atm；P 为远地点脉冲，VU；x_in = [r, V, γ, φ, ψ]^T 为下一圈入口状态），
%   在 (ȳ, P̄) 处求中心差分偏导：
%       Φ_y = ∂Φ/∂y ∈ R^(5×4),    Φ_P = ∂Φ/∂P ∈ R^5
%   差分步长: V 取 1e-6/VU，γ、φ、ψ 取 0.00025°，P 取 0.001/VU（均为单侧步长）。
%
% 代码形式:
%   c_x 为 4×5，按出口分量存放（行 = V, γ, φ, ψ；列 = 入口分量 r, V, γ, φ, ψ），
%   即 Φ_y 的转置：c_x(j, i) = Φ_y(i, j)。c_P = Φ_P，5×1。
%
% 输入:
%   x_ci_N - 1x6 出口状态 [R_atm, V, gamma, phi, psi, 0]（首分量固定不扰动）
%   P1     - 远地点脉冲
%
% 输出:
%   c_x - 4x5 矩阵，第 1~4 行依次为入口状态 5 分量对出口 V/gamma/phi/psi 的偏导（Φ_y 的转置）
%   c_P - 5x1 入口状态对 P1 的偏导

    delta_V = 1e-6 / ConstData.VU;
    delta_gamma = deg2rad(0.00025);
    delta_phi = deg2rad(0.00025);
    delta_psi = deg2rad(0.00025);

    x21 = x_ci_N; x22 = x_ci_N;
    x21(2) = x21(2) - delta_V; x22(2) = x22(2) + delta_V;
    x31 = x_ci_N; x32 = x_ci_N;
    x31(3) = x31(3) - delta_gamma; x32(3) = x32(3) + delta_gamma;
    x41 = x_ci_N; x42 = x_ci_N;
    x41(4) = x41(4) - delta_phi; x42(4) = x42(4) + delta_phi;
    x51 = x_ci_N; x52 = x_ci_N;
    x51(5) = x51(5) - delta_psi; x52(5) = x52(5) + delta_psi;

    c_V = (evaluate_coast_pass_to_entry(x22, P1, ConstData) ...
        - evaluate_coast_pass_to_entry(x21, P1, ConstData)) / (2 * delta_V);
    c_gamma = (evaluate_coast_pass_to_entry(x32, P1, ConstData) ...
        - evaluate_coast_pass_to_entry(x31, P1, ConstData)) / (2 * delta_gamma);
    c_phi = (evaluate_coast_pass_to_entry(x42, P1, ConstData) ...
        - evaluate_coast_pass_to_entry(x41, P1, ConstData)) / (2 * delta_phi);
    c_psi = (evaluate_coast_pass_to_entry(x52, P1, ConstData) ...
        - evaluate_coast_pass_to_entry(x51, P1, ConstData)) / (2 * delta_psi);

    c_x = [c_V; c_gamma; c_phi; c_psi];

    delta_P = 0.001 / ConstData.VU;
    c_P = (evaluate_coast_pass_to_entry(x_ci_N, P1 + delta_P, ConstData) ...
        - evaluate_coast_pass_to_entry(x_ci_N, P1 - delta_P, ConstData)) ...
        / (2 * delta_P);
end
