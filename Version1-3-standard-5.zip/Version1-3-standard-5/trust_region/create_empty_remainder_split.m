function RemainderSplit = create_empty_remainder_split()
% CREATE_EMPTY_REMAINDER_SPLIT 创建字段齐全的“动力学余项没有按阶拆分”记录。
%
% 字段与 evaluate_remainder_split 的输出一致；未算时数值为 NaN。

    RemainderSplit.evaluated = false;
    RemainderSplit.names = {'state_state', 'state_control', 'state_time', ...
        'control_time'};
    RemainderSplit.labels = {'状态×状态', '状态×控制', '状态×时长', '控制×时长'};
    RemainderSplit.orders = [2, 1, 1, 0];       % 各部分随半径变化的阶
    RemainderSplit.weighted = nan(1, 4);        % 各部分 w·Σ|·|
    RemainderSplit.weighted_channel = nan(4, 5);  % 4 部分 x 5 通道 (r, V, γ, φ, ψ)
    RemainderSplit.total = NaN;                 % w·Σ|区间余项|
    RemainderSplit.closure = NaN;               % max|区间余项 − 四部分之和|，自检用
end
