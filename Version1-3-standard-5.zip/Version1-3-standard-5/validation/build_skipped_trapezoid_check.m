function TrapezoidCheck = build_skipped_trapezoid_check(reason)
% BUILD_SKIPPED_TRAPEZOID_CHECK 构造配置关闭或未接受时的跳过报告。

    TrapezoidCheck = create_empty_trapezoid_check();
    TrapezoidCheck.failure_reason = reason;
end
