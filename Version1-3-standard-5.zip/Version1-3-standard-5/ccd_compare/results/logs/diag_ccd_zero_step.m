% 诊断 ccd 下零步长可行性的残差和 P3 解检查的失败项（一次性脚本，不进主链）。
version_root = 'E:/ConvexPrograming/lzq/bbb2_AeroBreaking_Trustupdate/Version1-3-standard-5';
cd(version_root);
addpath('setup','dynamics','constraints','subproblem','trust_region','validation','iteration','output');
config = scp_config_default();
config.unit_norm.mode = 'ccd';
config.plot.enable_initial = false; config.plot.enable_iteration = false; config.plot.enable_final = false;
config.output.print_pre_iteration = false; config.output.print_iteration = false; config.output.print_summary = false;
config.output.save.brief_text = false; config.output.save.detail_text = false; config.output.save.scan_mat = false;
config.output.save.full_mat = false; config.output.save.control_text = false; config.output.save.control_mat = false;
config.validation.enable_trapezoid_check = false;

[ConstData, InitialState] = initialize_problem(config);
[InitialReference, InitialPropagation] = generate_initial_reference(ConstData, InitialState, config);
[RunState, ~] = initialize_scp_run(InitialReference, InitialPropagation, config);
TRS = RunState.trust_region;

Refs = {RunState.current_reference};
fprintf('--- reference 1 (initial): max|‖u‖-1| = %.3e\n', max(abs(hypot(InitialReference.control.u1, InitialReference.control.u2) - 1)));
for iter = 1:3
    [Sol, Diag] = solve_scp_subproblem(RunState.current_reference, RunState.trust_region, ConstData, config, iter);
    TR = update_trust_region(Sol, Diag, RunState.current_reference, RunState.trust_region, ConstData, config, iter);
    [RunState, Rec] = advance_scp_iteration(RunState, Sol, Diag, TR, ConstData, config, iter);
    Refs{end + 1} = RunState.current_reference;
    fprintf('--- iter %d: solver status %s, feasibility_report.success = %d, p3_check.success = %d\n', iter, Diag.solver.status, Diag.p3_check.solver_feasibility_report.success, Diag.p3_check.success);
    M = Diag.p3_check.solver_feasibility_report.metrics;
    for m = 1:numel(M)
        if M(m).evaluated && ~M(m).satisfied
            fprintf('    FAILED metric %-28s value %.3e rel %.3e tol %.3e worst_row %d\n', M(m).name, M(m).value, M(m).relative_value, M(m).tolerance, M(m).worst_row);
        end
    end
    S = Diag.p3_check.slack_report.metrics;
    for m = 1:numel(S)
        if S(m).evaluated && ~S(m).satisfied
            fprintf('    FAILED slack %-28s value %.3e tol %.3e\n', S(m).name, S(m).value, S(m).tolerance);
        end
    end
    R = Diag.p3_check.reformulation_report.metrics;
    for m = 1:numel(R)
        if ~R(m).feasibility_satisfied || (R(m).tightness_checked && ~R(m).tightness_satisfied)
            fprintf('    FAILED cone %-28s idx %d feas %.3e gap %.3e role %s\n', R(m).name, R(m).index, R(m).feasibility_residual, R(m).tightness_gap, R(m).tightness_role);
        end
    end
    fprintf('    min‖u‖-1 = %.3e | max ε = %.3e | max(ε - (‖u‖-1)) = %.3e | min(ε-(‖u‖-1)) = %.3e\n', ...
        min(Diag.control_report.u_norm - 1), max(Sol.unit_norm_slack), max(Sol.unit_norm_slack - (Diag.control_report.u_norm - 1)), min(Sol.unit_norm_slack - (Diag.control_report.u_norm - 1)));
    fprintf('    mosek pfeas con %.2e var %.2e acc %.2e, status %s, iters %d\n', Diag.solver.mosek_report.primal_violation_con, Diag.solver.mosek_report.primal_violation_var, Diag.solver.mosek_report.primal_violation_acc, Diag.solver.mosek_report.response_name, Diag.solver.mosek_report.num_iterations);
end

for r = 1:numel(Refs)
    Ref = Refs{r};
    [VI, nv] = build_variable_index(Ref, ConstData, config);
    LC = build_linear_constraints(VI, Ref, ConstData, config);
    z = zeros(nv, 1);
    z(VI.u1) = Ref.control.u1(:); z(VI.u2) = Ref.control.u2(:);
    un = hypot(Ref.control.u1(:), Ref.control.u2(:));
    z(VI.unit_norm_slack) = max(un - 1, 0);
    rows = LC.row_groups.unit_norm_inner(:);
    res = LC.matrix(rows, :) * z - LC.upper(rows);
    [mx, mi] = max(res);
    fprintf('--- ref %d: max(A z - upper) = %.3e at node %d, ‖u‖-1 = %.3e; nodes with res > 1e-12: %d\n', r, mx, mi, un(mi) - 1, sum(res > 1e-12));
end
disp('DIAG_DONE');
