function Tile = build_plot_tile(title_text, y_label, curves, ...
        reference, reference_label, log_scale)
% BUILD_PLOT_TILE 组装一个分块：标题、纵轴标签、若干曲线和可选参考线。
%
% 输入:
%   title_text      - 分块标题
%   y_label         - 纵轴标签，写成“名称 (单位)”
%   curves          - build_plot_curve 输出的结构体数组
%   reference       - 参考线数值（上限、目标或容差），没有时省略或给 NaN
%   reference_label - 参考线图例名称，如“上限”“目标”“容差”
%   log_scale       - 是否用对数纵轴，省略时为 false

    if nargin < 4
        reference = NaN;
    end
    if nargin < 5
        reference_label = '';
    end
    if nargin < 6
        log_scale = false;
    end
    Tile.title = title_text;
    Tile.y_label = y_label;
    Tile.curves = curves;
    Tile.reference = reference;
    Tile.reference_label = reference_label;
    Tile.log_scale = logical(log_scale);
end
