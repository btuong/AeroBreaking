function Summary = build_case_summary(Diagnosis)
% BUILD_CASE_SUMMARY 汇总一个代表工况的抵消、弦上平坦和互补积观测。

    Summary.name = Diagnosis.case_name;
    Summary.type = Diagnosis.reg_type;
    Summary.w = Diagnosis.w_reg;
    Summary.executed = ~isempty(Diagnosis.rounds);
    Summary.success = false;
    Summary.message = '';
    if isfield(Diagnosis, 'message')
        Summary.message = Diagnosis.message;
    end
    Summary.rounds = repmat(create_empty_round_summary(), 0, 1);
    if ~Summary.executed
        return;
    end
    round_list = cell(numel(Diagnosis.rounds), 1);
    for k = 1:numel(Diagnosis.rounds)
        round_list{k} = summarize_round(Diagnosis.rounds(k));
    end
    Summary.rounds = vertcat(round_list{:});
    Summary.success = all([Summary.rounds.main_usable] ...
        & [Summary.rounds.alternate_success]);
end


function Round = create_empty_round_summary()
% CREATE_EMPTY_ROUND_SUMMARY 创建一轮机理汇总的字段。

    Round = struct('iter', NaN, 'with_max_gap', NaN, 'without_max_gap', NaN, ...
        'with_min_margin', NaN, 'without_min_margin', NaN, ...
        'cancellation_nodes', 0, 'strong_cancellation_nodes', 0, ...
        'chord_flat_nodes', 0, 'chord_flat_untight_nodes', 0, ...
        'bound_max_error', NaN, 'max_abs_stationarity_residual', NaN, ...
        'untight_nodes', zeros(0, 1), 'untight_table', zeros(0, 13), ...
        'chord_candidates', zeros(0, 1), 'alternate_success', false, ...
        'alternate_status', '', 'main_usable', false);
end


function Round = summarize_round(Comparison)
% SUMMARIZE_ROUND 提取一轮的大gap节点、抵消候选与弦上平坦候选。

    With = Comparison.with_rate;
    Without = Comparison.without_rate;
    Round = create_empty_round_summary();
    Round.iter = Comparison.iter;
    Round.alternate_success = Comparison.alternate_success;
    Round.alternate_status = Comparison.alternate_status;
    if ~With.evaluated || ~With.dual_available
        return;
    end
    Round.main_usable = true;
    Round.with_max_gap = max(With.tight_gap);
    Round.with_min_margin = min(With.tightness_margin);
    Round.cancellation_nodes = sum(With.cancellation_candidate);
    strong = With.cancellation_cosine < -0.9 ...
        & With.cancellation_strength < 0.1;
    Round.strong_cancellation_nodes = sum(strong);
    Round.chord_flat_nodes = sum(With.chord_active & With.chord_flat);
    Round.chord_flat_untight_nodes = sum(With.chord_active ...
        & With.chord_flat & With.tight_gap > 1e-6);
    valid = isfinite(With.complementarity_bound);
    if any(valid)
        Round.bound_max_error = max(With.tight_gap(valid) ...
            - With.complementarity_bound(valid));
    end
    Round.max_abs_stationarity_residual = max(abs( ...
        With.stationarity_residual), [], 'all');
    untight = find(With.tight_gap > 1e-6);
    Round.untight_nodes = untight;
    table = [With.node(untight), With.tight_gap(untight), ...
        With.tightness_margin(untight), With.cone_complementarity(untight), ...
        With.cancellation_cosine(untight), With.cancellation_strength(untight), ...
        With.radial_main(untight), With.radial_regularizer(untight), ...
        With.chord_flatness(untight), ...
        Comparison.nonrate_margin(untight), Comparison.nonrate_cosine(untight), ...
        nan(numel(untight), 2)];
    [~, order] = sort(table(:, 2), 'descend');
    Round.chord_candidates = find(With.chord_active ...
        & With.chord_flat & With.tight_gap > 1e-6);
    if Comparison.alternate_success && Without.dual_available
        Round.without_max_gap = max(Without.tight_gap);
        Round.without_min_margin = min(Without.tightness_margin);
        table(:, 12) = Without.tight_gap(untight);
        table(:, 13) = Without.tightness_margin(untight);
    end
    Round.untight_table = table(order(1:min(10, end)), :);
end
