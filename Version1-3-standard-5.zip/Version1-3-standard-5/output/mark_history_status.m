function mark_history_status(ax, iters, status, values, color, marker)
% MARK_HISTORY_STATUS 按接受/拒绝画点: 接受实心，拒绝空心；没有数值的轮（NaN）不画点。
%
% 输入:
%   ax     - 坐标轴
%   iters  - 1 x K 迭代序号
%   status - 1 x K 元胞，各轮 'accepted' / 'rejected' / 'failed' / 'initial'
%   values - 1 x K 纵轴数值
%   color  - 1 x 3 颜色
%   marker - 标记形状（如 'o'、'd'、'^'），区分同一分块里的几条曲线；省略时为 'o'
%
% 标记不进图例；接受、拒绝的含义写在窗口标题下面一行。

    if nargin < 6 || isempty(marker)
        marker = 'o';
    end
    iters = iters(:)';
    values = values(:)';
    is_accepted = strcmp(status, 'accepted') & ~isnan(values);
    is_rejected = strcmp(status, 'rejected') & ~isnan(values);
    plot(ax, iters(is_accepted), values(is_accepted), marker, ...
        'LineStyle', 'none', 'MarkerFaceColor', color, 'Color', color, ...
        'MarkerSize', 7, 'HandleVisibility', 'off');
    plot(ax, iters(is_rejected), values(is_rejected), marker, ...
        'LineStyle', 'none', 'MarkerFaceColor', 'none', 'Color', color, ...
        'MarkerSize', 7, 'LineWidth', 1.2, 'HandleVisibility', 'off');
end
