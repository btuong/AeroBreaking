function [CurrentSolution, SubproblemDiag] = solve_scp_subproblem( ...
        CurrentReference, TrustRegionState, ConstData, config, iter)
% SOLVE_SCP_SUBPROBLEM 构建、求解并检查第 iter 轮 SOCP 子问题。
%
% 本函数依次完成：
%   1. 为全部 P3 决策变量建立统一索引。
%   2. 构建 P3 的目标系数（终端松弛罚项 + 脉冲 + 衔接与动力学松弛罚项 + 控制正则）。
%   3. 构建动力学、衔接、入轨、控制连续性与路径仿射约束。
%   4. 构建物理边界、信赖域与上图变量上下界。
%   5. 构建控制圆盘与绝对值上图二阶锥。
%   6. 求解前检查送入 MOSEK 的系数量级（只报告）。
%   7. 调用 MOSEK 求解本轮 P3。
%   8. 提取 P3 的解。
%   9. 把目标函数值按项拆开。
%   10. 步长（相邻解差）：本轮解相对当前参考的相邻解差。
%   11. P3 解检查：原始矩阵、松弛、锥重构和乘子。
%   12. P2 可行性检查：动力学违反量、衔接违反量、终端违反量、路径约束、性能指标和终端映射的余项。
%   13. 控制量报告：u 的紧性、σ 的偏向和 u 列驻点条件的对偶分解（只报告）。
%   14. 汇总本轮诊断。
%
% 本函数只回答“这轮 P3 解得怎么样”，不修改 RunState、参考或信赖域，
% 不做接受、推进、停止、梯形递推检查、绘图或打印。
%
% 信赖域半径按 TrustRegionState（倍数 r × 基准半径）装配；接受与半径
% 更新由 update_trust_region 决定，参考与信赖域的更新由
% advance_scp_iteration 负责。

    %% 1. 为全部 P3 决策变量建立统一索引
    [VariableIndex, num_variables] = build_variable_index( ...
        CurrentReference, ConstData, config);

    %% 2. 构建 P3 的目标系数（终端松弛罚项 + 脉冲 + 衔接与动力学松弛罚项 + 控制正则）
    [objective, objective_offset] = build_objective( ...
        VariableIndex, CurrentReference, ConstData, config);

    %% 3. 构建动力学、衔接、入轨、控制连续性与路径仿射约束
    LinearConstraints = build_linear_constraints( ...
        VariableIndex, CurrentReference, ConstData, config);

    %% 4. 构建物理边界、信赖域与上图变量上下界
    VariableBounds = build_variable_bounds( ...
        VariableIndex, CurrentReference, TrustRegionState, ...
        ConstData, config);

    %% 5. 构建控制圆盘与绝对值上图二阶锥
    ConicConstraints = build_conic_constraints( ...
        VariableIndex, CurrentReference, ConstData, config);

    %% 6. 求解前检查送入 MOSEK 的系数量级（只报告）
    % 返回按约束块统计的最大/最小系数、行内跨度和异常块，求解失败时也保留
    CoefficientReport = scan_problem_coefficients( ...
        objective, LinearConstraints, VariableBounds, ...
        ConicConstraints, config);

    %% 7. 调用 MOSEK 求解本轮 P3
    SolverResult = solve_convex_subproblem( ...
        objective, LinearConstraints, VariableBounds, ...
        ConicConstraints, config, objective_offset);
    if ~SolverResult.success
        % 没有可用解，后面的取解和各项检查都不做；系数扫描结果照样留下
        CurrentSolution = [];
        SubproblemDiag = build_failed_subproblem_diag( ...
            SolverResult, CoefficientReport, num_variables, iter);
        return;
    end

    %% 8. 提取 P3 的解
    CurrentSolution = extract_subproblem_solution( ...
        SolverResult, VariableIndex, CurrentReference, ...
        ConstData, config);

    %% 9. 把目标函数值按项拆开
    % 终端松弛罚项、脉冲、衔接与动力学松弛罚项、控制正则各一项，供全程图画 P3 的目标随迭代的变化
    ObjectiveTerms = compute_objective_terms( ...
        objective, SolverResult.primal, VariableIndex, config, objective_offset);

    %% 10. 步长（相邻解差）：本轮解相对当前参考的相邻解差
    ConvergenceReport = compute_scp_convergence( ...
        CurrentSolution, CurrentReference, config);

    %% 11. P3 解检查：原始矩阵、松弛、锥重构和乘子
    % 各项检查由 check_p3_solution 逐类完成，只用 P3 自己的量；P3 乘子一并报告
    P3Check = check_p3_solution( ...
        SolverResult, LinearConstraints, VariableBounds, ...
        ConicConstraints, CurrentSolution, CurrentReference, config);

    %% 12. P2 可行性检查：动力学违反量、衔接违反量、终端违反量、路径约束、性能指标和终端映射的余项
    % 算罚函数 J 时直接读这份报告，不另写一套求值
    P2Feasibility = check_p2_feasibility(CurrentSolution, ConstData, config);
    % 候选解带着 P3 的终端变量，补上终端映射的余项（积分得到的终端量减 P3 的终端量）
    P2Feasibility.terminal_remainder_report = evaluate_terminal_remainder( ...
        CurrentSolution, ConstData, config);

    %% 13. 控制量报告：u 的紧性、σ 的偏向和 u 列驻点条件的对偶分解（只报告）
    % 正则项系数取自上面装配好的目标向量；输出只读这份报告，不重新求值
    ControlReport = evaluate_control_report( ...
        SolverResult, VariableIndex, objective, LinearConstraints, ...
        ConicConstraints, CurrentReference, config);

    %% 14. 汇总本轮诊断
    SubproblemDiag = build_subproblem_diag( ...
        SolverResult, CoefficientReport, ObjectiveTerms, ...
        ConvergenceReport, P3Check, P2Feasibility, ControlReport, ...
        num_variables, CurrentReference.N, iter);
end


function SubproblemDiag = build_subproblem_diag( ...
        SolverResult, CoefficientReport, ObjectiveTerms, ...
        ConvergenceReport, P3Check, P2Feasibility, ControlReport, ...
        num_variables, num_nodes, iter)
% BUILD_SUBPROBLEM_DIAG 把求解结果、步长检查、P3 解检查、P2 可行性检查和控制量报告填进本轮诊断。

    SubproblemDiag = create_empty_subproblem_diag();
    SubproblemDiag.success = true;
    SubproblemDiag.status = 'solved';
    SubproblemDiag.iter = iter;
    SubproblemDiag.num_variables = num_variables;
    SubproblemDiag.num_nodes = num_nodes;
    SubproblemDiag.solver = SolverResult;
    SubproblemDiag.coefficient_report = CoefficientReport;
    SubproblemDiag.objective_terms = ObjectiveTerms;
    SubproblemDiag.convergence_report = ConvergenceReport;
    SubproblemDiag.p3_check = P3Check;
    SubproblemDiag.p2_feasibility = P2Feasibility;
    SubproblemDiag.control_report = ControlReport;
end


function SubproblemDiag = build_failed_subproblem_diag( ...
        SolverResult, CoefficientReport, num_variables, iter)
% BUILD_FAILED_SUBPROBLEM_DIAG 组装求解失败的统一诊断。

    SubproblemDiag = create_empty_subproblem_diag();
    SubproblemDiag.status = 'solver_failed';
    SubproblemDiag.iter = iter;
    SubproblemDiag.num_variables = num_variables;
    SubproblemDiag.solver = SolverResult;
    SubproblemDiag.coefficient_report = CoefficientReport;
    SubproblemDiag.control_report = create_empty_control_report('solver_failed');
end
