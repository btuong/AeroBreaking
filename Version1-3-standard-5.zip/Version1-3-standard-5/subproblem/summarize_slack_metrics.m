function Report = summarize_slack_metrics(Metrics)
% SUMMARIZE_SLACK_METRICS 汇总活动指标（松弛、残差、余项共用）。

    active = [Metrics.active];
    failed = active & ~[Metrics.satisfied];
    Report.success = ~any(failed);
    Report.evaluated = true;
    Report.metrics = Metrics;
    Report.failed_names = {Metrics(failed).name};

    active_metrics = Metrics(active);
    if isempty(active_metrics)
        Report.max_ratio = 0;
        Report.max_name = '';
    else
        [Report.max_ratio, max_index] = ...
            max([active_metrics.ratio]);
        Report.max_name = active_metrics(max_index).name;
    end
end
