% 第一、二类不紧机理的代表工况诊断：线性正则与 norm_gap 各两档权重。
% 每轮保留主链候选解，再固定同一参考和半径求解无速率约束 P3，不推进该对照解。
% 可选工作区变量: case_filter（工况名元胞数组）、max_iter（默认 10）、
% results_folder（默认 results）、rerun_existing（默认 false）。
% 输出: tightness_diagnosis/<results_folder>/<工况名>.mat 和 汇总.txt。

%% ===== 环境准备 =====
diagnosis_root = fileparts(mfilename('fullpath'));
version_root = fileparts(diagnosis_root);
previous_path = path;
restore_diagnosis_path = onCleanup(@() path(previous_path));
modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
    'trust_region', 'validation', 'iteration', 'output'};
for k = 1:numel(modules)
    addpath(fullfile(version_root, modules{k}));
end
addpath(diagnosis_root);
rehash;

if ~exist('case_filter', 'var')
    case_filter = {};
end
if ~exist('max_iter', 'var')
    max_iter = 10;
end
if ~exist('results_folder', 'var')
    results_folder = 'results';
end
if ~exist('rerun_existing', 'var')
    rerun_existing = false;
end

%% ===== 代表工况 =====
case_list = cell(1, 8);
case_types = {'sum', 'u1', 'u2', 'norm_gap'};
count = 0;
for t = 1:numel(case_types)
    for w = [1e-3, 1e-4]
        count = count + 1;
        case_list{count} = struct('name', sprintf('%s_w%.0e', case_types{t}, w), ...
            'type', case_types{t}, 'w', w);
    end
end
Cases = [case_list{:}];
if ~isempty(case_filter)
    Cases = Cases(ismember({Cases.name}, case_filter));
end
results_root = fullfile(diagnosis_root, results_folder);
if ~isfolder(results_root)
    mkdir(results_root);
end

%% ===== 逐工况固定参考对照 =====
summary_list = cell(numel(Cases), 1);
for c = 1:numel(Cases)
    Case = Cases(c);
    result_path = fullfile(results_root, [Case.name '.mat']);
    if isfile(result_path) && ~rerun_existing
        loaded = load(result_path, 'Diagnosis');
        Diagnosis = loaded.Diagnosis;
        fprintf('[CASE] %s skipped（已有结果）\n', Case.name);
    else
        fprintf('[CASE] %s start\n', Case.name);
        try
            config = scp_config_default();
            config.iter.max_scp_iter = max_iter;
            config.iter.tolerance = 0;
            config.objective.control_reg_type = Case.type;
            config.objective.weight_control_reg = Case.w;
            config.plot.enable_initial = false;
            config.plot.enable_iteration = false;
            config.plot.enable_final = false;
            config.output.print_pre_iteration = false;
            config.output.print_iteration = false;
            config.output.print_summary = false;
            save_fields = fieldnames(config.output.save);
            for k = 1:numel(save_fields)
                if ~ismember(save_fields{k}, {'directory', 'filename_prefix'})
                    config.output.save.(save_fields{k}) = false;
                end
            end
            Diagnosis = run_tightness_diagnosis_case(config);
            save(result_path, 'Diagnosis');
            fprintf('[CASE] %s done（%d 轮）\n', Case.name, numel(Diagnosis.rounds));
        catch exception
            Diagnosis = struct('case_name', Case.name, 'reg_type', Case.type, ...
                'w_reg', Case.w, 'rounds', [], 'message', exception.message);
            fprintf('[CASE] %s failed: %s\n', Case.name, exception.message);
        end
    end
    summary_list{c} = build_case_summary(Diagnosis);
end
Summary = vertcat(summary_list{:});

%% ===== 保存汇总 =====
summary_path = fullfile(results_root, '汇总.mat');
save(summary_path, 'Summary');
text_path = fullfile(results_root, '汇总.txt');
write_tightness_diagnosis_summary(text_path, Summary);
fprintf('ALL_DONE（%d 个工况）\n', numel(Cases));
