function SolverFeasibilityReport = evaluate_solver_feasibility( ...
        SolverResult, LinearConstraints, VariableBounds, config)
% EVALUATE_SOLVER_FEASIBILITY 用送入 MOSEK 的原始矩阵重算返回解的约束残差，并统计解的量级。
%
% 残差对等式行和不等式行统一定义为
%   v_i = max(lower_i − A_i·x, A_i·x − upper_i, 0)
% 按 row_groups 分块取最大值；变量边界按同式对 x 计算。另给相对残差
%   v_i / (1 + max(|有限界值|, max_j |a_ij·x_j|))
% 分母是该行参与相消的最大量级：相对值远大于求解器精度时，说明返回解
% 没有满足送进去的方程（例如小系数贡献被丢掉），而不是 P3 本身的问题。
% 二阶锥的可行性残差已由 evaluate_conic_reformulation_consistency 给出，这里不重复。
%
% 解的量级：原始解 ‖x‖∞ 由返回解计算；对偶解 ‖·‖∞ 取自 MOSEK 返回的乘子
% （SolverResult.mosek_report.dual_norm_inf），缺失时该项记为未评价。
% 全部量为装配坐标（归一化单位）。本检查只报告，不作接受门槛，不修改解。
%
% 另存 A 的逐行相对残差 SolverFeasibilityReport.linear_rows（relative、
% block、block_names），供逐轮数值健康图使用。

    if ~SolverResult.success
        error('SCP:UnavailableSolverPrimal', ...
            '求解失败时不能重算原始矩阵残差。');
    end
    numerics_config = config.solver.numerics;
    primal = SolverResult.primal(:);

    % 线性约束：逐块统计残差
    [row_residual, row_relative] = compute_row_residuals( ...
        LinearConstraints, primal);
    group_names = fieldnames(LinearConstraints.row_groups);
    Metrics = cell(numel(group_names) + 3, 1);
    for g = 1:numel(group_names)
        rows = LinearConstraints.row_groups.(group_names{g});
        Metrics{g} = build_residual_metric(['A.' group_names{g}], ...
            row_residual(rows), row_relative(rows), ...
            numerics_config.max_constraint_residual);
    end

    % 变量边界
    [bound_residual, bound_relative] = compute_bound_residuals( ...
        VariableBounds, primal);
    Metrics{numel(group_names) + 1} = build_residual_metric('x_bounds', ...
        bound_residual, bound_relative, ...
        numerics_config.max_constraint_residual);

    % 原始解与对偶解的量级
    Metrics{numel(group_names) + 2} = build_norm_metric( ...
        'primal_norm_inf', max(abs(primal)), ...
        numerics_config.max_solution_norm);
    Metrics{numel(group_names) + 3} = build_norm_metric( ...
        'dual_norm_inf', SolverResult.mosek_report.dual_norm_inf, ...
        numerics_config.max_solution_norm);

    SolverFeasibilityReport = summarize_slack_metrics([Metrics{:}]);

    % 逐行相对残差，与系数扫描的逐行跨度按行号一一对应
    SolverFeasibilityReport.linear_rows.relative = row_relative;
    [SolverFeasibilityReport.linear_rows.block, ...
        SolverFeasibilityReport.linear_rows.block_names] = ...
        build_row_block_index(LinearConstraints.row_groups, ...
            size(LinearConstraints.matrix, 1));
end


function [residual, relative] = compute_row_residuals( ...
        LinearConstraints, primal)
% COMPUTE_ROW_RESIDUALS 计算每个线性行的绝对与相对残差。

    matrix = LinearConstraints.matrix;
    lower = LinearConstraints.lower(:);
    upper = LinearConstraints.upper(:);
    row_value = matrix * primal;
    residual = max(max(lower - row_value, row_value - upper), 0);

    % 每行最大单项 |a_ij·x_j|，即该行参与相消的数值量级
    [row, column, value] = find(matrix);
    term_scale = accumarray(row(:), abs(value(:) .* primal(column(:))), ...
        [size(matrix, 1), 1], @max, 0);
    relative = residual ./ (1 + max(term_scale, ...
        max(finite_abs(lower), finite_abs(upper))));
end


function [residual, relative] = compute_bound_residuals( ...
        VariableBounds, primal)
% COMPUTE_BOUND_RESIDUALS 计算每个变量越出上下界的绝对与相对量。

    lower = VariableBounds.lower(:);
    upper = VariableBounds.upper(:);
    residual = max(max(lower - primal, primal - upper), 0);
    relative = residual ./ (1 + max(abs(primal), ...
        max(finite_abs(lower), finite_abs(upper))));
end


function values = finite_abs(values)
% FINITE_ABS 取绝对值，无穷界记为 0（不参与量级）。

    values = abs(values);
    values(~isfinite(values)) = 0;
end


function Metric = build_residual_metric( ...
        name, residual, relative, tolerance)
% BUILD_RESIDUAL_METRIC 由一块行的残差组装指标（取块内最大值）。

    if isempty(residual)
        max_residual = 0;
        worst_row = NaN;
        max_relative = 0;
    else
        [max_residual, worst_row] = max(residual);
        max_relative = max(relative);
    end
    Metric = create_slack_metric(name, max_residual, tolerance, ...
        'normalized');
    Metric.num_rows = numel(residual);
    Metric.worst_row = worst_row;
    Metric.relative_value = max_relative;
end


function Metric = build_norm_metric(name, value, tolerance)
% BUILD_NORM_METRIC 组装解的量级指标；量值缺失时记为未评价而不是 0。

    if isfinite(value)
        Metric = create_slack_metric(name, value, tolerance, 'normalized');
    else
        Metric = create_slack_metric(name, NaN, tolerance, 'normalized');
        Metric.active = false;
        Metric.evaluated = false;
        Metric.reason = 'unavailable';
    end
    Metric.num_rows = NaN;
    Metric.worst_row = NaN;
    Metric.relative_value = NaN;
end
