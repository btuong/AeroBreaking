function [r_out, v_out] = transform_state2rv(x_state)
% TRANSFORM_STATE2RV 将 ECF 球坐标状态转换到 ECF 直角坐标 rv 矢量。
%
% 输入:
%   x_state - 6 元素 [r, V, gamma, phi, psi, theta]
%
% 输出:
%   r_out - 3x1 ECF 位置
%   v_out - 3x1 ECF 相对速度

    r = x_state(1);
    V = x_state(2);
    gamma = x_state(3);
    phi = x_state(4);
    psi = x_state(5);
    theta = x_state(6);

    rx = r * cos(phi) .* cos(theta);
    ry = r .* cos(phi) .* sin(theta);
    rz = r .* sin(phi);

    % 速度按天向/东向/北向分量投影到 ECF
    vx = V .* (cos(phi) .* cos(theta) .* sin(gamma) ...
        - cos(gamma) .* sin(psi) .* sin(theta) ...
        - cos(gamma) .* cos(psi) .* cos(theta) .* sin(phi));
    vy = V .* (cos(gamma) .* cos(theta) .* sin(psi) ...
        + cos(phi) .* sin(gamma) .* sin(theta) ...
        - cos(gamma) .* cos(psi) .* sin(phi) .* sin(theta));
    vz = V .* (sin(gamma) .* sin(phi) ...
        + cos(gamma) .* cos(phi) .* cos(psi));

    r_out = [rx; ry; rz];
    v_out = [vx; vy; vz];
end
