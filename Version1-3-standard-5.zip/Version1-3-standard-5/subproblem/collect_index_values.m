function all_indices = collect_index_values(index_struct)
% COLLECT_INDEX_VALUES 递归收集索引结构体中全部非空数值索引。

    all_indices = [];
    fields = fieldnames(index_struct);
    for f = 1:numel(fields)
        value = index_struct.(fields{f});
        if isstruct(value)
            all_indices = [all_indices; collect_index_values(value)];
        elseif isnumeric(value) && ~isempty(value)
            all_indices = [all_indices; value(:)];
        end
    end
end
