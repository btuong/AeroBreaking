function SaveReport = save_radius_scan(ScanRound, scan, config, version_root, figs)
% SAVE_RADIUS_SCAN 按扫描设置里的保存开关保存一轮参考点的扫描: 表、MAT、图。
%
% 输入:
%   ScanRound    - solve_radius_scan_round 的输出
%   scan         - 扫描设置，读 save_text、save_mat、save_figure
%   config       - 打印扫描表要用的配置（print_radius_scan 的输入）
%   version_root - 版本根目录，results 和 pictures 都在它下面
%   figs         - 这一轮扫描图的句柄，没画图时传空
%
% 写出（NN 为两位轮号），一个开关管一个文件:
%   scan.save_text   results/radius_scan_iterNN.txt  终端的表和结论（print_radius_scan 的输出）
%   scan.save_mat    results/radius_scan_iterNN.mat  顶层 ScanResult = ScanRound 加上 scan
%                                                    设置（不含参考点本身，按轮号从
%                                                    scan_mat 里取）
%   scan.save_figure pictures/<窗口名>.png           每扇窗一张
% 保存失败只记进 SaveReport，不中断。
%
% 输出 SaveReport: files（N x 2 元胞，每行 {文件说明, 路径}，只列写成了的）、success
% （打开了开关的都写成了）、error_message（失败原因）。

    SaveReport.files = cell(0, 2);
    SaveReport.success = false;
    SaveReport.error_message = '';
    stem = sprintf('radius_scan_iter%02d', ScanRound.iter);
    output_directory = fullfile(version_root, 'results');

    try
        if (scan.save_text || scan.save_mat) && ~isfolder(output_directory)
            mkdir(output_directory);
        end
        if scan.save_text
            text_path = fullfile(output_directory, [stem '.txt']);
            scan_text = evalc('print_radius_scan(ScanRound, config)');
            write_text_file(text_path, scan_text);
            SaveReport.files(end + 1, :) = {'扫描表', text_path};
        end
        if scan.save_mat
            mat_path = fullfile(output_directory, [stem '.mat']);
            ScanResult = ScanRound;
            ScanResult.scan = scan;
            save(mat_path, 'ScanResult', '-v7.3');
            SaveReport.files(end + 1, :) = {'扫描结果 MAT', mat_path};
        end
        if scan.save_figure
            for k = 1:numel(figs)
                figure_path = fullfile(version_root, 'pictures', ...
                    [figs(k).Name '.png']);
                save_plot_figure(figs(k), figure_path);
                SaveReport.files(end + 1, :) = {'扫描图', figure_path};
            end
        end
        SaveReport.success = true;
    catch exception
        SaveReport.error_message = exception.message;
    end
end


function write_text_file(text_path, text)
% WRITE_TEXT_FILE 把文本按 UTF-8 写进文件，同名文件覆盖。

    file_id = fopen(text_path, 'w', 'n', 'UTF-8');
    if file_id < 0
        error('SCP:OpenRadiusScanFileFailed', '无法打开扫描结果文件：%s。', text_path);
    end
    cleanup = onCleanup(@() fclose(file_id));
    fprintf(file_id, '%s', text);
end
