function [ScanInput, scan] = load_radius_scan_input(version_root, scan)
% LOAD_RADIUS_SCAN_INPUT 读 SCP.m 保存的扫描用 MAT，检查要扫的轮号，补上默认设置。
%
% 输入:
%   version_root - 版本根目录，scan.mat_file 相对它
%   scan         - 扫描设置（mat_file、iters、radius_scales、repair_radius_scale 等）
%
% 输出:
%   ScanInput - MAT 里的 ScanInput（config、ConstData、attempts）
%   scan      - 补好默认值的扫描设置:
%                 radius_scales 为空时取 r_max ./ 2.^(0:7)，并按从大到小排；
%                 repair_radius_scale 为空时取 radius_scales 里最小的一个；
%                 iters 为空时取保存的全部轮号，否则去掉重复的轮号，保持给出的顺序
%
% scan.iters 里有不在保存的轮号里的，报错并列出可选的轮号。

    mat_path = fullfile(version_root, scan.mat_file);
    if ~isfile(mat_path)
        error('SCP:RadiusScanMatMissing', ...
            ['找不到扫描用 MAT: %s。请先运行 SCP.m，' ...
            '并保持 config.output.save.scan_mat = true。'], mat_path);
    end
    Loaded = load(mat_path, 'ScanInput');
    if ~isfield(Loaded, 'ScanInput')
        error('SCP:RadiusScanInputMissing', ...
            ['%s 里没有 ScanInput。scan.mat_file 要指向 SCP.m 保存的 ' ...
            '<前缀>_scan.mat。'], mat_path);
    end
    ScanInput = Loaded.ScanInput;

    %% 检查轮号
    saved_iters = [ScanInput.attempts.iter];
    if isempty(saved_iters)
        error('SCP:RadiusScanNoAttempts', '%s 里没有保存任何一轮。', mat_path);
    end
    if isempty(scan.iters)
        scan.iters = saved_iters;
    end
    scan.iters = unique(scan.iters(:)', 'stable');
    missing = scan.iters(~ismember(scan.iters, saved_iters));
    if ~isempty(missing)
        error('SCP:RadiusScanIterOutOfRange', ...
            'scan.iters 里的 %s 不在保存的轮号里，可选: %s。', ...
            strjoin(arrayfun(@num2str, missing, 'UniformOutput', false), ', '), ...
            strjoin(arrayfun(@num2str, saved_iters, 'UniformOutput', false), ', '));
    end

    %% 默认半径
    if isempty(scan.radius_scales)
        scan.radius_scales = ScanInput.config.trust_region.max_scale ...
            ./ 2.^(0:7);
    end
    scan.radius_scales = sort(scan.radius_scales(:)', 'descend');
    if isempty(scan.repair_radius_scale)
        scan.repair_radius_scale = min(scan.radius_scales);
    end
end
