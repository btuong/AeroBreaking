function draw_history_tiles(fig, iters, status, Tiles, figure_title, config)
% DRAW_HISTORY_TILES 在图窗上画横轴为迭代序号的分块（最终图用）。
%
% 输入:
%   fig          - 目标图窗
%   iters        - 1 x K 迭代序号（可含第 0 次）
%   status       - 1 x K 元胞，各轮 'accepted' / 'rejected' / 'failed' / 'initial'
%   Tiles        - build_plot_tile 输出的结构体数组，曲线横轴为 iters
%   figure_title - 整扇窗的总标题
%   config       - 读取 config.plot.font_size
%
% 标记约定：接受实心，拒绝空心，初始参考（第 0 次）空心方块；失败轮曲线断开，在
% 纵轴下沿画红叉。标记含义写在窗口标题下面一行。
% 区分同一分块里的几条曲线：颜色和标记形状都按曲线顺序轮流取（各分块里同一通道的
% 曲线顺序相同，所以同名同画法）；style 为 'bold' 的曲线（同块里的总量）画粗线，
% 其余画同级线宽，粗线先画、细线后画。图例条目另画（add_legend_entry），图例里同时
% 显示线和标记。
% 对数纵轴的分块下限由数据定（compute_log_display），零值画在下限处并用点线
% 标明；参考线（容差）不再拉大范围: 落在数据范围内才画，范围外的不画，
% 在标题下面写出它的数值。线性纵轴的分块照旧把参考线包进范围。
% 整扇窗只放一个共用图例（finish_tile_window）；参考线一律起名字，图例里不会
% 出现 data1、data2。

    is_accepted = strcmp(status, 'accepted');
    is_rejected = strcmp(status, 'rejected');
    is_initial = strcmp(status, 'initial');

    Palette = build_analysis_palette();
    layout = create_tile_layout(fig, numel(Tiles));
    tile_axes = gobjects(1, numel(Tiles));
    notes = {describe_status_marks(status)};
    for j = 1:numel(Tiles)
        Tile = Tiles(j);
        ax = nexttile(layout);
        tile_axes(j) = ax;
        hold(ax, 'on');
        colors = get(ax, 'ColorOrder');

        if Tile.log_scale
            LogInfo = compute_log_display(Tile.curves);
        else
            LogInfo = [];
        end
        % 每条曲线的颜色、标记和线宽
        num_curves = numel(Tile.curves);
        curve_colors = zeros(num_curves, 3);
        curve_markers = cell(1, num_curves);
        curve_widths = zeros(1, num_curves);
        for c = 1:num_curves
            curve_colors(c, :) = colors(mod(c - 1, size(colors, 1)) + 1, :);
            curve_markers{c} = Palette.marker_cycle{ ...
                mod(c - 1, numel(Palette.marker_cycle)) + 1};
            curve_widths(c) = Palette.width.normal;
            if strcmp(Tile.curves(c).style, 'bold')
                curve_widths(c) = Palette.width.total;
            end
        end
        % 有粗线（总量）的分块里，其余曲线画细线
        if any(curve_widths == Palette.width.total)
            curve_widths(curve_widths ~= Palette.width.total) = Palette.width.part;
        end
        % 图例条目按曲线顺序先画
        for c = 1:num_curves
            add_legend_entry(ax, Tile.curves(c).label, curve_colors(c, :), '-', ...
                curve_widths(c), curve_markers{c}, true);
        end

        % 粗线先画，细线后画（sort 对相同线宽保持原顺序）
        [~, draw_order] = sort(-curve_widths);
        for c = draw_order
            Curve = Tile.curves(c);
            color = curve_colors(c, :);
            marker = curve_markers{c};
            y = Curve.y;
            if ~isempty(LogInfo)
                y = abs(y);
                y(y < LogInfo.floor_value) = LogInfo.floor_value;   % NaN 不受影响
            end
            plot(ax, Curve.x, y, '-', 'Color', color, ...
                'LineWidth', curve_widths(c), 'HandleVisibility', 'off');
            plot(ax, Curve.x(is_accepted), y(is_accepted), marker, ...
                'LineStyle', 'none', 'Color', color, 'MarkerFaceColor', color, ...
                'MarkerSize', 7, 'HandleVisibility', 'off');
            plot(ax, Curve.x(is_rejected), y(is_rejected), marker, ...
                'LineStyle', 'none', 'Color', color, 'MarkerFaceColor', 'none', ...
                'MarkerSize', 7, 'LineWidth', 1.2, 'HandleVisibility', 'off');
            plot(ax, Curve.x(is_initial), y(is_initial), 's', ...
                'LineStyle', 'none', 'Color', color, 'MarkerFaceColor', 'none', ...
                'MarkerSize', 9, 'LineWidth', 1.5, 'HandleVisibility', 'off');
        end

        if Tile.log_scale
            set(ax, 'YScale', 'log');
            ylim(ax, [LogInfo.floor_value / 3, LogInfo.top_value * 3]);
            if LogInfo.has_clamped
                yline(ax, LogInfo.floor_value, ':', 'Color', [0.5, 0.5, 0.5], ...
                    'LineWidth', 1.2, 'HandleVisibility', 'off');
                notes{end + 1} = '点线：0 值画在下限'; %#ok<AGROW>
            end
            notes{end + 1} = draw_log_reference(ax, Tile, LogInfo); %#ok<AGROW>
        else
            if isfinite(Tile.reference)
                yline(ax, Tile.reference, '--k', 'LineWidth', 1.2, ...
                    'DisplayName', Tile.reference_label);
            end
            fit_axis_limits(ax, Tile.reference);
        end

        % 失败轮画在当前纵轴下沿，纵轴范围先固定住再画
        mark_failed_rounds(ax, iters, status);
        finish_history_axes(ax, iters, Tile.y_label, config);
    end
    finish_tile_window(layout, tile_axes, figure_title, notes, config);
end


function note = draw_log_reference(ax, Tile, LogInfo)
% DRAW_LOG_REFERENCE 对数纵轴上的参考线: 落在数据范围内才画；范围外的不画，返回一句说明（写在标题下面）。
%
% 画出来或没有参考线时 note 为空字符串。

    note = '';
    if ~isfinite(Tile.reference) || Tile.reference <= 0
        return;
    end
    if Tile.reference >= LogInfo.floor_value && Tile.reference <= LogInfo.top_value
        yline(ax, Tile.reference, '--k', 'LineWidth', 1.2, ...
            'DisplayName', Tile.reference_label);
    else
        note = sprintf('%s %.1e 在范围外，未画', Tile.reference_label, ...
            Tile.reference);
    end
end
