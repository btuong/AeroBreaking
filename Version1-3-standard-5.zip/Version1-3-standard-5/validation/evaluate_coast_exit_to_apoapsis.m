function x_ff_x_i = evaluate_coast_exit_to_apoapsis(x_c5N, ConstData)
% EVALUATE_COAST_EXIT_TO_APOAPSIS 真空映射：末圈大气出口积分到最终远地点。
%
% 输入:
%   x_c5N - 1x6 末圈大气出口状态 [R_atm, V, gamma, phi, psi, 0]
%
% 输出:
%   x_ff_x_i - 1x6 [终态 ECF 球坐标 5 分量, 终态轨道倾角]
%
% 时间链口径：ECF 转换取 gast=0（z 轴旋转对称下与真实转角等价）。

    mu = ConstData.mu;
    we = ConstData.we;
    RM = ConstData.RM;
    TU = ConstData.TU;
    J2 = ConstData.J2;

    [r0, v0] = transform_state2rv(x_c5N);
    [r0, v0] = transform_ecf2eci(0, we, r0, v0);

    opts = odeset('Events', @event_apoapsis, 'RelTol', 1e-12, ...
        'AbsTol', 1e-12);
    [~, rv_trans_out] = ode45( ...
        @(t, x) evaluate_vacuum_dynamics(mu, J2, RM, x), ...
        [0, 3000000 / TU], [r0, v0], opts);
    [r_ra, v_ra] = transform_eci2ecf(0, we, ...
        rv_trans_out(end, 1:3)', rv_trans_out(end, 4:6)');
    x_ra = transform_rv2state(r_ra, v_ra);
    x_ra = x_ra(1:5);

    ele = transform_rv2elements(rv_trans_out(end, 1:3)', ...
        rv_trans_out(end, 4:6)', mu);
    i_ra = ele(3);

    x_ff_x_i = [x_ra, i_ra];
end
