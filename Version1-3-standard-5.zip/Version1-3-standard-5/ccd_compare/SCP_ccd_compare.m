% CCD（凹凸分解）与控制正则对比实验入口（阶段5-1）：同一套 SCP 设置下，把单位范数约束的
% 处理方式在 regularized（norm、norm_gap、none）与 ccd（多档罚权 p）之间切换，各跑一次
% （共 12 个工况），每个工况迭代到总脉冲进入平台或达到上限，再调用 analyze_ccd_compare 汇总作图。
%
% 本实验的“收敛”只按总脉冲平台判据（最近 W 个被接受轮的总脉冲极差 ≤ δ 且这些轮对 P2 可行，
% 默认 W = 5、δ = 0.1 m/s）；步长停止用 config.iter.tolerance = 0 关掉，不追求驻点收敛。
%
% 可选的工作区变量（运行前设置，没设就取默认）:
%   rerun_existing    - 默认 false；工况目录里已有 case_metrics.mat 时跳过，便于中断后续跑
%   case_filter       - 工况名的元胞数组，如 {'ccd_p1e2'}；空则全跑
%   max_iter          - 迭代上限，默认 50
%   plateau_window    - 平台判据的窗口长度 W（被接受轮数），默认 5
%   plateau_tolerance - 平台判据的总脉冲极差上限 δ (m/s)，默认 0.1
%   results_folder    - 结果文件夹名（在 ccd_compare 下），默认 'results'
%   run_analysis      - 结束后是否调用分析函数，默认 true（分析函数不存在时跳过）
%   p_exponents       - ccd 罚权档位 e（p = 10^e）的向量；空则用 list_compare_cases 的默认档位
% 输出: ccd_compare/<results_folder>/<工况名>/ 下各工况的结果文件和 case_metrics.mat；
%       全部结束后由分析函数写 results/对比汇总.txt、对比汇总.mat 和 pictures/ 下的图。
% 日志行: [CASE] <工况名> start/done/failed/skipped，全部结束打印 ALL_DONE。

%% ===== 环境准备 =====
% 本入口不清空工作区（case_filter 等变量要保留）；路径在脚本结束时恢复
tic;
compare_root = fileparts(mfilename('fullpath'));
version_root = fileparts(compare_root);
previous_path = path;
restore_compare_path = onCleanup(@() path(previous_path));
modules = {'setup', 'dynamics', 'constraints', 'subproblem', ...
    'trust_region', 'validation', 'iteration', 'output'};
for k = 1:numel(modules)
    addpath(fullfile(version_root, modules{k}));
end
addpath(compare_root);
rehash;   % 重新扫描路径，让新增或替换的 .m 文件立即可见

if ~exist('rerun_existing', 'var')
    rerun_existing = false;
end
if ~exist('case_filter', 'var')
    case_filter = {};
end
if ~exist('max_iter', 'var')
    max_iter = 50;
end
if ~exist('plateau_window', 'var')
    plateau_window = 5;
end
if ~exist('plateau_tolerance', 'var')
    plateau_tolerance = 0.1;
end
if ~exist('results_folder', 'var')
    results_folder = 'results';
end
if ~exist('run_analysis', 'var')
    run_analysis = true;
end
if ~exist('p_exponents', 'var')
    p_exponents = [];
end

%% ===== 平台判据与工况表 =====
plateau.window = plateau_window;        % 取最近几个被接受轮
plateau.tolerance = plateau_tolerance;  % 总脉冲极差上限 δ (m/s)

Cases = list_compare_cases(p_exponents);
if ~isempty(case_filter)
    Cases = Cases(ismember({Cases.name}, case_filter));
end
results_root = fullfile(compare_root, results_folder);
fprintf(['版本目录: %s\n工况数: %d，迭代上限: %d，平台判据: 最近 %d 个被接受轮极差 ≤ %g m/s，' ...
    '结果目录: %s\n'], version_root, numel(Cases), max_iter, plateau.window, ...
    plateau.tolerance, results_root);

%% ===== 逐个运行工况 =====
for c = 1:numel(Cases)
    Case = Cases(c);
    case_directory = fullfile(results_root, Case.name);
    metrics_path = fullfile(case_directory, 'case_metrics.mat');
    if isfile(metrics_path) && ~rerun_existing
        fprintf('[CASE] %s skipped (已有 case_metrics.mat)\n', Case.name);
        continue;
    end

    fprintf('[CASE] %s start\n', Case.name);
    case_timer = tic;
    try
        % 其余配置取 scp_config_default，信赖域保持默认 'fixed'、r = 1，与阶段3-1 相同
        config = scp_config_default();
        config.iter.max_scp_iter = max_iter;
        config.iter.tolerance = 0;   % 关掉步长停止：步长判据 max_value < 0 恒不成立
        config.plot.enable_initial = false;
        config.plot.enable_iteration = false;
        config.plot.enable_final = false;
        config.output.print_pre_iteration = false;
        config.output.print_iteration = false;
        config.output.print_summary = false;
        config.output.save.brief_text = true;
        config.output.save.detail_text = true;
        config.output.save.control_text = true;
        config.output.save.control_mat = true;
        config.output.save.scan_mat = false;
        config.output.save.full_mat = false;
        config.output.save.directory = ['ccd_compare/' results_folder '/' Case.name];
        % 单位范数约束的处理方式按工况设置: regularized 的 none/norm/norm_gap 和 ccd 的罚权 p
        switch Case.type
            case 'none'
                config.objective.control_reg_type = 'none';
                config.objective.weight_control_reg = 0;
            case 'norm'
                config.objective.control_reg_type = 'norm';
                config.objective.weight_control_reg = Case.w;
            case 'norm_gap'
                config.objective.control_reg_type = 'norm_gap';
                config.objective.weight_control_reg = Case.w;
            case 'ccd'
                config.unit_norm.mode = 'ccd';
                config.unit_norm.ccd_penalty_weight = Case.p;
                config.unit_norm.ccd_slack_max = 1;
                config.unit_norm.ccd_keep_control_bounds = Case.keep_control_bounds;
            otherwise
                error('CCDCompare:UnknownCaseType', ...
                    '未知工况类型 %s（工况 %s）。', Case.type, Case.name);
        end

        [Result, ~, SaveReport, RunInfo] = run_compare_case(config, plateau);
        elapsed_seconds = toc(case_timer);

        if ~SaveReport.success
            error('CCDCompare:SaveFailed', '工况 %s 的结果文件没有写成。', Case.name);
        end
        Metrics = extract_compare_metrics(Result, RunInfo, Case.name, Case, ...
            elapsed_seconds);
        save(metrics_path, 'Metrics');
        error_path = fullfile(case_directory, 'case_error.txt');
        if isfile(error_path)
            delete(error_path);   % 重跑成功后去掉上次失败的记录
        end
        final_impulse = NaN;
        if ~isnan(Metrics.final_index)
            final_impulse = Metrics.total_impulse_m_s(Metrics.final_index);
        end
        fprintf(['[CASE] %s done %.1f s, stop=%s, 末轮=%d, 平台起始轮=%g, ' ...
            '总脉冲=%.10f m/s\n'], Case.name, elapsed_seconds, Metrics.stop_reason, ...
            Metrics.final_index, Metrics.plateau_start_iter, final_impulse);
    catch exception
        elapsed_seconds = toc(case_timer);
        if ~isfolder(case_directory)
            mkdir(case_directory);
        end
        error_id = fopen(fullfile(case_directory, 'case_error.txt'), 'w', 'n', 'UTF-8');
        fprintf(error_id, 'identifier: %s\nmessage: %s\n', ...
            exception.identifier, exception.message);
        for s = 1:numel(exception.stack)
            fprintf(error_id, 'at %s (line %d)\n', ...
                exception.stack(s).name, exception.stack(s).line);
        end
        fclose(error_id);
        fprintf('[CASE] %s failed %.1f s\n', Case.name, elapsed_seconds);
        fprintf('[CASE] %s ERROR: %s (%s)\n', Case.name, exception.message, ...
            exception.identifier);
    end
end
fprintf('ALL_DONE (%.1f s)\n', toc);

%% ===== 汇总分析 =====
if run_analysis && exist('analyze_ccd_compare', 'file') == 2
    analyze_ccd_compare();
end
