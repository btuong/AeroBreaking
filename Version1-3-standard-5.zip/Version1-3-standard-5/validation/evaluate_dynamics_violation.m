function DynamicsReport = evaluate_dynamics_violation(Solution, ConstData, config)
% EVALUATE_DYNAMICS_VIOLATION 用原非线性动力学计算每个区间的梯形动力学违反量。
%
% 数学形式:
%   g_dyn,i = x_(i+1) - x_i - (Δτ_i/2)·t_f,c·[f(x_i,u_i)+f(x_(i+1),u_(i+1))],
%   i 为第 c 圈内部区间。x、u 取 Solution 的节点值，t_f,c 以 TU 计，
%   g_dyn,i 的五列为 [r,V,γ,φ,ψ]，单位分别为 LU、VU、rad。
%
% 代码形式:
%   values 按圈、区间顺序保存带符号违反量；interval_cir/node 保存其位置。
%   各通道 max_value 和 tolerance 使用 km、m/s、deg；sum_abs 是全部区间、
%   全部通道 |g_dyn,i| 的求解坐标总和，只用于和罚函数对照，不用于判定可行。
%
% 本函数依次完成：
%   1. 逐区间用原非线性动力学算动力学违反量。
%   2. 按通道换成物理单位，取最大值并与容差比较。
%   3. 汇总各通道结果与逐区间违反量。

    %% 1. 逐区间用原非线性动力学算动力学违反量
    interval_count = Solution.N - numel(Solution.PointsBounds);
    values = zeros(interval_count, 5);
    interval_cir = zeros(interval_count, 1);
    interval_node = zeros(interval_count, 1);
    row = 0;
    for cir = 1:numel(Solution.PointsBounds)
        for i = Solution.PointsBounds(cir).begin:(Solution.PointsBounds(cir).end - 1)
            dtau = Solution.tau(i + 1) - Solution.tau(i);
            f_i = evaluate_atmospheric_dynamics(i, Solution.state(i, :)', ...
                Solution.control.u1(i), Solution.control.u2(i), ConstData);
            f_i1 = evaluate_atmospheric_dynamics(i + 1, Solution.state(i + 1, :)', ...
                Solution.control.u1(i + 1), Solution.control.u2(i + 1), ConstData);
            row = row + 1;
            values(row, :) = Solution.state(i + 1, :) - Solution.state(i, :) ...
                - (dtau / 2) * Solution.t_f(cir) * (f_i(1:5) + f_i1(1:5))';
            interval_cir(row) = cir;
            interval_node(row) = i;
        end
    end

    %% 2. 按通道换成物理单位，取最大值并与容差比较
    channel_names = {'r', 'V', 'gamma', 'phi', 'psi'};
    scales = [ConstData.LU / 1e3, ConstData.VU, 180 / pi, 180 / pi, 180 / pi];
    units = {'km', 'm/s', 'deg', 'deg', 'deg'};
    metric_list = cell(1, numel(channel_names));
    for s = 1:numel(channel_names)
        [max_value, max_row] = max(abs(values(:, s)) * scales(s));
        tolerance = config.validation.dynamics_tolerance.(channel_names{s});
        metric_list{s} = create_violation_metric( ...
            ['dynamics_' channel_names{s}], max_value, tolerance, units{s}, ...
            max_row, values(:, s) * scales(s));
        metric_list{s}.max_cir = interval_cir(max_row);
        metric_list{s}.max_node = interval_node(max_row);
        metric_list{s}.max_point = NaN;
    end

    %% 3. 汇总各通道结果与逐区间违反量
    DynamicsReport = summarize_violation_metrics([metric_list{:}]);
    DynamicsReport.values = values;
    DynamicsReport.interval_values = abs(values);
    DynamicsReport.interval_cir = interval_cir;
    DynamicsReport.interval_node = interval_node;
    DynamicsReport.sum_abs = sum(abs(values), 'all');
    DynamicsReport.scale = scales;
end


function Metric = create_violation_metric(name, max_value, tolerance, unit, index, values)
% CREATE_VIOLATION_METRIC 创建单通道的物理最大值及容差比。

    Metric = struct('name', name, 'value', max_value, 'max_value', max_value, ...
        'tolerance', tolerance, 'unit', unit, 'ratio', max_value / tolerance, ...
        'satisfied', isfinite(max_value) && max_value <= tolerance, ...
        'active', true, 'evaluated', true, 'max_index', index, ...
        'components', values(index));
end


function Report = summarize_violation_metrics(Metrics)
% SUMMARIZE_VIOLATION_METRICS 汇总活动通道，不改变各通道的单位。

    Report.success = all([Metrics.satisfied]);
    Report.evaluated = true;
    Report.metrics = Metrics;
    Report.failed_names = {Metrics(~[Metrics.satisfied]).name};
    [Report.max_ratio, max_index] = max([Metrics.ratio]);
    Report.max_name = Metrics(max_index).name;
end
